# SPEC — PIA-PNFT Modular 1.10.0

## Exploración previa de rutas con IA

Antes de editar el mapa, PIA puede preparar una consulta autónoma con los saberes e indicadores seleccionados, marco curricular, tiempo neto, diagnóstico, contexto, recursos, DUA, Proyecto, evaluación y trayectoria selectiva. Solicita tres o cuatro rutas distintas para una sola proyección que articule lecciones pedagógicas y componente Proyecto, sin crear dos planeamientos.

La respuesta de IA es información no confiable hasta ser validada localmente. Debe usar JSON, conservar la huella de la entrada y referirse solo a identificadores entregados por PIA. El sistema limita extensión y cantidad, sanea texto, descarta saberes o relaciones inexistentes, evita duplicaciones, controla semanas y minutos y mantiene pendientes los datos insuficientes. Si el currículo, el tiempo o el contexto cambian, la respuesta anterior no puede aplicarse.

PIA calcula —sin aceptar porcentajes de la IA— cobertura ubicada, contribución prevista del Proyecto, contribución de lecciones pedagógicas, articulación, presencia de evidencia y ocupación temporal. Estos valores describen la estructura del borrador; nunca representan logro, calificación, cumplimiento, profundidad alcanzada, RdA alcanzado o calidad pedagógica. Proyecto y lecciones pueden superponerse, por lo que sus porcentajes no tienen que sumar 100 %.

La trayectoria se expresa como ANTES–AHORA–DESPUÉS. ANTES solo informa posibles condiciones de entrada para explorar; AHORA conserva el currículo obligatorio del nivel; DESPUÉS orienta continuidad y no autoriza anticipar el currículo siguiente. Un saber sin antecedente explícito inicia en el nivel actual y no recibe una base inventada.

Cada ruta propone varias posibilidades de producto coherentes con indicadores, recursos y tiempo; no impone programación ni un tema. La distribución semanal evita contar dos veces actividades integradas y reserva espacio para diagnóstico, evaluación, realimentación, interrupciones y cierre. Al elegir una alternativa, PIA la aplica como borrador reversible al mapa y calendario; no confirma la ruta ni modifica textos oficiales o semanas del planeamiento.

## Lienzo interactivo y propuesta inicial de organización

El mapa curricular funciona como un lienzo navegable. La persona usuaria puede arrastrar el espacio vacío para desplazarse, ajustar todo el mapa a la ventana, volver a 100 %, centrarlo y mover bloques para mejorar su lectura. La distribución visual, el zoom y el punto de vista se conservan como presentación; nunca cambian textos oficiales, ubicación curricular, semanas, fases o evidencias.

PIA puede construir un **borrador sugerido** de agrupaciones y vínculos usando únicamente los saberes e indicadores seleccionados, las vinculaciones oficiales ya confirmadas para fases del Proyecto y el catálogo interno de relaciones revisadas. La propuesta inicial es explicable, reversible y permanece sin confirmar. No decide productos, evidencias ni semanas; una coincidencia léxica, el color o la misma área no certifican una integración pedagógica.

Los saberes procedimentales, actitudinales y ejes se muestran como una banda que atraviesa la ruta, con la aclaración de que se movilizan según cada experiencia y no necesariamente todos en cada semana. Competencias y perfil orientan el proceso; el RdA permanece como destino orientador del ciclo y no como logro semanal o certificación automática.

En computadora el panel aprovecha casi todo el ancho disponible. En tableta y celular el modal ocupa la pantalla, mantiene un viewport del mapa independiente, controles horizontales, desplazamiento por arrastre y la alternativa tabular completa.

## Calendario visual de la ruta 1.9.2

El constructor de la ruta curricular de III Ciclo incorpora una línea temporal derivada del mismo estado del mapa. Sus columnas representan las semanas declaradas y sus filas distinguen diagnóstico, mediación curricular, Proyecto con Pensamiento de Diseño, trabajo cotidiano y tareas o calendario. Las capas simultáneas no se suman: una semana integrada continúa siendo una sola semana disponible.

La visualización no distribuye currículo ni escribe el planeamiento semanal. Solo coloca rangos aportados en las asignaciones del mapa y decisiones evaluativas confirmadas con un perfil vigente. La duración estimada del Proyecto no permite inferir su inicio o final; el texto libre de excepciones institucionales tampoco se convierte en una fecha o conflicto. Toda información insuficiente se conserva en una lista visible de decisiones no ubicadas.

El calendario puede mostrar el borrador para facilitar su revisión antes de confirmar la ruta, pero debe rotular ese estado. Un diagnóstico requiere activación expresa y tiempo declarado. Las ventanas evaluativas obsoletas, sugeridas, descartadas o asociadas con un perfil sin confirmar no se ubican como decisiones vigentes.

La vista gráfica ofrece desplazamiento horizontal controlado en pantallas pequeñas y una tabla semántica equivalente. El color es complementario a los rótulos. El calendario no certifica viabilidad temporal o pedagógica, no declara indicadores o RdA alcanzados y no forma parte del Word o PDF oficial del planeamiento.

## Organización guiada, productos y relaciones entre saberes

La decisión principal consiste en ubicar cada saber en **Lecciones pedagógicas**, **Componente Proyecto**, **Lecciones y Proyecto** o mantenerlo **Pendiente de ubicar**. Estas son ubicaciones de trabajo dentro de una única ruta y no categorías curriculares oficiales. La persona docente puede agrupar saberes y estimar semanas; PIA genera el mapa y el calendario sin exigir que dibuje nodos manualmente.

El inspector puede representar de manera opcional cinco relaciones en lenguaje común: un saber ayuda a preparar otro, apoya su desarrollo, se observa en evidencias relacionadas, lo continúa o profundiza, o necesita una base del otro. No se exige una justificación escrita; el campo de contexto se reserva para recursos, simulación, calendario u otra condición que PIA no pueda conocer. PIA conserva ambos indicadores y revisa disponibilidad, evidencia y secuencia temporal sin certificar pertinencia.

Para orientar a una persona nueva, “Posibles relaciones para explorar” combina un catálogo curado de relaciones previamente revisadas con señales literales de los indicadores: términos compartidos, área, módulo y verbo inicial. El sistema no aplica equivalencias curriculares inferidas. Azul petróleo identifica una relación previamente revisada; turquesa, términos y área; azul, términos; ámbar, área o verbo; gris, ausencia de señal textual evidente. El texto acompaña siempre al color. Seleccionar una tarjeta completa el destino y el tipo descriptivo sugerido, pero nunca crea ni valida la conexión.

Cuando la trayectoria no contiene un antecedente explícito, el inspector muestra “Este saber inicia en el nivel actual” y orienta a explorar condiciones de entrada, sin inventar un previo. Para el Proyecto, PIA ofrece formatos físicos, simulados, programados, multimedia, documentales o de baja tecnología como posibilidades editables. El formato nunca sustituye el verbo y la profundidad del indicador; “Producto por definir durante las etapas iniciales” es una decisión válida.

## Responsividad 1.9.2

- Escritorio conserva el mapa amplio, el inspector y el calendario.
- Tableta reorganiza controles e inspector, mantiene desplazamiento controlado del mapa y reduce las celdas del calendario.
- Celular transforma la tabla de saberes en tarjetas verticales, apila acciones críticas, conserva la tabla accesible del calendario y permite desplazamiento del mapa sin ocultar controles.
- Ninguna operación esencial depende de color, arrastre, ratón o pantalla amplia.

## Grafo conceptual trazable 1.9.1

- La vista principal del organizador de III Ciclo es un grafo semántico con nodos HTML accesibles y conexiones SVG curvas. Debe mostrar en una sola ruta diagnóstico, decisiones de entrada, Proyecto/APD, mediación curricular, evaluación, capas transversales y norte curricular.
- Empatizar, Definir e Idear muestran los tres indicadores oficiales protegidos del componente Proyecto. Prototipar y Probar/Evaluar permanecen sin indicadores inventados y reciben únicamente indicadores oficiales del módulo vinculados expresamente.
- El panel de entrada informa qué datos están protegidos, declarados, pendientes u opcionales. La ausencia de un campo opcional no permite completarlo por inferencia.
- El ejemplo visual abre el mismo tipo de mapa en modo de solo lectura y no modifica selección, relaciones, confirmación o guardado.
- El prompt autónomo de análisis incluye tiempo oficial y escenario preventivo separado, currículo literal, RdA, competencias, perfil, descripción del módulo, saberes procedimentales y actitudinales, ejes, diagnóstico, contexto/recursos/DUA, Proyecto, evaluación y relaciones docentes.
- La tabla accesible, el inspector y el grafo continúan representando el mismo estado semántico v6; las coordenadas y el SVG no se guardan.

## Mapa integral de ruta curricular de III Ciclo 1.9.0

1. El mapa representa una sola ruta semestral: diagnóstico y contexto, mediación curricular, componente Proyecto con Pensamiento de Diseño, continuidad y horizonte de RdA. No crea dos planeamientos.
2. Empatizar, Definir e Idear muestran sus indicadores oficiales protegidos. Prototipar y Probar/Evaluar reciben únicamente indicadores oficiales del módulo vinculados por la persona docente; PIA no los inventa.
3. Cada saber conceptual conserva su identidad oficial y puede registrar función, fase, semanas, grupo, evidencia, color visual y nota docente. Estos datos organizan la ruta y no modifican el currículo.
4. Las relaciones entre saberes son decisiones explícitas. PIA no infiere ni certifica que una relación temática, un recurso o un producto constituya integración pedagógica válida.
5. Los 13 saberes procedimentales, los 4 actitudinales y los ejes transversales se muestran como capas. Ocultar una capa no desmarca currículo ni la convierte en una metodología.
6. Competencias y perfil de salida funcionan como norte curricular; el RdA aparece como destino orientador. La planificación muestra contribución prevista y nunca certifica logro, dominio o promoción.
7. La línea de semanas muestra diagnóstico, ventana de Proyecto, saberes ubicados y ventanas evaluativas confirmadas. Una semana integrada se cuenta una sola vez y una evidencia no puede duplicarse entre componentes.
8. La auditoría local identifica pendientes, Proyecto inactivo, fases sin vínculo, semanas invertidas, relaciones incompletas, evidencias repetidas y riesgo temporal. Es orientativa y no sustituye el criterio profesional.
9. El modo guiado y el modo directo editan el mismo estado. Mapa, inspector y tabla accesible usan los mismos datos y funcionan con teclado, toque o ratón sin exigir arrastre.
10. La barra local permite grupos, relaciones, notas, color, deshacer/rehacer, zoom, centrado, PNG e impresión/Guardar como PDF. El mapa permanece fuera del PDF y Word oficial del planeamiento.
11. “Analizar mapa y comparar rutas” genera un prompt local que solicita dos o tres enfoques, auditoría temporal y curricular y decisiones pendientes; PIA no lo envía ni modifica el mapa con la respuesta.
12. El borrador se conserva en JSON/autoguardado/portable. “Guardar ruta y volver a PIA” confirma la decisión; todo cambio posterior exige una nueva revisión. Se mantiene `schemaVersion: 6`.

## Mapa de organización curricular de III Ciclo 1.8.0

1. Secundaria conserva una única proyección del módulo. La persona docente puede organizarla con predominio del Proyecto, alternancia entre Proyecto y otras lecciones pedagógicas, o preparación inicial seguida de articulación.
2. Las opciones organizativas no crean dos currículos, no obligan a convertir todos los saberes en evidencias del Proyecto y no sustituyen la ruta oficial de Pensamiento de Diseño del componente Proyecto.
3. Cada saber seleccionado conserva módulo, área, nombre e indicador literal y recibe una función editable: aplicación directa en el Proyecto, preparación, apoyo o documentación, otras lecciones pedagógicas, continuidad o pendiente.
4. Un saber pendiente nunca se omite ni recibe una función inferida silenciosamente. La IA debe justificar cualquier propuesta y la persona docente conserva la decisión final.
5. El mapa visual y la tabla accesible son representaciones del mismo objeto persistente. Los modos guiado y directo cambian el acompañamiento, no los datos ni el prompt.
6. PIA realiza una auditoría determinista de cobertura estructural, activación del Proyecto y cantidades temporales declaradas. Esta auditoría no certifica pertinencia, profundidad, RdA alcanzado ni viabilidad pedagógica.
7. La segunda metodología completa permanece como decisión excepcional y separada de la organización curricular. Exige fases completas, función, puente, semanas/minutos, evidencias y revisión de duplicaciones.
8. La ruta guardada llega al prompt antes de solicitar la matriz semestral; no escribe semanas, no modifica el currículo oficial y queda fuera de PDF y Word.
9. Los planes 1.7.5 conservan sus valores históricos de coordinación sin conversión silenciosa. Los campos nuevos usan valores seguros dentro de `schemaVersion: 6`.
10. La interfaz funciona localmente, sin red, se adapta a móvil, permite teclado y toque y mantiene una alternativa tabular para lectores de pantalla.

## Alcance diagnóstico y selección manual opcional 1.7.5

1. La selección manual de técnica, instrumento y criterio docente está desactivada por defecto y sus componentes permanecen ocultos.
2. Si la persona docente activa la selección manual, debe completar técnica e instrumento antes de generar el prompt; PIA no combina una selección manual incompleta con una recomendación automática.
3. Sin selección manual, la IA recomienda una sola técnica y un solo instrumento a partir de la actividad, evidencia, áreas de valoración, nivel, tiempo, recursos y DUA, conforme a los referentes del MEP y del PNFT.
4. El diagnóstico explora conocimientos y experiencias previas relacionados con saberes conceptuales, procedimentales y actitudinales del módulo correspondiente.
5. La experiencia puede integrar varios saberes y no debe fragmentarse en una prueba separada por cada uno; tampoco trata los indicadores actuales como requisitos de dominio previo.
6. El tiempo continúa limitado a un periodo no mayor a dos lecciones.

## Procedencia de técnica e instrumento diagnóstico 1.7.4

1. El valor “Solicitar recomendación razonada a la IA” significa que no existe una técnica o instrumento seleccionado ni confirmado por la persona docente.
2. Toda recomendación generada por IA se rotula como pendiente de validación docente y conserva esa procedencia en la interfaz, los prompts y el modelo Word.
3. Pegar, revisar o anexar una respuesta de IA no confirma la técnica ni el instrumento; la confirmación requiere una selección expresa en los campos correspondientes.
4. Cuando la persona docente selecciona una opción, PIA la identifica como decisión docente y solicita a la IA respetarla, sin ocultar posibles limitaciones de congruencia con la evidencia.

## Claridad de articulación y adaptación visual 1.7.3

1. En III Ciclo, la interfaz presenta APD como ruta integrada base: mediación curricular y Proyecto avanzan dentro de una sola proyección, conservando la identidad de indicadores, evidencias y componentes de evaluación.
2. La ventana de énfasis del Proyecto no se interpreta como un periodo añadido a la mediación curricular cuando se utiliza la ruta integrada.
3. Los campos de una segunda metodología completa solo se muestran para las modalidades secuencial completa o coordinada completa; un recurso puntual permanece dentro de la ruta integrada.
4. El diagnóstico conserva “Condiciones de entrada para los saberes actuales” como opción explícita y explica que permite explorar requisitos de inicio sin exigir el indicador final como aprendizaje previo.
5. Los diálogos generales y semanales de prompt limitan su altura al viewport y ofrecen desplazamiento interno para mantener alcanzables todas las acciones.
6. Toda etiqueta visible del presupuesto temporal utiliza “lecciones pedagógicas”; los identificadores internos históricos pueden conservarse por compatibilidad.

## Diagnóstico y factibilidad metodológica 1.7.2

1. El flujo diagnóstico diferencia técnica para obtener evidencia, instrumento para registrarla y función diagnóstica de la evaluación.
2. La persona docente puede seleccionar técnica e instrumento o solicitar a la IA una recomendación justificada; la IA debe devolver el instrumento completo, editable e imprimible, no solo nombrarlo.
3. El modelo Word deja vacíos los hallazgos y resultados hasta la aplicación real y presenta una plantilla coherente con el instrumento elegido.
4. La coordinación metodológica de III Ciclo registra una decisión explícita: ruta única de Pensamiento de Diseño, metodologías completas en secuencia o metodologías completas coordinadas mediante puentes.
5. ABR se entiende como el ciclo completo Comprender–Investigar–Actuar; un reto aislado no constituye la metodología. ABJ tampoco se reduce a incorporar un juego.
6. Si concurren dos metodologías, el prompt exige fases, función, semanas/minutos, puentes, evidencias, riesgo de duplicación y decisión docente pendiente.
7. PIA muestra alertas y audita la propuesta, pero no certifica la viabilidad ni sustituye el criterio docente o asesor.
8. El bloque oficial permanece en 80 minutos. Un valor efectivo menor es un escenario preventivo no oficial y se audita por separado sin reducir automáticamente el currículo.
9. 3.º, Módulo 1, conserva Operadores aritméticos y Operadores relacionales como saberes independientes asociados al indicador oficial integrado.
10. El catálogo curricular contiene 236 saberes–indicadores en 20 combinaciones nivel–módulo.
11. La ruta predeterminada de secundaria conserva Pensamiento de Diseño como metodología común para mediación curricular y Proyecto; una segunda metodología es una decisión explícita, no automática.
12. Para rutas separadas o coordinadas, PIA calcula diagnóstico + segunda metodología + Proyecto y muestra el margen dentro del periodo. Un margen negativo exige ajuste; un margen cero exige revisión temporal.
13. La relación de una segunda metodología se audita mediante saberes, indicadores, RdA, competencias específicas y perfil de salida. PIA no fuerza una integración sin relación pedagógica.

## Revisión para asesoría y seguridad del planeamiento

1. La proyección muestra, según nivel, módulo y áreas seleccionadas, competencia específica, perfil de salida del ciclo y propósito declarado en la descripción oficial del módulo.
2. Esta capa es informativa y trazable a las guías docentes; no altera saberes, indicadores o RdA protegidos y no convierte ejemplos de las guías en actividades obligatorias.
3. El prompt semestral solicita integrar dos o más saberes cuando existe relación pedagógica. Un tratamiento individual sigue permitido cuando la profundidad, seguridad, complejidad, prerrequisito o contexto lo justifican.
4. DUA se aplica al diseño general del aprendizaje. Los datos contextuales y apoyos específicos continúan siendo un registro opcional controlado por la persona docente.
5. El inventario estructurado permite declarar dispositivos, software, materiales, organización, accesibilidad y restricciones sin información personal.
6. La evaluación diagnóstica puede descargar un modelo Word editable que diferencia referentes curriculares, experiencia, áreas cognoscitiva/socioafectiva/psicomotora, instrumento, evidencia, hallazgo y decisión.
7. El modelo Word no es un formato oficial obligatorio y nunca completa resultados no observados.
8. El prompt exige una auditoría de contribución de la ruta: indicador, saberes movilizados, semanas, evidencia prevista, contribución prevista, vacío por revisar y decisión docente.
9. La comprobación local verifica la presencia estructural de esa auditoría, pero no certifica coherencia pedagógica ni logro.
10. Se conserva `schemaVersion: 6`, funcionamiento local, privacidad, compatibilidad histórica, currículo protegido y salidas oficiales vigentes.

## Experiencia formativa y apoyos inclusivos 1.7.1

1. La experiencia **Explorar un ejemplo de planeamiento** permanece dentro de `.container`; al abrirse, solo sus elementos hermanos se vuelven inertes. Nunca se vuelve inerte un ancestro que contenga la propia experiencia.
2. Al cerrarse, PIA restaura el atributo `inert`, `aria-hidden` y el foco exactamente al estado anterior.
3. La contextualización distingue DUA, apoyo de acceso, apoyo curricular no significativo y adecuación significativa o PEI previamente aprobada.
4. La selección de un marco de apoyo no representa aprobación, no modifica automáticamente el currículo y no autoriza a la IA a inferir adecuaciones.
5. PIA conserva únicamente información general del grupo; prohíbe nombres, diagnósticos clínicos, expedientes y datos sensibles del estudiantado.
6. El perfil **III Ciclo y Ciclo Diversificado Vocacional — Plan Nacional** solicita coordinación pedagógica, diagnóstico y criterio declarado para seleccionar y dosificar saberes.
7. La guía vocacional recuerda la disponibilidad de dos lecciones semanales y la prioridad de herramientas de productividad cuando responda a las necesidades identificadas.
8. El catálogo curricular continúa de Preescolar a 9.º. Para 10.º, 11.º y 12.º PIA no inventa saberes ni indicadores y exige fuente oficial vigente y validación correspondiente.
9. Los nuevos campos se conservan en JSON v6 con valores seguros para planes anteriores; no modifican PDF o Word salvo cuando la persona docente los incorpora mediante los prompts.
10. La orientación 2026 del PNFT prevalece como fuente funcional. El video de 2021 y el ejemplo aportado sirven como antecedentes explicativos, no como autorización automática.

## Ruta hacia el RdA 1.7.0

1. La Ruta organiza las 38 familias, cuatro áreas y diez niveles mediante nodos de ciclo, nivel, módulo, área, saber, indicador y RdA.
2. El vínculo estructural se deriva únicamente de la pertenencia oficial al mismo nivel, ciclo y área; no equivale a una contribución pedagógica validada.
3. Una correspondencia pedagógica solo se rotula como validada cuando existe una entrada aprobada, versionada y trazable en el catálogo independiente.
4. Sin una relación aprobada, la interfaz muestra “Correspondencia pedagógica pendiente de validación curricular”. La IA no completa ese vacío.
5. Los RdA y los indicadores se muestran literalmente. PIA no crea facetas, porcentajes, pesos, semáforos, dominio ni estados de RdA alcanzado.
6. Cada familia se organiza por Materno Infantil/Transición, I, II y III Ciclo. Los niveles conservan desarrollo explícito, ausencia de registro, no aplicable y área ausente; presencia o fortalecimiento no evaluable requieren fuente expresa.
7. El nivel elegido se identifica como AHORA y es el único alcance curricular vigente. Los demás niveles son referentes y nunca se incorporan por esta vista al planeamiento.
8. Preescolar utiliza exclusivamente el itinerario activo y no mezcla Básico requerido con Óptimo.
9. La Ruta es efímera y de solo lectura. No modifica estado, semanas, prompts, diagnóstico, Proyecto, autoguardado ni exportaciones.
10. Se conserva `schemaVersion: 6`; los planes 1.6.15 se cargan sin migración destructiva.
11. El cumplimiento del RdA solo puede valorarse con evidencias acumuladas y criterio profesional docente; PIA nunca lo certifica automáticamente.

## Controles de responsabilidad 1.6.15

1. Un perfil compatible mostrado automáticamente es una referencia y no una confirmación docente.
2. El prompt semestral y las ventanas evaluativas requieren confirmación explícita del perfil aplicable.
3. Proyecto solo se habilita cuando el perfil ha sido confirmado y contiene ese componente; ocultarlo no elimina datos guardados.
4. Un semestre ordinario utiliza un módulo. Ambos módulos solo pueden proyectarse tras confirmar que el marco temporal declarado cubre los dos periodos.
5. El presupuesto neto descuenta del total administrativo las lecciones de diagnóstico, las lecciones sin desarrollo curricular y la reserva declarada para aplicación/realimentación.
6. Las excepciones textuales no se convierten automáticamente en cantidades; la persona docente declara la cantidad afectada.
7. La IA debe presentar minutos netos disponibles, minutos asignados y diferencia antes de concluir la viabilidad temporal.
8. Las ventanas evaluativas locales son referencias proporcionales editables, no momentos óptimos calculados desde la estrategia.
9. La revisión local es una comprobación técnica de literalidad, trazabilidad, estructura y datos temporales; no certifica pertinencia, profundidad, integración, calidad evaluativa o aprendizaje.
10. La prueba curricular recorre las 20 combinaciones y los 236 indicadores, y Preescolar utiliza sus catálogos procedimentales y actitudinales propios.
11. Se conserva `schemaVersion: 6`; los nuevos campos cuentan con valores seguros al migrar planes anteriores.

## Experiencia formativa guiada 1.6.14

PIA 1.6.14 añade una capa de acompañamiento opcional desde la portada. Su propósito es mostrar, mediante ejemplos, cómo se relacionan las funciones existentes de PIA hasta concretar y revisar un planeamiento. No constituye un planeamiento obligatorio, no certifica competencia y no sustituye el criterio profesional docente.

### Contratos funcionales

1. El acceso visible se denomina “Explorar un ejemplo de planeamiento”.
2. La experiencia contiene siete momentos navegables: horizonte, punto de partida, ruta curricular, metodología, proyección semestral, semana y revisión.
3. Los números identifican momentos del recorrido y nunca grados escolares, niveles de dominio o pasos obligatorios.
4. Toda presentación distingue referente oficial, ejemplo formativo y decisión docente.
5. Los laboratorios de ABJ, ABR y APD usan explicaciones fundamentadas y situaciones ficticias. Permiten cambiar decisiones y comparar consecuencias sin calificar.
6. Preescolar conserva experiencias lúdicas breves, itinerarios Básico/Óptimo y evaluación diagnóstica/formativa. Primaria se contextualiza por ciclo. III Ciclo incorpora la articulación de currículo y Proyecto.
7. El ejemplo curricular consulta `PNFT_DATA`, `RDA_POR_CICLO`, `PIAPreschoolCurriculum`, `PIACurricularProgression` y `PIAProjectComponentCatalog` en modo de solo lectura. Un vacío no se completa por inferencia.
8. La experiencia no puede leer ni escribir `semanas`, el estado `pia`, prompts, diagnóstico, Proyecto del plan, exportaciones ni archivos JSON.
9. El avance formativo usa exclusivamente la clave local `pia.learning.example.v1`. La marca de exploración describe navegación y no dominio.
10. El recorrido no forma parte de JSON, autoguardado del plan, PDF o Word. La plantilla portable conserva la función, pero elimina el contenido transitorio antes de descargarse.
11. Los eventos internos no activan `markDirty`. Cerrar o reiniciar el recorrido conserva el planeamiento.
12. La interfaz permite elegir tema, regresar, retomar, consultar fuentes, usar teclado o toque, cerrar con `Esc` y reducir movimiento según la preferencia del sistema.
13. Las ayudas explican que generar una proyección o prompt no escribe automáticamente las semanas y que la persona docente revisa toda respuesta externa.
14. Las explicaciones de guardado distinguen autoguardado del navegador, archivo JSON para continuar y PDF/Word para compartir o imprimir.

## Objetivo

Facilitar a la persona docente la construcción, proyección, conservación y exportación de un
planeamiento de Formación Tecnológica, preservando el currículo oficial y su criterio profesional.

## Alcance correctivo y consolidado 1.6.13

PIA 1.6.13 incorpora las conclusiones consolidadas del 11 de setiembre de 2026:

1. **Semántica curricular protegida.** Texto significa desarrollo explícito; vacío significa ausencia
   de abordaje conceptual documentado; `N/A` significa no aplicable. Presencia conceptual o
   fortalecimiento sin evaluación solo se muestran con respaldo curricular expreso.
2. **Mapa curricular completo.** La trayectoria ofrece tarjetas y tabla comparativa, filtros por módulo,
   área y alcance —todos los saberes o solo los incorporados a la proyección—, y conserva ANTES, AHORA
   y DESPUÉS con énfasis en el currículo vigente.
3. **Trazabilidad visible.** El encabezado muestra ciclo, nivel, itinerario cuando corresponde, módulos,
   áreas y metodología. Cada registro muestra guía, nivel, módulo y área; AHORA incluye el RdA.
4. **Identidad PNFT.** Los íconos suministrados se integran como recurso local autónomo, acompañados
   siempre por nombre y color del área.
5. **Trayectoria fuera del prompt.** Los antecedentes, continuidades y familias son consulta interactiva;
   el prompt recibe únicamente el currículo seleccionado del nivel actual y reglas pedagógicas generales.
6. **Diagnóstico realmente opcional.** Inicia con cero lecciones y desactivado. Solo aparece en el prompt
   si la persona activa expresamente su incorporación. Puede reiniciarse sin alterar el resto del plan.
7. **Evaluación sin ambigüedad.** “Durante todo el periodo” no impone frecuencia semanal. “Nota” se
   sustituye por “Observación o decisión docente”, que no corresponde a una calificación.
8. **Tiempo pedagógico.** La auditoría continúa ejecutándose después de que la IA construye la matriz y
   el desarrollo semanal; no concluye sobrecarga por conteo aislado.

Se conserva `schemaVersion: 6`, compatibilidad con planes anteriores, operación local sin red y las
exportaciones validadas.

## Alcance histórico de trayectoria y tiempo 1.6.12

PIA 1.6.12 habilitó la primera lectura local de familias. Sus reglas sobre celdas vacías, alcance de
filtros, diagnóstico e incorporación al prompt quedan sustituidas por el alcance 1.6.13. Conservó una
lectura local, oficial e
informativa de las familias curriculares relacionadas con los saberes seleccionados:

1. **Acceso contextual.** “Explorar trayectoria curricular” aparece debajo de “Ver cobertura de las
   semanas” y requiere al menos un saber conceptual seleccionado.
2. **Tres momentos.** ANTES presenta el referente explícito más cercano como antecedente por explorar;
   AHORA presenta solo el nivel, módulo, saber e indicador seleccionados; DESPUÉS presenta la continuidad
   explícita más cercana sin convertirla en contenido obligatorio del nivel actual.
3. **Estado histórico corregido.** La interpretación inicial de los vacíos como fortalecimiento fue
   retirada en 1.6.13. `N/A` conserva el significado de no aplicable.
4. **Familias completas.** La interfaz consume las 38 familias y cuatro áreas del catálogo derivado de
   `Saberes por Año Escolar julio -2026.xlsx`; el Excel de escalabilidad conserva su papel de ejemplo
   asesor para seis familias y no limita la cobertura general.
5. **Interfaz PNFT.** Los filtros e iconos SVG propios usan azul para Apropiación tecnológica y Digital,
   verde para Ciencia de datos e Inteligencia artificial, turquesa para Computación física y Robótica
   y morado para Programación y Algoritmos.
6. **Solo lectura.** La vista no modifica selección, semanas, indicadores, JSON v6, autoguardado, Proyecto,
   PDF o Word. Tampoco declara enseñanza previa, dominio, aprendizaje alcanzado ni cumplimiento de RdA.
7. **Auditoría temporal de IA.** El prompt ordena revisar la propuesta después de construirla. La IA debe
   contrastar semanas, lecciones, minutos, diagnóstico, periodos no lectivos, integración, profundidad,
   continuidad, práctica, realimentación y evaluación; no puede concluir sobrecarga por un conteo aislado.
8. **Conclusión temporal controlada.** La respuesta usa exactamente una de tres conclusiones: Viabilidad
   temporal confirmada, Revisión temporal sugerida o Requiere ajuste temporal, con fundamento concreto.
9. **Proyecto en español.** Los identificadores internos `initial`, `development` y `final` permanecen
   estables; toda salida docente resuelve el nombre localizado, incluida “Etapa de desarrollo”.

Se conserva `schemaVersion: 6`; no se añade estado persistente ni se modifica el currículo protegido.

## Alcance de experiencia 1.6.11

PIA 1.6.11 conserva íntegramente los contratos de 1.6.10 y mejora el momento en que presenta el
apoyo diagnóstico y la explicación de conceptos técnicos:

1. **Secuencia diagnóstica contextual.** El número de lecciones permanece en el Marco temporal. La
   acción para preparar el diagnóstico se presenta después de seleccionar los saberes y antes de
   Proyecto y evaluación, de modo que disponga de ciclo, nivel, módulo, área y saber conceptual.
2. **Habilitación orientadora.** El botón permanece deshabilitado hasta completar esos referentes y
   seleccionar una o dos lecciones. Este requisito solo gobierna la apertura del apoyo diagnóstico:
   generar la proyección semestral sin diagnóstico continúa permitido para docentes y asesores.
3. **Glosario contextual centralizado.** Las explicaciones distinguen currículo del PNFT, orientación
   pedagógica, normativa aplicable y funciones propias de PIA. Un único catálogo evita definiciones
   contradictorias y permite actualización trazable.
4. **Interacción accesible.** Las ayudas responden a puntero y foco; clic o toque las fija; clic externo,
   otra ayuda o `Esc` las cierra. Solo una puede estar visible, se reposiciona dentro de la pantalla y
   no forma parte de JSON, prompts, PDF, Word ni impresión.

Se conserva `schemaVersion: 6`; esta versión no agrega datos persistentes ni modifica currículo,
prompts, semanas, Proyecto, exportadores o migraciones.

## Alcance integral 1.6.10

PIA 1.6.10 conserva los contratos de 1.6.9 y añade tres capas locales de acompañamiento que no
modifican automáticamente el planeamiento oficial:

1. **Diagnóstico pedagógico persistente.** Ofrece modo asesor —modelo sin resultados inventados— y
   modo docente —resultados generales aportados después de aplicar—. Organiza precisar, diseñar,
   aplicar, registrar, analizar/decidir y comunicar. Las áreas cognoscitiva, socioafectiva y
   psicomotora pueden observarse en una experiencia integrada y no se presentan como etapas consecutivas.
2. **Orientación de momentos evaluativos.** Genera ventanas de referencia por perfil. Cada sugerencia
   puede confirmarse, modificarse o descartarse. Solo las confirmadas pasan a los prompts y ninguna
   asigna contenido, fecha o calificación a una semana.
3. **Revisión local de respuestas de IA.** La persona pega voluntariamente una respuesta y PIA realiza
   comprobaciones deterministas de literalidad, estructura, selección curricular y afirmaciones de logro.
   El reporte orienta, no certifica calidad ni incorpora el texto al plan.

El diagnóstico utiliza antecedentes solo como hipótesis por verificar; los indicadores del nivel actual
siguen siendo el currículo que debe desarrollarse. Los alcances posteriores son una salvaguarda interna y
no se incorporan al semestre. Las reglas de evaluación distinguen trabajo cotidiano continuo, tareas por
necesidad de reforzamiento, prueba de ejecución posterior a la mediación y Proyecto progresivo.

Se conserva `schemaVersion: 6`. Los nuevos campos se migran con valores seguros y atraviesan JSON,
autoguardado y portable. PDF y Word mantienen exclusivamente la plantilla oficial; Proyección,
diagnóstico preparatorio, orientación evaluativa y auditoría de IA no se exportan como secciones nuevas.

## Alcance integral 1.6.9

PIA 1.6.9 conserva íntegramente el planeamiento 1.6.8 y añade una capa formativa independiente y
ajustes operativos de acompañamiento. El juego accesible desde la portada enseña ABJ, ABR y Pensamiento
de Diseño mediante siete misiones: Preescolar, ABJ, ABR, APD, secundaria con una ruta, secundaria con
dos rutas y evaluación diagnóstica/DUA. Sus resultados son formativos y nunca alteran el plan.

La Contextualización y DUA dispone de activación explícita. El apoyo diagnóstico genera un prompt para
precisar aprendizajes, diseñar evidencias e instrumentos, aplicar, sistematizar, analizar, decidir y
comunicar, considerando cuando corresponda dimensiones cognitiva, socioemocional y psicomotriz.

“Otra metodología” incorpora una ficha condicional de fundamentación. “Afinar semana con IA” revisa una
semana ya redactada, conserva currículo y metodología originales y separa cualquier propuesta de cambio.
En secundaria, Pensamiento de Diseño mantiene la ruta del Proyecto; Prototipar y Probar/Evaluar vinculan
indicadores oficiales del módulo. Los textos creados en versiones anteriores se mantienen como históricos.

## Alcance integral 1.6.8

PIA 1.6.8 mantiene el planeamiento validado y añade cuatro capas de acompañamiento sin sustituir la
decisión docente: una portada de entrada, una contextualización estructurada y opcional, referencias
curriculares controladas del PNFT y un ciclo explícito de edición/guardado de prompts. La edición
contextual de 1.6.7 se conserva íntegramente.

### Portada e identidad

- La portada presenta la identidad visual MEP–PNFT–PIA y ofrece **Iniciar planeamiento** y **Cargar
  planeamiento**. Puede omitirse en el dispositivo mediante una preferencia local reversible.
- Regresar a la portada no reinicia el estado. La portada queda excluida de las exportaciones oficiales.
- La identidad institucional opcional contiene únicamente escudo y lema, alineados a la izquierda;
  el centro educativo permanece exclusivamente en el encabezado administrativo oficial.

### Contextualización y DUA

- Los campos abiertos Contexto del grupo, Recursos/conectividad y Consideraciones/apoyos DUA se
  conservan en un panel opcional y plegable.
- Se añade un perfil de implementación: Regular, Aula Edad, Aula integrada de Audición y Lenguaje,
  Aula integrada de Discapacidad Intelectual, III Ciclo y Ciclo Diversificado Vocacional y EPJA
  (CINDEA/IPEC/CAN/CONED).
- Se pueden registrar condiciones complementarias del grupo sin datos personales: apoyos para acceso
  y participación, diversidad en puntos de partida y ritmos, organización multigrado o grupos espejo,
  alta dotación/talentos/creatividad, contexto sociocultural, pueblos originarios y su cosmovisión,
  continuidad educativa ante situaciones de salud, acceso tecnológico limitado y apoyos educativos
  definidos institucionalmente.
- El escenario tecnológico distingue recursos suficientes, conectividad limitada, dispositivos sin
  Internet, equipos compartidos, un equipo demostrativo, ausencia de dispositivos, kits de robótica
  y una descripción abierta.
- El punto de partida grupal puede registrarse como acorde con lo esperado, pendiente de evaluación
  diagnóstica pedagógica, con necesidad de nivelación, con diversos puntos de partida o con necesidad
  de profundización. No constituye diagnóstico clínico, etiqueta individual ni evidencia de dominio.

### Referencias curriculares controladas

- Una persona docente puede incorporar un indicador de otro nivel únicamente desde el catálogo
  autorizado del PNFT, seleccionando nivel, módulo, área, saber e indicador.
- PIA conserva literalmente el texto y su procedencia. Motivo y contextualización docente se guardan
  aparte; la referencia nunca cambia el nivel administrativo ni se rotula como indicador oficial del
  nivel vigente.
- La referencia se incorpora a una semana mediante selección explícita, puede retirarse sin borrar
  su registro y se conserva en JSON, autoguardado, PDF y Word cuando está seleccionada.

### Prompts persistentes

- General, semestral y semanal son documentos independientes con estado visible: pendiente de guardar,
  guardado o actualizado.
- Cerrar el diálogo no descarta la edición. **Guardar cambios del prompt** confirma el texto vigente;
  JSON y autoguardado lo conservan literalmente.
- **Actualizar desde PIA** y **Restablecer propuesta generada** requieren confirmación antes de sustituir
  texto docente. Copiar o abrir ChatGPT/Copilot no equivale a guardar ni transmite datos automáticamente.
- El contrato contextual entrega solo las condiciones seleccionadas, solicita alternativas equivalentes
  sin conexión, distingue currículo vigente/referencia/texto docente y marca toda decisión que requiera
  confirmación institucional.
- Los valores neutrales y campos opcionales vacíos no aparecen en el prompt. La orientación DUA universal
  permanece como contrato pedagógico y no supone que exista una adecuación individual.

## Contratos obligatorios

- Aplicación frontend autónoma; funciona en `file://` sin servidor ni backend.
- Datos `PNFT_DATA`, `RDA_POR_CICLO`, encabezado administrativo e indicadores oficiales protegidos.
- Orden visual: título/subtítulo → identidad opcional → encabezado oficial → ejes → metodología →
  Contextualización y DUA → proyección semestral de referencia → seguridad/recuperación → semanas.
- Identidad opcional: solo escudo PNG/JPEG de hasta 1 MB y lema; el nombre se registra una sola vez
  en Centro educativo.
- Proyección: uno o ambos módulos, áreas, RdA, saberes de los tres tipos, perfil de evaluación y
  entre cero y dos lecciones diagnósticas; no escribe ni distribuye contenido en las semanas.
- IA: PIA genera texto local opcional y no transmite información. La persona docente usa el
  resultado fuera de PIA como referencia y completa manualmente las semanas oficiales.
- Formato enriquecido limitado a mediación e indicadores de evaluación. La barra local se abre al
  seleccionar texto o mediante el control semanal, conserva la selección, identifica el campo activo,
  permanece accesible durante el desplazamiento y mantiene las opciones secundarias plegadas.
- Formato contextual: deshacer/rehacer por campo, negrita, subrayado, listas y limpieza de selección
  permanecen prioritarios. Sangría, alineación, color, tamaño, subtítulos Inicio–Desarrollo–Cierre,
  pegado limpio, vínculo HTTPS y limpieza del campo se agrupan en “Más opciones”.
- Los Indicadores de logro del currículo de FT permanecen protegidos. Los subtítulos rápidos solo se
  insertan en Estrategias de mediación; los vínculos exigen revisión docente y protocolo `https://`.
- Navegación: una semana visible por defecto, selector, anterior/siguiente, estados compactos y
  opción de mostrar todas sin perder contenido.
- Alcance semanal: junto al momento pedagógico, cada semana permite seleccionar Módulo 1, Módulo 2
  o ambos. Las áreas, los RdA y los saberes ofrecidos corresponden al nivel y módulos activos.
- Correspondencia semanal: cada saber nuevo conserva una referencia compuesta de módulo, área y
  nombre; sus indicadores de logro se obtienen de esa referencia exacta y se incorporan automáticamente
  en la columna oficial al marcar el saber.
- Compatibilidad semanal: el filtro no elimina selecciones fuera de su alcance. Los planes anteriores
  sin módulo semanal explícito se abren con ambos módulos disponibles y conservan íntegramente sus datos.
- Interfaz semanal: “Selección curricular de la semana” agrupa áreas, RdA y saberes en un panel
  plegable. Plegarlo cambia únicamente la visualización.
- Cobertura: referencia interna calculada desde los saberes realmente incorporados en las semanas;
  no equivale a aprendizaje alcanzado y no se exporta.
- Persistencia JSON `schemaVersion: 6`, con migración de planes anteriores; autoguardado solo local.
- Persistencia de texto: los prompts general, semestral y de cada semana se conservan en el JSON;
  una edición docente guardada no se sustituye al cerrar, cargar o volver a abrir el generador.
- Actualización del prompt semestral: una nueva generación usa el marco temporal vigente; cuando
  existe un prompt anterior distinto, la persona docente decide si lo actualiza o conserva.
- Composición del prompt semestral: exige metodología activa; omite fechas, ejes, contexto y referencias
  no aportados; conserva fechas parciales sin completarlas; enlaza área, saber, indicador de logro del
  PNFT y RdA; numera consecutivamente solo las reglas aplicables.
- Exportación PDF, Word horizontal, JSON y portable conservadas. PDF y Word excluyen proyección y cobertura.
- Backend/analítica: contrato presente, `local-only`, desactivado y sin APIs de red.
- Centros educativos: catálogo local mínimo, sin registros `0000` ni datos personales. El código
  presupuestario completa automáticamente una coincidencia única y solicita selección cuando es ambiguo.
  No existe carga de Excel en la interfaz; `codSaber` se conserva únicamente como metadato interno.
- Preescolar: el nivel interno `0°` ofrece Básico requerido u Óptimo. Cada opción aplica, por separado,
  los saberes conceptuales e indicadores oficiales de Módulo 1 y Módulo 2, junto con los RdA de la Guía docente.
- Marco de Preescolar: el catálogo aislado conserva también las cuatro competencias específicas y el
  perfil de salida por área. El prompt recibe únicamente los textos de las áreas seleccionadas.
- Trayectoria local: el catálogo y el servicio conservan las 38 familias y el contexto detallado
  ANTES–NIVEL ACTUAL–DESPUÉS para la consulta interactiva mediante tarjetas o tabla. La trayectoria
  no se incorpora al prompt semestral.
- Lectura protegida: una celda vacía se presenta como ausencia de registro curricular para ese nivel;
  no autoriza a inferir refuerzo, enseñanza, evaluación ni dominio. Solo una fuente oficial explícita
  puede identificar continuidad conceptual sin indicador o fortalecimiento no evaluable.
- La consulta no selecciona saberes, no supone aprendizaje previo, no crea indicadores, no modifica
  el orden oficial ni amplía el alcance escogido por la persona docente.
- Contrato de Preescolar: evaluación diagnóstica y formativa sin porcentajes; experiencia semanal con
  propósito, inicio, exploración o juego guiado, aplicación y cierre; bloque de 80 minutos continuo o
  fraccionado en dos lecciones de 40 minutos; integración auténtica sin mínimos numéricos impuestos.
- Separación por perfil: Preescolar, I y II Ciclo no reciben texto, columnas ni reglas de Proyecto. III
  Ciclo informa “Componente Proyecto no seleccionado” cuando está desactivado y presenta su ruta completa
  únicamente cuando se activa.
- El selector de itinerario debe estar oculto y deshabilitado en todo ciclo o nivel distinto de
  Materno Infantil/Transición + `0°`; los estilos no pueden anular el atributo `hidden`.
- Prompt semestral: la metodología seleccionada funciona como andamiaje continuo; sus etapas no se
  reinician semanalmente y cada bloque debe enlazar propósito, mediación, evidencia y continuidad.
- Evaluación: catálogo interno de instrumentos entregado al prompt. La recomendación de uno o varios
  instrumentos ocurre después de definir actividad y evidencia; no registra estudiantes ni notas.
- Proyecto: visible solo con perfiles que incluyan el componente. Conserva catálogo y texto oficial
  versionados, no divide el porcentaje por etapas y no inventa indicadores oficiales para fases sin fuente.
- Prototipar y Probar/Evaluar: la proyección permite activar cada fase y registrar un indicador de logro
  y dos de evaluación editables. Se identifican siempre como texto docente no oficial.
- Proyecto semanal: modalidad curricular (80 min), mixta (40 + 40 min) o integrada (80 min). Los
  indicadores de logro y evaluación se incorporan en las columnas oficiales; la contextualización
  docente se guarda aparte del texto oficial y no puede ser sobrescrita al cargar o cambiar de fase.
- Proyecto no calcula hitos, porcentajes ni estados. El borrado y la restauración oficial requieren confirmación.
- La proyección puede ocultarse o mostrarse para ahorrar espacio; esta acción solo cambia la vista y
  no elimina currículo, Proyecto, prompts ni datos semanales.
- Exportación del Proyecto: una semana mixta o integrada añade el texto efectivo de logro y evaluación
  dentro de las columnas oficiales de PDF y Word. La prioridad es `teacherText` no vacío y luego
  `officialText`; los indicadores de evaluación con `selected: false` no se exportan, pero se conservan.
- Contrato IA: indicadores oficiales literales, saberes procedimentales y actitudinales visibles por
  semana, integración prioritaria o tratamiento individual justificado, y mediaciones suficientemente desarrolladas.
- Progresión curricular: catálogo relacional de solo lectura separado de `PNFT_DATA`. Cada saber
  conceptual vigente se vincula de manera exacta, por área y nombre, con una familia de progresión.
- Semántica de progresión: texto en la celda significa alcance curricular explícito; celda vacía
  significa ausencia de abordaje conceptual documentado; `N/A` significa no aplicable. Fortalecimiento
  o presencia sin indicador requieren respaldo expreso de una fuente curricular.
- Uso de progresión: la trayectoria es una consulta interactiva y no se incorpora automáticamente al
  prompt. No puede inventar currículo, convertir vacíos en refuerzos o evaluaciones, ni declarar dominio,
  aprendizaje alcanzado o cumplimiento de un RdA.
- Prioridad del nivel: la propuesta debe desarrollar íntegramente el currículo del nivel seleccionado.
  Todo antecedente se rotula como expectativa curricular no comprobada y se valida mediante diagnóstico.
- Presentación: los niveles intermedios previos deben aparecer cronológicamente. En 9.º, la ausencia
  de un nivel posterior se explica como límite del catálogo y no como final del aprendizaje.
- Lenguaje docente: la trayectoria se organiza en referente curricular anterior, currículo actual y
  continuidad curricular posterior. Distingue no aplicable y sin registro curricular sin mostrar códigos.
- Selección protegida: AHORA permite consultar el módulo completo o solo los saberes de la proyección;
  la consulta nunca incorpora automáticamente otro saber al prompt o a las semanas.
- Alcance visual: PIA 1.6.13 amplía únicamente la ventana local informativa autorizada. No incorpora
  carga de archivos, persistencia, expedientes, analíticas ni funciones del proyecto independiente PIA 1.7.0.
- Word: Reflexiones Docentes conserva tres áreas blancas de 100 pt y Observaciones una de 145 pt,
  ampliables por contenido y sin transformar el área editable en un bloque morado.

## Criterio de aceptación

`npm test` debe aprobar todas las pruebas de fuente, ensamblado reproducible, alcance autorizado y
funcionamiento. No se fija anticipadamente una cifra hasta cerrar la entrega. La revisión final en
Edge/Chrome debe comprobar portada, inicio/carga, diagnóstico 0–2, perfiles y tecnología, referencia
curricular, persistencia de los tres prompts, formato contextual, popup de exportación, JSON, PDF y Word.
