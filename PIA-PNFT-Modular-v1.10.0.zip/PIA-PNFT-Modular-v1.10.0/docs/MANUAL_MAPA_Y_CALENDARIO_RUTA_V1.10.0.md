# Manual de exploración mapa y calendario de la ruta curricular

## Propósito

Este manual explica el constructor de ruta de PIA 1.10.0 para III Ciclo. Permite a docentes nuevos, docentes con experiencia y personas asesoras preparar una sola proyección que articula lecciones pedagógicas, componente Proyecto con Pensamiento de Diseño, evaluación y tiempo.

PIA organiza referentes y decisiones, solicita alternativas a una IA externa cuando la persona usuaria lo desea y convierte la alternativa elegida en un borrador visual. No certifica pertinencia, viabilidad, aprendizaje, calificación ni RdA alcanzado. La persona docente revisa, modifica, confirma o descarta.

## Dónde se encuentra

Seleccione III Ciclo, nivel, módulo, áreas y saberes. Declare el tiempo y active Proyecto cuando corresponda. Pulse **Organizar ruta y ver mapa**. Dentro del módulo encontrará, en este orden:

1. Revisión de la información de entrada.
2. Exploración previa con IA.
3. Mapa conceptual y calendario.
4. Tabla accesible e inspector.
5. Auditoría posterior del mapa.

## Dos formas de comenzar

| Opción | Cuándo utilizarla | Qué produce |
| --- | --- | --- |
| Explorar rutas con IA | Desea comparar organizaciones, productos, tiempos y riesgos antes de editar. | Tres o cuatro alternativas validadas por PIA. |
| Borrador local rápido | Trabaja sin IA o necesita un punto de partida inmediato. | Agrupaciones y relaciones revisables, sin semanas, producto ni evidencia asignados. |

Ambas opciones generan borradores. Ninguna confirma la ruta.

## Información que prepara PIA

- Nivel, módulo, áreas, saberes e indicadores oficiales seleccionados.
- RdA del ciclo, competencias específicas, perfil de salida y descripción del módulo.
- Saberes procedimentales, actitudinales y ejes transversales.
- Semanas, lecciones pedagógicas, minutos, diagnóstico, reservas e interrupciones.
- Contexto, recursos, inventario y DUA cuando fueron declarados.
- Proyecto, fases de Pensamiento de Diseño e indicadores vinculados.
- Perfil y decisiones evaluativas confirmadas.
- Trayectoria selectiva de 7.º, 8.º y 9.º.

Una ausencia permanece pendiente. PIA no completa contexto, diagnóstico, recursos o decisiones docentes mediante inferencia.

## Explorar rutas con IA paso a paso

1. Revise la entrada y corrija cualquier dato faltante que sí conozca.
2. Pulse **Preparar exploración**.
3. Pulse **Copiar prompt** y péguelo en la herramienta de IA de su preferencia.
4. Solicite que respete la salida JSON indicada por PIA.
5. Copie la respuesta completa y péguela en **Respuesta JSON de la IA**.
6. Pulse **Validar y comparar rutas**.
7. Compare organización, productos, semanas, contribuciones, trayectoria, riesgos y margen temporal.
8. Pulse **Aplicar como borrador al mapa** en una alternativa.
9. Revise y edite mapa, calendario, evidencias y relaciones.
10. Guarde la ruta únicamente cuando represente su decisión profesional.

PIA no envía datos automáticamente. El intercambio se realiza mediante copiar y pegar para conservar funcionamiento local e independencia del proveedor.

## Qué solicita PIA a la IA

PIA solicita tres o cuatro rutas significativamente distintas. Cada ruta debe:

- Conservar todos los textos curriculares sin reescribirlos.
- Utilizar exclusivamente identificadores entregados por PIA.
- Organizar una sola proyección, no dos planeamientos paralelos.
- Proponer agrupaciones auténticas sin forzar una cantidad.
- Indicar semanas y minutos sin contar dos veces experiencias integradas.
- Proponer de dos a cuatro formatos de producto viables.
- Incluir riesgos, supuestos y alternativas ante falta de equipo o interrupciones.
- Relacionar ANTES, AHORA y DESPUÉS sin exigir dominio previo ni adelantar el siguiente nivel.
- Mantener visibles los saberes que no logra ubicar.

## Cómo protege PIA la respuesta

La respuesta de IA se considera una propuesta no confiable hasta ser revisada. PIA:

- Comprueba que la huella corresponda a la selección actual.
- Bloquea una respuesta preparada con otro nivel, tiempo, contexto o currículo.
- Descarta identificadores inventados y autoenlaces.
- Conserva una sola ubicación por saber dentro de cada alternativa.
- Limita cantidades, extensión, semanas y minutos.
- Deja pendiente cualquier función de Proyecto cuando Proyecto no está activado.
- Muestra advertencias por faltantes, duplicaciones o ventanas inválidas.
- Escapa el texto antes de mostrarlo y nunca ejecuta la respuesta como código.

Si cambia currículo, calendario, contexto, diagnóstico o Proyecto, prepare una consulta nueva.

## Cómo comparar las alternativas

| Indicador visual | Qué mide | Qué no significa |
| --- | --- | --- |
| Cobertura ubicada | Saberes colocados respecto de los seleccionados. | Aprendizaje o cobertura ejecutada. |
| Contribución del Proyecto | Saberes previstos en Proyecto o en ambos momentos. | Peso oficial ni porcentaje de nota. |
| Contribución de lecciones | Saberes previstos en lecciones o en ambos momentos. | Tiempo exclusivo separado del Proyecto. |
| Articulación prevista | Saberes del Proyecto también desarrollados en lecciones. | Calidad o integración certificada. |
| Con evidencia prevista | Saberes con una evidencia descrita. | Evidencia aplicada o logro observado. |
| Ocupación temporal | Minutos propuestos respecto del tiempo neto. | Viabilidad pedagógica automática. |

Proyecto y lecciones pueden superponerse en una experiencia, por lo que sus porcentajes no tienen que sumar 100 %. Todos los valores son proyecciones estructurales, no calificación, cumplimiento, dominio o RdA alcanzado.

## Cómo leer la trayectoria

| Momento | Uso responsable |
| --- | --- |
| ANTES | Referencia para explorar condiciones de entrada mediante diagnóstico; no presume dominio. |
| AHORA | Currículo del nivel que corresponde planificar y desarrollar. |
| DESPUÉS | Continuidad para proteger la progresión; no se anticipa como currículo actual. |

Cuando no existe antecedente explícito, PIA muestra que el saber inicia en el nivel actual. El docente construye las bases necesarias sin inventar un indicador previo.

## La decisión principal del mapa

Para cada saber, PIA permite cuatro ubicaciones:

| Ubicación | Significado |
| --- | --- |
| Lecciones pedagógicas | Se desarrolla, practica, profundiza o realimenta en la mediación curricular. |
| Componente Proyecto | Se vincula con una fase de Pensamiento de Diseño y una evidencia del Proyecto. |
| Lecciones y Proyecto | Se fortalece en lecciones y se aplica, prueba o mejora en el Proyecto. |
| Pendiente de ubicar | Todavía requiere decisión y permanece visible. |

Son ubicaciones de trabajo dentro de una sola ruta; no son categorías oficiales del currículo ni metodologías adicionales.

## Agrupaciones y relaciones

Agrupar reúne saberes que pueden compartir una experiencia. Relacionar muestra que un saber prepara, apoya, evidencia, continúa o depende de otro. PIA puede sugerir candidatos a partir de relaciones revisadas y señales del texto oficial, pero el color o una palabra compartida no certifican integración.

Un docente nuevo puede comenzar con la alternativa de IA, abrir cada agrupación y comparar:

- Verbos y profundidad de los indicadores.
- Evidencia que haría observables ambos aprendizajes.
- Orden necesario entre los saberes.
- Recursos físicos, digitales, simulados o desconectados.
- Tiempo para exploración, práctica, aplicación y realimentación.

No es necesario escribir una justificación formal por cada conexión. El campo de contexto se usa cuando existe una condición que PIA no puede conocer.

## Proyecto Pensamiento de Diseño y productos

Pensamiento de Diseño organiza el componente Proyecto. Las lecciones pedagógicas aportan bases, práctica, profundización y realimentación; no necesitan convertirse en una segunda metodología completa.

El producto no está predeterminado. Puede ser físico, simulado, programado, multimedia, documental o de baja tecnología. Una propuesta solo es pertinente si permite observar la acción y profundidad del indicador. Un video, pódcast, revista, maqueta o programa puede documentar o demostrar aprendizajes distintos; el formato por sí solo no sustituye el desempeño.

Las fases Empatizar, Definir e Idear usan los indicadores oficiales del componente Proyecto. Prototipar y Probar o Evaluar reciben únicamente indicadores oficiales del módulo vinculados expresamente.

## Cómo leer el calendario

| Capa | Qué representa |
| --- | --- |
| Diagnóstico | Una o dos lecciones cuando fue activado. |
| Lecciones pedagógicas | Bases, desarrollo, práctica, profundización y realimentación. |
| Proyecto y APD | Etapas iniciales, Prototipar y Probar o Evaluar. |
| Trabajo cotidiano | Seguimiento continuo según evidencia; no exige registro semanal. |
| Tareas y calendario | Ventanas confirmadas con semana definida. |

Las capas pueden coincidir. Una semana integrada se cuenta una sola vez, pero el docente debe revisar cómo distribuye los minutos. Una duración declarada no autoriza a inventar el inicio o final.

## Ajustes ante interrupciones o recursos limitados

PIA puede mostrar margen, riesgos y alternativas. La persona docente decide qué ajustar sin eliminar currículo ni declarar aprendizajes no desarrollados.

- Reorganice una agrupación conservando los indicadores.
- Utilice simulación cuando permite ejecutar y observar la acción requerida.
- Emplee experiencias desconectadas o materiales disponibles sin reducir la profundidad.
- Traslade práctica o realimentación dentro del periodo disponible.
- Mantenga visible un saber pendiente cuando no existe una decisión viable.
- Solicite una nueva comparación si el tiempo o los recursos cambiaron.

## Uso en computadora tableta y celular

### Computadora

Use el panel ampliado, el comparador, el mapa y el calendario. Arrastre el espacio vacío para desplazarse y los bloques para acomodar la lectura. **Ajustar mapa**, **100 %** y **Centrar** controlan la vista.

### Tableta

El modal ocupa la pantalla y los controles pueden desplazarse horizontalmente. El mapa mantiene su propio desplazamiento. Cambie a **Tabla accesible** para una lectura lineal.

### Celular

Las alternativas y métricas se apilan, las tablas conservan desplazamiento propio y las acciones críticas siguen disponibles. Use **Ajustar mapa** para una vista general o la tabla accesible para editar sin arrastrar.

Ninguna decisión esencial depende solo del color, ratón, arrastre o tamaño de pantalla.

## Auditoría posterior

Después de ajustar el mapa, **Auditar el mapa actual con IA** prepara un segundo prompt. Su función es revisar la ruta ya construida, no crear nuevamente las alternativas iniciales. Pida que separe hechos, inferencias, riesgos y sugerencias. La respuesta no modifica el mapa automáticamente.

## Recorrido breve para experiencia docente o asesoría

1. Confirme currículo, tiempo neto, diagnóstico, contexto y Proyecto.
2. Compare las alternativas sin elegir solo la más sencilla.
3. Revise verbos, profundidad, evidencias, recursos y trayectoria.
4. Compruebe que los saberes restantes conservan una ruta viable.
5. Verifique semanas compartidas, minutos, evaluación y realimentación.
6. Aplique una opción como borrador y ajústela.
7. Audite el mapa final y confirme con criterio profesional.

## Qué puede y qué no puede hacer PIA

PIA puede reunir referentes, preparar consultas, validar estructura, calcular métricas proyectadas, visualizar rutas, advertir inconsistencias y conservar decisiones.

PIA no puede certificar integración, profundidad, viabilidad, aprendizaje, promoción o RdA; inventar antecedentes; decidir el producto; aprobar adecuaciones; interpretar una PEI; conocer resultados diagnósticos no registrados; ni garantizar la corrección de una respuesta externa.

## Lista de comprobación final

- [ ] Nivel, módulo, áreas, saberes e indicadores correctos.
- [ ] Tiempo neto, interrupciones y reservas revisados.
- [ ] Diagnóstico y condiciones de entrada diferenciados.
- [ ] Contexto, recursos y DUA incluidos cuando se conocen.
- [ ] Proyecto y fases activados según corresponda.
- [ ] Tres o cuatro alternativas comparadas, no aceptadas automáticamente.
- [ ] Productos coherentes con verbos, profundidad y recursos.
- [ ] Saberes ubicados o conscientemente pendientes.
- [ ] Semanas integradas contadas una sola vez.
- [ ] Evidencias sin duplicación entre componentes.
- [ ] Trayectoria usada sin exigir previos ni adelantar el nivel siguiente.
- [ ] Porcentajes interpretados como proyección estructural.
- [ ] Mapa, calendario y tabla accesible revisados.
- [ ] Ruta confirmada por la persona docente o asesora.
