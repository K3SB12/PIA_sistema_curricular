import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,core,spec,agents,readme]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/styles/08-enhancements.css'),read('src/domain/projection/projection-core.js'),read('SPEC.md'),read('AGENTS.md'),read('README.md')
]);

test('el explorador de IA aparece antes del mapa con un flujo comprensible',()=>{
  const explorer=template.indexOf('id="piaRouteAIExplorer"');
  const map=template.indexOf('class="pia-route-canvas-shell"');
  assert.ok(explorer>=0&&map>explorer);
  for(const id of ['piaRouteAIPrepare','piaRouteAICopy','piaRouteAIPrompt','piaRouteAIResponse','piaRouteAIImport','piaRouteAIResults'])assert.match(template,new RegExp(`id="${id}"`));
  for(const label of ['Preparar','Copiar y consultar','Pegar respuesta','Comparar','Aplicar como borrador'])assert.match(template,new RegExp(label,'i'));
});

test('el prompt solicita alternativas distintas, tiempo, productos y trayectoria 7 a 9',()=>{
  assert.match(runtime,/Genere 3 o 4 rutas significativamente distintas/);
  assert.match(runtime,/TRAYECTORIA SELECTIVA ANTES–AHORA–DESPUÉS/);
  assert.match(runtime,/PIACurricularProgression\.promptContext/);
  assert.match(runtime,/Proponga de 2 a 4 formatos de producto/);
  assert.match(runtime,/Una actividad integrada que sirve a lecciones y Proyecto se registra una vez/);
  assert.match(runtime,/No imponga programación si el indicador no la exige/);
  assert.match(runtime,/timeline/);
});

test('la respuesta se trata como dato no confiable y nunca como código',()=>{
  assert.match(runtime,/function routeAIExtractJSON/);
  assert.match(runtime,/value\.length>200000/);
  assert.match(runtime,/JSON\.parse\(candidate\)/);
  const section=runtime.slice(runtime.indexOf('function routeAIExtractJSON'),runtime.indexOf('function routeAIMetrics'));
  assert.doesNotMatch(section,/\beval\s*\(/);
  assert.doesNotMatch(section,/new Function/);
  assert.doesNotMatch(section,/innerHTML\s*=\s*raw/);
});

test('PIA valida la procedencia y vuelve a comprobarla antes de aplicar',()=>{
  assert.match(runtime,/routeAIInputFingerprint/);
  assert.match(runtime,/La respuesta corresponde a otra selección o a una configuración anterior/);
  assert.match(runtime,/map\.aiExplorer\.sourceFingerprint!==routeAIInputFingerprint\(\)/);
});

test('PIA limita propuestas e identificadores y conserva faltantes como alertas',()=>{
  assert.match(runtime,/source\.slice\(0,4\)/);
  assert.match(runtime,/conceptIds\.has\(id\)/);
  assert.match(runtime,/estaba duplicado y PIA conservó su primera ubicación/);
  assert.match(runtime,/permanecen pendientes porque la IA no los ubicó/);
  assert.match(runtime,/id:`route-\$\{index\+1\}`/);
});

test('la participación en Proyecto exige activación y fases permitidas',()=>{
  assert.match(runtime,/!state\.evaluation\.projectPlanning\?\.enabled&&\['direct','integrated'\]\.includes\(role\)/);
  assert.match(runtime,/intentaba usar Proyecto sin estar activado; PIA la dejó pendiente/);
  for(const phase of ['empathize','define','ideate','prototype','test-evaluate'])assert.match(runtime,new RegExp(phase));
});

test('la comparación incluye calendario sugerido y métricas calculadas por PIA',()=>{
  assert.match(runtime,/function routeAITimelineTable/);
  assert.match(runtime,/Distribución semanal sugerida/);
  assert.match(runtime,/function routeAIMetrics/);
  assert.match(runtime,/Cobertura ubicada/);
  assert.match(runtime,/Contribución del Proyecto/);
  assert.match(runtime,/Ocupación temporal/);
  assert.match(styles,/\.pia-route-ai-timeline/);
});

test('los porcentajes no se presentan como logro ni como cumplimiento',()=>{
  assert.match(runtime,/no son logro, calificación, cumplimiento ni RdA alcanzado/i);
  assert.match(runtime,/Proyecto y lecciones pueden superponerse y no deben sumar 100 %/);
  assert.match(runtime,/PIA calculará cobertura y contribución proyectadas/);
});

test('aplicar una alternativa genera solo un borrador reversible',()=>{
  assert.match(runtime,/pushRouteHistory\(\)/);
  assert.match(runtime,/map\.proposalStatus='draft'/);
  assert.match(runtime,/map\.confirmed=false/);
  assert.match(runtime,/Aplicar como borrador al mapa/);
  const apply=runtime.slice(runtime.indexOf('function applyRouteAIProposal'),runtime.indexOf('function renderRoutePlannerSummary'));
  assert.doesNotMatch(apply,/state\.calendar\.(weeks|blockMinutes|effectiveBlockMinutes)\s*=/);
  assert.doesNotMatch(apply,/state\.projection\.conceptIds\s*=/);
});

test('la migración conserva de forma acotada el explorador y su línea temporal',()=>{
  const context=vm.createContext({result:null,encodeURIComponent,Set,Object,Array,Math,Number,String,Boolean,JSON});
  vm.runInContext(`${core}\nresult=PIAProjectionCore;`,context);
  const oversized='x'.repeat(201000);
  const migrated=context.result.migrate({pia:{routeMap:{aiExplorer:{status:'parsed',prompt:oversized,response:oversized,sourceFingerprint:'fp',proposals:[{id:'duplicado',title:'Ruta',routeType:'alternating',timeline:[{week:99,label:'fuera',minutes:999,functions:['project','invented']},{week:2,label:'válida',minutes:90,functions:['curriculum']}]}]}}}});
  assert.equal(migrated.routeMap.version,3);
  assert.equal(migrated.routeMap.aiExplorer.prompt.length,160000);
  assert.equal(migrated.routeMap.aiExplorer.response.length,200000);
  assert.equal(migrated.routeMap.aiExplorer.proposals.length,1);
  assert.deepEqual(Array.from(migrated.routeMap.aiExplorer.proposals[0].timeline[0].functions),['project']);
  assert.equal(migrated.routeMap.aiExplorer.proposals[0].timeline[0].minutes,80);
});

test('la interfaz comparativa se adapta a escritorio tableta y celular',()=>{
  assert.match(styles,/grid-template-columns:repeat\(auto-fit,minmax\(330px,1fr\)\)/);
  assert.match(styles,/@media\(max-width:900px\)/);
  assert.match(styles,/@media\(max-width:650px\)/);
  assert.match(styles,/overflow:auto/);
});

test('la documentación contractualiza el explorador y el alcance responsable',()=>{
  for(const text of ['exploración previa','borrador','trayectoria','porcentajes','respuesta de IA'])assert.match(`${spec}\n${agents}\n${readme}`,new RegExp(text,'i'));
});
