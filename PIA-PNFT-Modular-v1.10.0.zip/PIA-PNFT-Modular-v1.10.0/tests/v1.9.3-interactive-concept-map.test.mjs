import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,core,spec,agents]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/styles/08-enhancements.css'),read('src/domain/projection/projection-core.js'),read('SPEC.md'),read('AGENTS.md')
]);

test('el lienzo se puede recorrer arrastrando el espacio vacío',()=>{
  for(const fn of ['beginRoutePointer','moveRoutePointer','endRoutePointer','saveRouteViewport'])assert.match(runtime,new RegExp(`function ${fn}`));
  assert.match(template,/Arrastre el espacio vacío para desplazarse/);
  assert.match(styles,/cursor:grab/);
  assert.match(styles,/is-panning/);
});

test('el mapa ofrece ajuste completo, tamaño real y centrado interno',()=>{
  for(const id of ['piaRouteFit','piaRouteActualSize','piaRouteCenter'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/function fitRouteMap/);
  assert.match(runtime,/function centerRouteMap/);
  assert.doesNotMatch(runtime,/piaRouteCenter'\)\?\.addEventListener\('click',\(\)=>\{\$\('piaRouteMap'\)\?\.scrollIntoView/);
});

test('el zoom admite ver mapas extensos y mantiene dimensiones desplazables reales',()=>{
  assert.match(runtime,/Math\.min\(180,Math\.max\(25/);
  assert.match(runtime,/mapElement\.style\.width/);
  assert.match(runtime,/graph\.style\.transform/);
  assert.match(styles,/\.pia-route-map\{display:block;position:relative;min-width:0!important;transform:none!important/);
});

test('los bloques se pueden acomodar sin alterar el currículo',()=>{
  assert.match(runtime,/data-pia-graph-id/);
  assert.match(runtime,/map\.nodeLayout\[action\.nodeId\]/);
  assert.match(runtime,/function moveRouteNodeWithKeyboard/);
  assert.match(template,/su posición visual no cambia el currículo/);
  assert.match(template,/id="piaRouteResetLayout"/);
});

test('la migración conserva y sanea zoom, viewport y distribución visual',()=>{
  const context=vm.createContext({result:null,encodeURIComponent,Set,Object,Array,Math,Number,String,Boolean,JSON});
  vm.runInContext(`${core}\nresult=PIAProjectionCore;`,context);
  const migrated=context.result.migrate({pia:{routeMap:{version:1,zoom:2,viewport:{left:-4,top:200,initialized:true},nodeLayout:{a:{x:-2,y:88,w:9,h:4}}}}});
  assert.equal(migrated.routeMap.version,3);
  assert.equal(migrated.routeMap.zoom,25);
  assert.equal(migrated.routeMap.viewport.left,0);
  assert.equal(migrated.routeMap.viewport.top,200);
  assert.equal(migrated.routeMap.nodeLayout.a.w,180);
  assert.equal(migrated.routeMap.nodeLayout.a.h,60);
});

test('PIA crea un borrador reversible de agrupaciones y vínculos',()=>{
  assert.match(template,/id="piaRouteSuggest"/);
  assert.match(runtime,/function proposeRouteOrganization/);
  assert.match(runtime,/routeSuggestedPairs/);
  assert.match(runtime,/PIARouteRelationCatalog/);
  assert.match(runtime,/proposalStatus='draft'/);
  assert.match(runtime,/No asignó semanas, evidencias ni productos y no confirmó la ruta/);
});

test('la propuesta usa vínculos oficiales seleccionados sin inventar productos ni semanas',()=>{
  assert.match(runtime,/projectPhaseLinkedToConcept/);
  assert.match(runtime,/sourceType==='official-curriculum'/);
  assert.match(runtime,/weekStart:0,weekEnd:0/);
  assert.match(runtime,/expectedSolution\|\|'por definir durante las etapas iniciales/);
});

test('el bloque de ambos momentos explica su sentido y deja de sugerir un error',()=>{
  assert.match(runtime,/Saberes trabajados en lecciones y retomados en el Proyecto/);
  assert.match(runtime,/Esta opción no es obligatoria y no significa que la ruta esté fragmentada/);
  assert.doesNotMatch(runtime,/Sin saberes ubicados en ambos momentos/);
});

test('procedimentales, actitudinales y ejes forman una banda transversal',()=>{
  assert.match(runtime,/Banda transversal · durante toda la ruta/);
  assert.match(runtime,/Se movilizan cuando la experiencia lo requiere/);
  assert.match(runtime,/w:1085/);
  assert.match(styles,/pia-route-graph-node\.is-transversal/);
});

test('RdA permanece como destino orientador y no como certificación',()=>{
  assert.match(runtime,/Destino orientador del ciclo/);
  assert.match(runtime,/Cada nivel aporta progresivamente/);
  assert.match(runtime,/la planificación no certifica su cumplimiento/i);
});

test('computadora, tableta y celular conservan un viewport útil',()=>{
  assert.match(styles,/width:min\(1800px,calc\(100vw - 8px\)\)/);
  assert.match(styles,/@media\(max-width:1100px\)/);
  assert.match(styles,/@media\(max-width:700px\)/);
  assert.match(styles,/@media\(max-width:420px\)/);
  assert.match(styles,/height:55dvh/);
});

test('las políticas documentan que el borrador no sustituye la decisión docente',()=>{
  assert.match(spec,/borrador sugerido/i);
  assert.match(agents,/propuesta inicial/i);
});
