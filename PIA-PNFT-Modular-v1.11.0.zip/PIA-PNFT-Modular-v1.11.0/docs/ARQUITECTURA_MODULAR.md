# Arquitectura modular inicial de PIA-PNFT

## Extensión 1.6.12

`curricular-progression-service.js` añade dos consultas puras de solo lectura. `curriculumRecordsForFamily()`
recupera saberes e indicadores oficiales por nivel y familia mediante correspondencia exacta;
`trajectoryView()` compone ANTES, AHORA y DESPUÉS. AHORA se construye desde `selectedConcepts()` y no
desde toda la familia, por lo que no amplía la selección docente.

`enhancements.js` transforma esa estructura en tarjetas efímeras y filtros por área. Los SVG y colores
se declaran localmente, sin archivos remotos ni solicitudes de red. La interfaz no introduce propiedades
en `state`, no modifica `schemaVersion: 6` y queda fuera de los exportadores. El prompt continúa consumiendo
solamente `promptSummary()`; la ventana consume `trajectoryView()` y no comparte su contenido con la IA.

`semester-projection-prompt.js` agrega una auditoría temporal posterior a la construcción de la propuesta
y localiza los identificadores técnicos del Proyecto mediante el catálogo. El identificador `development`
permanece estable; la salida docente utiliza “Etapa de desarrollo”.

## Extensión 1.6.7

La edición contextual conserva la separación existente entre interfaz, coordinación y persistencia.
`week-view.js` declara una barra local por semana; `enhancements.js` mantiene la referencia del campo
y el rango de selección activos, aplica comandos exclusivamente sobre Mediación o Evaluación y
sincroniza el HTML saneado con la semana. `08-enhancements.css` mantiene la barra adhesiva, compacta
y adaptable sin añadirla a la impresión.

Las opciones principales permanecen visibles y las secundarias se agrupan en un `details`. Inicio,
Desarrollo y Cierre insertan subtítulos únicamente en Mediación. El pegado limpio es un estado temporal
de interfaz. Los vínculos se aceptan solo con `https://`, se sanea su atributo `href` y nunca originan
una conexión automática. No cambia `schemaVersion: 6`, el currículo, Proyecto ni los exportadores.

## Extensión 1.6.6

La arquitectura separa ahora dos salidas del mismo servicio de progresión. `promptContext()` conserva
el mapa detallado AHORA–ANTES–DESPUÉS para validación interna, mientras `promptSummary()` entrega al
generador una sola orientación construida con las familias de los saberes seleccionados. La interfaz
no presenta el mapa técnico ni añade controles nuevos.

`enhancements.js` consulta únicamente `promptSummary()` y `semester-projection-prompt.js` incorpora
esa línea antes de la tarea para la IA. La dependencia continúa siendo unidireccional y de solo
lectura: progresión → prompt. No escribe en currículo, estado JSON, semanas, Proyecto o exportadores.
El contrato específico de Preescolar de 1.6.5 permanece como una rama especializada posterior y no
es sustituido por la simplificación de trayectoria.

## Extensión 1.6.5

`preschool-curriculum.js` amplía su catálogo aislado con competencias específicas y perfiles de
salida por área, sin cambiar los cuatro itinerarios, sus saberes, indicadores o RdA. `enhancements.js`
construye un marco de Preescolar únicamente con las áreas seleccionadas y lo entrega al generador.

`semester-projection-prompt.js` decide el contrato según el perfil: Preescolar recibe una ruta
lúdica y formativa; I y II Ciclo no reciben referencias a Proyecto; III Ciclo conserva la condición
de Proyecto seleccionado o no seleccionado. Esta decisión solo modifica el texto del prompt y no
escribe semanas, JSON ni exportaciones.

## Extensión 1.6.4

El servicio de progresión conserva internamente los tres estados de la matriz, pero construye una
salida docente simplificada: AHORA, ANTES y DESPUÉS. El filtrado del alcance actual ocurre dentro de
`curricular-progression-service.js` y utiliza exclusivamente los saberes seleccionados. El constructor
del prompt añade una sola regla general de interpretación; no cambia el estado JSON ni la interfaz.

La transformación es de presentación y contrato. El catálogo relacional, `PNFT_DATA`, los RdA y los
indicadores oficiales permanecen separados e inalterados.

## Extensión 1.6.2

La progresión curricular se incorpora como una capa relacional de solo lectura, sin duplicar ni
reemplazar la base curricular que usa el planeamiento:

- `src/data/curricular-progression.js`: 38 familias, estados por nivel y trazabilidad de las matrices.
- `src/domain/curriculum/curricular-progression-service.js`: correspondencias exactas y generación
  del contexto de fundamento previo, alcance actual y proyección posterior.
- `src/prompts/semester-projection-prompt.js`: consume la referencia y aplica sus salvaguardas.
- `scripts/import-curricular-progression.mjs`: actualización técnica reproducible, nunca accesible
  desde la interfaz docente.

La dependencia es unidireccional: el prompt consulta la progresión; la progresión nunca escribe en
`PNFT_DATA`, el estado JSON, las semanas ni los exportadores. No se incorporan componentes del
proyecto separado PIA 1.7.0.

## Extensión 1.6.1

La selección curricular semanal sigue distribuida entre `src/ui/week-view.js`, que construye el
panel, y `src/domain/curriculum/curriculum-operations.js`, que resuelve módulos, áreas, saberes,
RdA e indicadores. No se agrega una segunda copia del catálogo curricular.

Cada semana conserva dos propiedades compatibles con el esquema JSON v6:

- `modulos`: uno o ambos módulos usados como filtro visible.
- `saberRefs`: referencias compuestas `{modulo, area, nombre}` para identificar sin ambigüedad la
  procedencia de cada saber nuevo.

`saberes` permanece como arreglo de nombres para compatibilidad con exportadores, prompts y planes
anteriores. El indicador se resuelve desde `saberRefs`; cuando un plan histórico no las contiene,
PIA utiliza una ruta conservadora, habilita ambos módulos si ya existe contenido y no borra datos.

El panel `pia-week-curriculum-details` controla únicamente la visualización. Los filtros semanales
no dependen de la proyección semestral, por lo que esta puede plegarse después de orientar el semestre.

## Extensión 1.6.0

El esquema JSON v6 añade tres estados sin modificar `PNFT_DATA` ni `RDA_POR_CICLO`:

- `pia.evaluation.projectPlanning.phaseRecords`: plantillas docentes de Prototipar y Probar/Evaluar.
- `pia.aiPrompts`: textos general, semestral y por semana que la persona docente haya editado.
- `pia.ui.projectionExpanded`: preferencia visual para mostrar u ocultar la proyección.

`project-component-catalog.js` distingue indicadores oficiales de registros `teacher-authored`.
`enhancements.js` inicializa una semana solo cuando no tiene registro y conserva las ediciones
existentes. PDF y Word consumen `projectExportForWeek()` y no leen el catálogo por separado.

Versión documentada: **PIA-PNFT Modular 1.6.12**.

PIA 1.6.11 mantiene `schemaVersion: 6` y añade únicamente coordinación de interfaz en
`src/application/enhancements.js`: `diagnosticReadiness()` controla la apertura del apoyo diagnóstico
y `contextHelpCatalog` alimenta ayudas efímeras. Ninguna de estas funciones modifica el dominio,
la persistencia, el currículo o los exportadores.

La versión 1.5.0 añade dos catálogos aislados (`evaluation-instruments.js` y
`project-component-catalog.js`) antes de los consumidores de aplicación. El estado JSON v6 mantiene
la proyección curricular separada de `evaluation.projectPlanning`; Proyecto conserva instantáneas
versionadas y nunca altera `PNFT_DATA`, `RDA_POR_CICLO` ni los exportadores oficiales.

## Decisión

La primera reorganización aplica modularidad de fuente y conserva un bundle clásico embebido.
Cada fragmento se concatena sin transformar, minificar ni reformatear. La referencia permanece
intacta. La entrega difiere únicamente en los bloques autorizados de `eliminarSemana()` y
exportación Word; una puerta automática impide diferencias fuera de esos rangos.

## Límites

| Carpeta | Responsabilidad |
|---|---|
| `src/data` | Base PNFT protegida, Preescolar, centros y catálogo relacional de progresión |
| `src/domain` | Estado, semanas, operaciones curriculares, progresión y consulta local de centros |
| `src/application` | Inicialización y coordinación del plan |
| `src/infrastructure` | JSON, PDF, guardado y portable |
| `src/prompts` | Generadores general y semanal |
| `src/ui` | Construcción de semanas y notificaciones |
| `src/styles` | CSS principal dividido por área visual |
| `src/templates` | HTML dividido por secciones visibles |
| `scripts` | Construcción y verificación reproducible |

El orden de los fragmentos en `scripts/fragment-manifest.mjs` funciona como contrato de carga:
plantillas y estilos establecen la interfaz; datos y estado se declaran antes de sus consumidores;
aplicación, dominio, infraestructura, interfaz y prompts comparten después el ámbito global.

## Compatibilidad

La salida conserva los eventos inline y el ámbito global vigente. No se utiliza `type="module"`
en el navegador porque cambiaría la disponibilidad de las funciones invocadas desde HTML.
La migración hacia módulos ES y un puente `window` deberá ser un hito posterior con pruebas
específicas; no es necesaria para trabajar desde archivos separados desde esta entrega.

## Extensión funcional 1.5.1

El componente Proyecto conserva su catálogo en `src/data`, la estructura persistente v5 en
`src/domain`, la coordinación en `src/application` y la representación semanal en `src/ui`. Esta
separación permite sustituir posteriormente la interfaz por React o conectar un repositorio remoto
sin mezclar indicadores del Proyecto con `PNFT_DATA`. El puente de backend continúa inactivo.

El sistema vigente es frontend local. No contiene autenticación, base de datos, API ni backend.

## Escalabilidad

Una interfaz React futura puede sustituir `src/ui` y consumir servicios de aplicación. Un
backend PHP, Node u otra tecnología podrá añadir un repositorio por API. Ninguno deberá
reemplazar obligatoriamente el guardado local ni afectar la salida portable.

La exportación Word pertenece a `src/infrastructure/export/pdf-exporter.js` para conservar la
misma selección de contenido y presentación institucional de la salida PDF. Su vista es continua
en pantalla; el archivo declara A4 horizontal para Microsoft Word y la paginación aparece únicamente
al imprimir o abrir el archivo en un procesador de texto.
# Ampliación PIA 1.2.0

La capa `PIA_ENHANCEMENTS_*` añade proyección, esquema de plan v2, identidad, recuperación,
formato y revisión sin sustituir el núcleo heredado. `src/domain/projection/projection-core.js`
contiene reglas puras; `src/application/enhancements.js` compone la interfaz; y
`src/adapters/backend-bridge.js` reserva un puerto futuro deliberadamente inactivo. No existen
servidor, API, autenticación ni analítica activa.

# Organización visual PIA 1.2.1

`src/templates/enhancements.html` contiene el contexto y la proyección como parte del flujo
pedagógico principal. El manifiesto lo ensambla después de Metodología activa y antes de las
semanas. `src/templates/support-tools.html` contiene formato, recuperación, reutilización y el
diálogo común; se ubica después de las reflexiones como apoyo secundario.

La versión 1.2.1 conservaba el esquema JSON v2. El resumen en vivo y el filtro de saberes son
proyecciones de la selección local y no escriben en el catálogo curricular.

# Arquitectura funcional PIA 1.3.0

El esquema JSON pasa a v3 con migración aditiva desde v1/v2. La composición visual queda fijada
en `scripts/fragment-manifest.mjs`: título, identidad opcional, encabezado oficial, ejes,
metodología, contexto/DUA, proyección, edición contextual y semanas.

`src/data/evaluation-profiles.js` resuelve el perfil de evaluación; `src/prompts/semester-projection-prompt.js`
construye el contrato semestral sin datos administrativos; `src/domain/projection/projection-core.js`
migra, distribuye y calcula cobertura; `src/application/enhancements.js` coordina la experiencia
local. El backend permanece como puerto inactivo en `src/adapters/backend-bridge.js`.

## Arquitectura funcional PIA 1.3.1

La proyección es una referencia curricular y muestra módulo, áreas, saberes, indicadores y RdA.
No distribuye ni escribe datos en las semanas. `enhancements.js` calcula la cobertura comparando
los saberes seleccionados en Proyección con `semanas[].saberes`; por ello la cobertura representa
lo incorporado en el plan y nunca aprendizaje alcanzado.

`week-view.js` crea una barra de formato dentro de cada semana. `enhancements.js` mantiene un
historial independiente por campo editable, coordina el navegador semanal y preserva la regla de
que el indicador oficial no sea editable. PDF y Word consumen únicamente el planeamiento oficial:
no existe una dependencia de exportación hacia Proyección o Cobertura.

## Arquitectura funcional PIA 1.4.0

`src/data/preschool-curriculum.js` incorpora una capa curricular aislada para Preescolar. No
reescribe el archivo histórico `pnft-data.js`: adapta las cuatro combinaciones autorizadas
Módulo 1/2 × Básico requerido/Óptimo al contrato que ya consumen Proyección y las semanas.
Cada registro conserva área, RdA, saber conceptual e indicador oficial.

`src/data/institutional-centers.js` es un catálogo compilado de uso local. Contiene únicamente
`centro`, `codPres` y `codSaber`; se ensambla dentro del HTML portable y no realiza consultas de
red. `src/domain/institution/center-lookup-service.js` indexa el catálogo y devuelve tres estados:
`unique`, `ambiguous` o `notFound`. La interfaz autocompleta solo el primero y exige decisión
docente en el segundo.

La fuente Excel no forma parte del recorrido docente. Personal técnico autorizado ejecuta
`scripts/import-centers.mjs` para regenerar el catálogo, verificar columnas, excluir `0000`,
conservar ceros iniciales y comprobar la unicidad de `codSaber`. No se compilan nombres de
personas asesoras, teléfonos ni correos.

El esquema continúa en v3. El metadato opcional `pia.institutional.codSaber` es aditivo y las
migraciones antiguas reciben un valor vacío. No existe backend: React/PHP o una API futura podrán
consumir este identificador sin que la versión actual envíe información.

## Corrección de visibilidad 1.4.1

`renderProjectionOptions()` controla conjuntamente `hidden`, `aria-hidden` y `disabled` del
itinerario de Preescolar. La regla `.pia-field[hidden]` tiene prioridad sobre el diseño grid del
campo, evitando que el selector aparezca o reciba interacción en I, II o III Ciclo.
