# Bitácora operativa PIA-PNFT

## Entrada 018 — 2026-09-11 — Trayectoria curricular y auditoría temporal 1.6.12

Se autorizó transformar la progresión interna ya validada en una vista docente local y efímera. La
acción se ubicó debajo de la cobertura y presenta tarjetas por familia con filtros para las cuatro áreas.
ANTES orienta el diagnóstico, AHORA conserva únicamente la selección vigente y DESPUÉS informa la
continuidad. Los vacíos se identifican como fortalecimiento sin evaluación directa y `N/A` como ausencia
en la trayectoria. La interfaz no modifica ni exporta datos.

El prompt semestral añadió una auditoría temporal posterior a la matriz y al desarrollo semanal. La IA
debe valorar minutos, bloques, integración, profundidad, continuidad, práctica, realimentación y evaluación;
no puede declarar sobrecarga por un conteo aislado. También se localizó `development → Prototipar` como
“Etapa de desarrollo → Prototipar” manteniendo el identificador interno estable.

Los Excel adjuntos coincidieron exactamente con las huellas registradas. Se aprobaron 127 pruebas. La
revisión humana visual en Edge/Chrome continúa pendiente antes del despliegue institucional.

## Entrada 017 — 2026-09-11 — Secuencia diagnóstica y ayudas contextuales 1.6.11

Se aprobó una mejora focalizada de experiencia de uso. El selector de cero a dos lecciones se mantuvo
en Marco temporal y la acción **Preparar evaluación diagnóstica** se trasladó después de Saberes para
la proyección. La apertura exige ciclo, nivel, módulo, área, saber conceptual y una o dos lecciones;
esta condición no interviene en la proyección semestral, por lo que el diagnóstico continúa siendo opcional.

Se incorporó un glosario contextual único para explicar DUA, referencias, proyección, diagnóstico, RdA,
saberes, Proyecto y evaluación. Las ayudas funcionan con puntero, teclado y toque, solo muestran una
explicación, se cierran con clic externo o `Esc` y quedan excluidas del estado, prompts e impresión.

Se actualizaron contratos, especificación, estado operativo, manuales, guía de entrega, arquitectura,
informe y bitácora. Resultado automatizado: **120/120 pruebas aprobadas; 0 fallos**. La revisión humana
final en Edge o Chrome permanece recomendada antes del despliegue institucional.

## Entrada 016 — 2026-09-07 — Afinamiento funcional de PIA Modular 1.6.8

Se tomó como base exclusiva la versión 1.6.8 actualizada por la persona responsable del proyecto. Se
respetaron sus cambios de interfaz, redacción y estructura, y no se sustituyó el archivo original. El
trabajo se concentró en eliminar ambigüedades del prompt semestral y armonizar el diagnóstico y la
Contextualización/DUA con las decisiones pedagógicas ya validadas.

El diagnóstico volvió a admitir un máximo de dos lecciones. Se corrigieron de forma coordinada el
control visible, la captura del estado, la migración de planes anteriores, la sincronización de la
semana inicial y las pruebas. Esta decisión evita que PIA extienda automáticamente el periodo
diagnóstico más allá del acuerdo vigente, pero mantiene la posibilidad de usar cero, una o dos
lecciones sin eliminar contenidos semanales ni confundir diagnóstico con aprendizaje demostrado.

La Contextualización y DUA conserva todos sus campos y opciones en el JSON, pero el prompt incluye
únicamente la información realmente completada o seleccionada. Los valores iniciales Regular,
recursos suficientes y evaluación diagnóstica pendiente ya no producen bloques ni frases innecesarias.
También se omiten condiciones no marcadas e indicadores de referencia no elegidos. Se mantienen las
orientaciones universales de DUA y las alternativas desconectadas como reglas pedagógicas, sin suponer
una adecuación individual ni solicitar datos personales o clínicos.

Las etiquetas visibles se revisaron para emplear lenguaje docente, grupal y no estigmatizante:
apoyos para acceso y participación, diversidad de puntos de partida y ritmos, organización multigrado
o grupos espejo, alta dotación/talentos/creatividad, contexto sociocultural, pueblos originarios y su
cosmovisión, continuidad educativa ante situaciones de salud, acceso tecnológico limitado y apoyos
educativos definidos institucionalmente. El punto de partida se expresa como evaluación diagnóstica
pedagógica, nivelación, diversidad o profundización; no como diagnóstico clínico.

El generador semestral exige seleccionar una metodología activa antes de producir el texto. Las fechas,
ejes, excepciones, contexto y referencias se muestran solo cuando fueron aportados; una fecha parcial se
conserva como incompleta y se prohíbe a la IA inventar la restante. La numeración de las tareas se genera
de manera continua según las reglas realmente aplicables, incluido Proyecto únicamente en III Ciclo y
con el perfil correspondiente.

Se fortaleció la trazabilidad curricular del prompt: cada RdA aparece identificado por su área y cada
saber conceptual se relaciona con módulo, indicador o indicadores de logro del PNFT y RdA del área. La
redacción obliga a conservar la literalidad del PNFT, desarrollar el nivel seleccionado y no convertir
referencias, refuerzos o sugerencias en currículo oficial. Los bloques opcionales vacíos se eliminan
también del espaciado final para ofrecer un documento más limpio.

Se actualizaron `AGENTS.md`, `SPEC.md`, `info.md`, `README.md`, `CHANGELOG.md`, los manuales funcional
y técnico, y el informe de validación. No se modificaron `PNFT_DATA`, `RDA_POR_CICLO`, Preescolar,
Proyecto, la progresión interna, el esquema JSON v6, PDF, Word, portable ni el backend inactivo. La
construcción produjo tres salidas equivalentes con huella
`de256cf9a92ad22a19caf5d6dc915c016aebb0f67ac1ad39b8f9464fbae1b624`; las 105 pruebas automatizadas
resultaron aprobadas. Se mantiene la revisión humana recomendada en Edge/Chrome y Word antes del
despliegue institucional.

## Entrada 015 — 2026-09-06 — PIA Modular 1.6.7

Se atendió una fricción observada durante la edición de planeamientos extensos: la persona docente
debía sombrear un fragmento en Estrategias de mediación o Indicadores de evaluación, desplazarse hasta
el encabezado semanal, aplicar una opción y regresar al lugar de escritura. Este recorrido podía
repetirse varias veces y aumentaba el riesgo de perder la selección activa.

La barra local existente se transformó en una ayuda contextual. PIA conserva el rango sombreado,
abre la barra después de completar la selección y muestra explícitamente si el formato se dirige a
Estrategias de mediación o a Indicadores de evaluación. La apertura no ocurre durante el arrastre del
puntero, evitando desplazar la interfaz mientras se selecciona. El botón semanal se conserva como
alternativa y la barra puede ocultarse con su control, un clic externo o la tecla Escape.

Para evitar saturación, se priorizaron deshacer, rehacer, negrita, subrayado, lista y limpieza de la
selección. Las acciones menos frecuentes quedaron plegadas en “Más opciones”: cursiva, lista numerada,
sangría, alineación, color, resaltado, tamaño, subtítulos Inicio–Desarrollo–Cierre, pegado limpio,
vínculo y limpieza completa del campo. Los subtítulos rápidos solo actúan en Mediación. El pegado
limpio se activa voluntariamente durante la sesión y no añade estado al JSON.

Los vínculos requieren protocolo HTTPS y validación expresa de la persona docente; PIA no los abre ni
realiza conexiones automáticas. El saneamiento conserva únicamente vínculos HTTPS y convierte cualquier
otro esquema en texto. Los Indicadores de logro del currículo de FT permanecen protegidos y fuera del
alcance de todos los comandos de formato.

No se modificaron `PNFT_DATA`, `RDA_POR_CICLO`, Preescolar, progresión, Proyecto, perfiles de evaluación,
estructura JSON v6 ni composición de PDF/Word. El formato continúa sincronizándose con el contenido
semanal y utiliza las rutas vigentes de guardado, carga, autoguardado y exportación. Resultado: 96/96
pruebas automatizadas aprobadas; queda indicada la comprobación humana final en Edge o Chrome de
selección, desplazamiento, guardado/carga y exportación.

## Entrada 014 — 2026-09-04 — PIA Modular 1.6.6

Se atendió la necesidad de aprovechar la progresión horizontal y vertical sin trasladar al usuario
la complejidad técnica de la matriz. El catálogo de 38 familias y el análisis completo de trayectoria
permanecen activos internamente y continúan disponibles para comprobación automatizada. Se agregó una
salida resumida, generada desde las familias de los saberes seleccionados, que llega al prompt como
una sola orientación comprensible.

El cambio se realizó porque los bloques AHORA–ANTES–DESPUÉS podían inducir a interpretar los
antecedentes como aprendizajes comprobados o distraer del nivel que realmente se está planificando.
La nueva instrucción conserva el beneficio pedagógico: pide integración horizontal, progresión
vertical y continuidad por familias, pero obliga a desarrollar solo el nivel vigente, usar los
antecedentes para diagnóstico cuando existan y no adelantar alcances posteriores. Los refuerzos sin
evaluación directa siguen sin convertirse en indicadores.

Se mantuvo intacto el contrato específico de Preescolar de 1.6.5, incluidas competencias, perfiles de
salida, experiencias lúdicas completas y evaluación diagnóstica/formativa. No se modificaron currículo
oficial, JSON v6, semanas, Proyecto, PDF, Word, portable ni la línea independiente PIA 1.7.0.
Resultado: 93/93 pruebas automatizadas aprobadas.

## Entrada 008 — 2026-09-01 — PIA Modular 1.6.0

Se preservó íntegramente PIA 1.5.2 y se trabajó sobre una copia 1.6.0. Se habilitó la selección
semestral de Prototipar y Probar/Evaluar porque antes solo podían elegirse en la semana y no
aportaban texto exportable. Cada fase posterior incorpora un indicador de logro y dos de evaluación
editables, rotulados como texto docente no oficial porque la fuente no incorpora indicadores
oficiales para ellas. La proyección inicializa una semana únicamente cuando no existe registro, por
lo que nunca sobrescribe contextualizaciones semanales.

El esquema pasó a JSON v6 para conservar prompts general, semestral y semanales editados después de
guardar, cerrar y cargar. La Proyección semestral se puede ocultar sin borrar información. Word
reserva espacios blancos más amplios para Reflexiones Docentes y Observaciones. Se actualizaron los
contratos y manuales. Resultado: 75/75 pruebas automatizadas aprobadas; backend y analítica continúan
inactivos.

## Entrada 001 — 2026-08-26 — PIA Modular 1.3.0

Se creó una versión preservando PIA 1.2.1 y sus referencias. Se reorganizó el recorrido docente,
se eliminó la duplicidad del nombre institucional, se fortaleció proyección semestral, evaluación,
Contextualización/DUA, distribución, revisión local de propuesta IA y formato contextual. Se mantuvo
el encabezado oficial y el currículo protegido. El esquema pasó a JSON v3 con migración v1/v2.

Resultado: construcción reproducible y 23/23 pruebas automatizadas aprobadas. Backend, API,
autenticación y analítica continúan fuera de alcance. Próximo hito sugerido: piloto humano documentado.

## Entrada 002 — 2026-08-26 — PIA Modular 1.3.1

Con aprobación docente se simplificó Proyección semestral a tres pasos y se eliminó la distribución
automática, el espacio para pegar/aprobar respuestas de IA y las herramientas de reutilización que no
aportaban al recorrido. Los RdA oficiales ahora se muestran por área dentro de Proyección. La cobertura
se calcula exclusivamente desde los saberes incorporados manualmente en las semanas y permanece como
referencia interna, fuera de PDF y Word.

Se incorporó navegación para planes extensos, una semana visible por defecto, estados compactos,
momento pedagógico y diagnóstico visible. Cada semana dispone de formato local con deshacer/rehacer
independiente en Mediación e Indicadores de evaluación; los indicadores oficiales continúan protegidos.

Resultado: fuente, construcción y alcance autorizados aprobados; 24/24 pruebas Node aprobadas; tres
salidas HTML idénticas con SHA-256
`dc642f6466e4d50de954b9c004aa1877ae0124e68c103eccd0002cf248c9f791`. `PNFT_DATA`,
`RDA_POR_CICLO`, referencias, backend inactivo y analítica inactiva permanecen intactos.

## Entrada 003 — 2026-08-27 — PIA Modular 1.4.0

Se incorporó la mejora institucional del código presupuestario sin crear backend ni permitir la
carga de Excel desde la plantilla. El archivo autorizado fue depurado previamente para excluir 84
registros `0000` correspondientes a centros fuera del alcance. El catálogo compilado contiene
4.651 registros mínimos (`centro`, `codPres`, `codSaber`), 4.448 códigos de coincidencia única y
63 códigos ambiguos que agrupan 203 registros. Se excluyeron nombres de personas asesoras,
correos y teléfonos para reducir exposición de datos.

La consulta completa automáticamente el Centro educativo cuando el código es único. Cuando varias
sedes comparten código, PIA muestra una selección y no adivina. Si no existe coincidencia, mantiene
la posibilidad de completar el centro manualmente. `codSaber` se conserva únicamente como metadato
interno del JSON v3, preparando una integración futura sin activar red, API ni analítica.

Se corrigió Preescolar mediante un catálogo curricular aislado, trazable a la Guía docente oficial.
El nivel técnico `0°` se conserva para compatibilidad y ahora resuelve correctamente Módulo 1
Básico requerido (6 saberes), Módulo 2 Básico requerido (8), Módulo 1 Óptimo (8) y Módulo 2
Óptimo (10), con sus áreas, RdA e indicadores propios. Se eliminó el bloqueo informativo de la
ruta básica y el cambio de itinerario refresca Proyección y las semanas sin alterar otros niveles.

Se fortaleció el punto 4 de las tareas para IA: ABJ, ABR y APD deben funcionar como andamiaje
continuo durante el semestre, enlazando cada semana con la anterior y describiendo actuación del
estudiantado, acompañamiento docente, recursos, evidencias y continuidad. También se incorporó la
corrección validada del escudo en Word, con ancho estable de 90 px y altura proporcional.

Justificación: estas mejoras reducen digitación, evitan asociaciones incorrectas de centros,
eliminan registros no atendidos, corrigen la confiabilidad curricular de Preescolar y orientan a la
IA para producir una progresión metodológica coherente, sin modificar el formato oficial del
planeamiento ni sustituir el criterio profesional docente.

Resultado: construcción reproducible y alcance autorizado aprobados; importación real del catálogo
reproducida byte a byte; 44/44 pruebas Node aprobadas; tres salidas HTML idénticas con SHA-256
`7ef35a74307c460ce943ce80a244c5a131d07a484f5ffe1a50dd67a790caf280`. No se añadieron APIs de
red, backend, autenticación, analítica activa ni carga de Excel en la interfaz. La validación manual
final de ventanas emergentes, impresión y descarga continúa correspondiendo a Edge/Chrome del equipo usuario.

## Entrada 004 — 2026-08-28 — PIA Modular 1.4.1

Durante la comprobación docente en I Ciclo–2.º se observó que **Itinerario de preescolar** seguía
visible. La condición JavaScript era correcta, pero el estilo general `.pia-field { display:grid; }`
anulaba visualmente el atributo HTML `hidden`.

Se añadió la regla focalizada `.pia-field[hidden] { display:none!important; }`. Además,
`renderProjectionOptions()` ahora sincroniza tres estados: ocultamiento visual con `hidden`,
accesibilidad con `aria-hidden` y bloqueo funcional con `disabled`. El selector solo permanece
visible y operativo para Materno Infantil/Transición con nivel interno `0°`.

Justificación: elimina una fuente de confusión para docentes de I, II y III Ciclo y evita que un
control no aplicable pueda recibir foco o interacción, sin modificar datos curriculares, semanas,
guardado, exportaciones o el formato oficial.

Resultado: fuente, construcción y alcance autorizado aprobados; 45/45 pruebas Node aprobadas; tres
salidas HTML idénticas con SHA-256
`950bfd461e81772a799e80d13ca3b1a4096edfeb8dad26efb378ac2cbfbd77be`.

## Entrada 005 — 2026-08-28 — PIA Modular 1.5.0

Se incorporaron tres mejoras acordadas. Primero, un catálogo local y versionado recomienda nueve
instrumentos de evaluación según la evidencia y explica requisitos, uso y salvaguardas. PIA no
registra personas estudiantes, resultados o notas, no impone cantidades universales y evita la
doble valoración de una evidencia.

Segundo, se añadió el componente Proyecto como función condicionada al perfil de evaluación. El
catálogo independiente conserva literalmente los indicadores oficiales disponibles para
Empatizar, Definir e Idear. Prototipar y Probar/Evaluar quedan preparados sin inventar indicadores.
Los datos se almacenan en JSON v4 con identificador, texto y versión; ocultar o cambiar a un perfil
incompatible no los elimina, y su borrado exige una confirmación explícita. El avance mostrado es
operativo, no una calificación. Proyecto no agrega secciones al PDF o Word oficial.

Tercero, se fortalecieron los prompts general, semanal y semestral. La IA debe copiar completos y
literalmente los indicadores oficiales; mostrar en cada semana los saberes procedimentales y
actitudinales; priorizar la integración de saberes o justificar con razones pedagógicas su
tratamiento individual; y desarrollar inicio, desarrollo y cierre con consignas, acciones,
acompañamiento, recursos, tiempos, evidencia, DUA, realimentación y continuidad. También debe
diferenciar toda sugerencia de la normativa y abstenerse de inventar reglas, plazos, cantidades o
porcentajes.

Justificación: las mejoras reducen interpretaciones de la IA, fortalecen la coherencia entre
currículo, mediación y evaluación, y preparan el Proyecto sin mezclarlo con los indicadores
curriculares ni afectar funcionalidades validadas.

Resultado: 61/61 pruebas automatizadas aprobadas; tres salidas HTML idénticas con SHA-256
`df112c585f91861a26d790aaca9656cd8053921dca157cd420dd5e64dce976e2`; backend, API,
autenticación y analítica continúan inactivos.

## Entrada 006 — 2026-08-28 — PIA Modular 1.5.1

Se simplificó la orientación de instrumentos: se eliminó la selección prematura de una sola
necesidad y el catálogo completo pasa internamente al prompt. La IA debe definir primero actividad
y evidencia y luego recomendar uno o varios instrumentos con finalidad, función, justificación,
construcción, aplicación, comunicación y realimentación.

El componente Proyecto conserva la ruta global por etapas y añade una decisión clara en cada
semana: curricular (80 minutos), mixta (40 + 40) o integrada mediante Proyecto (80 minutos). Los
indicadores de logro y evaluación del Proyecto se muestran dentro de las columnas oficiales. Se
eliminaron hitos, porcentajes y estados que podían confundirse con logro, aprendizaje o nota.

La persistencia pasa a JSON v5. Cada fase guarda una instantánea oficial inmutable y una copia
`teacherText` contextualizable. Cambiar de fase, ocultar Proyecto o cargar el archivo conserva la
edición; restaurar el texto oficial o borrar todos los datos del Proyecto requiere confirmación.
PDF y Word mantienen un solo planeamiento e incorporan los textos contextualizados en las columnas
existentes.

Justificación: reduce carga cognitiva, evita decisiones evaluativas sin evidencia, hace visible la
relación entre currículo y Proyecto y protege el trabajo docente ante cambios de catálogo o sesión.

Resultado: 64/64 pruebas automatizadas aprobadas; fuente y alcance autorizado aprobados; backend,
API, autenticación y analítica continúan inactivos. La huella final se registra en
`CURRENT.sha256`.

## Entrada 007 — 2026-08-28 — PIA Modular 1.5.2

Se cerró la correspondencia entre el componente Proyecto semanal, el archivo JSON y las
exportaciones oficiales. Aunque v1.5.1 ya conservaba el texto oficial, la contextualización docente
y la selección, Word y PDF todavía componían sus columnas únicamente desde los campos curriculares
base de la semana.

Se incorporó una regla única de selección efectiva. Cuando una semana es mixta o integrada y el
Proyecto está habilitado, la columna Indicadores de logro añade el texto contextualizado del
Proyecto; si no existe edición, utiliza la instantánea oficial guardada. La columna Indicadores de
evaluación aplica la misma prioridad y exporta solo los indicadores seleccionados. Desmarcar un
indicador lo excluye de PDF y Word, pero no lo elimina del JSON.

Ambos exportadores consultan la misma función para evitar diferencias. Proyecto permanece dentro de
las tres columnas oficiales; Proyección y Cobertura continúan fuera del documento. También se
ampliaron las pruebas de guardado/carga para incluir modo, fase, texto oficial, texto docente y
estado seleccionado.

Justificación: garantiza que el documento entregado refleje exactamente la decisión docente y que
una reapertura del JSON no sustituya ni pierda contextualizaciones, sin alterar el currículo, la
presentación oficial o las funciones previamente validadas.

Resultado: 68/68 pruebas automatizadas aprobadas; construcción y alcance autorizado aprobados;
las tres salidas HTML comparten la huella SHA-256
`d61dc3d964af384e28f58bb6a8e419c00048f68bee613ae90a26ce46d459060c`; backend, API,
autenticación y analítica permanecen inactivos.

## Entrada 009 — 2026-09-02 — PIA Modular 1.6.1

Se incorporó un filtro curricular independiente por semana para Módulo 1, Módulo 2 o ambos. Las
áreas, RdA, saberes e indicadores ofrecidos corresponden al nivel y módulos activos, mientras las
selecciones previas se conservan aunque queden temporalmente fuera del filtro. Las referencias
compuestas `saberRefs` eliminan la ambigüedad entre módulos sin retirar el arreglo histórico
`saberes` requerido por planes y exportadores anteriores.

La selección curricular semanal se agrupó en un panel plegable para reducir desplazamiento. El
prompt semestral puede regenerarse con las fechas vigentes, pero protege cualquier texto editado y
solicita confirmación antes de reemplazarlo. Contextualización/DUA y Seguridad/recuperación se
mantuvieron desplegables sin cambiar identificadores ni eventos.

Justificación: mejora la precisión curricular y la navegación de planes extensos, evita obtener un
indicador del módulo incorrecto y protege el trabajo guardado de la persona docente.

Resultado: 80/80 pruebas automatizadas aprobadas; JSON v6, PDF, Word, portable, Proyecto y currículo
oficial preservados.

## Entrada 010 — 2026-09-04 — PIA Modular 1.6.2

Se partió exclusivamente del ZIP PIA 1.6.1 aportado por la persona usuaria. Se descartó expresamente
la incorporación de archivos, interfaz o arquitectura del proyecto separado PIA 1.7.0.

Se analizó la matriz validada “Saberes por Año Escolar julio -2026” y el ejemplo asesor de
escalabilidad de indicadores. El análisis mostró que la base vigente de PIA ya posee los saberes e
indicadores necesarios para planear, pero no registraba formalmente que denominaciones de distintos
niveles pertenecen a una misma familia, como Algoritmos, Entornos de programación, Robótica o
Inteligencia artificial.

Para cerrar esa brecha se creó un catálogo relacional interno de 38 familias, diez niveles y las
cuatro áreas del PNFT. Los 235 registros curriculares actuales se vincularon por correspondencia
exacta de área y nombre. Esta decisión evita asociaciones ambiguas y hace visible en pruebas cuando
un saber nuevo o renombrado requiere revisión asesora.

En 1.6.2 se interpretó una celda vacía como refuerzo conceptual. La revisión 1.6.13 corrige esa
inferencia: el vacío solo representa ausencia de registro curricular para el nivel y no prueba
enseñanza, refuerzo, evaluación ni dominio. `N/A` significa que no aplica al nivel.

La versión 1.6.2 trasladaba ese contexto al prompt. Desde 1.6.13, la trayectoria se consulta solo en
la interfaz local mediante tarjetas o tabla; el prompt semestral recibe únicamente el currículo del
nivel seleccionado y las decisiones docentes explícitas.

Se añadió un importador técnico reproducible para futuras actualizaciones controladas. No existe un
botón docente para cargar Excel y no se incorporaron datos personales, red, backend o analítica.
El esquema JSON continúa en v6 y las exportaciones oficiales no reciben la referencia de progresión.

Justificación: la mejora permite a PIA transferir a la IA una lectura horizontal entre niveles y
vertical dentro de cada área, respetando la gradualidad curricular y el criterio profesional, sin
alterar el planeamiento validado ni transformar una referencia pedagógica en evidencia de logro.

Resultado: 85/85 pruebas automatizadas aprobadas; 235/235 registros curriculares relacionados;
`PNFT_DATA`, `RDA_POR_CICLO`, Preescolar, Proyecto, guardado/carga, PDF, Word y portable conservados.

## Entrada 011 — 2026-09-04 — PIA Modular 1.6.3

Durante la explicación de una proyección de 9.º se detectaron dos riesgos de interpretación. La
etiqueta “fundamento explícito previo” podía hacer pensar que PIA comprobaba la enseñanza o el
aprendizaje de años anteriores; además, los niveles intermedios de Domótica aparecían en orden
inverso (`8.º → 7.º`). También se aclaró que la ausencia de proyección después de 9.º corresponde
al límite del catálogo actual y no al final de la continuidad educativa.

Se reformularon las etiquetas, se ordenaron cronológicamente los niveles intermedios y se fortaleció
el contrato del prompt: el currículo del nivel seleccionado gobierna toda la propuesta; los
antecedentes son expectativas curriculares no comprobadas y deben validarse mediante diagnóstico.

Justificación: evita que asesores, docentes o una IA confundan progresión curricular con evidencia
de ejecución o aprendizaje, y garantiza que una proyección de 9.º desarrolle íntegramente 9.º.

Resultado: 86/86 pruebas automatizadas aprobadas; no se modificaron currículo oficial, JSON v6,
semanas, Proyecto, PDF, Word, portable ni componentes del proyecto independiente PIA 1.7.0.

## Entrada 012 — 2026-09-04 — PIA Modular 1.6.4

La revisión con perspectiva de una persona docente nueva evidenció que la trayectoria era correcta,
pero estaba escrita como una auditoría técnica. Las expresiones “continuidad curricular intermedia”,
los estados `N/A`, “Sin niveles intermedios” y los separadores `/` aumentaban la carga cognitiva y
dificultaban reconocer qué debía planearse realmente.

Se reorganizó la salida en tres decisiones: AHORA muestra el currículo obligatorio del nivel actual;
ANTES ofrece referencias para diagnóstico sin confirmar aprendizaje; DESPUÉS explica la continuidad
sin trasladarla al semestre vigente. Las referencias separadas por niveles no aplicables se rotulan
como no continuas y no como prerrequisitos directos.

Durante la validación se detectó además que una familia puede contener varios saberes del mismo nivel.
Por ejemplo, la familia Domótica incluye Domótica y Prototipos. Se protegió la selección para que, si
la persona marca únicamente Domótica, el bloque AHORA no incorpore Prototipos como obligatorio.

Justificación: convierte una estructura útil para la IA en una explicación comprensible para un
docente nuevo, mantiene el control profesional y evita ampliar silenciosamente el currículo elegido.

Resultado: 88/88 pruebas automatizadas aprobadas; currículo oficial, JSON v6, semanas, Proyecto,
guardado/carga, PDF, Word y portable permanecen sin cambios.

## Entrada 013 — 2026-09-04 — PIA Modular 1.6.5

La revisión de una respuesta generada para 5.º evidenció que el prompt mencionaba Proyecto incluso
cuando el perfil no lo permitía. El análisis posterior de las Orientaciones generales 2026 y la Guía
docente de Preescolar confirmó que no bastaba con ocultar Proyecto: Preescolar necesita un contrato
propio, porque su evaluación es diagnóstica y formativa, su mediación prioriza experiencias lúdicas,
sensoriales, concretas y guiadas, y sus 80 minutos pueden impartirse continuos o fraccionados.

Se incorporaron al catálogo aislado las cuatro competencias específicas y el perfil de salida por
área de Preescolar. El prompt recibe solamente las áreas elegidas y puede comprobar la relación
indicador → RdA → perfil → competencia, sin afirmar que la planificación demuestra aprendizaje.

Cada experiencia semanal debe tener propósito, inicio, exploración o juego guiado, aplicación y
cierre propio, aunque el aprendizaje mantenga continuidad entre semanas. No se impone una cantidad
mínima de áreas, saberes o indicadores: la integración debe ser auténtica y adecuada al desarrollo
infantil; el trabajo individual de un saber requiere una razón pedagógica.

Proyecto se omite completamente en Preescolar, I y II Ciclo. En III Ciclo desactivado permanece la
advertencia “Componente Proyecto no seleccionado”; al activarlo se conservan la ruta, las modalidades
y los indicadores ya validados. El catálogo de instrumentos se filtra para que Preescolar reciba
solo funciones diagnósticas y formativas.

Justificación: reduce ruido, evita transferir reglas de secundaria o evaluación sumativa a
Preescolar y permite auditar la contribución de la propuesta al RdA y al perfil de salida.

Resultado: 92/92 pruebas automatizadas aprobadas; itinerarios 6/8/8/10, saberes, indicadores, RdA,
JSON v6, semanas, guardado/carga, PDF, Word, portable y el proyecto independiente PIA 1.7.0 protegidos.

## Entrada 014 — 2026-09-06 — PIA Modular 1.6.8 integral

### Situación que motivó la mejora

La revisión de PIA con perspectiva de uso nacional confirmó que la herramienta ya protegía el currículo,
la proyección, las semanas, Proyecto, Preescolar y las exportaciones. Persistían, sin embargo, cuatro
brechas de experiencia: la aplicación abría directamente sobre una plantilla extensa; la contextualización
dependía casi por completo de texto libre; un contexto que requiriera un indicador de otro nivel no tenía
una ruta controlada; y una edición del prompt podía no resultar suficientemente visible o segura para una
persona usuaria nueva.

También se identificaron mejoras puntuales: permitir hasta cuatro lecciones de diagnóstico, mantener el
escudo institucional alineado y con dimensiones estables, y conservar la barra de formato cerca del texto
sin invadir los campos editables.

### 1. Portada de entrada

Se especificó una portada institucional MEP–PNFT–PIA con **Iniciar planeamiento**, **Cargar planeamiento**
y una preferencia local para omitirla. La ruta de carga debe reutilizar el proceso validado de migración,
no crear una carga paralela. Regresar a la portada es exclusivamente navegación y no reinicia el estado.

**Justificación:** ofrece orientación antes de una plantilla amplia, reduce el impacto visual inicial y
permite que una persona docente nueva identifique inmediatamente las dos acciones principales. La portada
queda fuera de PDF y Word porque no pertenece al formato oficial de planeamiento.

### 2. Identidad institucional

Se mantuvo la decisión previa de conservar solamente escudo y lema opcionales. Se formalizó su alineación
a la izquierda y la obligación de controlar el tamaño del escudo en web y Word. El nombre del centro no se
repite porque ya pertenece al encabezado administrativo oficial.

**Justificación:** mejora la jerarquía visual y evita duplicidad administrativa sin modificar el formato MEP.

### 3. Diagnóstico ampliado

El rango previsto pasa de un máximo de dos a un máximo de cuatro lecciones. El valor debe reflejarse en el
marco temporal, el momento de las semanas iniciales y el prompt. Cambiarlo no distribuye currículo ni elimina
información previamente escrita.

**Justificación:** algunos grupos requieren dos bloques semanales de diagnóstico. La flexibilidad responde
al contexto real y evita que PIA imponga una duración única, manteniendo la diferencia entre diagnóstico,
actividad realizada y aprendizaje demostrado.

### 4. Contextualización y DUA opcional

Se conservaron los tres campos abiertos: características del grupo, recursos/conectividad y apoyos DUA.
Sobre esa base se definieron opciones estructuradas: perfil de implementación, condiciones complementarias,
escenario tecnológico y punto de partida grupal. La sección permanece plegable y opcional.

Los perfiles contemplados son Regular, Aula Edad, aulas integradas, III Ciclo y Ciclo Diversificado
Vocacional y EPJA. Las condiciones permiten registrar diversidad de niveles, acceso y participación,
multigrado, enriquecimiento, contexto sociocultural o lingüístico, contexto indígena, continuidad flexible,
tecnología limitada y apoyos curriculares sujetos a procedimiento institucional.

**Justificación:** un selector estructurado transmite a la IA únicamente el contexto pertinente y disminuye
omisiones, pero los campos abiertos conservan el criterio profesional. PIA no solicita nombres, expedientes
ni diagnósticos individuales. Un perfil de implementación no sustituye el nivel administrativo ni autoriza
inventar una distribución evaluativa.

### 5. Escenario tecnológico

Se definió una clasificación práctica: equipos e Internet suficientes, conectividad limitada, dispositivos
sin Internet, equipos compartidos, un equipo demostrativo, ausencia de dispositivos, kits de robótica y
descripción abierta. El prompt debe pedir alternativas equivalentes desconectadas.

**Justificación:** “sin tecnología” no describe una sola realidad. Diferenciar escenarios permite proponer
mediaciones viables sin reducir la intención curricular ni convertir una carencia de recursos en una menor
expectativa de aprendizaje.

### 6. Referencias curriculares controladas del PNFT

Se diseñó una ruta para incorporar, cuando existe justificación, un indicador de otro nivel. La selección
debe provenir del catálogo autorizado: nivel, módulo, área, saber e indicador. PIA conserva literalmente el
texto y registra por separado procedencia, motivo y contextualización docente.

La persona docente decide en qué semana incorporarlo. La referencia puede desmarcarse sin borrar su registro,
se conserva en JSON/autoguardado y se integra en la columna de logro de PDF y Word cuando está seleccionada.

**Justificación:** atiende Aula Edad, apoyos significativos u otros contextos sin permitir que texto libre se
presente como currículo oficial. La referencia no cambia el nivel administrativo y no demuestra que el
aprendizaje previo se haya alcanzado; toda decisión sujeta a procedimiento institucional debe indicarse.

### 7. Persistencia explícita de prompts

Se especificó un ciclo visible para los prompts General, Semestral y Semanal: borrador independiente,
estado pendiente/guardado/actualizado, **Guardar cambios del prompt**, **Actualizar desde PIA** y
**Restablecer propuesta generada**. Actualizar o restablecer requiere confirmación antes de sustituir texto.

La escritura debe capturarse antes de cerrar el diálogo. El JSON, el autoguardado y la versión portable deben
preservar literalmente los tres prompts. Copiar o abrir ChatGPT/Copilot no equivale a guardar y no envía el
texto automáticamente.

**Justificación:** la contextualización escrita por la persona docente es parte de su trabajo intelectual.
Hacer visible el estado elimina incertidumbre y evita que una regeneración silenciosa reemplace instrucciones
que no forman parte de la plantilla original.

### 8. Contrato contextual para IA

El prompt debe incluir únicamente las condiciones seleccionadas; diferenciar currículo vigente del PNFT,
referencia de otro nivel y texto docente; solicitar apoyos DUA y alternativas desconectadas; evitar
estereotipos; y rotular “requiere validación institucional” cuando una decisión dependa del comité, dirección,
asesoría o procedimiento aplicable.

**Justificación:** PIA no puede asumir contexto, modalidad ni adecuación. La IA propone; PIA estructura y
protege; la persona docente valida y decide.

### 9. Formato contextual conservado

La barra incorporada en 1.6.7 permanece exclusiva de Estrategias de mediación e Indicadores de evaluación.
Conserva la selección, identifica el campo, mantiene opciones secundarias plegadas y aplica vínculos HTTPS
saneados. Los Indicadores de logro del currículo de FT continúan protegidos.

**Justificación:** la versión integral no debe retroceder en la edición semanal ni introducir controles que
obstruyan la escritura.

### 10. Compatibilidad y límites

Se mantuvieron como contratos inalterables el currículo del PNFT, el encabezado administrativo, Preescolar,
Proyecto, progresión interna, filtro semanal, cobertura no exportable, JSON compatible, Word/PDF, portable y
el puente backend inactivo. PIA 1.7.x y el Mapa de Trayectoria continúan como proyecto independiente.

### 11. Documentación y validación

Se actualizaron `AGENTS.md`, `SPEC.md`, `info.md`, `README.md`, `CHANGELOG.md`, el manual funcional y el
manual técnico. Se creó `INFORME_VALIDACION_V1.6.8.md` como borrador con matriz de pruebas y casos críticos.

**Estado de cierre:** implementación construida desde `src/` y 103/103 pruebas automatizadas aprobadas.
La revisión humana multinavegador, apertura portable y Word permanece como control de aceptación previo
al despliegue institucional; no se confunde la cobertura automatizada con validación pedagógica de campo.
