# Contrato de progresión curricular — PIA 1.6.2

> Documento histórico actualizado por PIA 1.6.13. Las reglas activas de semántica de vacíos y uso
> exclusivamente local de la trayectoria prevalecen sobre el alcance original de 1.6.2.

## Propósito

Enseñar a PIA que los saberes conceptuales registrados por nivel, módulo y área también forman
familias de progresión. La relación permite explicar qué fundamentos preceden al nivel actual,
cuál es su alcance y hacia dónde continúa, sin sustituir el currículo oficial.

## Fuentes y trazabilidad

- Matriz principal: `Saberes por Año Escolar julio -2026.xlsx`, SHA-256
  `8889390a01bd93b3478441da2ff7cc5a73c5ee53a67e66bc310c2229105672c8`.
- Ejemplo asesor de lectura de indicadores: `Ejemplo de escalabilidad de los indicadores (1) 1.xlsx`,
  SHA-256 `ae7c3a8dbf073a571497182036759cec8b9c12644d9a43d49ddb2cf848e1bd71`.
- El ejemplo sirve para comprender dimensiones de progresión; no sustituye `PNFT_DATA` ni autoriza
  cambios de redacción curricular.

## Modelo relacional

Cada familia contiene un identificador estable, área, denominación, saber general y un estado por
nivel desde `0°` hasta `9°`. PIA relaciona cada saber vigente por la clave compuesta
`área + nombre normalizado`; no utiliza inferencias aproximadas durante la ejecución.

Los estados vigentes son:

| Estado interno | Lectura curricular | Consecuencia para PIA |
| --- | --- | --- |
| `explicit-evaluable` | Existe alcance explícito para el nivel. | Puede contextualizar el indicador oficial ya seleccionado. |
| `conceptual-non-evaluable` | Una fuente oficial registra presencia conceptual sin indicador directo. | Puede mostrarse en la consulta local; no crea indicador, instrumento ni evidencia de logro. |
| `reinforced-non-evaluable` | Una fuente oficial registra explícitamente fortalecimiento no evaluable. | Puede mostrarse en la consulta local; no se deduce de una celda vacía. |
| `no-curricular-record` | La celda está vacía y no documenta tratamiento conceptual para el nivel. | No permite inferir enseñanza, refuerzo, evaluación o dominio. |
| `not-applicable` | La matriz indica `N/A`. | No se presenta como alcance del nivel. |

## Salvaguardas obligatorias

1. No modificar textos ni correspondencias de `PNFT_DATA`, `RDA_POR_CICLO` o Preescolar.
2. No reemplazar el indicador oficial seleccionado por texto de la matriz de progresión.
3. No convertir una celda vacía en indicador, evaluación, calificación o evidencia de aprendizaje.
4. No afirmar que lo proyectado o ejecutado demuestra dominio, perfil alcanzado o cumplimiento del RdA.
5. No seleccionar saberes ni escribir automáticamente en las semanas.
6. No exportar la referencia relacional a PDF o Word.
7. No añadir carga de Excel a la interfaz docente.
8. Todo saber nuevo o renombrado debe quedar sin resolver y provocar una prueba fallida hasta recibir
   una correspondencia revisada.

## Alcance histórico de 1.6.2 y corrección vigente

En 1.6.2 la referencia se incorporaba al prompt semestral. Desde 1.6.13, los antecedentes y las
continuidades se muestran exclusivamente en la consulta interactiva local y no se transfieren a la
IA. El prompt usa el currículo oficial del nivel seleccionado y las decisiones expresas de la
persona docente.

PIA 1.6.2 no incorpora el Mapa de Trayectoria, la ventana ni la arquitectura del proyecto PIA 1.7.0.
