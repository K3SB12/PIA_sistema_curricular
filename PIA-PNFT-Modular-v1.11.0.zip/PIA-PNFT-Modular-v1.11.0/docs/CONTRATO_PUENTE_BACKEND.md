# Contrato del puente backend — estado inactivo

PIA 1.4.0 no tiene backend. `PIAIntegrationBridge` reserva dos puertos futuros:

- `repository.save(plan)` y `repository.load(id)`: rechazan con “Backend no configurado”.
- `analytics.track(event)`: devuelve `false` y no almacena ni transmite nada.

Una implementación futura debe inyectarse sin cambiar el dominio, mantener el repositorio local,
usar revisiones y excluir datos del estudiantado. La activación requiere aprobación independiente
de seguridad, privacidad, autenticación, respaldo, retención, auditoría y migración. No deben
existir endpoints ni credenciales en el HTML.
