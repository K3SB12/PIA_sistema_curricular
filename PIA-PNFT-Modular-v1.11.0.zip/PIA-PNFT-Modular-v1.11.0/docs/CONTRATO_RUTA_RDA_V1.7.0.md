# Contrato curricular — Ruta hacia el RdA 1.7.0

## Propósito

La Ruta muestra cómo se organizan los saberes y los indicadores oficiales a través de los niveles y
cómo se vinculan estructuralmente con el RdA del área y ciclo. Es una referencia curricular local de
solo lectura. No confirma que un aprendizaje haya sido enseñado, alcanzado o evaluado ni certifica el
cumplimiento del RdA.

## Dos capas que nunca se confunden

| Capa | Significado | Rótulo permitido |
|---|---|---|
| `structural-link` | El indicador pertenece a un nivel, módulo y área cuyo ciclo contiene el RdA mostrado. | Vinculado al RdA del área y ciclo. |
| `validated-contribution` | Una autoridad curricular aprobó documentalmente una correspondencia pedagógica. | Correspondencia pedagógica validada. |

Si no existe una relación aprobada, PIA muestra **Correspondencia pedagógica pendiente de validación
curricular**. Compartir palabras, área o ciclo no autoriza a completar esa correspondencia.

## Estados curriculares

| Estado | Lectura protegida |
|---|---|
| `explicit-evaluable` | Desarrollo curricular con saber e indicador oficial. |
| `conceptual-non-evaluable` | Presencia conceptual sin indicador directo, únicamente con fuente expresa. |
| `reinforced-non-evaluable` | Fortalecimiento sin evaluación directa, únicamente con fuente expresa. |
| `no-curricular-record` | Sin abordaje conceptual registrado; no se infiere refuerzo, dominio ni rezago. |
| `not-applicable` | El saber no corresponde al nivel según la fuente. |
| `area-absent` | El área no forma parte de la combinación nivel–módulo; no genera deuda ni alerta. |

## Antes, Ahora y Después

- **ANTES:** referencia curricular anterior para una posible exploración diagnóstica; no confirma
  enseñanza ni aprendizaje.
- **AHORA:** currículo del nivel, módulo y área seleccionados. Es el único alcance que corresponde
  planificar.
- **DESPUÉS:** continuidad curricular informativa; no se adelanta como contenido obligatorio actual.

Al cruzar de ciclo, cada nodo conserva el RdA de su propio ciclo. Un indicador de un ciclo anterior o
posterior nunca se cuenta como evidencia del RdA actual.

## Reglas del RdA

1. El texto oficial se conserva completo y literal.
2. PIA no crea facetas, paráfrasis, pesos, porcentajes ni indicadores nuevos.
3. Un indicador no es suficiente por sí solo para concluir el RdA.
4. Cobertura y planeamiento no equivalen a aprendizaje demostrado.
5. La valoración del RdA requiere evidencias acumuladas y criterio profesional docente.
6. Una relación validada conserva fuente, localizador, versión, autoridad, fecha e identidad literal
   del indicador y RdA.
7. Un cambio en la fuente invalida la revisión y obliga a validarla nuevamente.

## Casos protegidos

- Una denominación repetida puede tener distinta profundidad. Se comparan demanda cognitiva, alcance,
  representación, contexto y autonomía, sin asumir equivalencia.
- Una celda vacía no significa fortalecimiento.
- `N/A` y área ausente no generan indicadores, pendientes o alertas.
- Los saberes procedimentales y actitudinales se integran en las experiencias pertinentes; no se
  convierten automáticamente en indicadores conceptuales.
- Preescolar conserva por separado los itinerarios Básico requerido y Óptimo, con evaluación
  diagnóstica y formativa.

## Límite técnico

La Ruta no escribe ni modifica `PNFT_DATA`, `RDA_POR_CICLO`, Preescolar, semanas, proyección, prompts,
diagnóstico, Proyecto, JSON, autoguardado, PDF o Word. Mantiene `schemaVersion: 6`.

## Validación humana

Una correspondencia pedagógica solo puede aprobarse cuando indicador y RdA coinciden literalmente
con la fuente, pertenecen al mismo ciclo y área, la justificación respeta la profundidad del nivel y
la revisión identifica fuente, autoridad y fecha. Los desacuerdos permanecen como pendientes o por
resolver; PIA no decide por promedio ni mediante IA.
