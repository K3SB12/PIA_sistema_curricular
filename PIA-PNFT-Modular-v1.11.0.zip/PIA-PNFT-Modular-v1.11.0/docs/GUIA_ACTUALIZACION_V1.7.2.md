# Guía breve de uso — PIA 1.7.2

## 1. Preparar el diagnóstico

1. Seleccione ciclo, nivel, módulo, áreas, saberes y una o dos lecciones.
2. Abra **Preparar diagnóstico** y defina si trabaja como asesoría o aplicación docente.
3. Seleccione los aprendizajes previos por explorar. Si utiliza un indicador de otro nivel como referente, agréguelo con su procedencia; no se convierte en currículo vigente ni confirma aprendizaje.
4. Elija una técnica y un instrumento o solicite una recomendación razonada a la IA. La técnica obtiene evidencia; el instrumento la registra.
5. Revise las áreas cognoscitiva, socioafectiva y psicomotora. Se observan integradas cuando sean pertinentes; no son tres pruebas.
6. Genere el prompt. La respuesta debe incluir experiencia, consignas, evidencias, DUA, tiempos e instrumento completo en blanco.
7. Pegue la respuesta en **Revisar la respuesta de la IA**, verifique su coherencia y autorice su incorporación al modelo Word solo si es adecuada.
8. Descargue el modelo, aplíquelo y complete fortalezas, aspectos por fortalecer, decisiones y seguimiento únicamente con evidencia real.

El modo asesor bloquea los campos de resultados observados. PIA no asigna calificación, no inventa datos y no sustituye el criterio docente.

## 2. Vincular el diagnóstico con el planeamiento

La opción **Vincular con la semana 1** envía la decisión a los prompts semestral y semanal. No sobrescribe la mediación. La persona docente decide qué parte de la experiencia diagnóstica incorpora al inicio, desarrollo y cierre de la semana.

## 3. Coordinar metodología y Proyecto en secundaria

PIA ofrece cuatro decisiones:

- **Pensamiento de Diseño como ruta común:** APD organiza currículo y Proyecto sin crear un segundo planeamiento.
- **APD con recurso complementario puntual:** un reto, juego o dinámica apoya una fase, pero no se presenta como ABR o ABJ completos.
- **Metodologías completas en secuencia:** una ruta concluye antes de iniciar la otra; requiere especial revisión temporal.
- **Metodologías completas coordinadas:** se declaran fases, puentes, evidencias y procesos que no deben repetirse.

ABR completo comprende **Comprender, Investigar y Actuar**. ABJ requiere objetivo de aprendizaje, reto, reglas, participación, realimentación y valoración. Inicio, desarrollo y cierre son momentos didácticos, no fases metodológicas sustitutas.

Si declara una ventana de semanas para el Proyecto, PIA la contrasta con el periodo disponible. El dato es una decisión docente, no un mínimo o máximo oficial incorporado por PIA.

En una secuencia separada, PIA calcula: semanas de diagnóstico + semanas de la segunda metodología + semanas de Proyecto y muestra el margen. Por ejemplo, en 17 semanas: 1 + 3 + 8 deja 5; 1 + 4 + 10 deja 2; y 1 + 4 + 12 deja 0. Un margen cero no prueba automáticamente que el planeamiento sea imposible, pero obliga a revisar interrupciones, exploración, práctica, profundidad, realimentación y evaluación. Si la suma excede el periodo, PIA lo indica expresamente.

La relación no puede ser nominal. La revisión debe seguir la cadena metodología → saberes → indicadores → RdA → competencias específicas → perfil de salida. Si no existe relación pedagógica con el Proyecto, PIA solicita ajuste y prohíbe forzar una integración ficticia.

## 4. Interpretar el tiempo

El bloque oficial se mantiene en **80 minutos**. El campo de minutos efectivos permite simular de manera preventiva una realidad menor, por ejemplo 60 minutos. PIA muestra ambos balances por separado. El escenario preventivo no modifica la carga oficial, no autoriza eliminar currículo y no certifica viabilidad.

## 5. Responsabilidad profesional

PIA estructura información, conserva literalidad y formula alertas. La IA propone una secuencia. La persona docente o asesora revisa profundidad, integración, tiempo, evidencias, DUA, evaluación y contexto; confirma, ajusta o descarta la propuesta.
