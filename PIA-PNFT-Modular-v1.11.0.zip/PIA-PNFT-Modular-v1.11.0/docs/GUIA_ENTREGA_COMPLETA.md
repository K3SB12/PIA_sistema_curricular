# Guía de la entrega modular completa de PIA-PNFT

Versión: **PIA-PNFT Modular 1.6.12**.

## Cambios de entrega 1.6.12

- **Explorar trayectoria curricular** abre una vista local después de seleccionar saberes conceptuales.
- Los filtros cromáticos permiten concentrarse en una de las cuatro áreas del PNFT; cada familia puede
  expandirse para leer ANTES, AHORA y DESPUÉS.
- ANTES y DESPUÉS son referencias oficiales de continuidad. AHORA contiene solo lo seleccionado.
  Fortalecimiento sin evaluación y ausencia en la trayectoria se presentan como estados distintos.
- La vista no cambia semanas, módulos, saberes, indicadores, JSON ni exportaciones.
- El prompt semestral revisa su viabilidad temporal después de construir la matriz y evita alertas por
  conteos aislados. La etapa `development` se muestra como **Etapa de desarrollo**.
- La verificación completa requiere 127 pruebas aprobadas; la revisión manual en Edge/Chrome permanece pendiente.

## Cambios de entrega 1.6.11

- **Preparar evaluación diagnóstica** aparece después de Saberes; el selector de lecciones continúa
  en Marco temporal y el diagnóstico no condiciona la proyección semestral.
- La acción se habilita con ciclo, nivel, módulo, área, saber conceptual y una o dos lecciones.
- Los botones de ayuda contextual explican términos bajo demanda mediante mouse, teclado o toque.
- Las ayudas son efímeras, se muestran de una en una y no forman parte de JSON, prompts o exportaciones.
- La verificación completa requiere 120 pruebas aprobadas y revisión manual final en Edge o Chrome.

## Cambios de entrega 1.6.7

- La selección de texto en Mediación o Evaluación abre la barra contextual de la semana.
- La barra conserva el rango seleccionado, identifica el campo activo y permanece accesible durante
  el desplazamiento. Las opciones adicionales están plegadas para reducir ruido visual.
- Los subtítulos Inicio, Desarrollo y Cierre se restringen a Mediación. El pegado limpio es opcional
  y los vínculos aceptados deben comenzar con `https://`.
- Los Indicadores de logro del currículo de FT no se vuelven editables ni reciben formato.
- La verificación completa requiere 96 pruebas aprobadas y revisión manual en Edge/Chrome.

## Cambios de entrega 1.6.2

> Registro histórico superado por la corrección 1.6.13: una celda vacía indica ausencia de registro
> curricular y no permite inferir refuerzo, enseñanza o evaluación.

- El prompt semestral incorpora una referencia de progresión para los saberes seleccionados.
- El catálogo interno relaciona 235 registros con 38 familias, sin modificar currículo oficial.
- En esa versión se interpretó el vacío como refuerzo; la versión 1.6.13 corrige esa inferencia.
- La mejora no agrega interfaz, mapa, importación docente ni funciones de PIA 1.7.0.
- La verificación completa requiere 85 pruebas aprobadas.

## Cambios de entrega 1.6.0

- Los planes nuevos usan JSON v6 y cargan versiones anteriores.
- Los prompts general, semestral y semanales editados se conservan al guardar y cargar.
- Prototipar y Probar/Evaluar aceptan textos docentes no oficiales y los trasladan a las semanas,
  PDF y Word cuando corresponde.
- Mostrar/Ocultar proyección solo modifica la vista.
- La verificación requiere `npm test` y revisión manual en Edge o Chrome de JSON, Word, PDF y portable.

Esta entrega conserva el funcionamiento de PIA en un único HTML ejecutable, pero organiza su
código fuente por responsabilidades para facilitar mantenimiento, pruebas y evolución futura.

## Código editable

| Ruta | Responsabilidad |
|---|---|
| `src/data/` | Datos PNFT, Preescolar, centros y catálogo relacional de progresión. |
| `src/domain/curriculum/` | Operaciones curriculares y consulta de progresión. |
| `src/domain/institution/` | Normalización y consulta local por código presupuestario. |
| `src/domain/planning/` | Estado del planeamiento y operaciones de semanas. |
| `src/application/` | Inicialización y coordinación de los servicios de PIA. |
| `src/infrastructure/persistence/` | Carga y guardado local del planeamiento. |
| `src/infrastructure/export/` | Exportación PDF y construcción de la versión portable. |
| `src/prompts/` | Generación de prompts general y semanal. |
| `src/ui/` | Construcción visual de semanas y notificaciones. |
| `src/styles/` | Estilos separados por área visual. |
| `src/templates/` | Estructura HTML separada por secciones. |

## Construcción

Desde la carpeta raíz, ejecute:

```bash
npm run build
```

El constructor usa `scripts/fragment-manifest.mjs` para ensamblar los fragmentos en el orden
compatible y genera tres salidas equivalentes:

- `index.html`
- `dist/web/index.html`
- `dist/portable/index.html`

## Pruebas

```bash
npm test
```

La comprobación valida la fuente, construye las salidas, limita las diferencias autorizadas y
prueba la eliminación consecutiva de las semanas 8 y 7, el selector Word, la vista continua,
la descarga `.doc`, la impresión, el ciclo de guardado y carga JSON, la migración v1/v2→v3,
los perfiles de evaluación, los RdA visibles, la cobertura semanal, el navegador, el formato local
y el contrato del prompt.

En 1.6.11 también valida la secuencia visual del diagnóstico, sus requisitos de apertura sin bloqueo
semestral y la disponibilidad, accesibilidad y exclusión de impresión de las ayudas contextuales.

En 1.6.12 valida además la trayectoria por familias, la literalidad de indicadores, la separación de
fortalecimiento y ausencia, la selección protegida de AHORA, la auditoría temporal y la localización del Proyecto.

En 1.6.2 también valida las 38 familias, las cuatro áreas, los diez niveles, la correspondencia
exacta de los 235 registros y la prohibición de evaluar directamente un refuerzo sin indicador.

En 1.4.0 también valida los cuatro itinerarios de Preescolar, los conteos del catálogo de centros,
la exclusión de `0000`, la resolución única/ambigua, la privacidad del catálogo, la persistencia
interna de `codSaber` y la metodología como andamiaje continuo.

## Ejecución directa

Para utilizar PIA sin Node.js ni servidor, abra `dist/portable/index.html` en Microsoft Edge o
Google Chrome. Para GitHub Pages, mantenga `index.html` en la raíz del repositorio.

## Exportar Word

1. Presione **Exportar**.
2. Seleccione **Word editable**, situado a la par de PDF.
3. Presione el botón morado **Exportar**.
4. Revise el planeamiento en la vista continua.
5. Use **Guardar Word** para descargar el `.doc`, o **Imprimir** para abrir el diálogo del sistema.

El archivo `.doc` es HTML compatible con Microsoft Word y otros procesadores de texto. Declara el
papel A4 en orientación horizontal y permite distribuir encabezados largos en varias líneas. No
contiene saltos de página forzados; el programa aplica su paginación natural al imprimir. El
navegador debe permitir ventanas emergentes. Si las bloquea, PIA descarga el Word directamente
como respaldo.

Las pruebas Node verifican el flujo y la estructura, pero no sustituyen la comprobación final en
Chrome o Edge de ventanas emergentes, diálogo de impresión y ubicación de descargas.

## Protección

`reference/index.original.html` y `reference/index.received.html` son referencias históricas y no
deben editarse ni generarse nuevamente desde `src/`. La carpeta `server/` está reservada para un
backend futuro y no representa un backend implementado en esta versión.

## Recorrido 1.4.1

1. Abra `dist/portable/index.html` en Edge o Chrome.
2. Complete identidad opcional y encabezado oficial. Al escribir el código presupuestario, PIA
   completa el centro si existe una coincidencia única. Si varias sedes comparten código,
   seleccione explícitamente la correcta.
3. Seleccione ejes, metodología y contexto/DUA.
4. Configure el periodo, módulo(s), áreas, saberes y perfil de evaluación.
   **Itinerario de preescolar** solo aparece en Materno Infantil/Transición con nivel `0°`.
5. Consulte los RdA y saberes; use el prompt semestral solo si necesita una referencia externa.
6. Complete manualmente las semanas oficiales con el navegador anterior/siguiente o el selector.
7. Sombree texto en Mediación o Indicadores de evaluación para abrir la barra contextual, o use
   **Formato** manualmente. Las opciones habituales quedan visibles y las restantes en **Más opciones**.
8. Consulte Cobertura para comparar la Proyección con las semanas ya completadas.
9. Guarde JSON y exporte PDF o Word; estos formatos oficiales no incluyen Proyección ni Cobertura.

## Actualización técnica del catálogo de centros

La persona docente no debe subir archivos Excel. Cuando la institución entregue una actualización,
un desarrollador ejecuta desde la raíz:

```bash
node scripts/import-centers.mjs "ruta/Asesores-Centros.xlsx" src/data/institutional-centers.js
npm test
```

El importador exige las columnas `centro`, `cod_saber` y `cod_pres`; elimina `0000`, conserva
cuatro cifras y detiene la actualización si falta información o se repite un `cod_saber`.
# Nota de entrega 1.2.0

Además del flujo validado de PIA 1.1.1, la entrega incluye herramientas avanzadas, JSON v2 y
documentación específica en `MANUAL_FUNCIONAL_V1.2.0.md`, `MANUAL_TECNICO_V1.2.0.md` e
`INFORME_VALIDACION_V1.2.0.md`. El backend continúa fuera de alcance; su puente está inactivo.
