# Guía de la experiencia formativa — PIA 1.6.14

## Propósito

“Explorar un ejemplo de planeamiento” acompaña a docentes y personas asesoras que empiezan a utilizar PIA. Presenta una posible forma de relacionar los componentes del PNFT y las funciones de PIA. No crea un plan, no modifica el plan abierto y no reemplaza el criterio profesional docente.

## Cómo ingresar

En la portada, seleccione **Explorar un ejemplo de planeamiento**. Puede comenzar el recorrido, retomar su avance local o elegir directamente un tema. **Volver a PIA** cierra la experiencia y conserva el planeamiento.

## Los siete momentos

1. **El horizonte:** consulta nivel, áreas presentes, RdA e indicadores completos.
2. **El punto de partida:** compara contextos y explica el diagnóstico pedagógico.
3. **La ruta curricular:** muestra profundidad y consulta Antes, Ahora y Después.
4. **Vivir la metodología:** abre los laboratorios de ABJ, ABR y APD.
5. **Mirar el semestre:** relaciona continuidad, tiempo, proyección y prompts.
6. **Construir una semana:** integra saberes, ejes, acciones, apoyos y evidencias.
7. **Revisar y continuar:** ofrece una lista de revisión y explica cómo guardar.

Los números indican momentos de navegación. La persona puede cambiar de tema, regresar y repetir decisiones; no expresan grados escolares ni dominio.

## Tipos de información

- **Referente oficial:** texto consultado desde los catálogos de PIA, acompañado de su procedencia.
- **Ejemplo formativo:** situación ficticia que ilustra una posibilidad de mediación.
- **Decisión docente:** aspecto que cada persona valora y contextualiza según su grupo.

## Laboratorios metodológicos

- **ABJ — Taller de juegos:** objetivo, contenido, reto, normas, incentivos, realimentación y evaluación.
- **ABR — Misión comunidad:** Comprender, Investigar y Actuar. El escenario no impone un único reto semestral.
- **APD — Laboratorio de soluciones:** Empatizar, Definir, Idear, Prototipar y Probar/Evaluar, con posibilidad de regresar según la evidencia.

Cada laboratorio permite probar alternativas y leer sus implicaciones. La devolución no califica ni afirma que una opción sea la única posible.

## Preescolar, primaria y secundaria

El selector del ejemplo ajusta las explicaciones por nivel y ciclo. Preescolar conserva itinerarios, experiencias lúdicas concretas y evaluación diagnóstica/formativa. En primaria se muestra cómo la profundidad del indicador orienta la experiencia. En III Ciclo se añade la integración entre currículo y Proyecto, respetando etapas, indicadores, tiempo y evidencias.

## Protección del planeamiento

La experiencia no lee ni escribe semanas, mediación, evaluación, diagnóstico, Proyecto, prompts o archivos del plan. Su avance utiliza una clave local independiente. Tampoco aparece en JSON, PDF o Word. Al construir una plantilla portable, PIA elimina cualquier contenido transitorio del recorrido.

## Verificación realizada

- Fuente modular ensamblada y salidas byte a byte.
- Contratos de currículo, persistencia, Proyecto, evaluación y exportación.
- Apertura y cierre del recorrido.
- Navegación por siete vistas.
- Apertura de tres laboratorios.
- Preservación del plan durante la interacción.
- Ausencia de errores de consola en DOM ejecutable.

El navegador remoto disponible bloqueó la apertura de la URL local. Antes de publicar, se debe efectuar una prueba humana en Chrome o Edge de escritorio y móvil, revisando legibilidad, desplazamiento, navegación con teclado y toque, diálogos, cambio de nivel y regreso a PIA.

## Fuentes metodológicas incluidas

- Metodología activa Aprendizaje Basado en Juego, PNFT, enero de 2024.
- Metodología activa Aprendizaje Basado en Retos, PNFT, enero de 2024.
- Metodología activa Design Thinking, PNFT, enero de 2024.

Los PDF de referencia se conservan en `docs/fuentes/` dentro del paquete completo.
