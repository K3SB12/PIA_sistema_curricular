# Auditoría de entrada y trazabilidad — PIA 1.9.1

## Resultado

La entrada del organizador de III Ciclo conserva lo validado y distingue cuatro procedencias: currículo oficial protegido, información declarada por la persona docente, decisiones docentes editables y campos opcionales no aportados. Ningún campo opcional se completa por inferencia.

## Matriz de trazabilidad

| Elemento | Fuente o decisión | Visible en el control de entrada | Representación en el mapa | Llega al prompt semestral | Llega al análisis autónomo |
| --- | --- | --- | --- | --- | --- |
| Ciclo, nivel, módulo, áreas | Selección docente sobre catálogos oficiales | Sí | Raíz y nodos curriculares | Sí | Sí |
| Saberes conceptuales e indicadores | `PNFT_DATA`, texto protegido | Sí | Nodo seleccionable por saber | Sí, literal | Sí, literal |
| RdA por área | `RDA_POR_CICLO`, texto protegido | Sí | Destino orientador | Sí, literal | Sí, literal |
| Competencias y perfil de salida | Marco curricular oficial | Sí | Norte curricular | Sí | Sí |
| Descripción o propósito del módulo | Marco curricular oficial | Sí | Referente del norte curricular | Sí | Sí |
| Procedimentales y actitudinales | Selección docente sobre catálogos oficiales | Sí | Capa transversal | Sí | Sí |
| Ejes transversales | Selección docente | Sí | Capa transversal | Sí cuando se aportan | Sí cuando se aportan |
| Semanas, lecciones y minutos | Marco temporal | Sí | Raíz y calendario | Sí | Sí |
| Diagnóstico y hallazgos | Activación y datos docentes | Sí | Punto de partida | Solo si se activa | Solo si se activa; sin inventar resultados |
| Contexto, recursos y DUA | Registro opcional docente | Sí | Decisiones de entrada | Solo si se activa | Solo lo declarado; DUA general permanece |
| Proyecto y fases APD | Perfil confirmado y decisiones docentes | Sí | Rama de Proyecto | Sí cuando se activa | Sí |
| Indicadores de Empatizar, Definir e Idear | Catálogo oficial del componente Proyecto | Sí | Nodos oficiales protegidos | Sí | Sí |
| Prototipar y Probar/Evaluar | Indicadores oficiales del módulo vinculados | Sí | Fases sin contenido inventado | Sí, solo los vinculados | Sí, solo los vinculados |
| Función, grupo, fase, semanas, evidencia y nota | Decisión docente en el mapa | Sí | Nodos y conexiones | Sí | Sí |
| Perfil y ventanas evaluativas | Confirmación docente | Sí | Capa y calendario | Solo decisiones confirmadas | Solo decisiones confirmadas |
| Segunda metodología completa | Decisión excepcional | En su panel específico | No sustituye APD | Sí con auditoría de fases, puente y tiempo | Sí mediante el análisis de riesgos |

## Controles de seguridad curricular

- PIA mantiene una sola proyección para mediación curricular y Proyecto.
- La asignación de una función no declara dominio, logro del indicador, RdA alcanzado ni promoción.
- Los pendientes permanecen visibles y llegan al prompt; PIA no los omite ni decide por la persona docente.
- El bloque oficial se conserva en 80 minutos. El escenario operativo menor permanece separado, preventivo y no oficial.
- El diagnóstico no califica, no inventa hallazgos y no convierte los indicadores actuales en requisitos de entrada.
- Una evidencia no debe contabilizarse dos veces y una semana integrada no se suma como dos procesos.
- Las coordenadas, colores visuales y curvas SVG no modifican el currículo ni se guardan como contenido oficial.

## Pruebas de aceptación específicas

La suite `v1.9.1-concept-map-traceability.test.mjs` comprueba: grafo real, capas validadas, control de entrada, ejemplo de solo lectura, prompt completo y relaciones editables sin depender del color.

