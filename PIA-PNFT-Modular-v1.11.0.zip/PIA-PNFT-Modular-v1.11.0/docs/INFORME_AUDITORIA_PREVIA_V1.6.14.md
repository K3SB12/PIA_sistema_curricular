# Informe de auditoría integral de PIA-PNFT 1.6.14

**Fecha:** 13 de setiembre de 2026  
**Alcance:** Preescolar (0°) a 9.º, Módulos 1 y 2, áreas presentes, RdA, saberes, indicadores, metodologías, diagnóstico, contexto/DUA, evaluación, Proyecto, tiempo, persistencia y exportación.

## Dictamen ejecutivo

PIA 1.6.14 está bien estructurada como asistente local para organizar el planeamiento de Formación Tecnológica. Protege el currículo oficial, conserva la literalidad de los indicadores, diferencia información oficial, ejemplo y decisión docente, y mantiene a la persona docente como responsable de confirmar la contextualización, la secuencia, la evaluación y la viabilidad.

No es responsable afirmar todavía que PIA demuestra que todos los módulos caben pedagógicamente en cualquier semestre. La aplicación conoce semanas, lecciones, minutos, diagnóstico, periodos no lectivos, currículo seleccionado, Proyecto y perfil de evaluación; sin embargo, no existe una carga temporal oficial validada por indicador. La auditoría de IA es posterior y contextual: evalúa su propia propuesta, pero no constituye por sí sola una prueba curricular externa.

**Conclusión defendible:** PIA tiene cobertura funcional y curricular suficiente para apoyar el planeamiento; requiere fortalecer la validación temporal por casos completos, la paridad exhaustiva contra fuentes y dos controles de interfaz antes de presentarse como solución plenamente validada para toda combinación.

## Evidencia ejecutada

- 138 de 138 pruebas automatizadas aprobadas.
- Fuente, ensamblado y alcance autorizado aprobados.
- 235 registros curriculares relacionados con 38 familias, cuatro áreas y diez niveles.
- 20 combinaciones nivel–módulo con áreas, saberes, indicadores y RdA disponibles.
- Cero nombres vacíos, indicadores vacíos, saberes sin indicador o áreas presentes sin un RdA resoluble en el catálogo operativo.
- Las huellas SHA-256 del Excel maestro y del ejemplo de escalabilidad coinciden exactamente con las registradas en `curricular-progression.js`.
- Pendiente: validación humana real de interfaz en Chrome o Edge, escritorio y móvil.

## Matriz curricular observada

Los valores muestran **saberes/indicadores**. El conteo es una medida de densidad nominal, no una medida de tiempo ni de dificultad.

| Nivel | Módulo 1 | Áreas M1 | Módulo 2 | Áreas M2 |
|---|---:|---:|---:|---:|
| Preescolar | 6/6 | 2 | 12/12 | 4 |
| 1.º | 8/8 | 2 | 7/7 | 3 |
| 2.º | 9/9 | 2 | 8/8 | 3 |
| 3.º | 7/7 | 2 | 10/10 | 2 |
| 4.º | 13/13 | 2 | 16/16 | 3 |
| 5.º | 15/15 | 4 | 16/16 | 4 |
| 6.º | 10/10 | 3 | 17/17 | 2 |
| 7.º | 18/18 | 2 | 15/15 | 3 |
| 8.º | 16/16 | 3 | 12/12 | 4 |
| 9.º | 10/10 | 3 | 10/10 | 2 |

Las áreas ausentes se conservan como ausentes; no se completan artificialmente. El RdA está organizado oficialmente por ciclo y área, no como un resultado nuevo para cada grado. El indicador de cada saber expresa el escalón y la profundidad correspondientes al nivel.

## Variables que PIA debe relacionar para un planeamiento responsable

### 1. Identidad y marco administrativo

- Centro, docente, ciclo, nivel, módulo, semestre o periodo.
- Fechas aportadas, semanas lectivas efectivas, lecciones y minutos.
- Feriados, interrupciones y demás periodos no lectivos declarados.
- Perfil de evaluación compatible y cualquier validación institucional requerida.

### 2. Currículo vigente

- Áreas efectivamente presentes en el nivel y módulo.
- RdA del ciclo para cada área seleccionada.
- Saber conceptual e indicador oficial literal.
- Profundidad del indicador: acción o verbo, objeto, condición, representación, contexto, autonomía y finalidad.
- Saberes procedimentales y actitudinales que realmente se movilizan.
- Ejes transversales pertinentes, sin agregarlos por cumplimiento superficial.
- Itinerario Básico requerido u Óptimo en Preescolar, sin mezclar rutas.

### 3. Progresión y trayectoria

- ANTES como expectativa curricular no comprobada y posible referente diagnóstico.
- AHORA como alcance obligatorio seleccionado del nivel vigente.
- DESPUÉS como continuidad informativa, nunca como contenido que deba adelantarse.
- Diferencia entre desarrollo explícito, presencia conceptual sin indicador, celda vacía, N/A y área ausente.
- Relación horizontal y vertical entre familias, sin sustituir `PNFT_DATA`, RdA o indicadores.

### 4. Contexto y accesibilidad

- Evidencia diagnóstica grupal disponible, sin datos personales.
- Edad, desarrollo, autonomía, intereses y apoyos DUA pertinentes.
- Conectividad, cantidad de equipos, equipos compartidos, un equipo demostrativo, ausencia de dispositivos y recursos de robótica.
- Alternativa desconectada equivalente que conserve la intención de aprendizaje.
- Seguridad, montaje, distribución y recogida de recursos cuando consuman tiempo real.

### 5. Metodología como andamiaje

- ABJ, ABR, APD u otra metodología fundamentada.
- Propósito, fases o dinámica, continuidad y posibilidad de iteración.
- Acciones del estudiantado y mediación docente.
- Retiro progresivo de apoyos, realimentación y enlace entre semanas.
- Integración auténtica de saberes; tratamiento individual justificado por profundidad, prerrequisito, seguridad, práctica o contexto.
- En III Ciclo, coordinación explícita entre la metodología curricular y Pensamiento de Diseño cuando Proyecto está activo.

### 6. Diagnóstico pedagógico

- Activación expresa y reserva de cero a dos lecciones.
- Propósito: inicio, nuevo aprendizaje o seguimiento.
- Aprendizajes previos fundamentales por explorar; no todo el semestre.
- Dimensiones cognoscitiva, socioafectiva y psicomotora solo cuando sean observables auténticamente.
- Experiencia integrada, evidencia, instrumento, sistematización, análisis, decisión, comunicación y seguimiento.
- Separación estricta entre evidencia, interpretación y decisión; sin calificación, etiqueta clínica o declaración automática de dominio.

### 7. Tiempo y profundidad

- Tiempo de exploración o introducción.
- Práctica guiada y progresión de autonomía.
- Aplicación o producción.
- Evidencia, realimentación, mejora y evaluación.
- Continuidad de aprendizajes que requieren varias semanas.
- Posibilidad real de evidencia compartida e integración.
- Tiempo de Proyecto dentro de las mismas lecciones en III Ciclo.
- Margen para recuperación y cierre.

### 8. Evaluación

- Evidencia definida antes del instrumento.
- Función diagnóstica, formativa o sumativa.
- Componente y porcentaje provenientes únicamente del perfil oficial confirmado.
- Indicador de evaluación editable y congruente con la evidencia.
- Instrumento técnicamente pertinente, tiempo de aplicación, comunicación, devolución y realimentación.
- Calendario institucional, plazos aplicables y prohibición de doble contabilización.
- Confirmación, ajuste o descarte por la persona docente.

### 9. Proyecto en III Ciclo

- Activación solo cuando el perfil lo incluye.
- Problema, población beneficiaria, solución esperada y ruta Empatizar–Definir–Idear–Prototipar–Probar/Evaluar.
- Indicadores oficiales de la etapa inicial.
- En fases posteriores, indicadores oficiales del módulo vinculados explícitamente.
- Semana curricular de 80 minutos, mixta 40+40 o integrada mediante Proyecto de 80 minutos.
- Una sola estrategia y evidencia claramente atribuida; no un segundo planeamiento ni doble conteo.

## Hallazgos priorizados

### Prioridad alta

1. **No existe una estimación temporal curricular validada por indicador.** La IA puede revisar la distribución que genera, pero PIA no dispone de valores oficiales para convertir profundidad en bloques mínimos. Un conteo como 18 indicadores y 21 bloques curriculares solo acredita capacidad nominal.
2. **La proyección permite seleccionar ambos módulos simultáneamente.** La interfaz avisa que quedarán “en secuencia”, aunque la función se denomina proyección semestral y el prompt habla del módulo. En 7.º, ambos reunirían 33 indicadores. Debe exigirse confirmación explícita de que el marco temporal corresponde realmente a ambos módulos o restringirse a uno cuando se trate de un semestre.
3. **Las pruebas no comparan exhaustivamente cada texto curricular contra una fuente oficial independiente.** El barrido previo comprobaba al menos un indicador por combinación; la nueva matriz comprueba estructura y conteo completos, pero todavía falta una paridad literal fuente–aplicación de todos los registros.
4. **El perfil de evaluación predeterminado puede presentarse como confirmado sin una acción explícita.** La interfaz asigna el perfil compatible por defecto y el prompt lo rotula “PERFIL DE EVALUACIÓN CONFIRMADO”. Debe existir una confirmación inequívoca o utilizar el rótulo “perfil de referencia no confirmado” hasta que la persona docente lo valide.
5. **La revisión de una respuesta de IA es principalmente léxica y estructural.** Comprueba presencia de textos, secciones, numeración semanal y una conclusión temporal permitida; no certifica que cada indicador esté ubicado correctamente, que la profundidad sea suficiente, que los minutos sumen o que la integración sea pedagógicamente válida.
6. **El presupuesto temporal neto no se calcula de manera estructurada.** PIA envía semanas y lecciones totales, diagnóstico y excepciones en texto, pero no descuenta aritméticamente diagnóstico, interrupciones, aplicación y devolución de instrumentos, Proyecto o cierres.

### Prioridad media

7. **Las semanas evaluativas iniciales se calculan con fracciones fijas** (aproximadamente 28 %, 52 %, 74 % y 86 %). Son ventanas editables de referencia, no el resultado de analizar actividades, profundidad o evidencias. La IA realiza ese análisis después; la interfaz debe hacerlo inequívoco.
8. **La cobertura puede interpretarse como logro.** PIA ya advierte que describe lo incorporado y no el dominio; conviene rotular cada porcentaje como “incorporado al planeamiento” y sostener siempre los estados separados: proyectado, ejecutado y evidenciado.
9. **“Requiere profundización” no debe elegirse sin evidencia real.** Debe entenderse como una decisión posterior al diagnóstico, no como una impresión inicial ni como autorización para adelantar el currículo del nivel siguiente.
10. **Falta validación de usabilidad con personas nuevas.** Las pruebas automatizadas no sustituyen observación de docentes y asesores realizando el recorrido completo sin acompañamiento.

### Prioridad baja/técnica

11. **La auditoría local de respuestas en Preescolar debe verificarse contra sus catálogos específicos** de saberes procedimentales y actitudinales; existe riesgo de una comprobación vacía si usa únicamente el catálogo general.
12. **El ejemplo formativo presenta menos escenarios tecnológicos que la sección completa de PIA.** Esto no afecta el planeamiento, pero limita el alcance del aprendizaje inicial.

## Protocolo objetivo de prueba por nivel

Para cada una de las 20 combinaciones nivel–módulo se debe ejecutar un caso completo con todos los textos oficiales y un calendario real:

1. Verificar áreas presentes y ausentes, RdA, saberes e indicadores literales.
2. Descomponer la profundidad de cada indicador sin asignar minutos arbitrarios.
3. Proponer integración solo cuando exista afinidad demostrable.
4. Reservar diagnóstico, interrupciones, Proyecto y evaluación aplicables.
5. Construir la secuencia bloque por bloque con exploración, práctica, aplicación y realimentación.
6. Comprobar que ninguna semana exceda el tiempo y que no existan vacíos injustificados.
7. Revisar evidencia e instrumento después de la actividad.
8. Emitir una sola conclusión: “Viabilidad temporal confirmada”, “Revisión temporal sugerida” o “Requiere ajuste temporal”.
9. Someter los casos representativos y cualquier regla de carga a validación de especialistas PNFT.

La prueba debe fallar si se omite, acorta, parafrasea, reasigna o inventa un indicador; si una celda vacía se interpreta como fortalecimiento; si se adelanta el nivel posterior; si se excede el tiempo; o si se declara logro sin evidencia.

## Respuestas ante críticas previsibles

| Crítica | Respuesta basada en evidencia |
|---|---|
| “PIA decide el planeamiento.” | No. Organiza información y genera apoyos editables; la persona docente selecciona, contextualiza y valida. |
| “La IA cambia el currículo.” | El contrato exige indicadores literales y prohíbe inventarlos. La paridad total con fuentes debe incorporarse como prueba exhaustiva adicional. |
| “100 % significa que el grupo aprendió.” | No. Cobertura significa incorporación en semanas; ejecución y aprendizaje evidenciado son estados distintos. |
| “Un indicador por bloque demuestra que alcanza.” | No. La viabilidad depende de profundidad, integración, continuidad, práctica, evidencia, contexto y realimentación. |
| “La trayectoria obliga a evaluar lo anterior.” | No. Los antecedentes son expectativas curriculares no comprobadas y solo orientan una exploración diagnóstica pertinente. |
| “Profundizar significa avanzar al siguiente nivel.” | No. Profundizar desarrolla mejor el indicador vigente; DESPUÉS es solo referencia. |
| “Proyecto duplica trabajo y evaluación.” | No debe hacerlo: se integra en la misma estrategia y tiempo, con indicadores de procedencia diferenciada y sin doble conteo. |
| “PIA decide cuándo evaluar.” | No. Muestra ventanas iniciales editables; la IA analiza luego estrategia, evidencia y tiempo, y la persona docente confirma, modifica o descarta. |
| “El diagnóstico etiqueta o califica.” | No. Es pedagógico, grupal y orienta decisiones; no es clínico ni sumativo. |
| “PIA obliga a una metodología.” | No. Ofrece ABJ, ABR, APD u otra fundamentada; la metodología funciona como andamiaje y no reemplaza el currículo. |

## Criterio para autorizar una siguiente actualización

No modificar los catálogos protegidos. La siguiente actualización debería limitarse a controles trazables y reversibles:

1. confirmación de marco temporal al seleccionar ambos módulos;
2. rotulado inequívoco de ventanas evaluativas y cobertura;
3. corrección de la comprobación específica de Preescolar;
4. prueba exhaustiva de paridad curricular;
5. banco de 20 casos temporales con revisión experta;
6. prueba de usabilidad con docentes y asesores nuevos en escritorio y móvil.

Hasta completar la validación experta de carga, PIA debe mantener esta formulación: **la auditoría temporal analiza la propuesta generada y orienta una revisión profesional; no certifica automáticamente la suficiencia del tiempo ni reemplaza el criterio docente.**
