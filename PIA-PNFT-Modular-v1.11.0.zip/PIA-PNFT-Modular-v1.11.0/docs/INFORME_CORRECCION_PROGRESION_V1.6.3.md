# Informe de corrección de progresión — PIA 1.6.3

**Fecha:** 4 de setiembre de 2026  
**Base preservada:** PIA 1.6.2, derivada exclusivamente del ZIP PIA 1.6.1

Las tres salidas ejecutables comparten SHA-256
`562844d8ba311f5daf39a2b40ac2beca51275116ddec0a5153ca43d7b93ef639`.

## Hallazgos

1. La expresión “fundamento explícito previo” podía interpretarse como evidencia de que el saber fue
   enseñado o aprendido, aunque solo describía una relación curricular.
2. En familias con más de un nivel intermedio anterior, la búsqueda descendente mostraba los niveles
   en orden inverso. Por ejemplo, Domótica en 9.º presentaba `8.º → 7.º`.
3. “No registrada hasta 9.º” podía confundirse con ausencia de continuidad educativa posterior,
   cuando realmente el catálogo actual termina en 9.º.

## Correcciones

- Nueva etiqueta: “Antecedente curricular de referencia (no confirma enseñanza ni aprendizaje)”.
- El prompt ordena planear íntegramente el nivel seleccionado y verificar antecedentes mediante diagnóstico.
- Los niveles intermedios anteriores se ordenan de menor a mayor.
- En 9.º se informa: “Fuera del alcance del catálogo actual, que finaliza en 9.º”.
- La trayectoria continúa sin crear indicadores, evaluación ni afirmaciones de logro.

## Resultado esperado

Un asesor que seleccione 9.º recibe una proyección de 9.º. Los niveles anteriores solo aportan
referencias para diagnóstico, activación de conocimientos y posibles apoyos; nunca autorizan a
suponer que el estudiantado ya domina esos aprendizajes.
