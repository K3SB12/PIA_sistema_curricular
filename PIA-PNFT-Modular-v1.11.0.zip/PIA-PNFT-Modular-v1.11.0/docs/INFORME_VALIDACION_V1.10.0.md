# Informe de validación — PIA 1.10.0

## Alcance validado

- Exploración previa con IA antes de construir el mapa curricular de III Ciclo.
- Entrada trazable con currículo protegido, tiempo neto, diagnóstico, contexto, recursos, DUA, Proyecto, evaluación y trayectoria selectiva.
- Contrato JSON para tres o cuatro rutas distintas, sin envío automático ni dependencia de un proveedor.
- Huella de procedencia para bloquear respuestas correspondientes a otra selección o configuración.
- Saneamiento local de texto, identificadores, fases, funciones, relaciones, semanas, minutos y cantidades.
- Conservación de saberes faltantes como pendientes y bloqueo de funciones de Proyecto cuando el componente no está activado.
- Comparación de agrupaciones, productos posibles, distribución semanal, trayectoria, riesgos, supuestos y ajustes.
- Cálculo local de cobertura y contribución proyectadas, separado de logro, calificación, cumplimiento, calidad o RdA alcanzado.
- Aplicación de la alternativa elegida únicamente como borrador reversible del mapa y calendario.
- Persistencia compatible con `schemaVersion: 6`, funcionamiento local y tres salidas HTML idénticas.
- Interfaz adaptable para computadora, tableta y celular con tabla accesible equivalente.

## Salvaguardas curriculares y profesionales

PIA conserva los textos oficiales y únicamente acepta identificadores pertenecientes a la selección vigente. ANTES se usa como referencia diagnóstica, AHORA como alcance del nivel y DESPUÉS como continuidad no planificable en el periodo actual. La IA no puede inventar antecedentes, anticipar el currículo siguiente, imponer programación o declarar aprendizajes alcanzados.

Una ruta importada permanece sin confirmar. PIA no escribe las semanas del planeamiento, no modifica currículo y no convierte porcentajes estructurales en evidencia de calidad o aprendizaje. Las semanas compartidas entre lecciones y Proyecto se cuentan una sola vez.

## Pruebas automatizadas

Resultado: **234/234 pruebas aprobadas**. La regresión cubre estructura de la interfaz, contrato del prompt, validación de procedencia, límites, JSON no ejecutable, identificadores desconocidos, duplicaciones, Proyecto inactivo, fases, calendario sugerido, métricas responsables, aplicación reversible, migración, responsividad, integridad de fuentes y equivalencia de salidas.

Las tres salidas HTML son idénticas y corresponden byte por byte a la fuente modular ensamblada.

## Manual

Se generó y revisó visualmente `Manual_de_uso_exploracion_mapa_y_calendario_PIA_1.10.0.docx`. El documento consta de 9 páginas e incluye recorridos para docentes nuevos, docentes con experiencia y personas asesoras; exploración previa; lectura de alternativas; trayectoria; productos; mapa; calendario; responsividad; límites y lista de comprobación.

## Comprobación recomendada antes de publicación institucional

La prueba automatizada no sustituye una comprobación humana en dispositivos reales. Antes de publicar en GitHub Pages se recomienda verificar en Chrome y Edge los tamaños 390×844, 768×1024 y 1366×768; interacción táctil; navegación por teclado; lector de pantalla; copiar y pegar con al menos dos proveedores de IA; exportación PNG; impresión o Guardar como PDF; persistencia y retorno del foco.

## Huella de la entrega

`d6e77a0ec5728ff471b3c9b17b6e0acb5b5c0a1d74b2f3b0f1f2983b4b87d258`
