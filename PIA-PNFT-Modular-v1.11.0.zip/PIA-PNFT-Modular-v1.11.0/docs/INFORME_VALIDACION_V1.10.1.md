# Informe de validación — PIA 1.10.1

## Alcance validado

- Exploración previa con IA antes de construir el mapa curricular de III Ciclo.
- Entrada trazable con currículo protegido, tiempo neto, diagnóstico, contexto, recursos, DUA, Proyecto, evaluación y trayectoria selectiva.
- Contrato JSON para tres o cuatro rutas distintas, sin envío automático ni dependencia de un proveedor.
- Huella de procedencia para bloquear respuestas correspondientes a otra selección o configuración.
- Saneamiento local de texto, identificadores, fases, funciones, relaciones, semanas, minutos y cantidades.
- Comparación de agrupaciones, productos posibles, distribución semanal, trayectoria, riesgos, supuestos y ajustes.
- Aplicación de la alternativa elegida únicamente como borrador reversible del mapa y calendario.
- Interfaz adaptable para computadora, tableta y celular con tabla accesible equivalente.

## Corrección de continuidad preparar–copiar

“Preparar prompt” confirma visualmente que la consulta quedó construida. Si la persona pulsa “Copiar prompt” con el campo vacío, PIA ejecuta primero la preparación y después intenta copiar. Los fallos se comunican en la sección y mediante aviso; en Safari móvil se conserva una alternativa de selección y copia manual.

## Salvaguardas curriculares y profesionales

PIA conserva los textos oficiales y únicamente acepta identificadores pertenecientes a la selección vigente. ANTES se usa como referencia diagnóstica, AHORA como alcance del nivel y DESPUÉS como continuidad no planificable en el periodo actual. La IA no puede inventar antecedentes, anticipar el currículo siguiente, imponer programación o declarar aprendizajes alcanzados.

Una ruta importada permanece sin confirmar. PIA no escribe las semanas del planeamiento, no modifica currículo y no convierte porcentajes estructurales en evidencia de calidad o aprendizaje. Las semanas compartidas entre lecciones y Proyecto se cuentan una sola vez.

## Pruebas automatizadas

Resultado: **235/235 pruebas aprobadas**. La regresión incluye el flujo de recuperación preparar–copiar, comunicación de errores, portapapeles moderno y alternativa manual, además de estructura, seguridad, migración, responsividad e integridad de las salidas.

Las tres salidas HTML son idénticas y corresponden byte por byte a la fuente modular ensamblada.

## Manual

El manual de exploración, mapa y calendario continúa siendo aplicable. Su fuente incorpora la numeración de los botones y explica la preparación automática al copiar.

## Huella de la entrega

`170641cfa070b3105b85021a03f55b1b3c7865259c8896403adc3f7173bc6f61`
