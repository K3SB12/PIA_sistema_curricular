# Informe de validación — PIA-PNFT Modular 1.11.0

## Alcance

Actualización del explorador previo de rutas curriculares de III Ciclo, comparación de propuestas externas de IA, mapas y calendarios derivados, controles de integridad y adaptación de navegación para computadora, tableta y celular.

## Controles implementados

- Las propuestas proceden de una respuesta externa de IA; PIA no crea alternativas simuladas.
- Una sola acción prepara y copia la consulta; existe recuperación manual si el portapapeles falla.
- La persona usuaria pega la respuesta completa sin manipular JSON.
- Se aceptan entre dos y cuatro propuestas con esquema `pia-route-options-v2` y huella vigente.
- Se descartan identificadores desconocidos, duplicados y rangos inválidos.
- Los saberes omitidos permanecen visibles como pendientes y no cuentan como cobertura.
- Una alternativa con saberes pendientes o tiempo superior al disponible no puede aplicarse.
- Cada propuesta muestra posibilidad de producto, recursos, mapa, calendario, riesgos, supuestos y ajustes.
- La propuesta elegida se aplica exclusivamente como borrador reversible y editable.
- El mapa admite paneo, movimiento de bloques, teclado, tabla accesible y vista general desde 12 %.
- Los controles móviles tienen área táctil, disposición vertical y respeto de zona segura inferior.

## Pruebas automatizadas

- Suite completa: **243 pruebas aprobadas, 0 fallidas** antes del cierre de huella.
- Verificación de fuente y ensamblado: aprobada.
- Equivalencia de salidas: `index.html`, `dist/web/index.html` y `dist/portable/index.html` idénticos.
- Contratos específicos 1.11.0: procedencia externa, flujo guiado, esquema, cobertura, mapa/calendario, producto contextual y responsividad.

## Límites responsables

Las comprobaciones de PIA son estructurales y temporales. No certifican pertinencia pedagógica, aprendizaje, competencia, perfil de salida, promoción ni RdA alcanzado. La persona docente o asesora confirma, modifica o descarta la propuesta según el diagnóstico, el grupo, los recursos, el calendario institucional y la normativa vigente.

## Integridad

SHA-256 de las tres salidas HTML: `2e8a3c9134c29d9bd18afe48c7104d205496d0f423337ad463bc95c0ea6f670e`.
