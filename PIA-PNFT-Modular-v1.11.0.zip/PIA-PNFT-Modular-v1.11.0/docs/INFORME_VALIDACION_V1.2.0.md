# Informe de validación — PIA-PNFT Modular 1.2.0

## Resultado automatizado

- Construcción reproducible: aprobada; raíz, web y portable son byte a byte iguales.
- Protección del núcleo: aprobada mediante rangos nuevos explícitos y comparación con la referencia.
- Datos curriculares: sin modificación.
- Red: no se añadieron APIs de comunicación.
- Pruebas Node: 15 aprobadas.
- Guardar/cargar v1, eliminación de semanas y Word horizontal: conservados.
- Proyección, IDs compuestos, ambos módulos, distribución flexible, cobertura y migración: aprobados.
- Backend y analítica: comprobados como inactivos.

## Validación humana pendiente

Este entorno no dispone de Chrome/Edge ejecutable. Antes de la aceptación institucional, abra
`index.html` y complete el recorrido del manual: JSON, reducción de semanas, proyección,
autoguardado, escudo, formato, PDF, Word y portable. Verifique popups y Word horizontal.

El itinerario **Básico requerido** de preescolar no contiene una selección inferida. Permanece
bloqueado hasta recibir la correspondencia oficial y autorización expresa para incorporarla.
