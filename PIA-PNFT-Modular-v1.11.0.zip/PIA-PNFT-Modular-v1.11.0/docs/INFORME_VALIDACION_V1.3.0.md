# Informe de validación — PIA-PNFT Modular 1.3.0

Fecha: 2026-08-26

## Alcance

Se validó la evolución autorizada desde 1.2.1, sin modificar `PNFT_DATA`, `RDA_POR_CICLO` ni las
referencias históricas. El backend y la analítica permanecen inactivos.

## Resultado automatizado

- Fuente y JavaScript: aprobado.
- Construcción reproducible: aprobado; las tres salidas son idénticas.
- Alcance autorizado frente a referencia: aprobado.
- 23 pruebas funcionales: 23 aprobadas, 0 fallidas.
- Guardar/cargar JSON, migración, semanas 8→7→6, Word, evaluación, prompt y orden: aprobados.
- APIs de red nuevas: 0.

## Huellas protegidas

- Referencias: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `pnft-data.js`: `ef8bab8d6ff32798425a1a28441f7651aabe050fac8307bc92c517da88212edf`.
- `rda-por-ciclo.js`: `652f1df1de6e5686dc6b1df7b19f46c23615b21eca8da6fd3336a2fc14d40a87`.

## Validación humana recomendada

Abrir el portable en Edge/Chrome, recorrer un nivel real, guardar/cargar un plan y revisar PDF/Word.
Los diálogos de impresión y la carpeta de descargas dependen del navegador y sistema operativo.
