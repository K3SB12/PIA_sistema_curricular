# Informe de validación — PIA-PNFT Modular 1.5.0

Fecha: 28 de agosto de 2026.

## Alcance

La versión incorpora tres mejoras independientes y reversibles: orientación de instrumentos de
evaluación, planificación condicionada del componente Proyecto y contratos estrictos para los
prompts. Se preservan el currículo, el encabezado, las semanas, el guardado/carga y las salidas
oficiales PDF y Word.

## Resultados

- Catálogo de nueve instrumentos con finalidad, uso, requisitos, salvaguardas y fuentes.
- Proyecto visible únicamente cuando el perfil contiene dicho componente.
- Indicadores oficiales de Empatizar, Definir e Idear conservados literalmente y versionados.
- Prototipar y Probar/Evaluar quedan preparados, sin indicadores inventados.
- JSON v4 conserva el estado de Proyecto y migra planes v1, v2 y v3.
- Los prompts prohíben acortar indicadores, exigen saberes procedimentales y actitudinales por
  semana, integración pedagógica o justificación del tratamiento individual, y actividades
  desarrolladas con continuidad, DUA, evidencia y realimentación.
- Proyecto no crea una segunda plantilla ni una sección adicional en PDF o Word.

## Pruebas

`npm test`: 61 pruebas aprobadas, 0 fallidas. Incluye sintaxis, fuente modular, ensamblado,
alcance autorizado, catálogos, migración, guardado/carga, contratos de prompts, exclusión de
Proyecto en exportadores, eliminación de semanas y exportación Word.

La comprobación manual final en Edge o Chrome sigue recomendada para interacción visual, descarga,
apertura emergente e impresión en el equipo institucional.

SHA-256 común de `index.html`, `dist/web/index.html` y `dist/portable/index.html`:
`df112c585f91861a26d790aaca9656cd8053921dca157cd420dd5e64dce976e2`.
