# Informe de validación — PIA-PNFT Modular 1.5.1

Fecha: 2026-08-28

## Alcance validado

- Migración a JSON v5 sin alterar el currículo protegido.
- Tres modalidades semanales del componente Proyecto.
- Separación entre texto oficial y contextualización docente.
- Indicadores del Proyecto dentro de las columnas oficiales.
- Eliminación de hitos, porcentajes y estados de avance.
- Catálogo de instrumentos interno al prompt y recomendación posterior a la evidencia.
- Contratos de IA para literalidad, integración y mediaciones desarrolladas.
- Ausencia de red, backend y analítica activa.

## Resultado automatizado

`npm test`: 64 pruebas aprobadas, 0 fallidas. Las puertas comprueban fuente, construcción,
alcance autorizado, catálogos, migración, guardado/carga, prompts, Proyecto, exportación Word,
eliminación de semanas y equivalencia de las tres salidas ensambladas.

## Límite de esta validación

La prueba manual final de ventanas emergentes, impresión, descarga y reapertura visual debe
realizarse en Edge o Chrome del equipo institucional. Este informe no afirma que esa prueba humana
haya sido ejecutada en este entorno.
