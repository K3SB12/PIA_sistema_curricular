# Informe de validación — PIA-PNFT Modular 1.5.2

**Fecha:** 2026-08-28

## Alcance

- Persistencia de indicadores de Proyecto originales y contextualizados.
- Conservación de indicadores de evaluación seleccionados y desmarcados.
- Exportación del texto efectivo en las columnas oficiales de PDF y Word.
- Ausencia de una tabla o planeamiento paralelo de Proyecto.
- Conservación de Proyección y Cobertura como ayudas internas no exportables.

## Casos comprobados

1. Texto docente presente: se exporta la contextualización.
2. Texto docente vacío: se exporta el original guardado.
3. Indicador de evaluación seleccionado: se exporta.
4. Indicador desmarcado: no se exporta y permanece en JSON.
5. Semana curricular: no exporta Proyecto.
6. Guardado y carga: conserva modo, fase, textos y selección.
7. Word y PDF: consultan la misma regla efectiva.

## Resultado

- 68 pruebas automatizadas aprobadas.
- 0 pruebas fallidas, canceladas u omitidas.
- Fuente modular, ensamblado y alcance autorizado aprobados.
- Las tres salidas HTML comparten la huella SHA-256
  `d61dc3d964af384e28f58bb6a8e419c00048f68bee613ae90a26ce46d459060c`.
- Backend, API, autenticación y analítica permanecen inactivos.

## Límite

La inspección visual de ventanas emergentes, impresión y apertura de archivos debe completarse en
Edge o Chrome del equipo institucional.
