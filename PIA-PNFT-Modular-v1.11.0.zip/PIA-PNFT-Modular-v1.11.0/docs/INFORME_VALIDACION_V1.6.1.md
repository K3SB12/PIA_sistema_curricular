# Informe de validación — PIA-PNFT Modular 1.6.1

Fecha: 2026-09-02

## Alcance verificado

- Conservación de todas las funciones y contratos aprobados en PIA 1.6.0.
- Selector semanal independiente para Módulo 1, Módulo 2 o ambos.
- Valor inicial Módulo 1 para I semestre y Módulo 2 para II semestre en semanas nuevas.
- Compatibilidad de planes anteriores: si contienen áreas o saberes sin módulo semanal, PIA habilita
  ambos módulos para evitar ocultamiento o pérdida.
- Filtrado de áreas y saberes por nivel y módulos activos.
- RdA visibles únicamente a partir de las áreas incorporadas en la semana.
- Inserción automática de indicadores mediante referencia compuesta `modulo + area + nombre`.
- Persistencia JSON de `modulos`, `saberRefs` y contenido semanal existente.
- Panel plegable de selección curricular sin eliminación de datos.
- Advertencia visible cuando una selección guardada permanece fuera del filtro actual.
- Confirmación antes de retirar un área que contiene saberes seleccionados.
- Actualización del prompt semestral con las fechas vigentes y protección de un prompt anterior.
- Mejoras manuales recibidas: orden interno de Proyección, eliminación de métricas técnicas visibles,
  simplificación del encabezado y secciones opcionales desplegables.
- Ausencia de cambios en `PNFT_DATA`, `RDA_POR_CICLO`, catálogos oficiales, backend o analítica.

## Resultado automatizado

`node --test tests/*.test.mjs`: **80 aprobadas, 0 fallidas**.

`verify:source`, construcción y `verify:authorized`: aprobados. Las tres salidas HTML son idénticas.

## Validación manual pendiente de la persona usuaria

En Edge o Chrome se debe comprobar al menos una semana de cada semestre:

1. Elegir Módulo 1 y confirmar que solo se ofrecen sus áreas y saberes.
2. Elegir Módulo 2 y confirmar el indicador literal correspondiente.
3. Activar ambos módulos y seleccionar saberes de cada uno.
4. Plegar y desplegar la selección curricular sin pérdida.
5. Guardar el JSON, cerrar, cargar y confirmar módulos, saberes, indicadores, mediación y evaluación.
6. Exportar PDF y Word para comprobar que el formato oficial permanece intacto.

Las pruebas automatizadas no sustituyen la revisión visual final ni la apertura real de ventanas y archivos.
