# Informe de validación — PIA-PNFT Modular 1.6.11

## Alcance verificado

| Mejora | Resultado esperado | Salvaguarda |
|---|---|---|
| Diagnóstico persistente | Preparar, guardar y recuperar modalidad, experiencia, resultados y prompt. | Máximo dos lecciones; sin resultados inventados ni datos personales. |
| Modo asesor | Producir un modelo aplicable sin atribuir hallazgos a un grupo inexistente. | Las decisiones se expresan condicionalmente. |
| Modo docente | Utilizar únicamente resultados generales aportados. | No diagnostica clínicamente ni autoriza adecuaciones. |
| Progresión | Usar antecedentes como referencia diagnóstica y planear el nivel actual. | No adelanta alcances posteriores ni crea indicadores. |
| Orientación evaluativa | Sugerir ventanas editables según el perfil. | Solo lo confirmado llega al prompt; no escribe semanas ni notas. |
| Reglas de aplicación | Relacionar tareas, prueba y Proyecto con evidencia, mediación y calendario. | Mantiene decisión docente y validación institucional. |
| Revisión de IA | Detectar literalidad, estructura y alertas básicas. | No incorpora, certifica ni aprueba la respuesta. |
| Persistencia | Conservar campos nuevos al guardar y cargar JSON v6. | Migración no destructiva de planes anteriores. |
| Secuencia diagnóstica | Presentar la acción después de los saberes y conservar las lecciones en Marco temporal. | La reubicación es visual y no altera el estado. |
| Requisitos de apertura | Habilitar con ciclo, nivel, módulo, área, saber y 1–2 lecciones. | La proyección semestral continúa disponible sin diagnóstico. |
| Ayudas contextuales | Explicar términos mediante mouse, teclado y toque. | Catálogo único, una ayuda visible y ningún dato persistente. |
| Exportación | Mantener las ayudas fuera de impresión, PDF y Word. | No se modifica ningún exportador oficial. |

## Pruebas

- Verificación sintáctica de los JavaScript modificados.
- Ensamblado idéntico de `index.html`, `dist/web/index.html` y `dist/portable/index.html`.
- Verificación del alcance autorizado frente al núcleo protegido.
- Pruebas específicas de diagnóstico, orientación evaluativa, prompts, revisión de IA y migración.
- Regresión de currículo, Preescolar, Proyecto, metodología, semanas, autoguardado, PDF y Word.

Resultado automatizado final: **120 pruebas aprobadas de 120; 0 fallos**.

La revisión manual final en Chrome o Edge y la apertura de una exportación en Microsoft Word siguen
siendo controles recomendados antes de declarar un despliegue institucional.
