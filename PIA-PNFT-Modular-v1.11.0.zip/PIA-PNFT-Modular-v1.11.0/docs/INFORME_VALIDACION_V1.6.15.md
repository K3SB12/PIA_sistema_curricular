# Informe de validación — PIA-PNFT Modular 1.6.15

## Resultado 1.6.15

- 143/143 pruebas automatizadas aprobadas.
- 235/235 indicadores completos en 20 combinaciones nivel–módulo.
- Confirmación explícita del perfil de evaluación y del alcance excepcional de ambos módulos.
- Presupuesto temporal neto y balance numérico exigido al prompt.
- Comprobación de IA delimitada como técnica, con trazabilidad de saberes, RdA e indicadores.
- Catálogos oficiales, JSON v6, semanas, Proyecto y exportaciones preservados.
- Continúa pendiente la validación humana final en Chrome/Edge de escritorio y móvil.

Fecha: 13 de setiembre de 2026.

## Resultado de la actualización

- Fuente y ensamblado reproducible: aprobados.
- Alcance autorizado respecto de la referencia protegida: aprobado.
- Pruebas automatizadas: **138/138 aprobadas**.
- Prueba ejecutable del recorrido: apertura, siete vistas, tres laboratorios, cierre y preservación del plan aprobados.
- Barrido curricular del ejemplo: 20 combinaciones de nivel y módulo (0° a 9°, módulos 1 y 2), todas con área, indicador literal y RdA disponibles en la consulta.
- Revisión estructural de accesibilidad: sin identificadores duplicados, botones sin nombre, selectores sin etiqueta o diálogos sin título en las ocho vistas revisadas.
- Salidas equivalentes: `index.html`, `dist/web/index.html` y `dist/portable/index.html`, SHA-256 `fb7545b490167ba45975cf9b7cc5796c2912d6987858148ac324612e7fac8c4a`.
- La experiencia queda fuera del JSON, autoguardado del plan, PDF y Word. La salida portable conserva la función y limpia su contenido transitorio.
- Pendiente antes de publicación: revisión visual humana en Chrome o Edge de escritorio y móvil. El navegador remoto disponible bloqueó la URL local; por eso esta entrega no se declara visualmente validada.

## Resultado automatizado

- Fuente y ensamblado reproducible: aprobados.
- Alcance autorizado respecto de la referencia protegida: aprobado.
- Pruebas automatizadas: **132/132 aprobadas**.
- Salidas equivalentes: `index.html`, `dist/web/index.html` y `dist/portable/index.html`.
- Currículo operativo protegido: 235 registros relacionados, 38 familias, cuatro áreas y diez niveles.
- Huellas de los Excel: coinciden con las fuentes trazadas.

## Contratos verificados

- Vacío curricular distinto de fortalecimiento y de `N/A`.
- Tarjetas y tabla comparativa con filtros por módulo, área y alcance.
- RdA, procedencia curricular e iconografía PNFT local.
- Trayectoria excluida del prompt, JSON, PDF y Word.
- Diagnóstico inicialmente desactivado, incorporación expresa y reinicio aislado.
- “Observación o decisión docente” distinta de calificación y frecuencia evaluativa bajo criterio docente.
- Auditoría temporal posterior sin regla de conteo aislado.
- “Etapa de desarrollo → Prototipar” localizada.
- Compatibilidad JSON v6 y funcionamiento portable.

## Control visual pendiente en navegador de escritorio

El entorno de entrega bloqueó la apertura de archivos locales mediante el navegador automatizado. Por
ello, no se declara realizada una inspección visual en Chrome o Edge. La revisión manual debe comprobar:
apertura de la trayectoria, cambio de vista, filtros, textos extensos, desplazamiento de tabla, iconos,
cierre por botón/clic exterior/`Esc`, diagnóstico y funcionamiento directo mediante `file://`. Las pruebas
automatizadas verifican la estructura, los eventos y la inclusión exacta del recurso gráfico; PDF y Word
conservan sus verificaciones históricas y no incluyen la trayectoria.
