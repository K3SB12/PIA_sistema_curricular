# Informe de validación — PIA-PNFT Modular 1.6.4

**Fecha:** 4 de setiembre de 2026  
**Base:** PIA 1.6.3, derivada exclusivamente de la línea PIA 1.6.x

## Propósito

Hacer comprensible la trayectoria curricular para una persona docente nueva sin debilitar los
contratos que protegen el currículo oficial y orientan a la IA.

## Resultado funcional

- `AHORA`: presenta solo el alcance del nivel y los saberes seleccionados.
- `ANTES`: presenta una referencia diagnóstica y aclara que no demuestra enseñanza ni aprendizaje.
- `DESPUÉS`: explica la continuidad, pero prohíbe planearla como contenido obligatorio actual.
- Los niveles `N/A` no se enumeran; cuando interrumpen una trayectoria se informa que la referencia
  no constituye un prerrequisito directo.
- Los refuerzos sin evaluación directa conservan su significado y no generan indicadores.

## Protección comprobada

- 38 familias, cuatro áreas y diez niveles conservados.
- 235/235 registros curriculares relacionados exactamente.
- Una familia no incorpora saberes no seleccionados al alcance actual.
- `PNFT_DATA`, RdA, Preescolar, Proyecto y JSON v6 no fueron modificados.
- PDF, Word y portable mantienen su comportamiento validado.
- No se incorporó ninguna función de PIA 1.7.0.

## Pruebas ejecutadas

- Resultado: **88/88 pruebas automatizadas aprobadas**, sin fallos, cancelaciones ni omisiones.
- Se comprobaron la lectura `AHORA–ANTES–DESPUÉS`, la ausencia de ruido técnico y la protección de
  saberes no seleccionados.
- Las tres salidas ejecutables son idénticas y tienen el hash SHA-256
  `9cabb94fd93606ac428c2932f89ec4a833a46d0649bd114b7188c607b3200097`.
- Los tres archivos curriculares protegidos coinciden exactamente con PIA 1.6.3 y conservan sus
  hashes autorizados.
