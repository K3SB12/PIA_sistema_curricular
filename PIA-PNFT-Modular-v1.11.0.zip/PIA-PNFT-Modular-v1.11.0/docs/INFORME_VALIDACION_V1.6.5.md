# Informe de validación — PIA-PNFT Modular 1.6.5

**Fecha:** 4 de setiembre de 2026  
**Base:** PIA-PNFT Modular 1.6.4

## Alcance

Se incorporó un contrato exclusivo para Preescolar y se condicionó el texto de Proyecto al perfil
educativo aplicable. No se modificaron el formato oficial ni las funciones del planeamiento.

## Validaciones curriculares

- Cuatro competencias específicas oficiales organizadas por área.
- Perfil de salida organizado en 5, 6, 4 y 3 descriptores para ATD, Programación, CFR y Datos/IA.
- Cuatro itinerarios preservados con 6, 8, 8 y 10 saberes.
- Indicadores y RdA existentes conservados literalmente.
- La evaluación de Preescolar se limita a funciones diagnóstica y formativa, sin porcentajes.
- No se impone una cantidad mínima semanal de áreas, saberes o indicadores.

## Validaciones por perfil

- Preescolar: no recibe ninguna referencia a Proyecto o evaluación sumativa.
- I y II Ciclo: no reciben ninguna referencia a Proyecto.
- III Ciclo sin Proyecto: conserva la advertencia de componente no seleccionado.
- III Ciclo con Proyecto: conserva la ruta y las modalidades ya validadas.

## Protección funcional

- JSON v6, guardado, carga y autoguardado conservados.
- Semanas, filtros curriculares y navegación conservados.
- PDF, Word y portable conservados.
- No se incorporó ninguna función del proyecto independiente PIA 1.7.0.

## Resultado

**92/92 pruebas automatizadas aprobadas.** Las tres salidas HTML son idénticas y conservan el hash
SHA-256 `d4c240aad8bec100f6bc9eb62b850eb6697a1549d58978926012fa47b0b49598`.
