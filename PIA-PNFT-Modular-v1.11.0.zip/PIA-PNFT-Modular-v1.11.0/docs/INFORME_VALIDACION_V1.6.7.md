# Informe de validación — PIA-PNFT Modular 1.6.7

## Resultado automatizado

- Sintaxis JavaScript: aprobada.
- Verificación de fuente: aprobada.
- Construcción reproducible de las tres salidas: aprobada.
- Alcance autorizado: aprobado.
- Contratos curriculares, persistencia, Proyecto, Preescolar, progresión y exportación: conservados.
- Contratos nuevos de formato contextual: aprobados.
- Resultado total: **96/96 pruebas aprobadas**.

## Salvaguardas comprobadas

- Los Indicadores de logro del currículo de FT siguen protegidos.
- El formato se limita a Mediación y Evaluación.
- La selección se conserva antes de ejecutar comandos.
- Las opciones secundarias permanecen plegadas.
- Los controles táctiles alcanzan 44 px en pantallas pequeñas.
- La barra no forma parte de la impresión.
- Los vínculos se limitan a HTTPS y no se abren automáticamente.
- JSON v6, autoguardado y exportadores no cambian de estructura.

## Validación humana requerida

Abrir `dist/portable/index.html` en Edge o Chrome y comprobar: selección con ratón y teclado,
desplazamiento dentro de un campo largo, varias acciones consecutivas, `Esc`, vista móvil, guardado y
carga del JSON y presencia del formato aplicado en Word y PDF.
