# Validación funcional y pedagógica de PIA 1.6.9

## Alcance

PIA 1.6.9 incorpora una ruta formativa interactiva y ajustes de acompañamiento sin sustituir el
planeamiento oficial ni modificar los catálogos curriculares protegidos. La metodología activa se
presenta como andamiaje para movilizar RdA, saberes e indicadores del PNFT; no como una actividad
aislada ni como un rótulo semanal.

## Correspondencia documental

| Mejora | Criterio aplicado | Salvaguarda |
|---|---|---|
| Juego metodológico | ABJ: objetivo, contenido, reto, reglas, realimentación y valoración; ABR: comprender, investigar y actuar; APD: Empatizar, Definir, Idear, Prototipar y Probar/Evaluar. | No escribe el plan ni certifica resultados. |
| Ruta de Preescolar | Experiencias breves, lúdicas, concretas, sensoriales y guiadas; evaluación diagnóstica/formativa; contribución a RdA y perfil. | No introduce porcentajes ni Proyecto. |
| Diagnóstico | Precisar, diseñar, aplicar, sistematizar, analizar, decidir y comunicar; dimensiones cognitiva, socioemocional y psicomotriz cuando sean pertinentes.^1 | Máximo dos lecciones; sin calificación, diagnóstico clínico ni datos personales. |
| DUA | La persona docente activa expresamente el contexto que desea enviar al prompt. | Desactivar conserva datos y omite el bloque del prompt. |
| Otra metodología | Fundamentación sobre propósito curricular, continuidad, rol del estudiantado, evidencia y viabilidad. | No se presenta como metodología oficial del PNFT. |
| Afinar semana | Revisa una semana existente y mantiene la metodología y los indicadores oficiales completos. | Un cambio metodológico se entrega aparte y requiere validación docente. |
| Proyecto | Pensamiento de Diseño conserva su ruta; Prototipar y Probar/Evaluar usan indicadores oficiales del módulo seleccionados. | Textos históricos se conservan y no se rotulan como oficiales. |

## Escenarios de secundaria

Una sola metodología es posible cuando Pensamiento de Diseño organiza tanto la mediación curricular
como el Proyecto. Esto no fusiona los componentes de evaluación ni permite duplicar evidencias.

También es posible utilizar una metodología curricular diferente —por ejemplo ABR— y mantener
Pensamiento de Diseño para el Proyecto. En ese caso PIA exige que la propuesta haga visibles los
puentes entre ambas rutas en las semanas mixtas o integradas. Una metodología alternativa no puede
sustituir silenciosamente la ruta del Proyecto.

## Preescolar

La misión específica evita trasladar mecánicamente reglas de primaria o secundaria. El itinerario
Básico u Óptimo se contextualiza a partir del diagnóstico pedagógico, tiempo y posibilidades del
grupo. La experiencia puede iniciar y concluir en una semana, pero conserva continuidad curricular.
Los criterios de desempeño se consideran apoyo para describir progresión observable, no una escala
porcentual ni una declaración automática de que el RdA fue alcanzado.^2

## Compatibilidad

- Se conserva `schemaVersion: 6`; no se crea un formato de plan incompatible.
- `context.enabled` y la fundamentación metodológica tienen valores iniciales seguros.
- Los planes anteriores infieren la activación contextual cuando ya contienen datos significativos.
- Los registros históricos de Proyecto permanecen disponibles y diferenciados.
- El juego no se serializa, no activa autoguardado y no se incluye en PDF, Word o portable guardado.

## Fuentes

1. Ministerio de Educación Pública. *Evaluación diagnóstica v1.0*. Documento PDF aportado para la revisión, secciones sobre proceso de evaluación diagnóstica y dimensiones del aprendizaje.
2. Programa Nacional de Formación Tecnológica. *Guía docente FT-Preescolar*. Documento aportado para la revisión, orientaciones metodológicas, itinerarios y evaluación formativa.
3. Programa Nacional de Formación Tecnológica. *Metodología activa Aprendizaje Basado en Juego 2*. Documento PDF aportado para la revisión.
4. Programa Nacional de Formación Tecnológica. *Metodología CBL - Retos 2*. Documento PDF aportado para la revisión.
5. Programa Nacional de Formación Tecnológica. *Metodología activa Design Thinking*. Documento PDF aportado para la revisión.
6. Ministerio de Educación Pública. *Orientaciones generales para docentes de Formación Tecnológica – PNFT 2026*. Documento PDF aportado para la revisión.
