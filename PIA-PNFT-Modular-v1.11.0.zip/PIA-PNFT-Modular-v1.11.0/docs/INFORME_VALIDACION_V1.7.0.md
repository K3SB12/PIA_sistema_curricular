# Informe de validación — PIA-PNFT Modular 1.7.0

## Resultado

La versión 1.7.0 incorpora **Explorar ruta hacia el RdA** como una consulta curricular local, reversible
y de solo lectura. La implementación conserva separados:

1. el vínculo estructural verificable entre nivel, módulo, área, saber, indicador, familia, ciclo y RdA;
2. la correspondencia pedagógica indicador–RdA, que solo puede mostrarse como validada cuando existe
   fuente, localizador, versión, autoridad, fecha y versión de aprobación.

No se incorporó ninguna correspondencia pedagógica como aprobada porque los insumos disponibles no
incluyen una matriz institucional que autorice esa afirmación. La interfaz muestra el estado pendiente
sin interpretar la ausencia como error, rezago, fortalecimiento o incumplimiento.

## Cobertura comprobada

| Elemento | Resultado |
|---|---:|
| Niveles | 10, de Preescolar a 9.º |
| Ciclos representados | 4 |
| Áreas PNFT | 4 |
| Familias curriculares | 38 |
| RdA conservados por ciclo y área | 16 |
| Combinaciones nivel–módulo resolubles | 20 |
| Saberes–indicadores del catálogo PIA | 235 de 235 |
| Correspondencias pedagógicas aprobadas incorporadas | 0 |

Preescolar mantiene separados sus itinerarios Básico requerido y Óptimo. La selección de uno no mezcla
registros del otro.

## Pruebas automatizadas

- Resultado: **151 aprobadas, 0 fallidas, 0 omitidas**.
- Las tres salidas `index.html`, `dist/web/index.html` y `dist/portable/index.html` son idénticas.
- SHA-256 común: `4791e846ee0e8cb91444b0d3f4d68782e6bcef9f4be04dd3876948488097e938`.
- Se comprobó el alcance autorizado, la literalidad exigida, el aislamiento de la vista, la separación
  de itinerarios de Preescolar, las 20 combinaciones y la ausencia de porcentajes o certificaciones de logro.

## Salvaguardas funcionales

- Solo **AHORA** corresponde al currículo seleccionable del planeamiento actual.
- **ANTES** orienta el diagnóstico y **DESPUÉS** muestra continuidad; ninguno se incorpora al plan.
- Una celda vacía significa ausencia de abordaje conceptual documentado, no fortalecimiento.
- `N/A` y área ausente no crean deudas curriculares ni alertas.
- El RdA se presenta de forma literal como horizonte del ciclo; PIA no calcula avance, porcentaje o cumplimiento.
- La Ruta no escribe semanas, proyección, diagnóstico, evaluación, Proyecto, prompts, autoguardado, JSON,
  PDF ni Word.
- Se conserva `schemaVersion: 6` y la compatibilidad con planes 1.6.15.

## Validaciones que requieren intervención humana

Antes de una publicación institucional se mantienen dos controles externos a la automatización:

1. validar curricularmente las correspondencias indicador–RdA mediante la matriz incluida en
   `docs/MATRIZ_VALIDACION_RUTA_RDA_V1.7.0.md`;
2. realizar aceptación visual y de interacción en Chrome y Edge, escritorio y móvil, especialmente con
   textos largos, navegación por teclado, filtros, desplazamiento, `Esc` y retorno sin cambios al plan.

Estos pendientes no impiden usar la relación estructural como consulta, pero sí impiden presentar a PIA
como certificadora de contribución pedagógica o logro del RdA.
