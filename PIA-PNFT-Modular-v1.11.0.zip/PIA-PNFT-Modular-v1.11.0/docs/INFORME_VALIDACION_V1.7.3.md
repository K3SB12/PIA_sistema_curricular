# Informe de validación — PIA 1.7.3

## Alcance comprobado

- La guía de secundaria presenta APD como una ruta integrada entre saberes, indicadores, Proyecto y evidencias.
- Las modalidades con segunda metodología completa conservan sus controles y auditoría temporal, pero se muestran como decisiones excepcionales.
- “Condiciones de entrada para los saberes actuales” permanece disponible y cuenta con una explicación contextual.
- Los diálogos de prompt general y semanal tienen límite de altura relativo al viewport y desplazamiento interno.
- La terminología visible utiliza “lecciones pedagógicas”.
- El esquema JSON permanece en versión 6 y las tres salidas HTML siguen siendo equivalentes.

## Resultado automatizado

- Pruebas: **170/170 aprobadas**.
- Registros curriculares comprobados: **236** en **20 combinaciones** nivel–módulo.
- Verificación de fuente: aprobada.
- Verificación de alcance autorizado: aprobada.
- SHA-256 de `index.html`, `dist/web/index.html` y `dist/portable/index.html`: `4e35c4a00831b1ec9aab6d9713ac6dfbf14dd82610625b9385f39977f9c2d980`.

## Validación visual pendiente de publicación institucional

El entorno automatizado disponible no contiene un ejecutable de Chrome, Edge o Chromium. Antes de publicación institucional conviene realizar una comprobación humana breve en Chrome o Edge, especialmente con una ventana de poca altura, para confirmar desplazamiento, foco, lectura y acceso a los botones finales del prompt.
