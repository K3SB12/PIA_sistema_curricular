# Informe de validación — PIA 1.7.4

## Incidencia corregida

Cuando la persona usuaria dejaba “Solicitar recomendación razonada a la IA”, la respuesta podía presentar “Observación” y “Lista de cotejo” bajo el rótulo “Técnica seleccionada”. Esas opciones eran recomendaciones generadas por IA, no selecciones docentes.

## Comportamiento verificado

- La interfaz informa que técnica e instrumento están pendientes cuando no existe selección docente.
- El prompt rotula las recomendaciones de IA como pendientes de validación y prohíbe atribuirlas a la persona docente.
- Una selección expresa se conserva como decisión docente.
- Revisar o anexar la respuesta de IA no confirma automáticamente técnica ni instrumento.
- El modelo Word conserva la procedencia y el estado.
- `schemaVersion: 6` y el currículo protegido permanecen sin cambios.

## Resultado automatizado

- Pruebas: **174/174 aprobadas**.
- Salidas verificadas: `index.html`, `dist/web/index.html` y `dist/portable/index.html` son idénticas.
- SHA-256 común: `9a88bee75c614696081448d64b450572ddad0316bf45a4ad3ee34c0a91de4c73`.

La prueba humana final en los navegadores y dispositivos de publicación continúa recomendada para comprobar la presentación visual completa.
