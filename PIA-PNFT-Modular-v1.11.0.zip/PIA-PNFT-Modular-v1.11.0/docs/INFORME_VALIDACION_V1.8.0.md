# Informe de validación — PIA 1.8.0

## Alcance

Sustitución de la ficha de coordinación metodológica por un organizador accesible de rutas curriculares para 7.º, 8.º y 9.º. Se conserva una única proyección, el currículo protegido, Pensamiento de Diseño para el componente Proyecto y `schemaVersion: 6`.

## Evidencia curricular estructural

Dos revisiones independientes ejecutaron escenarios sobre el catálogo real de PIA:

| Nivel y módulo | Organización probada | Condición | Resultado |
|---|---|---|---|
| 7.º M1 | Preparación inicial | Docente nuevo | Todos los saberes ubicados, sin duplicados |
| 7.º M2 | Alternancia | Docente experto | Área ausente respetada |
| 8.º M1 | Preparación inicial | Sin equipo físico; simulación | Todos los saberes ubicados; recurso sujeto al verbo del indicador |
| 8.º M1 | Alternancia | Docente experto | Misma selección, ruta contextual distinta |
| 9.º M1 | Proyecto predominante | Docente experto | Integración estructural posible sin certificar pertinencia |
| 9.º M2 | Alternancia | Docente nuevo | No se inventó Computación Física y Robótica |

Las pruebas demuestran capacidad de representación y conservación del currículo. No constituyen validación pedagógica oficial de las secuencias.

## Controles verificados

- El bloque anterior fue retirado.
- El organizador se ubica fuera del formulario del Proyecto.
- Modo guiado y directo comparten el mismo estado.
- Seis funciones posibles por saber, incluida decisión pendiente.
- Mapa visual y alternativa tabular accesible.
- Adaptación vertical para pantallas pequeñas.
- Ruta excluida de PDF y Word.
- Persistencia y migración compatibles con planes 1.7.5.
- El prompt recibe la ruta guardada, conserva pendientes y prohíbe doble contabilización.
- Segunda metodología completa conservada como excepción con auditoría.
- Las tres salidas HTML deben ser idénticas y coincidir con `CURRENT.sha256`.

## Limitación responsable

La comprobación automatizada no sustituye una prueba humana final en Chrome o Edge de escritorio y móvil. PIA no certifica viabilidad pedagógica, correspondencia validada, RdA alcanzado, aprendizaje ni promoción.

## Resultado automatizado

- Pruebas aprobadas: **186/186**.
- Verificación de fuente: aprobada.
- Verificación de cambio autorizado: aprobada.
- Integridad de versión y distribución: aprobada.
- Salidas raíz, web y portable: idénticas.
- SHA-256: `2a4cb23f36cfdda2548b880624c498b15824c1fd0dcab1c45da633834f9d2a23`.
- Navegador automatizado: no ejecutado porque el entorno de validación no dispone del binario de Chromium; se mantiene como requisito la prueba humana final en Chrome o Edge.
