# Informe de validación — PIA 1.9.1

## Alcance validado

- Mapa conceptual de III Ciclo construido con nodos HTML accesibles y conexiones SVG locales.
- Una sola ruta semestral para diagnóstico, Proyecto/APD, mediación curricular, evaluación y norte curricular.
- Cinco fases de Pensamiento de Diseño, tres indicadores oficiales iniciales protegidos e indicadores del módulo vinculados en fases posteriores.
- Control de entrada para distinguir currículo protegido, información declarada, decisiones docentes, datos opcionales y pendientes.
- Ejemplo visual de solo lectura que no modifica ni confirma la ruta real.
- Función, fase, semanas, grupo, evidencia, nota, color y relaciones editables por saber.
- Tabla accesible equivalente, inspector, línea temporal, zoom, PNG e impresión/PDF independientes del planeamiento oficial.
- Prompt autónomo con currículo, marco temporal, diagnóstico, contexto, recursos, DUA, Proyecto, evaluación, competencias, perfil, descripción del módulo, RdA y relaciones.
- Persistencia compatible con planes históricos y `schemaVersion: 6` sin guardar SVG o coordenadas.

## Auditoría de la entrada

La matriz `INFORME_AUDITORIA_ENTRADA_V1.9.1.md` confirma trazabilidad desde cada selección hasta el mapa y los prompts. Los campos opcionales solo se incluyen cuando la persona docente los activa o aporta. Los pendientes permanecen visibles y no son resueltos silenciosamente por PIA.

## Salvaguardas curriculares

PIA no modifica textos oficiales, no inventa indicadores para Prototipar o Probar/Evaluar, no convierte relaciones en logro, no certifica RdA, competencia, perfil o promoción y no reemplaza el criterio docente. El escenario operativo menor a 80 minutos permanece preventivo, separado y no oficial.

## Pruebas automatizadas

Resultado: **198/198 pruebas aprobadas**. La regresión incluye seis pruebas nuevas para el grafo, las capas validadas, el control de entrada, el ejemplo de solo lectura, el prompt completo y la gestión accesible de relaciones. Las tres salidas HTML son idénticas.

## Revisión visual pendiente de publicación

La revisión automatizada no sustituye una comprobación humana en Chrome y Edge. Antes de la publicación institucional se recomienda verificar archivo local, GitHub Pages, 390×844, 768×1024 y 1366×768, navegación por teclado, lector de pantalla, exportación PNG, impresión/PDF y retorno de foco.

## Huella de la entrega

`d43d6a239743061c8ed2d4f28c9a9ac72d3a3291cc669afa3925053f8d889278`

