# Informe de validación — PIA 1.9.2

## Alcance validado

- Calendario visual integrado exclusivamente en el constructor de la ruta curricular de III Ciclo.
- Línea temporal dinámica para diagnóstico, mediación curricular, Proyecto y APD, trabajo cotidiano y tareas o calendario.
- Rangos derivados de semanas aportadas; la duración estimada del Proyecto no infiere su inicio o final.
- Evaluación ubicada solo cuando el perfil y la decisión están confirmados y vigentes.
- Decisiones sin rango, excepciones textuales, rutas en borrador y fases pendientes conservadas sin inferencias.
- Tabla accesible equivalente y desplazamiento horizontal controlado para pantallas pequeñas.
- Ubicación simple de saberes en lecciones pedagógicas, componente Proyecto, ambos o pendiente.
- Revisión guiada de relaciones opcionales en lenguaje común, con catálogo revisado y señales textuales que no certifican integración.
- Contexto docente opcional incorporado al prompt junto con indicadores literales, sin exigir una justificación escrita por conexión.
- Productos físicos, simulados, programados, multimedia, documentales o de baja tecnología sujetos al verbo del indicador.
- Adaptación diferenciada de mapa, tabla, calendario, inspector y acciones para computadora, tableta y celular.
- Persistencia compatible con `schemaVersion: 6`, operación local, portable y sin red.

## Salvaguardas

El calendario no escribe semanas del planeamiento, no forma parte del Word o PDF oficial y no suma dos veces una semana integrada. PIA no certifica integración, viabilidad, aprendizaje, indicador o RdA alcanzado. Las frases utilizadas para explicar relaciones son ayudas de interfaz y no modifican el currículo oficial.

## Pruebas automatizadas

Resultado: **210/210 pruebas aprobadas**. La regresión incluye pruebas para pertenencia del calendario al constructor, cinco capas temporales, ausencia de inferencias, vigencia evaluativa, ubicaciones comprensibles, productos flexibles, trayectoria sin antecedentes inventados y responsividad en computadora, tableta y celular.

Las tres salidas HTML son idénticas y corresponden a la fuente ensamblada.

## Manual

Se generó y revisó visualmente el archivo `Manual_de_uso_mapa_y_calendario_PIA_1.9.2.docx`, con recorridos diferenciados para docentes nuevos y con experiencia, interpretación del mapa y calendario, explicación de relaciones, estados y alertas, uso en dispositivos pequeños y lista de comprobación final.

## Revisión humana recomendada antes de publicación institucional

La automatización no sustituye una comprobación real en Chrome y Edge. Se recomienda verificar archivo local y GitHub Pages en 390×844, 768×1024 y 1366×768; navegación por teclado; lector de pantalla; desplazamiento del calendario; tabla accesible; relaciones opcionales; exportación PNG; impresión o Guardar como PDF; y retorno del foco.

## Huella de la entrega

`98f92f8b02e9457b63f014ef522290b1b3236bb4e8d13837eb21f11775d31657`
