# Informe de validación — PIA 1.9.3

## Alcance validado

- Lienzo navegable mediante arrastre del espacio vacío con puntero, ratón o interacción táctil.
- Desplazamiento horizontal y vertical dentro del mapa, sin depender de una barra ubicada al final.
- Zoom ampliado de 25 % a 180 %, tamaño real, centrado y ajuste del mapa completo al espacio disponible.
- Bloques móviles cuya posición visual se conserva sin modificar el texto ni la organización curricular.
- Modal ampliado y viewport independiente para computadora, tableta y celular, con tabla accesible como alternativa.
- Borrador inicial generado por PIA a partir de saberes e indicadores seleccionados, vínculos oficiales ya confirmados y un catálogo interno de relaciones revisadas.
- Propuesta reversible que no selecciona producto, evidencia o semanas, no confirma integración y no sustituye el criterio docente.
- Bloque comprensible para los saberes trabajados en lecciones y retomados en el Proyecto.
- Banda transversal para saberes procedimentales, actitudinales y ejes transversales durante toda la ruta.
- RdA, competencias y perfil presentados como horizonte orientador, no como logro certificado.
- Calendario visual derivado únicamente de rangos declarados y decisiones evaluativas vigentes y confirmadas.
- Productos físicos, simulados, programados, multimedia, documentales o de baja tecnología condicionados por el verbo y la profundidad del indicador.
- Persistencia compatible con `schemaVersion: 6`, funcionamiento local, portable y sin red.

## Salvaguardas curriculares y profesionales

PIA conserva los textos oficiales y diferencia una sugerencia del sistema de una decisión docente. Una coincidencia de color, área, verbo o palabras no demuestra por sí sola que exista integración. El mapa no certifica profundidad, viabilidad, aprendizaje, indicador ni RdA alcanzado; tampoco obliga a usar un producto programado ni convierte el trabajo cotidiano o las tareas en ramas del currículo.

## Pruebas automatizadas

Resultado: **222/222 pruebas aprobadas**. La regresión cubre navegación del lienzo, zoom y dimensiones desplazables, movimiento de bloques, migración y saneamiento del viewport, borrador reversible, ausencia de productos y semanas inventados, banda transversal, RdA como destino orientador, responsividad, calendario, equivalencia de salidas y preservación del núcleo protegido.

Las tres salidas HTML son idénticas y corresponden byte por byte a la fuente modular ensamblada.

## Manual

Se generó y revisó visualmente `Manual_de_uso_mapa_y_calendario_PIA_1.9.3.docx`. El documento consta de 9 páginas e incluye recorridos para docentes nuevos y con experiencia, propuesta inicial, desplazamiento y organización visual, lectura curricular, calendario, productos flexibles, alertas y lista de comprobación.

## Comprobación recomendada antes de publicación institucional

La prueba automatizada no sustituye una comprobación humana en dispositivos reales. Antes de publicar en GitHub Pages se recomienda verificar en Chrome y Edge los tamaños 390×844, 768×1024 y 1366×768; interacción táctil; navegación por teclado; lector de pantalla; exportación PNG; impresión o Guardar como PDF; persistencia del mapa y retorno del foco.

## Huella de la entrega

`5b5ff15fee1b01b2756a06d49d7cc40d0126a2aec167ce83396e8d538f81fda8`
