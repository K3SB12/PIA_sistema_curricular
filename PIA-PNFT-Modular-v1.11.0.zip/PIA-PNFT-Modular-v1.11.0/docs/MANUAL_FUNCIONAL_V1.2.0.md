# Manual funcional — PIA-PNFT Modular 1.2.0

## Uso básico conservado

1. Abra `index.html` o `dist/portable/index.html` en Edge o Chrome.
2. Complete información general, ejes, metodología y semanas.
3. Guarde el JSON para continuar después; use **Abrir** para recuperarlo.
4. Use **Exportar** para abrir la vista PDF o Word horizontal.
5. Descargue la portable para trabajar sin servidor.

## Herramientas avanzadas

Abra **Herramientas avanzadas de PIA**. Allí puede agregar nombre, lema y escudo; describir el
contexto general, recursos y DUA; y definir el estado del plan. Evite datos personales del
estudiantado.

Para proyectar:

1. Seleccione ciclo y nivel en la sección general.
2. Indique semanas, diagnóstico, fechas editables y excepciones.
3. Marque Módulo 1, Módulo 2 o ambos.
4. Marque áreas. PIA selecciona sus saberes conceptuales del módulo activo.
5. Ajuste conceptos y marque saberes procedimentales y actitudinales.
6. Abra **Editar distribución por semanas**, revise y aplique.
7. PIA recomienda dos saberes por semana y permite tres o más previa confirmación.
8. Use **Ver cobertura**. “Ejecutado” significa que la semana fue desarrollada; no demuestra dominio.
9. Use **Generar prompt semestral** y revise el texto antes de copiarlo a una IA.

**Básico requerido** de preescolar queda visible pero no proyecta hasta incorporar datos
curriculares oficialmente autorizados. PIA no crea ese subconjunto por inferencia.

## Seguridad del trabajo docente

- El autoguardado queda en el navegador; recuperar reemplaza la vista solo con confirmación.
- Deshacer/rehacer cubre operaciones estructurales de las herramientas avanzadas.
- Ocultar la barra de formato no borra cambios. Restablecer conserva texto y pide confirmación.
- El escudo acepta PNG/JPEG de hasta 1 MB y se guarda dentro del JSON.
- La revisión de respuestas de IA ocurre localmente; PIA no envía su contenido.
- Use revisión previa antes de exportar y diagnóstico local si una descarga o ventana falla.

El JSON v2 contiene las funciones nuevas y sigue aceptando planes v1. PDF y Word incorporan la
identidad institucional y el anexo de cobertura cuando existen. La portable incorpora una copia
del plan actual dentro del HTML descargado.
