# Manual funcional — PIA-PNFT Modular 1.5.1

## Evaluación orientada por la evidencia

La persona docente no debe escoger anticipadamente un único instrumento para todo el semestre.
PIA incorpora al prompt un catálogo interno de instrumentos. La herramienta de IA debe diseñar
primero la actividad y la evidencia y, después, sugerir uno o varios instrumentos pertinentes.
Cada sugerencia debe explicar finalidad, función evaluativa, justificación, construcción, momento,
tiempo, comunicación y realimentación. La persona docente contextualiza y confirma con el Comité de
Evaluación cuando corresponda.

## Componente Proyecto en secundaria

El bloque Proyecto aparece únicamente cuando el perfil de evaluación seleccionado contiene dicho
componente. En Proyección se registra el contexto general y se consulta la ruta:

1. Etapa inicial: Empatizar, Definir e Idear.
2. Etapa de desarrollo: Prototipar.
3. Etapa final: Probar/Evaluar.

PIA solo muestra indicadores incorporados desde una fuente oficial. Las fases pendientes de fuente
permanecen identificadas sin datos inventados.

## Uso semanal

En cada semana se elige una modalidad:

- Curricular: bloque de 80 minutos.
- Mixta: 40 minutos de currículo y 40 minutos de Proyecto.
- Integrada mediante Proyecto: bloque de 80 minutos que articula ambos procesos.

Al elegir Mixta o Integrada se seleccionan etapa y fase. El indicador de logro del Proyecto aparece
en la columna existente de indicadores de logro y sus indicadores de evaluación en la columna de
evaluación. La estrategia de mediación continúa escribiéndose en su columna habitual.

El texto oficial queda disponible para consulta. La persona docente puede contextualizar una copia
editable y restaurar el original mediante confirmación. Cambiar de fase conserva lo escrito para
cada fase; guardar/cargar mantiene ambas versiones.

## Guardado y exportación

El JSON v5 conserva el modo, etapa, fase, referencia oficial, contextualización docente e indicadores
seleccionados de cada semana. Ocultar Proyecto o elegir temporalmente otro perfil no borra datos.
Solo **Eliminar explícitamente los datos del Proyecto** los retira, previa confirmación.

PDF y Word no agregan una sección paralela de Proyecto: muestran los textos contextualizados dentro
de las columnas oficiales de la semana. Proyección y Cobertura siguen siendo ayudas internas.

## Salvaguardas

PIA no calcula porcentaje de avance, hitos completados, dominio ni calificaciones. Tampoco envía
información, ejecuta IA ni activa backend. La persona docente conserva la decisión profesional.
