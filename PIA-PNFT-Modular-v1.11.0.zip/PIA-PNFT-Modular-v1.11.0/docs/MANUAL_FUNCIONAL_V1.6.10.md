# Guía funcional — PIA-PNFT Modular 1.6.10

## 1. Propósito

PIA ayuda a organizar y conservar el planeamiento de Formación Tecnológica. Presenta el currículo
del PNFT, orienta la proyección, prepara prompts editables y conserva las decisiones docentes. No
envía información a una IA, no califica y no sustituye el criterio profesional ni las instancias institucionales.

## 2. Ruta recomendada

1. Complete el encabezado administrativo, ciclo y nivel.
2. Seleccione ejes y metodología activa.
3. Active **Contextualización y DUA** únicamente si desea aportar esas condiciones al prompt.
4. Defina semanas, fechas, excepciones y entre cero y dos lecciones de diagnóstico.
5. Seleccione módulo, áreas, saberes conceptuales, procedimentales y actitudinales.
6. Confirme el perfil de evaluación aplicable.
7. En III Ciclo, active Proyecto solo cuando vaya a proyectarlo.
8. Genere el prompt semestral, revíselo y guarde cualquier edición.
9. Complete las semanas y utilice **Afinar semana con IA** solo para mejorar una semana ya estructurada.
10. Revise, guarde el JSON y exporte la plantilla oficial a PDF o Word.

## 3. Preparar la evaluación diagnóstica

El botón **Preparar evaluación diagnóstica** abre un espacio separado sin salir del planeamiento.

- **Modelo para asesoría:** genera un ejemplo sin inventar características ni resultados de un grupo.
- **Aplicación docente:** permite guardar resultados generales después de aplicar la experiencia.
- **Aprendizajes previos:** pueden ser antecedentes vinculados, condiciones de entrada o experiencias
  que la persona docente declara. Los indicadores del nivel actual orientan lo que se enseñará y no se
  presuponen dominados.
- **Áreas de valoración:** cognoscitiva, socioafectiva y psicomotora. Se observan de forma integrada
  cuando resulten pertinentes; no son tres etapas ni tres pruebas.
- **Resultados:** registre fortalezas, aspectos por fortalecer, decisiones de mediación y seguimiento,
  siempre de forma grupal y sin nombres.

Genere el prompt, edítelo si lo necesita y pulse **Guardar diagnóstico**. El JSON y el autoguardado
conservarán los datos. La propuesta no se agrega como una sección extra al PDF o Word oficial.

## 4. Momentos evaluativos sugeridos

Abra **Momentos evaluativos sugeridos — Orientación editable** y pulse **Generar o actualizar sugerencias**.
PIA muestra ventanas de referencia según el perfil y el periodo:

- trabajo cotidiano durante la mediación;
- tareas condicionadas por necesidades observadas de repaso o reforzamiento;
- prueba de ejecución en primaria, después de la mediación y realimentación;
- Proyecto como proceso progresivo cuando el perfil lo incluye.

Cada tarjeta puede quedar **Sugerida**, **Confirmada** o **Descartada**. La semana y la nota son
editables. Solo las confirmadas orientan los prompts. PIA nunca escribe automáticamente la semana,
la actividad, el instrumento, el porcentaje ni la calificación.

## 5. Revisar una respuesta de IA

Después de obtener una respuesta externa, pulse **Revisar respuesta recibida de la IA**, péguela y
seleccione **Analizar respuesta**. PIA comprueba aspectos verificables: presencia literal de indicadores,
secciones solicitadas, currículo no seleccionado, numeración semanal y declaraciones automáticas de logro.

El resultado es una alerta de apoyo. No prueba por sí mismo la calidad pedagógica y nunca sustituye la
lectura de la persona docente o asesora. **Guardar sin incorporar** conserva la respuesta en el JSON,
separada del contenido oficial de las semanas.

## 6. Guardado seguro

El autoguardado permite recuperación en el mismo navegador. El archivo JSON es la copia transportable
del planeamiento y conserva diagnóstico, prompts, sugerencias evaluativas confirmadas o descartadas,
respuestas de IA y reportes. Use **Guardar** antes de cambiar de dispositivo o carpeta.

