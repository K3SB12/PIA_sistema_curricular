# Manual funcional — PIA-PNFT Modular 1.6.8

## 1. Propósito

PIA acompaña a la persona docente para proyectar y elaborar el planeamiento de Formación Tecnológica.
Organiza información, protege el currículo del PNFT, prepara solicitudes para una IA externa y conserva
las decisiones docentes. No sustituye el criterio profesional, no determina aprendizaje alcanzado y no
envía información automáticamente.

## 2. Portada de bienvenida

Al abrir PIA se presenta una portada institucional con dos rutas:

1. **Iniciar planeamiento:** abre una plantilla nueva o el plan vigente sin borrar información.
2. **Cargar planeamiento:** permite seleccionar un archivo JSON previamente guardado.

La opción **No volver a mostrar en este dispositivo** guarda una preferencia exclusivamente local. La
portada puede volver a abrirse y no se incorpora al PDF ni al Word oficial.

## 3. Identidad y encabezado administrativo

La identidad institucional opcional se ubica antes del encabezado administrativo. Permite añadir:

- escudo institucional;
- lema institucional.

Ambos se alinean a la izquierda. El nombre del centro educativo se registra solamente en el campo
oficial correspondiente. PIA controla el tamaño del escudo para evitar que crezca en web o Word.

## 4. Diagnóstico y marco temporal

El diagnóstico puede ocupar **0, 1 o 2 lecciones**. PIA refleja esa decisión en el marco temporal,
las semanas iniciales y el prompt semestral. Cambiar la cantidad no elimina mediación, indicadores ni
otros contenidos ya escritos.

El diagnóstico identifica el punto de partida; no demuestra dominio ni reemplaza la evaluación del
aprendizaje.

## 5. Contextualización y DUA — opcional

La sección puede plegarse para reducir desplazamiento. Plegarla no borra nada. Se recomienda completar
solo aquello que cambie una decisión pedagógica y describir al grupo en general, sin nombres, expedientes,
diagnósticos clínicos ni otros datos personales.

### 5.1 Campos abiertos

- **Características generales del grupo.**
- **Recursos y conectividad disponibles.**
- **Apoyos y consideraciones DUA.**

### 5.2 Perfil de implementación

Elija el contexto aplicable. **Regular** es el valor inicial. También pueden aparecer Aula Edad, aulas
integradas, III Ciclo y Ciclo Diversificado Vocacional y EPJA. Este selector contextualiza la mediación;
no cambia automáticamente el nivel administrativo ni inventa un perfil de evaluación.

### 5.3 Condiciones complementarias

Marque únicamente las presentes: apoyos para acceso y participación, diversidad en puntos de partida y
ritmos, organización multigrado o grupos espejo, atención a alta dotación/talentos/creatividad, contexto
sociocultural, pueblos originarios y su cosmovisión, continuidad educativa ante situaciones de salud,
acceso tecnológico limitado o apoyos educativos definidos institucionalmente.

### 5.4 Escenario tecnológico

Seleccione la condición predominante: recursos suficientes, Internet limitado, dispositivos sin Internet,
equipos compartidos, un equipo para demostración, ausencia de dispositivos o recursos de robótica. Puede
añadir una descripción. El prompt pedirá alternativas equivalentes desconectadas cuando corresponda.

### 5.5 Punto de partida grupal

Registre si el grupo presenta un punto acorde con lo esperado, requiere nivelación, muestra diversos puntos
de partida, necesita profundización o todavía está pendiente de evaluación diagnóstica pedagógica. Es una
referencia para planear, no una etiqueta ni un diagnóstico clínico del estudiantado.

## 6. Referencias curriculares de otros niveles

Esta función atiende situaciones justificadas sin permitir texto curricular libre como si fuera oficial.

1. Seleccione el nivel de procedencia.
2. Seleccione módulo, área, saber conceptual e indicador del catálogo del PNFT.
3. Registre el motivo pedagógico o administrativo.
4. Añada, si procede, una contextualización docente separada del texto literal.
5. Incorpore expresamente la referencia en la semana donde se utilizará.

PIA conserva la procedencia y nunca presenta esa referencia como indicador oficial del nivel administrativo
vigente. La selección semanal puede retirarse sin borrar el registro general. Al guardar y cargar JSON se
conservan el texto, la procedencia, el motivo, la contextualización y las semanas seleccionadas.

## 7. Proyección y semanas

La proyección semestral sigue siendo una referencia para organizar módulo, áreas, RdA, saberes, indicadores,
metodología y evaluación. No distribuye automáticamente el contenido en las semanas. La persona docente
selecciona en cada semana el módulo, las áreas y los saberes que corresponden.

Las referencias curriculares seleccionadas se muestran diferenciadas de los indicadores del nivel vigente.
Proyecto, Preescolar y la progresión interna conservan sus reglas especializadas.

## 8. Prompts General, Semestral y Semanal

Cada tipo conserva un borrador independiente. El diálogo informa si el texto está pendiente de guardar,
guardado o actualizado.

- **Guardar cambios del prompt:** confirma el texto actual.
- **Copiar:** copia el texto; no lo envía ni equivale a guardarlo.
- **Abrir ChatGPT/Copilot:** abre la herramienta externa; PIA no transmite el contenido.
- **Actualizar desde PIA:** reconstruye la propuesta con la información vigente y solicita confirmación
  antes de sustituir una edición docente.
- **Restablecer propuesta generada:** vuelve a la versión generada por PIA después de confirmar.

Cerrar el diálogo conserva la edición vigente. El JSON y el autoguardado mantienen los tres tipos de
prompt y sus modificaciones. Para máxima seguridad, use **Guardar cambios del prompt** y luego **Guardar
planeamiento**.

El prompt contextual incluye solo las condiciones marcadas, diferencia el currículo vigente de las
referencias y textos docentes, solicita DUA y alternativas desconectadas y señala lo que requiere validación
institucional.

El prompt semestral requiere una metodología activa. Si fechas, ejes, contexto o referencias opcionales no
fueron aportados, no los muestra como pendientes. Una fecha parcial permanece identificada como incompleta.
La ruta curricular relaciona cada área con su RdA y cada saber con sus indicadores de logro del PNFT.

## 9. Formato contextual

La barra actúa únicamente en **Estrategias de mediación** e **Indicadores de evaluación**. Se abre al
seleccionar texto, permanece accesible durante el desplazamiento y conserva el fragmento activo para aplicar
varios cambios. Los Indicadores de logro del currículo de FT permanecen protegidos.

Incluye deshacer, rehacer, negrita, cursiva, subrayado, listas, alineación, sangría, tamaño, color,
resaltado, limpieza, vínculo HTTPS y estilos rápidos Inicio–Desarrollo–Cierre para Mediación.

## 10. Guardado, carga y exportación

- **Autoguardado:** recuperación local en el mismo dispositivo y navegador.
- **JSON:** respaldo completo y portable del plan, incluidos contexto, referencias y prompts.
- **PDF y Word:** documento oficial; excluye portada, proyección y cobertura.
- **Portable:** aplicación autónoma para uso local sin servidor.

Antes de cerrar una sesión importante, se recomienda guardar el JSON. PIA no depende de un backend y no
sincroniza información entre equipos.

## 11. Límites y responsabilidad

- PIA guía, analiza y conserva; la persona docente decide.
- Una referencia curricular no demuestra que un aprendizaje previo fue alcanzado.
- Una actividad ejecutada no equivale automáticamente a dominio.
- Las sugerencias de IA nunca se convierten en currículo oficial del PNFT.
- Toda adaptación significativa o regla evaluativa no confirmada debe seguir el procedimiento institucional.
