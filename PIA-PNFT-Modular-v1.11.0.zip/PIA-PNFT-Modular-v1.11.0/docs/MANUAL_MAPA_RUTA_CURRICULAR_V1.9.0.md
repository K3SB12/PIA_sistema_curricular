# Manual del mapa integral de ruta curricular — PIA 1.9.0

## Propósito

El mapa ayuda a organizar una única proyección de III Ciclo en la que la mediación curricular y el componente Proyecto se articulan. No sustituye el planeamiento, no modifica el currículo oficial y no certifica que un indicador, RdA, competencia o perfil haya sido alcanzado.

## Antes de abrir el mapa

1. Seleccione III Ciclo, 7.º, 8.º o 9.º, el módulo y las áreas aplicables.
2. Revise y seleccione los saberes conceptuales e indicadores oficiales.
3. Registre contexto, recursos, DUA y diagnóstico cuando corresponda.
4. Active Proyecto si el perfil confirmado lo incluye y complete problema, población y producto o solución según su contexto.
5. Seleccione los indicadores oficiales del módulo que podrán vincularse con Prototipar y Probar/Evaluar.

## Recorrido guiado

1. **Punto de partida:** confirme diagnóstico, condiciones, recursos y apoyos.
2. **Proyecto:** revise Empatizar, Definir, Idear, Prototipar y Probar/Evaluar. Los tres primeros indicadores proceden del catálogo oficial protegido; los dos últimos usan indicadores oficiales del módulo elegidos por la persona docente.
3. **Saberes:** asigne a cada saber una función. “Aporta evidencia dentro del Proyecto” no significa que el saber sea exclusivo del Proyecto; puede requerir mediación previa, práctica o realimentación posterior.
4. **Relaciones:** conecte saberes solo cuando exista una relación pedagógica. Compartir tema, recurso o producto no basta si la experiencia no permite movilizar y evidenciar el indicador.
5. **Semanas:** registre una ventana inicial y final. Una semana integrada se cuenta una sola vez.
6. **Revisar:** atienda pendientes, alertas temporales, fases sin indicador, relaciones incompletas y posibles evidencias duplicadas.

## Controles

- **＋ Grupo:** reúne saberes bajo una organización docente sin cambiar su identidad oficial.
- **Relacionar:** seleccione un nodo, active el control y seleccione el destino.
- **Deshacer/Rehacer:** opera durante la sesión actual.
- **Zoom/Centrar:** cambia únicamente la vista.
- **Capas:** muestra u oculta procedimentales, actitudinales, ejes, horizonte y evaluación sin desmarcar currículo.
- **Exportar PNG:** descarga una representación visual del mapa.
- **Imprimir/PDF:** abre la impresión del mapa; no lo incorpora al PDF oficial del planeamiento.
- **Tabla accesible:** permite realizar las decisiones esenciales con teclado y lector de pantalla.

## Guardado y análisis con IA

El mapa se conserva como borrador dentro del plan y del autoguardado local. **Guardar ruta y volver a PIA** confirma que la persona docente revisó la organización. Un cambio posterior vuelve a dejarla pendiente de confirmación.

**Analizar mapa y comparar rutas con IA** prepara un prompt que solicita dos o tres enfoques, revisión de coherencia curricular, tiempo, profundidad, dependencias, evidencias y riesgos. PIA no envía el prompt ni aplica la respuesta automáticamente.

Después de confirmar la ruta, use **Generar proyección semestral con la ruta confirmada**. La IA propone; la persona docente revisa, ajusta, acepta o descarta.

## Lectura responsable

- Los procedimentales, actitudinales y ejes transversales no son metodologías.
- El producto puede ser video, podcast, revista, texto, presentación, maqueta, simulación u otra solución contextualizada; el nombre del producto no demuestra el indicador.
- La ausencia de equipo físico puede justificar simulación, actividades desconectadas, demostración o estaciones, siempre que se conserve la intención y profundidad del indicador.
- Las ventanas de evaluación orientan; no fijan porcentajes, fechas ni cantidad universal de instrumentos.
- El RdA, las competencias y el perfil son horizontes curriculares. Su cumplimiento requiere evidencias acumuladas y criterio profesional.

