# Manual de uso del mapa y calendario visual de la ruta curricular

## Propósito

Este manual explica **Organizar la ruta curricular del semestre** de PIA 1.9.3 para III Ciclo. Ayuda a docentes nuevos, docentes con experiencia y personas asesoras a organizar una sola proyección que articula lecciones pedagógicas, componente Proyecto con Pensamiento de Diseño, evaluación y tiempo.

PIA protege los textos oficiales, construye el mapa y deriva el calendario de las decisiones registradas. No certifica viabilidad, no declara aprendizajes o RdA alcanzados y no sustituye el diagnóstico, el criterio profesional, la normativa ni las decisiones institucionales.

## Dónde se encuentra

Seleccione III Ciclo, nivel, módulo, áreas y saberes. Active Proyecto cuando corresponda y pulse **Organizar ruta y ver mapa**. Puede utilizar **Mapa y semanas**, **Solo mapa** o **Tabla accesible**.

## Propuesta inicial de PIA

Pulse **Proponer organización** cuando desee que PIA construya un primer borrador. PIA utiliza los saberes e indicadores seleccionados, las vinculaciones oficiales que usted ya confirmó para las fases del Proyecto y su catálogo interno de relaciones revisadas.

El resultado se rotula **Borrador sugerido por PIA**. Puede aceptarlo parcialmente, modificarlo, deshacerlo o sustituirlo. La propuesta no confirma una integración, no selecciona productos o evidencias y no asigna semanas. Una coincidencia de términos, área, verbo o color nunca demuestra por sí sola que dos saberes deban integrarse.

Si ya existe una organización, PIA solicita confirmación antes de sustituirla y el historial permite deshacer el cambio.

## La decisión principal

Para cada saber, indique dónde se trabajará:

| Ubicación | Significado |
| --- | --- |
| Lecciones pedagógicas | Se desarrolla, practica, profundiza o realimenta en la mediación curricular. |
| Componente Proyecto | Se vincula con una fase de Pensamiento de Diseño y evidencia del Proyecto. |
| Lecciones y Proyecto | Se fortalece en lecciones y se aplica, retoma o evidencia en el Proyecto. |
| Pendiente de ubicar | Todavía requiere decisión; PIA lo conserva visible. |

Son ubicaciones de trabajo dentro de una sola ruta, no categorías curriculares ni prueba de logro.

## Información que utiliza PIA

- Nivel, módulo, áreas, saberes, indicadores y RdA oficiales.
- Competencias específicas, perfil de salida y descripción del módulo.
- Saberes procedimentales, actitudinales y ejes transversales.
- Semanas, lecciones pedagógicas, diagnóstico, reservas y excepciones.
- Contexto, recursos y DUA cuando fueron declarados.
- Proyecto, fases APD y producto cuando fue definido.
- Ubicación, grupo, fase, semanas, evidencia y contexto opcional de cada saber.
- Perfil y ventanas evaluativas confirmadas y vigentes.

Una ausencia permanece pendiente. Una duración del Proyecto no autoriza a inventar su inicio.

## Recorrido para una persona nueva

1. Confirme nivel, módulo, áreas y saberes.
2. Lea competencias, perfil, RdA y descripción del módulo como horizonte.
3. Declare semanas, diagnóstico, periodos sin desarrollo y reservas.
4. Registre contexto, recursos y DUA solo cuando cuente con información.
5. Active Proyecto y seleccione sus indicadores oficiales cuando corresponda.
6. Abra el constructor en **Modo guiado**.
7. Si necesita apoyo, pulse **Proponer organización** y revise el borrador; también puede organizar todo manualmente.
8. Seleccione cada saber y elija lecciones, Proyecto, ambos o pendiente.
9. Si participa en Proyecto, seleccione la fase APD.
10. Cree o ajuste bloques para agrupar saberes que compartan una experiencia auténtica.
11. Indique semanas solo cuando exista una decisión.
12. Consulte relaciones posibles; crear o conservar una conexión es opcional.
13. Revise el mapa y luego el calendario. Las semanas compartidas se cuentan una vez.
14. Explore formatos de producto si aún no existe uno y compruebe el verbo del indicador.
15. Revise alertas, pendientes y la tabla accesible.
16. Guarde la ruta, genere el prompt y revise la respuesta antes de incorporarla.

## Cómo leer el mapa

La raíz representa el semestre. Sus ramas muestran diagnóstico y contexto, lecciones pedagógicas, Proyecto con Pensamiento de Diseño, evaluación, capas transversales y norte curricular. Cada tarjeta conserva área, módulo, indicador, ubicación y semanas.

El bloque **Saberes trabajados en lecciones y retomados en el Proyecto** muestra los saberes que se desarrollan o fortalecen en lecciones y después se aplican, prueban o mejoran en una fase del Proyecto. Que el bloque esté vacío no es un error, no es obligatorio y no significa que la ruta esté fragmentada.

Los saberes procedimentales, actitudinales y ejes aparecen como una banda transversal porque acompañan la ruta cuando la experiencia los requiere. Esto no obliga a observarlos todos cada semana. Las competencias y el perfil orientan el proceso; el RdA continúa siendo el destino orientador del ciclo y no una actividad semanal ni una certificación automática.

Los colores identifican áreas o explican por qué aparece una relación posible. Nunca validan calidad, pertinencia o integración; cada color incluye un rótulo textual.

### Cuando no existe un saber previo

Si PIA encuentra un antecedente explícito, lo presenta como referencia para el andamiaje, no como aprendizaje demostrado. Si no existe, muestra **Este saber inicia en el nivel actual**. Explore condiciones de entrada, construya las bases dentro del nivel y no invente un indicador anterior.

## Agrupaciones y relaciones

Agrupar organiza saberes dentro de un bloque. Relacionar dibuja una conexión opcional para mostrar dependencia, apoyo, continuidad o evidencia vinculada.

| Color y rótulo | Procedencia | Interpretación responsable |
| --- | --- | --- |
| Azul petróleo · Revisada previamente | Catálogo de relaciones posibles revisadas. | Ayuda curada; no aprobación oficial ni obligación. |
| Turquesa · Términos y área | Coinciden términos relevantes y área. | Compare indicadores y profundidad. |
| Azul · Términos | Coinciden palabras del indicador. | Compruebe que cumplen una función compatible. |
| Ámbar · Área o verbo | Solo coincide área o verbo inicial. | Señal débil; puede no existir integración auténtica. |
| Gris · Sin señal textual | No existe coincidencia literal evidente. | El contexto podría aportar relación, pero PIA no la infiere. |

No es necesario justificar por escrito cada conexión. Use **Contexto adicional** solo para recursos, simulación, calendario u otra condición que PIA no pueda conocer. La persona docente decide crear, cambiar o eliminar la relación.

## Proyecto, Pensamiento de Diseño y producto

Pensamiento de Diseño organiza el Proyecto. Las lecciones pedagógicas aportan bases, práctica, profundización y realimentación sin constituir por ello otra metodología completa.

El producto puede quedar **por definir durante las etapas iniciales** o ser físico, simulado, programado, multimedia, documental o de baja tecnología.

| Formato | Puede ser pertinente cuando | Precaución |
| --- | --- | --- |
| Físico o maqueta | El indicador exige montar, construir o probar. | La apariencia no demuestra funcionamiento. |
| Simulación | No existen kits, pero permite ejecutar y observar. | Una captura aislada no basta. |
| Programado | El indicador requiere programación. | No lo imponga si el currículo no lo exige. |
| Multimedia | Se debe comunicar, diseñar o producir contenido. | Narrar no sustituye una acción técnica. |
| Documental | Se requiere registrar análisis o decisiones. | Puede acompañar, pero no reemplazar el desempeño. |
| Baja tecnología | Los recursos son limitados. | Conserve intención y profundidad curricular. |

PIA compara posibilidades; la persona docente elige según diagnóstico, contexto, recursos, indicadores y tiempo.

## Segunda metodología completa

La opción base es **Pensamiento de Diseño organiza el Proyecto; las lecciones aportan mediación curricular**. Inicio, desarrollo y cierre son momentos didácticos. Una tarea, reto o juego puntual no constituye automáticamente otra metodología.

Declare una segunda metodología completa solo si conservará fases, semanas, minutos, evidencias y puente con el Proyecto. PIA muestra el impacto temporal y riesgos de duplicación; la decisión final es profesional.

## Cómo leer el calendario

| Capa | Qué muestra |
| --- | --- |
| Diagnóstico | Solo cuando fue activado y tiene una o dos lecciones. |
| Mediación curricular | Desarrollo, práctica y articulación según rangos aportados. |
| Proyecto · APD | Etapas iniciales, Prototipar y Probar/Evaluar con semanas definidas. |
| Trabajo cotidiano | Seguimiento continuo; no obliga a registrar cada semana. |
| Tareas y calendario | Ventanas confirmadas y vigentes con semana definida. |

Las capas pueden coincidir. La semana se cuenta una vez, pero debe comprobarse si existe una experiencia integrada o cómo se distribuyen los minutos. Trabajo cotidiano, tareas e instrumentos son capa evaluativa, no otra ruta curricular.

PIA no ubica automáticamente excepciones escritas como texto ni ventanas obsoletas o sin confirmar.

## Uso en computadora, tableta y celular

### Cómo desplazarse y acomodar el mapa

- Arrastre el espacio vacío del mapa para desplazarse en cualquier dirección.
- Pulse **Ajustar mapa** para ver la organización completa dentro del espacio disponible.
- Pulse **100 %** para volver al tamaño real y **Centrar** para centrar el contenido dentro del lienzo.
- Arrastre un bloque para acomodarlo visualmente. Esta acción no cambia su ubicación curricular, fase, semanas ni relaciones.
- Use **Restablecer distribución** para recuperar la organización automática sin perder decisiones pedagógicas.
- Con teclado, enfoque un bloque y use Alt más las flechas. Agregue Mayús para desplazamientos mayores.

### Computadora

Use el mapa de ancho ampliado, el inspector y el calendario. El lienzo tiene su propio desplazamiento; no es necesario buscar una barra al final de la ventana.

### Tableta

El modal ocupa la pantalla, los controles se desplazan horizontalmente y el inspector se reorganiza. Arrastre dentro del lienzo sin desplazar toda la página; cambie a **Tabla accesible** para lectura lineal.

### Celular

La tabla se transforma en tarjetas verticales, las acciones críticas se apilan y el mapa conserva un viewport táctil. Use **Ajustar mapa** para obtener una vista general o **Tabla accesible** si desea una lectura lineal. Ninguna decisión esencial depende de arrastrar.

## Alertas

| Mensaje | Significado | Acción |
| --- | --- | --- |
| Saber pendiente | No existe ubicación. | Elegir o conservarlo conscientemente pendiente. |
| Fase APD pendiente | Participa en Proyecto sin fase. | Revisar la fase correspondiente. |
| Falta rango | Existe ubicación sin tiempo. | Definir semanas o mantener pendiente. |
| Rango inválido | Excede el periodo o está invertido. | Corregir; PIA no recorta. |
| Semanas compartidas | Lecciones y Proyecto coinciden. | Confirmar integración o distribución de minutos. |
| Evidencia repetida | La descripción aparece varias veces. | Evitar doble contabilización. |
| Evaluación desactualizada | Cambió perfil, tiempo o contexto. | Actualizar y reconfirmar. |
| Sin antecedente explícito | El saber inicia en el nivel actual. | Explorar condiciones de entrada. |

## Prompt de análisis

El botón prepara un texto local y no lo envía automáticamente. Solicita auditoría curricular y temporal, comparación de dos a cuatro productos, dos o tres enfoques de ruta, revisión de progresión, escalabilidad, RdA, competencias y perfil, y separación entre hechos, inferencias y recomendaciones.

## Recorrido para experiencia docente o asesoría

1. Confirme currículo, evaluación, tiempo y cambios.
2. Revise pendientes, agrupaciones forzadas y repeticiones sin profundidad.
3. Compruebe puentes entre lecciones y fases del Proyecto.
4. Verifique que el producto evidencie los verbos.
5. Revise calendario, minutos, interrupciones, práctica y realimentación.
6. Evite duplicar evidencias o porcentajes.
7. Compare alternativas mediante el prompt.
8. Realice la validación profesional final.

## Qué puede y qué no puede hacer PIA

PIA puede organizar referentes, crear un borrador reversible de agrupaciones y vínculos revisables, visualizar la ruta, representar rangos declarados, advertir inconsistencias y preparar instrucciones para una IA externa.

PIA no puede certificar integración, profundidad, viabilidad, aprendizaje o RdA; decidir cuándo evaluar; imponer un producto; aprobar adecuaciones; interpretar una PEI; conocer el ritmo real sin evidencia; ni garantizar una respuesta externa.

## Lista de comprobación final

- [ ] Currículo y referentes correctos.
- [ ] Diagnóstico y condiciones de entrada diferenciados.
- [ ] Saberes ubicados o conscientemente pendientes.
- [ ] Agrupaciones coherentes con indicadores, evidencia y tiempo.
- [ ] Relaciones opcionales revisadas sin depender del color.
- [ ] Borrador sugerido por PIA revisado, modificado o descartado conscientemente.
- [ ] Producto realizable que evidencia el verbo.
- [ ] Fases APD y lecciones articuladas en una sola ruta.
- [ ] Semanas compartidas contadas una vez y minutos revisados.
- [ ] Procedimentales, actitudinales, ejes y DUA considerados.
- [ ] Evaluación tratada como capa, sin duplicar evidencias.
- [ ] Alertas y respuesta de IA revisadas profesionalmente.
