# Manual técnico — PIA-PNFT Modular 1.5.1

## Estado y migración

`schemaVersion: 5` amplía cada elemento de `semanas` con `project`:

```text
project.mode                       curricular | mixed | integrated
project.stageId                    etapa vigente
project.phaseId                    fase vigente
project.records[phaseId]           instantánea persistente por fase
achievementIndicators[].officialText
achievementIndicators[].teacherText
evaluationIndicators[].officialText
evaluationIndicators[].teacherText
evaluationIndicators[].selected
```

`PIAProjectComponentCatalog.normalizeWeekProject()` migra de forma aditiva. Los planes sin
`project` reciben la modalidad curricular. La prioridad de lectura es la copia guardada por la
persona docente, luego su instantánea oficial guardada y, solo al crear una fase por primera vez,
el catálogo vigente. De esta forma una actualización futura no reescribe planes anteriores.

## Responsabilidades

- `src/data/project-component-catalog.js`: catálogo versionado, etapas, fases e instantáneas.
- `src/ui/week-view.js`: controles semanales y contenedores dentro de las columnas oficiales.
- `src/application/enhancements.js`: coordinación, persistencia, confirmaciones y renderizado.
- `src/data/evaluation-instruments.js`: conocimiento interno para recomendaciones de IA.
- `src/prompts/*`: contratos de literalidad, integración, evidencia e instrumentos.
- `src/domain/projection/projection-core.js`: estado v5 y migración.

## Invariantes

1. `officialText` nunca se edita desde la interfaz.
2. `teacherText` no se recalcula al cargar, cambiar de fase u ocultar Proyecto.
3. La restauración y el borrado requieren confirmación.
4. Las fases sin indicador oficial no reciben texto sintético.
5. Proyecto no crea un segundo documento ni una tabla de exportación independiente.
6. El catálogo de instrumentos no se convierte en un selector obligatorio.
7. Backend, API y analítica permanecen `local-only` e inactivos.

## Validación

Ejecutar `npm test`. Además, en Edge/Chrome comprobar un plan de III Ciclo con una semana de cada
modalidad, editar ambos tipos de indicadores, cambiar de fase, guardar/cargar JSON y revisar PDF y
Word. La comprobación humana complementa, no reemplaza, las pruebas automatizadas.
