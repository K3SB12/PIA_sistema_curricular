# Manual técnico — PIA-PNFT Modular 1.6.12

## Componentes modificados

| Archivo | Responsabilidad en 1.6.12 |
|---|---|
| `src/domain/curriculum/curricular-progression-service.js` | Compone registros oficiales y la estructura ANTES–AHORA–DESPUÉS. |
| `src/application/enhancements.js` | Abre la vista, genera tarjetas/filtros y amplía la revisión local de respuestas. |
| `src/templates/enhancements.html` | Declara la acción de trayectoria debajo de la cobertura. |
| `src/styles/08-enhancements.css` | Identidad cromática, tarjetas, filtros y adaptación móvil. |
| `src/prompts/semester-projection-prompt.js` | Auditoría temporal posterior y localización de la etapa de Proyecto. |
| `tests/curricular-progression.test.mjs` | Literalidad, continuidad y selección protegida de AHORA. |
| `tests/v1.6.12-trajectory-temporal.test.mjs` | Contratos visuales, exportación, tiempo y localización. |

## Flujo de datos

1. `selectedConcepts()` entrega únicamente los saberes marcados para nivel, módulo y áreas vigentes.
2. `trajectoryView()` relaciona cada saber con una familia mediante `familyIdFor(area, name)`.
3. `curriculumRecordsForFamily()` recupera por nivel los nombres e indicadores literales desde el
   currículo en memoria; no realiza coincidencias aproximadas.
4. `showTrajectory()` convierte la estructura en HTML efímero dentro del modal existente.
5. Los filtros modifican solo el atributo visual `hidden`; no llaman `markDirty()` ni alteran `state`.

La dependencia es de solo lectura: currículo + catálogo relacional → servicio → vista. El prompt conserva
su dependencia independiente mediante `promptSummary()`.

## Compatibilidad y seguridad

- `schemaVersion: 6` permanece sin cambios.
- No se agregan claves al JSON ni al autoguardado.
- No se incorporan solicitudes de red ni recursos externos.
- PDF y Word no consultan ni renderizan la trayectoria.
- Los SVG son cadenas locales de presentación y no contienen enlaces.
- Los identificadores `initial`, `development` y `final` se mantienen para cargar planes existentes.

## Pruebas

Ejecute `npm test`. El cierre 1.6.12 aprueba 127 pruebas, la verificación de fuente, el ensamblado
reproducible y el alcance autorizado. La revisión humana final debe cubrir Edge/Chrome, diseño móvil,
teclado, `Esc`, texto extenso, `file://`, JSON, PDF y Word.
