# Manual técnico — PIA-PNFT Modular 1.6.13

## Componentes principales

| Archivo | Responsabilidad |
|---|---|
| `scripts/import-curricular-progression.mjs` | Importa la matriz y asigna `no-curricular-record` a celdas vacías. |
| `src/data/curricular-progression.js` | Catálogo 1.1.0 de 38 familias y diez niveles. |
| `src/domain/curriculum/curricular-progression-service.js` | Compone referentes anterior, actual y posterior sin inferencias. |
| `src/application/enhancements.js` | Trayectoria, filtros, tabla, fuentes, diagnóstico y orientación evaluativa. |
| `src/templates/enhancements.html` | Controles de trayectoria, diagnóstico y evaluación. |
| `src/styles/08-enhancements.css` | Diseño PNFT, tarjetas, tabla y adaptación móvil. |
| `src/assets/pnft-area-icons.png` | Recurso gráfico PNFT suministrado. |
| `scripts/build.mjs` | Inserta el recurso gráfico como `data:` para mantener el HTML autónomo. |
| `src/prompts/semester-projection-prompt.js` | Diagnóstico condicional y auditoría temporal posterior. |

## Estados curriculares

| Estado | Regla |
|---|---|
| `explicit-evaluable` | La matriz contiene alcance explícito y el currículo operativo aporta el indicador. |
| `conceptual-non-evaluable` | Presencia conceptual sin indicador, respaldada expresamente. |
| `reinforced-non-evaluable` | Fortalecimiento sin evaluación directa, respaldado expresamente. |
| `no-curricular-record` | Celda vacía; no permite inferir enseñanza, refuerzo o dominio. |
| `not-applicable` | La fuente contiene `N/A`. |

`SOURCE_VERIFIED_STATES` es el único punto autorizado para incorporar estados no evaluables derivados de
una fuente explícita. Permanece vacío mientras no exista esa trazabilidad.

## Compatibilidad

- `schemaVersion: 6` no cambia.
- Los planes anteriores se migran; un diagnóstico previo solo se activa automáticamente cuando contiene
  información real guardada, no por el antiguo valor inicial de dos lecciones.
- La trayectoria no persiste y queda fuera de PDF y Word.
- El HTML portable contiene el recurso gráfico y no necesita red ni servidor.
- `PNFT_DATA`, `RDA_POR_CICLO`, Preescolar y los indicadores oficiales no fueron modificados.

## Validación

Ejecute `npm test`. La suite incluye contratos de vacío curricular, filtros y vistas, recurso gráfico,
diagnóstico opcional, terminología evaluativa, prompt sin trayectoria, auditoría temporal, exportaciones,
persistencia y regresión general.
