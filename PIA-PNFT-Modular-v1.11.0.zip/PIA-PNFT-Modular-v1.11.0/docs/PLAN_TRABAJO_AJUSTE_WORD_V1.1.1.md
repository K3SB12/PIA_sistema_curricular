# Plan de trabajo — ajuste Word horizontal de PIA 1.1.1

## Objetivo

Corregir la orientación del archivo Word guardado, contener encabezados largos y renombrar el
botón morado del diálogo como **Exportar**, sin modificar la presentación ni el comportamiento
validado del planeamiento, PDF, JSON, currículo, semanas o versión portable.

## Alcance aplicado

1. Confirmar la integridad de la versión 1.1.0 y sus referencias protegidas.
2. Modificar únicamente el bloque autorizado de exportación Word y el texto del botón del modal.
3. Declarar A4 horizontal mediante CSS estándar y metadatos compatibles con Microsoft Word.
4. Permitir ajuste de línea dentro de tablas, títulos de sección y encabezados.
5. Mantener la vista previa continua, sin saltos de página forzados.
6. Regenerar `index.html`, `dist/web/index.html` y `dist/portable/index.html` desde `src/`.
7. Ejecutar verificaciones de fuente, red, alcance autorizado, construcción, guardado/carga JSON,
   eliminación de semanas, selección PDF/Word, descarga, respaldo e impresión.
8. Generar un `.doc`, abrirlo con LibreOffice y comprobar visualmente su conversión a A4 horizontal.

## Resultado

- Las ocho pruebas automatizadas aprobaron.
- Las tres salidas generadas son idénticas.
- Las referencias curriculares conservan su huella original.
- El documento de prueba se reconoció como A4 horizontal de 841,89 × 595,304 puntos.
- El botón morado muestra **📄 Exportar** para PDF y Word.
- No se añadieron API, backend, dependencias ni solicitudes de red.

## Aceptación docente pendiente

En una computadora con Microsoft Edge o Google Chrome: abrir `dist/portable/index.html`, cargar un
plan de prueba, seleccionar Word, presionar **Exportar**, guardar el `.doc`, abrirlo en Microsoft
Word y confirmar orientación horizontal, contenido completo, impresión y ubicación de descarga.
Esta aceptación no requiere modificar el código si el resultado coincide con la validación incluida.
