# AGENTS.md — Reglas obligatorias para PIA-PNFT

## 1. Propósito

Este documento establece cómo debe trabajar cualquier agente de programación dentro del repositorio PIA-PNFT.

PIA es un aplicativo validado, publicado y utilizado por docentes desde marzo de 2026. La fase actual no corresponde a un rediseño ni a una sustitución. Su único propósito es organizar profesionalmente el código interno para mejorar su comprensión, mantenimiento, persistencia y escalabilidad.

## 2. Orden obligatorio de lectura

Antes de analizar, planificar o modificar archivos, el agente debe leer completamente y en este orden:

1. `AGENTS.md`.
2. `docs/info.md`.
3. `docs/SPEC.md`.
4. `docs/tasks.md`.
5. `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`.
6. `docs/BITACORA_PIA_PNFT.md`.
7. `docs/MAPA_FUNCIONES_PIA_PNFT.json` cuando la tarea requiera analizar funciones o dependencias.

Si existe contradicción entre documentos, el agente debe detenerse y solicitar una decisión humana. No debe resolver contradicciones por inferencia.

## 3. Regla principal de preservación absoluta

La reorganización de PIA-PNFT es exclusivamente interna.

La versión resultante debe conservar exactamente:

- la plantilla visual;
- los estilos, colores, tipografía, medidas y distribución;
- la secuencia de uso;
- las secciones, categorías, campos, rótulos y controles;
- las funciones visibles;
- los datos curriculares;
- la correspondencia ciclo–nivel;
- la correspondencia nivel–módulo;
- la correspondencia módulo–área;
- la correspondencia área–saber–indicador;
- `PNFT_DATA`;
- `RDA_POR_CICLO`;
- la creación, edición, aumento, reducción y eliminación de semanas;
- el guardado y apertura de JSON;
- la compatibilidad con planeamientos creados desde marzo de 2026;
- la exportación PDF vigente;
- los *prompts* general y semanal;
- el acceso manual a ChatGPT y Copilot;
- el funcionamiento conectado y desconectado;
- la posibilidad de entregar un `index.html` autónomo.

Si una reorganización produce cualquier diferencia visual, funcional, curricular, secuencial, documental o de compatibilidad, la tarea se considera fallida y el cambio debe revertirse.

## 4. Fuente de referencia inalterable

Los siguientes archivos contienen la misma versión original:

- `index.html`.
- `reference/index.original.html`.

La huella SHA-256 aprobada para ambos es:

```text
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79
```

Durante la fase de documentación y pruebas de caracterización:

- no se debe modificar `index.html`;
- nunca se debe modificar `reference/index.original.html`;
- las pruebas iniciales deben ejecutarse contra la versión vigente;
- cualquier futura versión generada debe compararse contra esta referencia.

## 5. Protección de la base curricular

`PNFT_DATA` y `RDA_POR_CICLO` contienen información curricular oficial validada.

El agente no debe:

- modificarla por iniciativa propia;
- corregir ortografía, estilo o redacción sin autorización;
- resumir o parafrasear resultados de aprendizaje, saberes o indicadores;
- trasladar contenido entre niveles, módulos o áreas;
- completar campos mediante inferencias;
- eliminar información aparentemente duplicada;
- sustituir nombres oficiales;
- normalizar mayúsculas, tildes o signos si ello modifica el texto;
- cambiar varios elementos cuando la solicitud autoriza solamente uno.

Una futura modificación curricular debe indicar obligatoriamente:

1. nivel;
2. módulo;
3. área de conocimiento;
4. elemento curricular;
5. texto vigente;
6. texto nuevo aprobado;
7. fuente oficial;
8. motivo;
9. criterios de aceptación;
10. aprobación humana.

Si falta cualquiera de estos datos, el agente debe detenerse y solicitar aclaración.

## 6. Acciones no autorizadas en la fase actual

El agente no debe:

- rediseñar la interfaz;
- cambiar estilos o textos visibles;
- reordenar secciones;
- agregar o eliminar campos;
- agregar funciones no solicitadas;
- introducir React, Vue, Angular u otro *framework*;
- introducir una API, autenticación, base de datos remota o servidor de aplicación;
- cambiar el formato JSON sin un plan de migración aprobado;
- eliminar funciones duplicadas sin pruebas previas;
- corregir automáticamente los hallazgos del análisis;
- instalar dependencias innecesarias;
- publicar directamente en producción;
- ejecutar pruebas de carga o estrés contra GitHub Pages;
- ejecutar pruebas de estrés sin autorización, entorno, límites y mecanismo de detención;
- trabajar simultáneamente con otros agentes sobre los mismos archivos sin una división aprobada.

## 7. Principios de trabajo

El agente debe:

- trabajar una tarea a la vez;
- identificar la primera tarea `PENDIENTE` autorizada;
- inspeccionar antes de modificar;
- realizar el cambio mínimo necesario;
- crear o seleccionar pruebas antes de reorganizar;
- preservar compatibilidad histórica;
- comparar antes y después;
- revisar diferencias exactas;
- registrar evidencia;
- actualizar `docs/tasks.md` únicamente después de verificar;
- añadir una nueva entrada a `docs/BITACORA_PIA_PNFT.md` al cerrar cada jornada;
- solicitar revisión humana antes de publicar.

## 8. Hallazgos no equivalen a defectos confirmados

Los códigos `PIA-H001` a `PIA-H014` son hallazgos del análisis estático.

El agente no debe corregirlos directamente. Primero debe:

1. reproducir el comportamiento;
2. ejecutar una prueba controlada;
3. conservar evidencia;
4. clasificar el hallazgo como confirmado, descartado o pendiente;
5. solicitar autorización para cualquier corrección funcional.

## 9. Funciones y estructuras críticas

Requieren pruebas reforzadas:

- `PNFT_DATA`;
- `RDA_POR_CICLO`;
- `semanas`;
- `actualizarAreaSemana()`;
- `actualizarRdASemana()`;
- `generarSaberesConceptuales()`;
- `manejarSeleccionSaber()`;
- `actualizarIndicadoresSemana()`;
- `obtenerIndicadoresLogroSemana()`;
- `reconstruirVistaSemanasPreservandoContenido()`;
- `obtenerDatosPlan()`;
- `cargarPlan()`;
- `exportarAPDF()`;
- `generarPromptCompleto()`;
- `generarPromptSemana()`;
- `descargarVersionPortable()`.

## 10. Compatibilidad de archivos JSON

Los planeamientos creados desde marzo de 2026 constituyen datos de compatibilidad obligatoria.

El agente debe:

- preservar la lectura del formato vigente;
- no eliminar campos históricos;
- no cambiar nombres o tipos sin migración;
- utilizar copias ficticias o anonimizadas para pruebas;
- comprobar guardado → apertura → equivalencia;
- evitar incluir datos personales reales en pruebas automatizadas.

## 11. Versiones web y portable

La arquitectura futura tendrá una única fuente modular y dos salidas:

1. versión web para GitHub Pages;
2. `index.html` autónomo para descarga y uso sin conexión.

La versión portable no puede depender de que el docente instale Node.js, npm o un servidor local. Node.js se utilizará únicamente durante desarrollo, pruebas y construcción.

## 12. Flujo obligatorio de una tarea

```text
1. Leer documentación obligatoria.
2. Identificar tarea y alcance.
3. Confirmar archivos permitidos.
4. Identificar comportamiento de referencia.
5. Preparar prueba o evidencia previa.
6. Presentar plan.
7. Esperar aprobación cuando la tarea pueda cambiar código.
8. Implementar el cambio mínimo.
9. Ejecutar pruebas.
10. Comparar con la referencia.
11. Revisar seguridad y compatibilidad.
12. Documentar resultados.
13. Actualizar tarea y bitácora.
14. Solicitar revisión humana.
```

## 13. Regla de detención

El agente debe detenerse cuando:

- falte una especificación;
- una tarea pueda cambiar contenido curricular;
- se detecte una diferencia no autorizada;
- las pruebas no puedan ejecutarse;
- un JSON histórico deje de abrir;
- una modificación requiera credenciales, infraestructura o autoridad no concedida;
- exista riesgo de afectar la versión publicada;
- dos documentos indiquen acciones incompatibles.

## 14. Documentación y bitácora

Cada entrada de bitácora debe incluir:

- fecha;
- objetivo;
- archivos revisados;
- acciones realizadas;
- hallazgos;
- decisiones;
- cambios implementados;
- pruebas y resultados;
- riesgos o bloqueos;
- archivos producidos;
- pendientes;
- próximo paso;
- validación humana cuando corresponda.

Las entradas anteriores no deben eliminarse ni reescribirse.

## 15. Definición de terminado de una tarea

Una tarea está terminada solamente cuando:

- cumple su objetivo y criterios de aceptación;
- conserva la equivalencia absoluta;
- tiene pruebas aprobadas;
- no genera errores nuevos;
- no modifica contenido curricular;
- conserva compatibilidad con JSON históricos;
- fue revisada;
- actualizó tareas y bitácora;
- cuenta con aprobación humana cuando corresponda.

## 16. Estado inicial de esta entrega

Esta entrega es documental. No autoriza la reorganización del código. La primera tarea técnica autorizable será crear pruebas de caracterización sobre el `index.html` vigente sin modificarlo.

## 17. Protocolo de ejecución ágil para tareas autorizadas

Este protocolo complementa las reglas anteriores y no elimina, sustituye ni debilita ninguna protección, requisito de aprobación o regla de detención de este documento.

1. **Autoridad documental.** `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, el análisis funcional, la bitácora y, cuando corresponda, el mapa de funciones constituyen la autoridad del trabajo en el orden definido en la sección 2. El alcance literal de la tarea prevalece sobre ampliaciones inferidas.
2. **Frontera de integridad.** Las huellas SHA-256 aprobadas y `BASELINE.sha256` son la frontera objetiva de integridad. Deben comprobarse antes de una ejecución que dependa de la línea base y después de cualquier cambio o ejecución autorizada que pueda producir artefactos.
3. **Pruebas acotadas.** Cada prueba debe limitarse al criterio literal de aceptación de la tarea activa. No se debe volver a caracterizar toda la aplicación, ampliar cobertura a tareas posteriores ni convertir hallazgos adyacentes en correcciones no autorizadas.
4. **Ciclo mínimo.** Cuando exista autorización humana explícita para implementar y continuar, se realizará una implementación mínima, una revisión focalizada y una ejecución canónica. Una revisión o ejecución ya aprobada no se repite. Cualquier repetición posterior a un fallo exige conservar el run fallido y cumplir la autorización aplicable de las secciones 8, 12 y 13.
5. **Cobertura `file://`.** La modalidad `file://` se ejecutará únicamente cuando el criterio de la tarea requiera equivalencia portable, funcionamiento autónomo o cobertura offline. Debe ser mínima y posterior a la ejecución canónica aprobada, salvo que la especificación indique otro orden.
6. **Continuidad autorizada.** El agente puede avanzar entre tareas consecutivas cuando la autorización humana lo indique expresamente, siempre de una en una, después de cerrar la anterior y sin exceder el último identificador autorizado. Esa autorización satisface la espera del paso 7 de la sección 12 únicamente para el alcance literal ya aprobado; no autoriza cambios adicionales.
7. **Detención operativa.** Dentro de un alcance ya autorizado, el agente debe continuar sin solicitar aprobaciones intermedias y detenerse únicamente ante un fallo real, una diferencia de integridad, una ambigüedad material que pueda alterar el producto o un riesgo de sobrescritura. Las situaciones enumeradas en la sección 13 se interpretan y atienden como manifestaciones obligatorias de estas condiciones, no como excepciones para continuar.
8. **Conservación ante fallos.** Todo artefacto, resultado, reporte, captura, traza o diagnóstico generado por un run fallido debe conservarse sin sobrescritura. No se debe repetir el run, corregir automáticamente el defecto ni promover sus resultados como evidencia válida sin la autorización correspondiente.
9. **Cierre y evidencia.** Tras una ejecución aprobada se deben revisar resultados, consola, página, red, huellas y cierre de procesos; componer evidencia sin datos locales; actualizar únicamente la tarea activa; añadir una nueva entrada de bitácora; y solicitar revisión humana cuando corresponda antes de publicar.
