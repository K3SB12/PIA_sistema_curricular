# SPEC.md — Especificación de preservación y reorganización de PIA-PNFT

## 1. Propósito de la especificación

Definir los requisitos verificables para organizar profesionalmente el código interno de PIA sin alterar el producto vigente.

## 2. Principio rector

La reorganización será exclusivamente interna.

La versión reorganizada debe producir, para las mismas entradas, la misma apariencia, secuencia, información, correspondencia y salida que la versión original.

```text
Misma entrada + mismo proceso + mismos datos
= misma salida + misma experiencia docente
```

## 3. Línea base

Archivos equivalentes de referencia:

- `index.html`.
- `reference/index.original.html`.

Huella SHA-256:

```text
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79
```

## 4. Alcance autorizado

La fase de reorganización podrá:

- documentar funciones y dependencias;
- crear pruebas sobre el comportamiento actual;
- separar responsabilidades internas;
- organizar datos, estado, interfaz, persistencia, exportación y *prompts*;
- establecer procesos de construcción;
- generar una versión web y una versión portable;
- incorporar controles de calidad que no cambien el comportamiento aprobado.

## 5. Fuera del alcance

No se autoriza:

- rediseñar la plantilla;
- modificar contenido curricular;
- cambiar la secuencia de uso;
- agregar o eliminar secciones;
- agregar o eliminar campos;
- cambiar categorías;
- modificar estilos;
- cambiar *prompts*;
- cambiar la exportación PDF visible;
- cambiar el formato JSON sin migración aprobada;
- incorporar autenticación, backend o API;
- sustituir la aplicación por un *framework*;
- introducir nuevas funciones docentes.

## 6. Requisitos de equivalencia

### PIA-REQ-EQ-001 — Equivalencia visual

La versión reorganizada deberá conservar colores, tipografía, dimensiones, distribución, espaciados, tablas, modales, botones, iconos y comportamiento responsivo.

**Criterios de aceptación:**

- Las capturas en resoluciones acordadas coinciden con la referencia dentro del umbral aprobado.
- No existen elementos faltantes, desplazados, recortados o añadidos.
- La impresión y exportación mantienen su disposición.

### PIA-REQ-EQ-002 — Equivalencia funcional

Todas las acciones disponibles en la versión original deberán producir el mismo resultado.

**Criterios de aceptación:**

- Cada flujo documentado tiene una prueba equivalente.
- No se pierden controles ni respuestas.
- No aparecen errores nuevos en consola.

### PIA-REQ-EQ-003 — Equivalencia secuencial

El orden de interacción del docente se conservará.

**Criterios de aceptación:**

- Ciclo y nivel mantienen su relación.
- Las semanas se crean y actualizan en el mismo momento.
- Las áreas preceden la selección de saberes e indicadores.

### PIA-REQ-EQ-004 — Equivalencia curricular

Los textos y correspondencias curriculares deberán permanecer exactos.

**Criterios de aceptación:**

- `PNFT_DATA` conserva todos sus textos.
- `RDA_POR_CICLO` conserva todos sus textos.
- Cada nivel, módulo, área, saber e indicador mantiene su ubicación.
- Una comparación automatizada no detecta diferencias no autorizadas.

### PIA-REQ-EQ-005 — Compatibilidad histórica

La versión reorganizada deberá abrir los planeamientos JSON generados desde marzo de 2026.

**Criterios de aceptación:**

- Cada archivo histórico de prueba abre sin pérdida.
- Guardar y volver a abrir conserva el contenido.
- Una migración futura no elimina campos.

## 7. Requisitos curriculares

### PIA-REQ-CUR-001 — Consulta de datos

El sistema deberá obtener la información curricular a partir del nivel, módulo, área y saber correspondiente.

### PIA-REQ-CUR-002 — Resultados de aprendizaje

El sistema deberá mostrar los RdA exactos del ciclo y área seleccionados.

### PIA-REQ-CUR-003 — Identidad futura

La futura organización podrá incorporar identificadores internos estables para diferenciar saberes, siempre que no cambie el texto visible ni los JSON históricos sin migración.

### PIA-REQ-CUR-004 — Actualización controlada

Una modificación curricular requerirá solicitud explícita, fuente y aprobación humana.

## 8. Requisitos de semanas

### PIA-REQ-SEM-001

La cantidad de semanas continuará calculándose según la cantidad de lecciones vigente.

### PIA-REQ-SEM-002

Aumentar semanas deberá conservar el contenido existente.

### PIA-REQ-SEM-003

Reducir semanas deberá conservar el comportamiento de confirmación y eliminar únicamente las semanas excedentes cuando se acepte.

### PIA-REQ-SEM-004

Eliminar una semana deberá mantener correctamente las semanas restantes y sus selecciones.

### PIA-REQ-SEM-005

La reconstrucción deberá restaurar áreas, saberes, indicadores, saberes procedimentales, actitudinales y campos editables.

## 9. Requisitos de persistencia

### PIA-REQ-DATA-001

El guardado deberá producir un JSON con el contenido que produce la versión original.

### PIA-REQ-DATA-002

La apertura deberá reconstruir el plan sin pérdida.

### PIA-REQ-DATA-003

Antes de endurecer validaciones deberá existir una colección de JSON históricos de prueba.

### PIA-REQ-DATA-004

Una futura versión del esquema deberá incluir migraciones compatibles.

## 10. Requisitos de exportación

### PIA-REQ-EXP-001

La exportación PDF deberá conservar exactamente las secciones seleccionadas, contenido, formato y comportamiento vigentes.

### PIA-REQ-EXP-002

La presencia de `exportarAWord()` no implica que Word sea una función visible autorizada. Su estado deberá confirmarse antes de modificarla o eliminarla.

## 11. Requisitos de *prompts*

### PIA-REQ-PRM-001

El *prompt* general deberá conservar textos, orden, datos curriculares, ejes, metodología, semanas e instrucciones.

### PIA-REQ-PRM-002

El *prompt* semanal deberá conservar exclusivamente la información correspondiente a la semana seleccionada y las instrucciones vigentes.

### PIA-REQ-PRM-003

PIA no enviará el contenido mediante API. El docente continuará copiando y pegando manualmente.

## 12. Requisitos de funcionamiento web y offline

### PIA-REQ-OFF-001

El repositorio deberá generar una versión web y una versión portable desde una misma fuente.

### PIA-REQ-OFF-002

La versión portable funcionará sin servidor, Node.js ni instalación adicional en la computadora docente.

### PIA-REQ-OFF-003

Se deberá verificar el comportamiento visual cuando Google Fonts no esté disponible.

## 13. Requisitos de seguridad

### PIA-REQ-SEC-001

No se almacenarán secretos, tokens ni claves en el repositorio.

### PIA-REQ-SEC-002

Las pruebas de archivos JSON deberán utilizar datos ficticios o anonimizados.

### PIA-REQ-SEC-003

Una futura validación de JSON no podrá rechazar archivos históricos válidos.

### PIA-REQ-SEC-004

El contenido importado no deberá ejecutar código. Este requisito deberá implementarse únicamente después de caracterizar el contenido HTML permitido y aprobar la compatibilidad.

### PIA-REQ-SEC-005

No se ejecutarán pruebas de estrés contra infraestructura externa sin autorización.

## 14. Requisitos de mantenibilidad

### PIA-REQ-MNT-001

Cada módulo futuro tendrá una responsabilidad principal.

### PIA-REQ-MNT-002

Los datos curriculares estarán separados de la lógica, sin modificar su contenido.

### PIA-REQ-MNT-003

Las tareas, pruebas, decisiones y cambios deberán conservar trazabilidad.

### PIA-REQ-MNT-004

Cada cambio deberá poder revertirse.

## 15. Requisitos de rendimiento

Antes de una prueba de carga se presentarán plan, riesgos, archivos, entorno, límites, umbrales y mecanismo de detención.

Las pruebas del navegador y del alojamiento se tratarán por separado.

## 16. Puertas de calidad

Una reorganización no podrá avanzar si falla alguna de estas puertas:

1. integridad curricular;
2. compatibilidad JSON;
3. equivalencia funcional;
4. equivalencia visual;
5. funcionamiento offline;
6. ausencia de errores nuevos;
7. revisión de seguridad;
8. aprobación humana.

## 17. Definición de terminado del proyecto

El proyecto reorganizado estará terminado cuando:

- todas las tareas obligatorias estén verificadas;
- todas las pruebas de equivalencia estén aprobadas;
- los textos curriculares sean idénticos;
- los JSON históricos abran correctamente;
- la versión web y portable funcionen;
- la documentación coincida con el resultado;
- exista evidencia de revisión técnica y humana;
- exista un procedimiento probado de reversión.
