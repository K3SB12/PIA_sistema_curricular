import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const EXPECTED_HEADERS = ['centro', 'cod_saber', 'cod_pres'];

function decodeXml(value = '') {
  return value
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&quot;', '"')
    .replaceAll('&apos;', "'")
    .replaceAll('&amp;', '&');
}

function zipEntries(buffer) {
  const endSignature = 0x06054b50;
  const centralSignature = 0x02014b50;
  const localSignature = 0x04034b50;
  const minimumOffset = Math.max(0, buffer.length - 65_557);
  let endOffset = -1;

  for (let offset = buffer.length - 22; offset >= minimumOffset; offset -= 1) {
    if (buffer.readUInt32LE(offset) === endSignature) {
      endOffset = offset;
      break;
    }
  }
  if (endOffset < 0) throw new Error('El archivo no es un XLSX/ZIP válido.');

  const entries = new Map();
  const totalEntries = buffer.readUInt16LE(endOffset + 10);
  let offset = buffer.readUInt32LE(endOffset + 16);

  for (let index = 0; index < totalEntries; index += 1) {
    if (buffer.readUInt32LE(offset) !== centralSignature) {
      throw new Error('Directorio central ZIP inválido.');
    }
    const compression = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const uncompressedSize = buffer.readUInt32LE(offset + 24);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString('utf8');

    if (buffer.readUInt32LE(localOffset) !== localSignature) {
      throw new Error(`Entrada ZIP inválida: ${name}`);
    }
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataOffset = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(dataOffset, dataOffset + compressedSize);
    let data;
    if (compression === 0) data = compressed;
    else if (compression === 8) data = inflateRawSync(compressed);
    else throw new Error(`Compresión ZIP no soportada (${compression}) en ${name}.`);
    if (data.length !== uncompressedSize) throw new Error(`Tamaño ZIP inválido en ${name}.`);
    entries.set(name, data);
    offset += 46 + nameLength + extraLength + commentLength;
  }

  return entries;
}

function sharedStringsFrom(entries) {
  const xml = entries.get('xl/sharedStrings.xml')?.toString('utf8') || '';
  return [...xml.matchAll(/<(?:(?:\w+):)?si\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?si>/g)].map((match) =>
    [...match[1].matchAll(/<(?:(?:\w+):)?t\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?t>/g)]
      .map((part) => decodeXml(part[1]))
      .join('')
  );
}

function columnIndex(reference) {
  const letters = reference.match(/^[A-Z]+/)?.[0] || '';
  return [...letters].reduce((value, letter) => value * 26 + letter.charCodeAt(0) - 64, 0) - 1;
}

function rowsFromWorksheet(xml, sharedStrings) {
  return [...xml.matchAll(/<(?:(?:\w+):)?row\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?row>/g)].map((rowMatch) => {
    const row = [];
    for (const cellMatch of rowMatch[1].matchAll(/<(?:(?:\w+):)?c\b([^>]*)\/>|<(?:(?:\w+):)?c\b([^>]*)>([\s\S]*?)<\/(?:(?:\w+):)?c>/g)) {
      const attributes = cellMatch[1] || cellMatch[2] || '';
      const body = cellMatch[3] || '';
      const reference = attributes.match(/\br="([A-Z]+\d+)"/)?.[1];
      if (!reference) continue;
      const type = attributes.match(/\bt="([^"]+)"/)?.[1] || '';
      const raw = body.match(/<(?:(?:\w+):)?v>([\s\S]*?)<\/(?:(?:\w+):)?v>/)?.[1]
        ?? body.match(/<(?:(?:\w+):)?t\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?t>/)?.[1]
        ?? '';
      row[columnIndex(reference)] = type === 's' ? sharedStrings[Number(raw)] : decodeXml(raw);
    }
    return row;
  });
}

export function extractCentersFromXlsx(buffer) {
  const entries = zipEntries(buffer);
  const worksheet = entries.get('xl/worksheets/sheet1.xml');
  if (!worksheet) throw new Error('No se encontró xl/worksheets/sheet1.xml.');
  const rows = rowsFromWorksheet(worksheet.toString('utf8'), sharedStringsFrom(entries));
  const headers = rows.shift()?.map((value) => String(value || '').trim().toLowerCase()) || [];
  for (const expected of EXPECTED_HEADERS) {
    if (!headers.includes(expected)) throw new Error(`Falta la columna obligatoria ${expected}.`);
  }
  const positions = Object.fromEntries(EXPECTED_HEADERS.map((header) => [header, headers.indexOf(header)]));

  const centers = rows.map((row, rowIndex) => ({
    centro: String(row[positions.centro] || '').trim(),
    codPres: String(row[positions.cod_pres] || '').trim().padStart(4, '0'),
    codSaber: String(row[positions.cod_saber] || '').trim()
  })).filter((record) => record.centro || record.codPres || record.codSaber);

  const invalid = centers.filter((record) => !record.centro || !record.codSaber || !/^\d{4}$/.test(record.codPres));
  if (invalid.length) throw new Error(`Hay ${invalid.length} filas incompletas o con cod_pres inválido.`);

  const excluded = centers.filter((record) => record.codPres === '0000').length;
  const accepted = centers.filter((record) => record.codPres !== '0000');
  const codSaberSet = new Set(accepted.map((record) => record.codSaber));
  if (codSaberSet.size !== accepted.length) throw new Error('cod_saber debe ser único en el catálogo público.');

  accepted.sort((left, right) => left.codPres.localeCompare(right.codPres, 'es-CR') || left.centro.localeCompare(right.centro, 'es-CR'));
  return { centers: accepted, excluded };
}

export function summarizeCenters(centers) {
  const byCode = new Map();
  for (const center of centers) {
    const list = byCode.get(center.codPres) || [];
    list.push(center);
    byCode.set(center.codPres, list);
  }
  const ambiguous = [...byCode.values()].filter((list) => list.length > 1);
  return {
    records: centers.length,
    distinctCodes: byCode.size,
    uniqueCodes: [...byCode.values()].filter((list) => list.length === 1).length,
    ambiguousCodes: ambiguous.length,
    ambiguousRecords: ambiguous.reduce((total, list) => total + list.length, 0),
    uniqueCodSaber: new Set(centers.map((center) => center.codSaber)).size
  };
}

export function serializeCentersModule(centers, sourceName) {
  return '// PIA_INSTITUTIONAL_CENTERS_JS_START\n' +
    `// Generado por scripts/import-centers.mjs desde ${sourceName}.\n` +
    '// Datos públicos mínimos: no incluye personas asesoras, correos ni teléfonos.\n' +
    `const PIAInstitutionalCenters = Object.freeze(${JSON.stringify(centers, null, 2)});\n` +
    '// PIA_INSTITUTIONAL_CENTERS_JS_END\n';
}

async function main() {
  const inputPath = resolve(process.argv[2] || '../outputs/centers-filter/Asesores-Centros-sin-0000.xlsx');
  const outputPath = resolve(process.argv[3] || 'src/data/institutional-centers.js');
  const { centers, excluded } = extractCentersFromXlsx(await readFile(inputPath));
  await writeFile(outputPath, serializeCentersModule(centers, inputPath.split(/[\\/]/).at(-1)), 'utf8');
  const summary = summarizeCenters(centers);
  console.log(JSON.stringify({ inputPath, outputPath, excluded, ...summary }, null, 2));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await main();
}
