import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';

const LEVELS = Object.freeze([
  ['0°', 3], ['1°', 4], ['2°', 5], ['3°', 6], ['4°', 7],
  ['5°', 8], ['6°', 9], ['7°', 10], ['8°', 11], ['9°', 12]
]);

const FAMILY_ROWS = Object.freeze([
  [6, 'programming.environments', 'Entornos de programación'],
  [8, 'programming.logic', 'Introducción a la lógica'],
  [9, 'programming.algorithms', 'Algoritmos'],
  [10, 'programming.data-structures', 'Estructura de datos'],
  [11, 'programming.control-structures', 'Estructuras de control'],
  [12, 'programming.operators', 'Operadores'],
  [13, 'programming.events-functions', 'Eventos, procedimientos y funciones'],
  [16, 'digital.fundamentals', 'Conceptos básicos de hardware y software'],
  [17, 'digital.connections', 'Conexión y comunicación entre dispositivos'],
  [18, 'digital.operating-systems', 'Sistemas operativos'],
  [20, 'digital.productivity', 'Herramientas de productividad'],
  [21, 'digital.multimedia', 'Creación y edición de audio, imagen y video'],
  [22, 'digital.internet', 'Internet'],
  [23, 'digital.collaboration', 'Ciudadanía digital colaborativa'],
  [24, 'digital.intellectual-property', 'Propiedad intelectual'],
  [25, 'digital.iot', 'Internet de las cosas'],
  [26, 'digital.crypto', 'Monedas virtuales y criptomonedas'],
  [28, 'digital.citizenship', 'Ciudadanía e identidad digital'],
  [29, 'digital.authentication', 'Contraseñas y autenticación'],
  [30, 'digital.hacking', 'Hackeo'],
  [31, 'digital.malware', 'Software malicioso y antivirus'],
  [32, 'digital.online-risks', 'Riesgos en línea y seguridad web'],
  [35, 'physical.robotics', 'Robótica'],
  [37, 'physical.mechanics', 'Conceptos básicos de mecánica'],
  [38, 'physical.mechanisms', 'Mecanismos robóticos'],
  [40, 'physical.electronics', 'Principios de electrónica'],
  [42, 'physical.interfaces', 'Interfaces físicas y digitales'],
  [43, 'physical.domotics', 'Domótica y prototipos'],
  [48, 'data.importance', 'Datos y su importancia'],
  [50, 'data.management', 'Gestión de datos'],
  [51, 'data.visualization-intro', 'Introducción a la visualización de datos'],
  [53, 'data.statistics', 'Introducción a estadística descriptiva'],
  [55, 'data.presentation', 'Presentación clara y efectiva de datos'],
  [57, 'data.augmented-reality', 'Realidad aumentada'],
  [58, 'data.virtual-reality', 'Realidad virtual'],
  [59, 'data.metaverse', 'Metaversos'],
  [60, 'data.blockchain', 'Tecnología blockchain'],
  [62, 'data.ai', 'Inteligencia artificial']
]);

const INDICATOR_EXAMPLE_FAMILIES = Object.freeze([
  'programming.environments',
  'programming.algorithms',
  'programming.data-structures',
  'digital.productivity',
  'digital.internet',
  'data.ai'
]);

// Solo se incorporan estados no evaluables cuando una fuente curricular los
// declara de forma expresa. Una celda vacía de la matriz no constituye esa
// evidencia y, por tanto, nunca se registra aquí como fortalecimiento.
const SOURCE_VERIFIED_STATES = Object.freeze({});

function decodeXml(value = '') {
  return value.replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"')
    .replaceAll('&apos;', "'").replaceAll('&amp;', '&');
}

function zipEntries(buffer) {
  const endSignature = 0x06054b50, centralSignature = 0x02014b50, localSignature = 0x04034b50;
  const minimumOffset = Math.max(0, buffer.length - 65_557);
  let endOffset = -1;
  for (let offset = buffer.length - 22; offset >= minimumOffset; offset -= 1) {
    if (buffer.readUInt32LE(offset) === endSignature) { endOffset = offset; break; }
  }
  if (endOffset < 0) throw new Error('El archivo no es un XLSX/ZIP válido.');
  const entries = new Map();
  const totalEntries = buffer.readUInt16LE(endOffset + 10);
  let offset = buffer.readUInt32LE(endOffset + 16);
  for (let index = 0; index < totalEntries; index += 1) {
    if (buffer.readUInt32LE(offset) !== centralSignature) throw new Error('Directorio central ZIP inválido.');
    const compression = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const uncompressedSize = buffer.readUInt32LE(offset + 24);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString('utf8');
    if (buffer.readUInt32LE(localOffset) !== localSignature) throw new Error(`Entrada ZIP inválida: ${name}`);
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataOffset = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(dataOffset, dataOffset + compressedSize);
    const data = compression === 0 ? compressed : compression === 8 ? inflateRawSync(compressed) : null;
    if (!data) throw new Error(`Compresión ZIP no soportada (${compression}) en ${name}.`);
    if (data.length !== uncompressedSize) throw new Error(`Tamaño ZIP inválido en ${name}.`);
    entries.set(name, data);
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

function sharedStringsFrom(entries) {
  const xml = entries.get('xl/sharedStrings.xml')?.toString('utf8') || '';
  return [...xml.matchAll(/<(?:(?:\w+):)?si\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?si>/g)].map(match =>
    [...match[1].matchAll(/<(?:(?:\w+):)?t\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?t>/g)]
      .map(part => decodeXml(part[1])).join('')
  );
}

function columnIndex(reference) {
  const letters = reference.match(/^[A-Z]+/)?.[0] || '';
  return [...letters].reduce((value, letter) => value * 26 + letter.charCodeAt(0) - 64, 0) - 1;
}

function rowsFromWorksheet(xml, sharedStrings) {
  const rows = new Map();
  for (const rowMatch of xml.matchAll(/<(?:(?:\w+):)?row\b([^>]*)>([\s\S]*?)<\/(?:(?:\w+):)?row>/g)) {
    const number = Number(rowMatch[1].match(/\br="(\d+)"/)?.[1]);
    if (!number) continue;
    const row = [];
    for (const cellMatch of rowMatch[2].matchAll(/<(?:(?:\w+):)?c\b([^>]*)\/>|<(?:(?:\w+):)?c\b([^>]*)>([\s\S]*?)<\/(?:(?:\w+):)?c>/g)) {
      const attributes = cellMatch[1] || cellMatch[2] || '', body = cellMatch[3] || '';
      const reference = attributes.match(/\br="([A-Z]+\d+)"/)?.[1];
      if (!reference) continue;
      const type = attributes.match(/\bt="([^"]+)"/)?.[1] || '';
      const raw = body.match(/<(?:(?:\w+):)?v>([\s\S]*?)<\/(?:(?:\w+):)?v>/)?.[1]
        ?? body.match(/<(?:(?:\w+):)?t\b[^>]*>([\s\S]*?)<\/(?:(?:\w+):)?t>/)?.[1] ?? '';
      row[columnIndex(reference)] = type === 's' ? sharedStrings[Number(raw)] : decodeXml(raw);
    }
    rows.set(number, row);
  }
  return rows;
}

function clean(value) {
  return String(value ?? '').replace(/\r\n/g, '\n').replace(/[ \t]+\n/g, '\n').trim();
}

function stateFor(value, familyId, level) {
  const text = clean(value);
  if (/^n\s*\/\s*a\.?$/i.test(text.replace(/\u00a0/g, ' '))) return { status: 'not-applicable', scope: '' };
  const verified = SOURCE_VERIFIED_STATES[`${familyId}::${level}`];
  if (verified) return { status: verified.status, scope: clean(verified.scope), source: verified.source };
  if (!text) return { status: 'no-curricular-record', scope: '' };
  return { status: 'explicit-evaluable', scope: text };
}

function sha256(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

export function extractProgression(masterBuffer, sourceName, exampleBuffer, exampleName) {
  const entries = zipEntries(masterBuffer);
  const worksheet = entries.get('xl/worksheets/sheet2.xml');
  if (!worksheet) throw new Error('No se encontró la hoja Saberes X año escolar VF (sheet2.xml).');
  const rows = rowsFromWorksheet(worksheet.toString('utf8'), sharedStringsFrom(entries));
  const families = FAMILY_ROWS.map(([rowNumber, id, fallbackLabel]) => {
    const row = rows.get(rowNumber) || [];
    return {
      id,
      area: areaForFamily(id),
      label: clean(row[1]) || fallbackLabel,
      generalKnowledge: clean(row[2]),
      sourceRow: rowNumber,
      levels: Object.fromEntries(LEVELS.map(([level, column]) => [level, stateFor(row[column], id, level)]))
    };
  });
  return {
    catalogVersion: '1.1.0',
    levelOrder: LEVELS.map(([level]) => level),
    states: {
      'explicit-evaluable': 'Desarrollo explícito con alcance curricular e indicador correspondiente.',
      'conceptual-non-evaluable': 'Presencia conceptual sin indicador directo, respaldada expresamente por una fuente curricular.',
      'reinforced-non-evaluable': 'Fortalecimiento sin evaluación directa, respaldado expresamente por una fuente curricular.',
      'no-curricular-record': 'La matriz no registra abordaje conceptual para el nivel; no permite inferir enseñanza, refuerzo ni dominio.',
      'not-applicable': 'El saber no corresponde al nivel.'
    },
    source: { file: sourceName, sha256: sha256(masterBuffer), role: 'Matriz validada de saberes por año escolar' },
    indicatorProgressionExample: {
      file: exampleName,
      sha256: exampleBuffer ? sha256(exampleBuffer) : '',
      role: 'Ejemplo asesor de lectura horizontal y vertical; no sustituye el currículo oficial.',
      familyIds: INDICATOR_EXAMPLE_FAMILIES,
      dimensions: ['verbo o demanda cognitiva', 'saber conceptual', 'alcance esperado', 'representación', 'contexto y autonomía']
    },
    families
  };
}

function areaForFamily(id) {
  if (id.startsWith('programming.')) return 'Programación y Algoritmos';
  if (id.startsWith('digital.')) return 'Apropiación tecnológica y Digital';
  if (id.startsWith('physical.')) return 'Computación física y Robótica';
  return 'Ciencia de datos e Inteligencia artificial';
}

export function serializeProgressionModule(catalog) {
  return '// PIA_CURRICULAR_PROGRESSION_DATA_START\n' +
    '// Catálogo relacional de solo lectura. No modifica PNFT_DATA, RDA_POR_CICLO ni indicadores oficiales.\n' +
    `const PIACurricularProgressionData = Object.freeze(${JSON.stringify(catalog, null, 2)});\n` +
    '// PIA_CURRICULAR_PROGRESSION_DATA_END\n';
}

async function main() {
  const masterPath = resolve(process.argv[2]);
  const examplePath = resolve(process.argv[3]);
  const outputPath = resolve(process.argv[4] || 'src/data/curricular-progression.js');
  if (!process.argv[2] || !process.argv[3]) throw new Error('Uso: node scripts/import-curricular-progression.mjs <saberes.xlsx> <ejemplo.xlsx> [salida.js]');
  const master = await readFile(masterPath), example = await readFile(examplePath);
  const catalog = extractProgression(master, masterPath.split(/[\\/]/).at(-1), example, examplePath.split(/[\\/]/).at(-1));
  await writeFile(outputPath, serializeProgressionModule(catalog), 'utf8');
  console.log(JSON.stringify({ outputPath, families: catalog.families.length, levels: catalog.levelOrder.length, sourceSha256: catalog.source.sha256 }, null, 2));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
