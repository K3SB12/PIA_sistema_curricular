import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const expectedHash = '46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79';
const paths = [
  'reference/index.original.html',
  'reference/index.received.html',
  'index.html',
  'dist/web/index.html',
  'dist/portable/index.html',
];
const buffers = await Promise.all(paths.map((file) => readFile(join(root, file))));

for (let index = 0; index < buffers.length; index += 1) {
  const digest = createHash('sha256').update(buffers[index]).digest('hex');
  assert.equal(digest, expectedHash, `${paths[index]} no coincide con la huella aprobada`);
  assert.deepEqual(buffers[index], buffers[0], `${paths[index]} no es binariamente identico`);
  console.log(`${paths[index]}: ${digest}`);
}

console.log('EQUIVALENCE=PASS');
