        // ===== FUNCIONES PARA OBTENER DATOS PEDAGÓGICOS =====
        function obtenerEjesTransversales() {
            const ejesSeleccionados = Array.from(document.querySelectorAll('input[name="eje"]:checked')).map(cb => cb.value);
            const ejesMap = {
                'ciudadania': 'Ciudadanía y ética digital',
                'pensamiento': 'Pensamiento computacional',
                'emprendimiento': 'Emprendimiento e Innovación'
            };
            
            return ejesSeleccionados.map(eje => ejesMap[eje] || eje);
        }

        function obtenerMetodologiaActiva() {
            let metodo = document.getElementById('metodologiaActiva').value;
            if (metodo === 'otra') {
                metodo = document.getElementById('metodologiaPersonalizada').value || 'Otra metodología';
            }
            
            const metodologiasMap = {
                'ABJ': 'Aprendizaje basado en juegos (ABJ)',
                'ABR': 'Aprendizaje basado en retos (ABR)',
                'APD': 'Aprendizaje Pensamiento por Diseño (APD)'
            };
            
            return metodo ? (metodologiasMap[metodo] || metodo) : 'Pendiente';
        }

