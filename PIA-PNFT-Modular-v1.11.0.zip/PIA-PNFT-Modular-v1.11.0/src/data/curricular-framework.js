// PIA_CURRICULAR_FRAMEWORK_JS_START
// Marco curricular oficial de consulta. No sustituye PNFT_DATA ni RDA_POR_CICLO.
// Las descripciones conservan el párrafo inicial de propósito; los ejemplos posteriores de las guías
// son orientadores y no se convierten en una secuencia obligatoria de mediación.
const PIACurricularFramework = (() => {
    const SOURCE = Object.freeze({
        authority:'Programa Nacional de Formación Tecnológica, DRTE-MEP',
        reviewedAt:'2026-09-16',
        guides:Object.freeze({
            preschool:Object.freeze({title:'Guía docente para la Formación Tecnológica - Educación Preescolar',file:'Guía docente FT-Preescolar(6).pdf',competencies:'6',profiles:'7-9',modules:Object.freeze({'0°|Módulo 1|basic-required':'13','0°|Módulo 2|basic-required':'19','0°|Módulo 1|optimal':'27','0°|Módulo 2|optimal':'33'})}),
            primary:Object.freeze({title:'Guía docente para la Formación Tecnológica - Primaria',file:'Guía docente FT-Primaria(6).pdf',competencies:Object.freeze({'I Ciclo':'8-9','II Ciclo':'61'}),profiles:Object.freeze({'I Ciclo':'10-11','II Ciclo':'62-64'}),modules:Object.freeze({'1°|Módulo 1':'15','1°|Módulo 2':'22','2°|Módulo 1':'30','2°|Módulo 2':'37-38','3°|Módulo 1':'46','3°|Módulo 2':'54','4°|Módulo 1':'68-69','4°|Módulo 2':'76','5°|Módulo 1':'85','5°|Módulo 2':'93','6°|Módulo 1':'102','6°|Módulo 2':'109'})}),
            secondary:Object.freeze({title:'Guía docente para la Formación Tecnológica - Secundaria III Ciclo',file:'Guía docente FT-Secundaria III C(6).pdf',competencies:'7',profiles:'8-11',modules:Object.freeze({'7°|Módulo 1':'15','7°|Módulo 2':'23','8°|Módulo 1':'32','8°|Módulo 2':'40','9°|Módulo 1':'49','9°|Módulo 2':'56'})})
        })
    });

    const COMPETENCIES_BY_AREA = PIAPreschoolCurriculum.COMPETENCIES_BY_AREA;

    const EXIT_PROFILES_BY_CYCLE = Object.freeze({
        'Materno Infantil/Transición': PIAPreschoolCurriculum.EXIT_PROFILE_BY_AREA,
        'I Ciclo': Object.freeze({
            'Apropiación tecnológica y Digital':Object.freeze([
                'Identifica vocabulario técnico básico relacionado con la tecnología, tales como: software, hardware, dispositivos de entrada y salida, red de computadoras, Wifi, bluetooth, sistemas operativos, archivo y carpetas.',
                'Utiliza aplicaciones de productividad según su función, por ejemplo: procesadores de texto, presentaciones, editores gráficos, navegadores y buscadores, grabadora de audios, herramientas para la creación de videos.',
                'Realiza búsquedas en línea en sitios seguros y confiables.',
                'Reconoce las normas básicas de netiqueta en los procesos de comunicación.',
                'Describe el concepto de huella digital y sus implicaciones en la vida de las personas.',
                'Reconoce el concepto de software malicioso (virus) y sus consecuencias al trabajar con equipos tecnológicos.'
            ]),
            'Programación y Algoritmos':Object.freeze([
                'Resuelve desafíos digitales o físicos con niveles de dificultad progresiva que requieren el uso de algoritmos, secuencias, condicionales simples, ciclos finitos e infinitos, datos, estado, variables, operadores aritméticos, operadores relacionales y eventos.',
                'Resuelve problemas de programación o de actividades cotidianas, a partir del reconocimiento y creación de patrones.',
                'Utiliza entornos de programación iconográficos y por bloques aplicando los conceptos computacionales aprendidos para resolver problemas específicos.'
            ]),
            'Computación física y Robótica':Object.freeze(['No aplica para esta área.']),
            'Ciencia de datos e Inteligencia artificial':Object.freeze(['Reconoce qué es la inteligencia artificial y los asistentes virtuales comprendiendo la importancia de usarlos de forma segura y responsable.'])
        }),
        'II Ciclo': Object.freeze({
            'Apropiación tecnológica y Digital':Object.freeze([
                'Utiliza vocabulario técnico relacionado con la tecnología, tal como: virus, comprimir y descomprimir archivos, carpetas, sistema operativo, hardware, software, periféricos, red (dispositivos comunicación), conexión wifi, bluetooth, configuración, escritorio, herramientas de productividad, unidades de almacenamiento, direcciones IP.',
                'Configura los programas o aplicaciones que utiliza atendiendo sus necesidades (accesibilidad), por ejemplo: cambia el funcionamiento del ratón, modifica el idioma de un programa o aplicación.',
                'Realiza búsquedas en línea utilizando motores de búsqueda, seleccionando información relevante y confiable, comprendiendo la importancia de verificar la fuente y la precisión de la información encontrada.',
                'Reconoce prácticas seguras al compartir información en diferentes espacios, resguardando su integridad y la de los demás.'
            ]),
            'Programación y Algoritmos':Object.freeze([
                'Aplica los conocimientos adquiridos (ciclos, estructuras de control, operadores, procedimientos, entre otros) para la resolución de problemas complejos de su contexto y apropiados a un propósito específico, descomponiéndolos en pasos más pequeños, diseñando diagramas de flujo o pseudocódigo para luego programarlos.',
                'Diseña sus propios juegos o simulaciones arrastrando y soltando bloques de código.',
                'Programa con bloques para expresar de forma creativa la computación física.'
            ]),
            'Computación física y Robótica':Object.freeze([
                'Identifica qué es un circuito y cómo funciona.',
                'Comprende los conceptos básicos de electrónica, tales como pines de entrada o salida, señal analógica o digital.',
                'Utiliza sensores y/o actuadores internos y/o externos conectándolos a un microcontrolador y programándolos según lo que requiere la solución del problema que resuelve.',
                'Emplea las tarjetas microcontroladoras para integrarlas en la solución al problema que resuelve.'
            ]),
            'Ciencia de datos e Inteligencia artificial':Object.freeze([
                'Comprende conceptos básicos de los datos como tipos de datos, su importancia y uso en la actualidad.',
                'Clasifica datos del entorno en tablas simples. Por ejemplo, hacer un registro de la cantidad de estudiantes que cumplen años en cada mes o contabilizar en una estadística el tiempo que usan las personas en redes sociales.',
                'Reconoce qué es la inteligencia artificial, los asistentes virtuales y las herramientas generativas, comprendiendo su funcionamiento básico y la importancia de usarlos de forma segura, ética y responsable.'
            ])
        }),
        'III Ciclo': Object.freeze({
            'Apropiación tecnológica y Digital':Object.freeze([
                'Implementa vocabulario técnico relacionado con la tecnología, tal como: software, hardware, IoT, protocolos de comunicación, software malicioso, riesgos en línea, IDE, hacker, huella digital, almacenamiento en la nube y base de datos.',
                'Utiliza de manera competente herramientas de comunicación digital, como el correo electrónico y los chats en línea, aplicando normas de netiqueta y seguridad en la comunicación, siendo consciente del comportamiento inapropiado en línea.',
                'Integra programas y aplicaciones de programación o productividad de diseño gráfico y edición de video para el desarrollo de proyectos creativos y producción de contenido, mediante la creación y edición de imágenes, videos y audio, para expresar sus ideas de manera efectiva.',
                'Realiza búsquedas efectivas en línea y evalúa críticamente la información que encuentra, distinguiendo entre fuentes confiables y no confiables, evaluando la calidad y la relevancia de la información, citando sus fuentes adecuadamente.',
                'Utiliza aplicaciones de almacenamiento en la nube, que le permiten trabajar de manera colaborativa.',
                'Aplica medidas de seguridad para proteger su privacidad y disminuir los riesgos en línea.'
            ]),
            'Programación y Algoritmos':Object.freeze([
                'Diseña interfaces físicas o digitales para resolver problemas complejos de su contexto y así implementar funcionalidades y familiarizarse con el ciclo de vida de un programa o aplicación.',
                'Aplica conceptos de programación como funciones, variables, estructuras de datos y control de flujo en la solución programada, según lo requiera.',
                'Crea prototipos de artefactos físicos programados en entornos de programación textual.',
                'Resuelve problemas mediante la programación por bloques o la programación textual.'
            ]),
            'Computación física y Robótica':Object.freeze([
                'Aplica principios de diseño de robots incluyendo sus componentes y los desafíos éticos y legales.',
                'Implementa los diferentes tipos de mecanismos para generar fuerza y velocidad.',
                'Experimenta con componentes electrónicos básicos (resistencias y LEDs) y su conexión en distintos tipos de circuitos.',
                'Crea prototipos de artefactos físicos o robots que permitan utilizar una tarea o resolver un problema de la realidad.'
            ]),
            'Ciencia de datos e Inteligencia artificial':Object.freeze([
                'Conoce la importancia de los datos en situaciones cotidianas como control de redes sociales, historial de navegación y localización.',
                'Comprende la importancia de recolectar y organizar datos personales como gastos, notas, actividad física o salud.',
                'Conoce cómo se almacenan, gestionan y protegen los datos a lo largo de su ciclo de vida, aplicando principios de responsabilidad y seguridad digital.',
                'Conoce los fundamentos de la inteligencia artificial y reflexiona críticamente sobre sus beneficios, riesgos y desafíos en la actualidad.',
                'Identifica el funcionamiento de los asistentes virtuales y las herramientas generativas, comprendiendo la importancia de usarlos de forma segura, ética y responsable.'
            ])
        })
    });

    const MODULE_PURPOSES = Object.freeze({
        '0°|Módulo 1|basic-required':'Este módulo pretende introducir a los niños en el universo digital mediante experiencias lúdicas, sensoriales y concretas que estimulan la curiosidad, el pensamiento secuencial y la exploración activa. A través del juego guiado y la interacción con dispositivos tecnológicos, los estudiantes comienzan a reconocer qué es una computadora, sus partes visibles y algunas de sus funciones básicas. Se promueve el contacto inicial con el software, identificando elementos visuales como iconos, botones y ventanas, en actividades que combinan lo digital con lo simbólico.',
        '0°|Módulo 2|basic-required':'Este módulo busca introducir la comprensión de la tecnología digital mediante experiencias lúdicas y exploratorias que introducen conceptos fundamentales de conectividad, robótica y programación.',
        '0°|Módulo 1|optimal':'Este módulo pretende profundizar la apropiación tecnológica y digital mediante experiencias lúdicas, creativas y guiadas que amplían la comprensión funcional de los dispositivos y entornos digitales.',
        '0°|Módulo 2|optimal':'Este módulo busca profundizar la comprensión de la tecnología digital mediante experiencias lúdicas, sensoriales y exploratorias que permiten a los estudiantes interactuar con conceptos clave de conectividad, robótica, programación y ciencia de datos.',
        '1°|Módulo 1':'El abordaje de los saberes conceptuales de este módulo debe realizarse de forma intencional según lo que establece cada indicador de logro, evitando tratarlos de manera aislada, por el contrario, promoviendo la conexión significativa entre saberes al proponer las estrategias de mediación.',
        '1°|Módulo 2':'Este módulo debe desarrollarse de forma articulada, guiado por los indicadores de logro que orientan la selección y secuencia de los saberes conceptuales y la construcción de las actividades, generando experiencias significativas que favorezcan la exploración, la creación y el análisis.',
        '2°|Módulo 1':'Este módulo propicia los elementos para generar una secuencia integrada de experiencias que, guiadas por los indicadores de logro, permiten seleccionar y organizar los saberes conceptuales, procedimentales y actitudinales de manera coherente. Su desarrollo busca generar aprendizajes significativos a través de actividades que estimulen la exploración, la producción creativa y el análisis reflexivo en situaciones escolares cotidianas.',
        '2°|Módulo 2':'Este módulo amplía las experiencias del estudiante en el uso de recursos digitales, promoviendo la comprensión funcional de herramientas tecnológicas y el fortalecimiento del pensamiento lógico. Guiado por los indicadores de logro, se propone una secuencia de actividades que favorezcan la exploración, la organización de información, la resolución de problemas y la producción en situaciones escolares cotidianas.',
        '3°|Módulo 1':'En este año se consolidan los aprendizajes desarrollados en primero y segundo grado, fortaleciendo el pensamiento lógico, la apropiación tecnológica y la comprensión de estructuras básicas de programación. Se propone una secuencia de actividades que promueven la exploración, la organización de información y la resolución de problemas en contextos escolares cotidianos, articulando saberes conceptuales, procedimentales y actitudinales.',
        '3°|Módulo 2':'En este módulo se espera profundizar en el uso crítico, creativo y seguro de las tecnologías digitales, promoviendo la autonomía del estudiante en la gestión de contenidos, la exploración de información y la comunicación en entornos virtuales para consolidar habilidades de producción multimedia y navegación responsable.',
        '4°|Módulo 1':'Este módulo busca fortalecer la comprensión funcional de los dispositivos tecnológicos, el uso consciente del software y la organización de la información, promoviendo el pensamiento lógico y la resolución de problemas en contextos escolares y cotidianos con tecnología o en entornos desconectados.',
        '4°|Módulo 2':'Este módulo busca profundizar en el uso responsable, ético y creativo de las tecnologías digitales, promoviendo la autonomía del estudiante en la búsqueda de información, la producción de contenidos y la reflexión sobre su participación en entornos virtuales.',
        '5°|Módulo 1':'En este módulo se propone la introducción de los elementos fundamentales de la computación física, como el circuito eléctrico, los fundamentos de electrónica y el microcontrolador, con el objetivo de que el estudiantado comprenda cómo se conectan y funcionan los componentes físicos que permiten la interacción entre el mundo digital y el mundo real al relacionarse con otros saberes de apropiación tecnológica y programación.',
        '5°|Módulo 2':'Este módulo da continuidad a los aprendizajes iniciados en el Módulo 1, promoviendo la aplicación de los conocimientos adquiridos en computación física, programación y apropiación tecnológica. Se propone el diseño de soluciones automatizadas mediante el uso de sensores y actuadores, acercando al estudiantado a experiencias que vinculan el mundo físico y digital en contextos reales.',
        '6°|Módulo 1':'El abordaje de los saberes de este módulo debe realizarse de forma articulada, favoreciendo la integración entre conceptos, procedimientos y actitudes, siempre guiado por los indicadores de logro.',
        '6°|Módulo 2':'Este módulo busca que los estudiantes desarrollen competencias en el uso seguro y responsable de la tecnología, la gestión de información digital y el análisis de datos, integrando habilidades de pensamiento crítico, comunicación digital y trabajo colaborativo.',
        '7°|Módulo 1':'En este módulo se promueve el desarrollo de habilidades fundamentales en el uso de tecnologías digitales, consolidando la apropiación tecnológica y la comprensión de estructuras básicas de programación.',
        '7°|Módulo 2':'En este segundo módulo se profundiza en el uso responsable, ético y seguro de las tecnologías digitales, promoviendo habilidades para la comunicación, la colaboración y la gestión de información en entornos conectados, articulando esto con saberes conceptuales, procedimentales y actitudinales en las áreas de apropiación tecnológica, programación y ciencia de datos.',
        '8°|Módulo 1':'Este módulo promueve el desarrollo de competencias digitales mediante la integración de saberes conceptuales, procedimentales y actitudinales en experiencias significativas que vinculan la apropiación tecnológica, la programación, la robótica y la inteligencia artificial. Se espera que el estudiante combine herramientas digitales considerando fundamentos tecnológicos, seguridad digital y su experiencia de uso para crear productos funcionales.',
        '8°|Módulo 2':'Este módulo profundiza en el uso crítico y seguro de herramientas digitales para la productividad, la programación y la robótica, integrando saberes que permiten al estudiante resolver problemas reales mediante el diseño de soluciones digitales.',
        '9°|Módulo 1':'Este módulo se enfoca en consolidar habilidades avanzadas en programación, robótica y ciencia de datos, integrando saberes conceptuales, procedimentales y actitudinales mediante experiencias significativas guiadas por los indicadores de logro.',
        '9°|Módulo 2':'Este módulo amplía la comprensión del estudiante sobre el uso ético, creativo y seguro de las tecnologías digitales, aplicando la gestión de contenidos, la producción multimedia y el análisis de datos en plataformas digitales. A través del uso de la metodología, se promueve la creación de soluciones que respondan a necesidades del entorno.'
    });

    function guideForLevel(level){return level==='0°'?SOURCE.guides.preschool:['1°','2°','3°','4°','5°','6°'].includes(level)?SOURCE.guides.primary:SOURCE.guides.secondary;}
    function moduleKey(level,moduleName,track){return level==='0°'?`${level}|${moduleName}|${PIAPreschoolCurriculum.normalizeRoute(track)||'optimal'}`:`${level}|${moduleName}`;}
    function sourcePagesForModule(level,moduleName,track){const guide=guideForLevel(level);return guide?.modules?.[moduleKey(level,moduleName,track)]||'';}
    function framework({level,cycle,modules=[],areas=[],preschoolTrack='optimal'}={}){
        const guide=guideForLevel(level),profiles=EXIT_PROFILES_BY_CYCLE[cycle]||{};
        return Object.freeze({
            source:guide,
            competencies:Object.freeze(areas.map(area=>({area,text:COMPETENCIES_BY_AREA[area]||''})).filter(item=>item.text)),
            exitProfiles:Object.freeze(areas.map(area=>({area,statements:Object.freeze([...(profiles[area]||[])])})).filter(item=>item.statements.length)),
            modules:Object.freeze(modules.map(moduleName=>({module:moduleName,text:MODULE_PURPOSES[moduleKey(level,moduleName,preschoolTrack)]||'',pages:sourcePagesForModule(level,moduleName,preschoolTrack)})).filter(item=>item.text))
        });
    }

    return Object.freeze({SOURCE,COMPETENCIES_BY_AREA,EXIT_PROFILES_BY_CYCLE,MODULE_PURPOSES,moduleKey,sourcePagesForModule,framework});
})();
// PIA_CURRICULAR_FRAMEWORK_JS_END
