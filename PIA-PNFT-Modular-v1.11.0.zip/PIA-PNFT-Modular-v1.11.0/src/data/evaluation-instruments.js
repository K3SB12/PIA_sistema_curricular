        // PIA_EVALUATION_INSTRUMENTS_JS_START
        const PIAEvaluationInstruments = (() => {
            const CATALOG_VERSION = '2026.1';
            const REVIEWED_AT = '2026-08-28';

            const SOURCES = Object.freeze({
                instrumentsMep: Object.freeze({
                    id: 'mep-instrumentos-evaluacion',
                    title: 'Instrumentos de evaluación MEP',
                    sections: ['Rúbricas', 'Escalas de calificación', 'Lista de cotejo', 'Registro de desempeño', 'Registro anecdótico'],
                    reviewedAt: REVIEWED_AT
                }),
                rea: Object.freeze({
                    id: 'rea-45509-mep',
                    title: 'Decreto Ejecutivo N.° 45509-MEP — Reglamento de Evaluación de los Aprendizajes y de la Conducta',
                    articles: ['10', '29', '31', '32', '33', '35', '38'],
                    reviewedAt: REVIEWED_AT
                }),
                lineamientos2026: Object.freeze({
                    id: 'lineamientos-tecnicos-2026',
                    title: 'Lineamientos técnicos para la evaluación de los aprendizajes 2026',
                    sections: ['Instrumento de evaluación sumativa', 'Rúbrica analítica', 'Escala de desempeño'],
                    reviewedAt: REVIEWED_AT
                }),
                orientacionesFt2026: Object.freeze({
                    id: 'orientaciones-ft-2026',
                    title: 'Orientaciones generales para docentes de Formación Tecnológica 2026',
                    sections: ['Evaluación de los aprendizajes', 'Prueba de ejecución (primaria)', 'Componente Proyecto (secundaria)'],
                    reviewedAt: REVIEWED_AT
                })
            });

            const COMMON_SAFEGUARDS = Object.freeze([
                'La recomendación es orientadora y editable; la decisión final corresponde a la persona docente.',
                'Debe existir coherencia entre aprendizaje, indicador, actividad, evidencia, criterio e instrumento.',
                'Deben considerarse el contexto, los apoyos educativos, el DUA y las disposiciones institucionales aplicables.',
                'PIA no registra datos de personas estudiantes, resultados individuales ni calificaciones.',
                'Una misma evidencia no debe contabilizarse dos veces en componentes de calificación diferentes.'
            ]);

            function freezeInstrument(instrument) {
                return Object.freeze({
                    ...instrument,
                    evaluationFunctions: Object.freeze([...instrument.evaluationFunctions]),
                    evidenceTypes: Object.freeze([...instrument.evidenceTypes]),
                    compatibleComponents: Object.freeze([...instrument.compatibleComponents]),
                    technicalRequirements: Object.freeze([...instrument.technicalRequirements]),
                    safeguards: Object.freeze([...instrument.safeguards]),
                    sourceRefs: Object.freeze([...instrument.sourceRefs])
                });
            }

            const instruments = Object.freeze([
                freezeInstrument({
                    id: 'checklist',
                    label: 'Lista de cotejo',
                    need: 'Comprobar la presencia o ausencia de acciones, características o procedimientos concretos.',
                    recommendedUse: 'Procedimientos breves, secuenciales y verificables mediante categorías dicotómicas.',
                    evaluationFunctions: ['diagnóstica', 'formativa', 'sumativa'],
                    evidenceTypes: ['procedimiento observable', 'secuencia de acciones', 'producto con requisitos verificables'],
                    compatibleComponents: ['trabajo cotidiano', 'tarea', 'proyecto'],
                    technicalRequirements: [
                        'Formular indicadores significativos, observables y vinculados con los aprendizajes.',
                        'Ordenar los indicadores de acuerdo con la secuencia lógica de la actividad.',
                        'Usar categorías dicotómicas explícitas, por ejemplo: sí/no o logrado/no logrado.',
                        'Incluir identificación, instrucciones y espacio de observaciones cuando corresponda.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'No utilizarla cuando se necesite describir grados o niveles de calidad del desempeño.'
                    ],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:10', 'rea-45509-mep:29']
                }),
                freezeInstrument({
                    id: 'descriptive-scale',
                    label: 'Escala descriptiva',
                    need: 'Valorar cualidades o progresión mediante descripciones ordenadas del desempeño.',
                    recommendedUse: 'Habilidades, actitudes o procesos que evolucionan durante varias experiencias de aprendizaje.',
                    evaluationFunctions: ['diagnóstica', 'formativa', 'sumativa'],
                    evidenceTypes: ['desempeño progresivo', 'habilidad observable', 'actitud observable', 'proceso'],
                    compatibleComponents: ['trabajo cotidiano', 'tarea', 'proyecto', 'prueba de ejecución'],
                    technicalRequirements: [
                        'Definir indicadores observables relacionados con el aprendizaje.',
                        'Redactar categorías descriptivas breves, claras y ordenadas secuencialmente.',
                        'Evitar etiquetas ambiguas que no describan la calidad observada.',
                        'Incluir instrucciones y condiciones de observación o aplicación.'
                    ],
                    safeguards: [...COMMON_SAFEGUARDS],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:10', 'lineamientos-tecnicos-2026']
                }),
                freezeInstrument({
                    id: 'performance-scale',
                    label: 'Escala de desempeño',
                    need: 'Determinar el nivel de complejidad o grado de logro alcanzado en cada indicador.',
                    recommendedUse: 'Desempeños que requieren niveles graduados y criterios observables por aprendizaje.',
                    evaluationFunctions: ['diagnóstica', 'formativa', 'sumativa'],
                    evidenceTypes: ['desempeño progresivo', 'ejecución práctica', 'proceso', 'producto'],
                    compatibleComponents: ['trabajo cotidiano', 'tarea', 'proyecto', 'prueba de ejecución', 'instrumento de evaluación sumativa'],
                    technicalRequirements: [
                        'Consignar los aprendizajes e indicadores seleccionados.',
                        'Definir niveles graduados de acuerdo con la complejidad del desempeño.',
                        'Describir criterios observables para cada nivel sin modificar el indicador oficial.',
                        'Mantener correspondencia entre la escala, la evidencia solicitada y el propósito evaluativo.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'Cuando forma parte de un instrumento de evaluación sumativa, debe cumplir los lineamientos técnicos vigentes.'
                    ],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:35', 'lineamientos-tecnicos-2026']
                }),
                freezeInstrument({
                    id: 'analytic-rubric',
                    label: 'Rúbrica analítica',
                    need: 'Analizar por separado varias dimensiones de un proceso, producto o desempeño complejo.',
                    recommendedUse: 'Proyectos, prototipos, producciones multimedia, soluciones programadas y evidencias con varios criterios.',
                    evaluationFunctions: ['formativa', 'sumativa'],
                    evidenceTypes: ['proceso complejo', 'producto complejo', 'prototipo', 'producción digital', 'solución programada'],
                    compatibleComponents: ['trabajo cotidiano', 'tarea', 'proyecto', 'prueba de ejecución', 'instrumento de evaluación sumativa'],
                    technicalRequirements: [
                        'Consignar los aprendizajes e indicadores vinculados con la evidencia.',
                        'Desglosar el desempeño en criterios observables sin alterar los indicadores oficiales.',
                        'Describir cada nivel de desempeño para cada criterio.',
                        'Comunicar previamente los indicadores y criterios aplicables cuando corresponda.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'En el Proyecto debe permitir valorar el proceso y el producto, junto con la realimentación.',
                        'No asignar porcentajes independientes a etapas del Proyecto si la normativa no los establece.'
                    ],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:33', 'rea-45509-mep:35', 'lineamientos-tecnicos-2026']
                }),
                freezeInstrument({
                    id: 'holistic-rubric',
                    label: 'Rúbrica global u holística',
                    need: 'Valorar integralmente un desempeño o producto como una totalidad.',
                    recommendedUse: 'Valoraciones globales, principalmente formativas, cuando no se requiere analizar cada dimensión por separado.',
                    evaluationFunctions: ['diagnóstica', 'formativa'],
                    evidenceTypes: ['producto integral', 'desempeño global', 'presentación'],
                    compatibleComponents: ['trabajo cotidiano', 'tarea', 'proyecto'],
                    technicalRequirements: [
                        'Seleccionar el aprendizaje y la evidencia que se valorarán como una totalidad.',
                        'Definir niveles globales con criterios claros y diferenciables.',
                        'Precisar qué características del desempeño sustentan cada nivel.',
                        'Comunicar el propósito formativo y la forma de realimentación.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'No sustituye la rúbrica analítica o la escala de desempeño exigida para el instrumento de evaluación sumativa.',
                        'Evitarla cuando el docente necesite identificar fortalezas y mejoras por criterio específico.'
                    ],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:35']
                }),
                freezeInstrument({
                    id: 'performance-record',
                    label: 'Registro de desempeño',
                    need: 'Registrar el desarrollo gradual de una destreza o habilidad durante la mediación.',
                    recommendedUse: 'Uso de herramientas, programación, montaje, depuración o ejecución de procedimientos.',
                    evaluationFunctions: ['diagnóstica', 'formativa'],
                    evidenceTypes: ['destreza práctica', 'procedimiento', 'ejecución progresiva', 'proceso de depuración'],
                    compatibleComponents: ['trabajo cotidiano', 'proyecto'],
                    technicalRequirements: [
                        'Establecer en secuencia los indicadores significativos que se observarán.',
                        'Registrar la presencia o ausencia del desempeño y añadir observaciones pertinentes.',
                        'Definir el tiempo o momento de observación.',
                        'Utilizar la información para realimentar el proceso y orientar el siguiente paso.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'El registro del avance operativo no equivale por sí mismo al nivel de aprendizaje ni a la calificación.'
                    ],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:10', 'rea-45509-mep:29']
                }),
                freezeInstrument({
                    id: 'anecdotal-record',
                    label: 'Registro anecdótico',
                    need: 'Documentar hechos, sucesos o situaciones cualitativas significativas.',
                    recommendedUse: 'Actitudes, colaboración, autonomía, perseverancia, intereses, procedimientos o situaciones particulares.',
                    evaluationFunctions: ['diagnóstica', 'formativa'],
                    evidenceTypes: ['hecho significativo', 'actitud observable', 'interacción', 'situación particular'],
                    compatibleComponents: ['trabajo cotidiano', 'proyecto'],
                    technicalRequirements: [
                        'Describir objetivamente el hecho, el contexto, la fecha y la situación observada.',
                        'Diferenciar la descripción de la interpretación profesional.',
                        'Relacionar el registro con el seguimiento o la realimentación pertinente.',
                        'Mantener el tratamiento institucional y confidencial que corresponda fuera de PIA.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'No utilizarlo como único fundamento de una calificación sumativa.',
                        'PIA solo recomienda su uso; no debe almacenar anécdotas ni información individual del estudiantado.'
                    ],
                    sourceRefs: ['mep-instrumentos-evaluacion', 'rea-45509-mep:10']
                }),
                freezeInstrument({
                    id: 'performance-test',
                    label: 'Prueba de ejecución acompañada por rúbrica o escala',
                    need: 'Medir la demostración práctica de aprendizajes, habilidades o destrezas.',
                    recommendedUse: 'Formación Tecnológica en primaria, de acuerdo con las orientaciones y el contexto y recursos disponibles.',
                    evaluationFunctions: ['sumativa'],
                    evidenceTypes: ['ejecución práctica', 'procedimiento observable', 'producto elaborado durante la prueba'],
                    compatibleComponents: ['prueba de ejecución'],
                    technicalRequirements: [
                        'Seleccionar aprendizajes e indicadores de acuerdo con el planeamiento y el programa vigente.',
                        'Aplicar ante la persona docente responsable.',
                        'Utilizar una rúbrica o escala técnicamente elaborada para registrar el desempeño.',
                        'Comunicar por escrito los aprendizajes e indicadores con al menos cinco días hábiles de anticipación.',
                        'Respetar el máximo reglamentario de cuatro lecciones; una ampliación adicional requiere justificación y autorización del Comité.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'Debe contextualizarse según los recursos disponibles y las orientaciones del Comité de Evaluación institucional.',
                        'La duración requerida para una aplicación concreta la determina el docente sin exceder el máximo reglamentario.'
                    ],
                    sourceRefs: ['rea-45509-mep:10', 'rea-45509-mep:32', 'rea-45509-mep:38', 'orientaciones-ft-2026']
                }),
                freezeInstrument({
                    id: 'daily-work-instrument',
                    label: 'Instrumento para el trabajo cotidiano',
                    need: 'Recopilar información continua sobre el progreso demostrado durante la mediación.',
                    recommendedUse: 'Evidenciar el avance gradual en diferentes contextos, no solamente un producto final.',
                    evaluationFunctions: ['diagnóstica', 'formativa', 'sumativa'],
                    evidenceTypes: ['desempeño progresivo', 'proceso', 'aplicación en contexto', 'práctica guiada'],
                    compatibleComponents: ['trabajo cotidiano'],
                    technicalRequirements: [
                        'Seleccionar el tipo concreto de instrumento según la evidencia: lista, escala, rúbrica o registro.',
                        'Registrar desempeños y logros demostrados durante el periodo.',
                        'Reflejar el avance gradual como parte del proceso de construcción del conocimiento.',
                        'Utilizar la información para realimentar y reorientar las actividades de aprendizaje.'
                    ],
                    safeguards: [
                        ...COMMON_SAFEGUARDS,
                        'No valorar el trabajo cotidiano únicamente a partir de un producto final.',
                        'Esta entrada orienta el propósito; el docente debe elegir el instrumento concreto según la evidencia.'
                    ],
                    sourceRefs: ['rea-45509-mep:10', 'rea-45509-mep:29', 'mep-instrumentos-evaluacion']
                })
            ]);

            function get(id) {
                return instruments.find(instrument => instrument.id === id) || null;
            }

            function compatibleWith(component) {
                const normalized = String(component || '').trim().toLocaleLowerCase('es');
                if (!normalized) return [];
                return instruments.filter(instrument => instrument.compatibleComponents.some(item => item.toLocaleLowerCase('es') === normalized));
            }

            function forFunction(evaluationFunction) {
                const normalized = String(evaluationFunction || '').trim().toLocaleLowerCase('es');
                if (!normalized) return [];
                return instruments.filter(instrument => instrument.evaluationFunctions.includes(normalized));
            }

            function recommend({ component = '', evaluationFunction = '', evidenceType = '' } = {}) {
                const normalizedComponent = String(component).trim().toLocaleLowerCase('es');
                const normalizedFunction = String(evaluationFunction).trim().toLocaleLowerCase('es');
                const normalizedEvidence = String(evidenceType).trim().toLocaleLowerCase('es');
                return instruments.filter(instrument =>
                    (!normalizedComponent || instrument.compatibleComponents.some(item => item.toLocaleLowerCase('es') === normalizedComponent)) &&
                    (!normalizedFunction || instrument.evaluationFunctions.includes(normalizedFunction)) &&
                    (!normalizedEvidence || instrument.evidenceTypes.some(item => item.toLocaleLowerCase('es').includes(normalizedEvidence)))
                );
            }

            return Object.freeze({ CATALOG_VERSION, REVIEWED_AT, SOURCES, COMMON_SAFEGUARDS, instruments, get, compatibleWith, forFunction, recommend });
        })();
        // PIA_EVALUATION_INSTRUMENTS_JS_END
