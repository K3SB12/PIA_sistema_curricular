        // PIA_EVALUATION_PROFILES_JS_START
        const PIAEvaluationProfiles = (() => {
            const SOURCE = {
                title: 'Decreto Ejecutivo N.° 45509-MEP — Reglamento de Evaluación de los Aprendizajes y de la Conducta',
                url: 'https://www.mep.go.cr/sites/default/files/2026-05/ReglamentoEvalAprendizajesConducta.pdf',
                reviewedAt: '2026-08-26'
            };
            const profiles = Object.freeze({
                preschool: { id:'preschool', label:'Materno Infantil/Transición · evaluación formativa', cycles:['Materno Infantil/Transición'], blockMinutes:80, components:[], rule:'Evaluación diagnóstica y formativa, sin distribución porcentual en PIA.', source:SOURCE },
                primary: { id:'primary', label:'I y II Ciclo · Formación Tecnológica', cycles:['I Ciclo','II Ciclo'], blockMinutes:80, components:[['Trabajo cotidiano',65],['Tareas',10],['Prueba (una)',20],['Asistencia',5]], rule:'Corresponde una prueba. Las tareas se aplican según los Lineamientos técnicos vigentes, la necesidad de reforzamiento y el calendario institucional.', article:'40', source:SOURCE },
                hearing: { id:'hearing', label:'Aula Integrada de Audición y Lenguaje · Formación Tecnológica', cycles:['I Ciclo','II Ciclo'], blockMinutes:40, components:[['Trabajo cotidiano',45],['Tareas',20],['Proyecto (uno)',30],['Asistencia',5]], rule:'El proyecto se contextualiza con apoyos y decisiones DUA.', article:'40', source:SOURCE },
                secondary: { id:'secondary', label:'III Ciclo · Formación Tecnológica', cycles:['III Ciclo'], blockMinutes:80, components:[['Trabajo cotidiano',45],['Tareas',10],['Proyecto (uno)',40],['Asistencia',5]], rule:'El proyecto debe planificarse progresivamente durante el periodo.', article:'41', source:SOURCE },
                diversified: { id:'diversified', label:'Educación Diversificada · Formación Tecnológica', cycles:[], blockMinutes:80, components:[['Trabajo cotidiano',55],['Tareas',5],['Proyecto (uno)',35],['Asistencia',5]], rule:'Perfil preparado para una futura ampliación curricular de PIA.', article:'42', source:SOURCE, future:true },
                vocational: { id:'vocational', label:'III Ciclo y Ciclo Diversificado Vocacional · Formación Tecnológica', cycles:['III Ciclo'], blockMinutes:80, components:[['Trabajo cotidiano',55],['Tareas',5],['Proyecto (uno)',35],['Asistencia',5]], rule:'Aplicar únicamente cuando esta sea la oferta educativa seleccionada.', article:'44', source:SOURCE },
                adult: { id:'adult', label:'CINDEA/IPEC II Nivel · módulos de Formación Tecnológica', cycles:['III Ciclo'], blockMinutes:80, components:[['Trabajo cotidiano',45],['Tareas',10],['Proyecto (uno)',40],['Asistencia',5]], rule:'Aplicar únicamente en el II Nivel de la oferta correspondiente.', article:'43', source:SOURCE }
            });
            function availableForCycle(cycle) {
                return Object.values(profiles).filter(profile => profile.cycles.includes(cycle));
            }
            function defaultForCycle(cycle) {
                return cycle === 'Materno Infantil/Transición' ? profiles.preschool : cycle === 'III Ciclo' ? profiles.secondary : profiles.primary;
            }
            function get(id) { return profiles[id] || null; }
            function describe(profile) {
                if (!profile) return 'Seleccione ciclo y perfil de evaluación.';
                if (!profile.components.length) return profile.rule;
                return `${profile.components.map(([name,value])=>`${value}% ${name.toLocaleLowerCase('es')}`).join(' · ')}. ${profile.rule}`;
            }
            return { SOURCE, profiles, availableForCycle, defaultForCycle, get, describe };
        })();
        // PIA_EVALUATION_PROFILES_JS_END
