        // PIA_PRESCHOOL_CURRICULUM_JS_START
        // Catálogo curricular aislado. No sustituye ni modifica PNFT_DATA o RDA_POR_CICLO.
        const PIAPreschoolCurriculum = (() => {
            const SOURCE = Object.freeze({
                title: 'Guía docente para la Formación Tecnológica - Educación Preescolar',
                file: 'Guía docente FT-Preescolar(3).pdf',
                authority: 'Guía docente oficial de Formación Tecnológica para Educación Preescolar',
                reviewedAt: '2026-09-04',
                pages: Object.freeze({
                    competenciesAndRda: '6-7',
                    exitProfile: '7-9',
                    module1Basic: '14-15',
                    module2Basic: '20-22',
                    module1Optimal: '28-29',
                    module2Optimal: '34-36'
                })
            });

            const RDA_BY_AREA = Object.freeze({
                'Apropiación tecnológica y Digital': 'Identifica los dispositivos digitales considerando características funcionales, experimentando su utilidad y reconociendo la autoría, durante la accesibilidad, interacción y comunicación en la creación de recursos digitales.',
                'Programación y Algoritmos': 'Ordena secuencias integrando conceptos de programación como dato, evento, estado, ciclos, así como nociones de lateralidad y orientación espacial, en la solución de desafíos propuestos, utilizando la programación iconográfica por bloques.',
                'Computación física y Robótica': 'Reconoce el funcionamiento de los robots, así como sus componentes (cuerpo, sistema sensorial, sistemas de control), al clasificarlos por su uso y programarlos para resolver retos.',
                'Ciencia de datos e Inteligencia artificial': 'Reconoce los conceptos básicos relacionados con la recopilación, organización e interpretación de datos simples, mediante gráficos pictóricos en la resolución de problemas, fomentando el pensamiento crítico y la curiosidad hacia el mundo que lo rodea.'
            });

            const COMPETENCIES_BY_AREA = Object.freeze({
                'Apropiación tecnológica y Digital': 'Crea productos con ayuda de herramientas digitales para aprovecharlos en su desarrollo personal, académico o profesional, de acuerdo con las normas de ciberseguridad y ética digital.',
                'Programación y Algoritmos': 'Resuelve problemas mediante la programación de algoritmos para desarrollar el pensamiento lógico matemático, tomando en cuenta las prácticas y actitudes del pensador computacional.',
                'Computación física y Robótica': 'Crea artefactos físicos o robots para proponer soluciones a problemas de su entorno a través de prototipos, de acuerdo con las normas y principios de electrónica, programación y robótica.',
                'Ciencia de datos e Inteligencia artificial': 'Analiza datos apoyándose en la estadística, matemáticas, programación y el conocimiento de dominio, para procesar datos que le permitan tomar decisiones y mejorar procesos en diferentes campos, tomando en cuenta los principios de ciencia de datos, inteligencia artificial y ciberseguridad.'
            });

            const EXIT_PROFILE_BY_AREA = Object.freeze({
                'Apropiación tecnológica y Digital': Object.freeze([
                    'Conoce las características de dispositivos tecnológicos comunes, como tabletas, computadoras o teléfonos inteligentes, así como sus periféricos.',
                    'Conoce funciones básicas de los dispositivos tecnológicos que utiliza, tales como encender o apagar, así como acceder a las aplicaciones o programas que requiera.',
                    'Conoce las funciones básicas como abrir, cerrar, minimizar, maximizar y guardar, al utilizar las aplicaciones o programas que utiliza.',
                    'Escoge aplicaciones que le ayuden a desarrollar habilidades básicas, como la identificación de colores, formas o números.',
                    'Usa aplicaciones y entornos visuales de programación para dibujar, programar, crear música, videos, o contar historias propias para su nivel.'
                ]),
                'Programación y Algoritmos': Object.freeze([
                    'Sigue instrucciones específicas para realizar una serie de acciones, como saltar, girar, avanzar, retroceder asociadas al sentido de lateralidad u orientación espacial.',
                    'Reconoce patrones visuales y secuenciales. Por ejemplo, puede completar una serie de imágenes o patrones de colores que sigan una regla predecible.',
                    'Reconoce conceptos básicos de programación: evento, estado, secuencias de acciones, ciclo finito e infinito, a través de juegos en entornos digitales o físicos.',
                    'Programa objetos modificando su estado según las propiedades de orientación, dirección y/o tamaño.',
                    'Reconoce la importancia de los datos en contexto físico y en contexto digital al resolver desafíos propuestos.',
                    'Participa en la resolución de desafíos programando soluciones simples, arrastrando y soltando bloques de código para crear secuencias lógicas, mediante un entorno de programación iconográfico.'
                ]),
                'Computación física y Robótica': Object.freeze([
                    'Reconoce qué es un robot y cómo se diferencia de otros objetos.',
                    'Identifica diferentes partes de un robot, como cuerpo, sistema sensorial y control.',
                    'Identifica los robots según su uso.',
                    'Programa movimientos simples en los robots, como avanzar, retroceder y girar.'
                ]),
                'Ciencia de datos e Inteligencia artificial': Object.freeze([
                    'Recopila datos simples de su entorno fomentando el pensamiento crítico y la curiosidad hacia el mundo que los rodea. Por ejemplo, la cantidad de árboles en el patio de la escuela o registra el clima durante una semana.',
                    'Reconoce datos con base en características específicas. Por ejemplo, clasificar juguetes según su forma, color, tamaño o cantidad.',
                    'Participa en experiencias lúdicas que combinan el entorno físico con elementos digitales a través de la realidad aumentada, desarrollando su percepción sensorial y curiosidad por descubrir.'
                ])
            });

            const PROCEDURAL_KNOWLEDGE = Object.freeze([
                'Reconoce patrones.',
                'Transfiere.',
                'Programa.',
                'Comunica.',
                'Colabora.',
                'Piensa de forma creativa.'
            ]);

            const ATTITUDINAL_KNOWLEDGE = Object.freeze([
                'Aprender del error.',
                'Flexibilidad para manejar problemas.',
                'Tolerancia a la frustración.'
            ]);

            function entry(id, area, conceptualKnowledge, achievementIndicator) {
                return Object.freeze({
                    id,
                    area,
                    rda: RDA_BY_AREA[area],
                    conceptualKnowledge,
                    achievementIndicator
                });
            }

            const itineraries = Object.freeze({
                'module-1:basic-required': Object.freeze({
                    id: 'module-1:basic-required',
                    module: 1,
                    route: 'basic-required',
                    label: 'Módulo 1 - Básico requerido',
                    sourcePages: SOURCE.pages.module1Basic,
                    entries: Object.freeze([
                        entry('m1-basic-computer', 'Apropiación tecnológica y Digital', 'Computadora.', 'Identificar qué es una computadora y algunas de sus características, a partir de experiencias prácticas de interacción con dispositivos digitales.'),
                        entry('m1-basic-software', 'Apropiación tecnológica y Digital', 'Software.', 'Reconocer elementos visuales básicos de la interfaz de software (iconos, botones, ventanas), interactuando con ellos mediante el uso guiado de dispositivos digitales.'),
                        entry('m1-basic-multimedia', 'Apropiación tecnológica y Digital', 'Herramientas de creación de contenido multimedia.', 'Reconocer las herramientas de creación de contenido multimedia según su utilidad: editor gráfico, grabadora de audio y video, en la creación de recursos digitales.'),
                        entry('m1-basic-iconographic-environment', 'Programación y Algoritmos', 'Entorno de programación iconográfico.', 'Reconocer el entorno de programación iconográfico, interactuando con bloques de la interfaz, como desplazamiento, apariencia o sonido, mediante el uso guiado del docente.'),
                        entry('m1-basic-laterality', 'Programación y Algoritmos', 'Lateralidad y orientación espacial.', 'Reconocer los conceptos de lateralidad y orientación espacial en la construcción de secuencias de acciones para la solución de retos de programación.'),
                        entry('m1-basic-event', 'Programación y Algoritmos', 'Evento.', 'Reconocer que un evento desencadena una acción, identificando la relación de causa y efecto en juegos o actividades.')
                    ])
                }),
                'module-2:basic-required': Object.freeze({
                    id: 'module-2:basic-required',
                    module: 2,
                    route: 'basic-required',
                    label: 'Módulo 2 - Básico requerido',
                    sourcePages: SOURCE.pages.module2Basic,
                    entries: Object.freeze([
                        entry('m2-basic-device-connection', 'Apropiación tecnológica y Digital', 'Conexión entre dispositivos.', 'Reconocer la conexión entre dispositivos por bluetooth y los requerimientos de dispositivos digitales para conectarse, a través de una exploración dirigida.'),
                        entry('m2-basic-state', 'Programación y Algoritmos', 'Estado.', 'Reconocer el concepto de estado programando objetos que modifican las propiedades de orientación y/o dirección.'),
                        entry('m2-basic-algorithm', 'Programación y Algoritmos', 'Algoritmo.', 'Reconocer el concepto de algoritmo mediante secuencias de acciones lógicas y ordenadas, en la construcción de soluciones a desafíos propuestos.'),
                        entry('m2-basic-programming-data', 'Programación y Algoritmos', 'Dato (programación).', 'Reconocer la importancia del dato en contexto físico y en contexto digital mientras soluciona desafíos propuestos.'),
                        entry('m2-basic-loops', 'Programación y Algoritmos', 'Estructuras repetitivas.', 'Reconocer estructuras repetitivas en secuencias de acciones durante la programación guiada de objetos digitales, distinguiendo si una acción se repite un número limitado o ilimitado de veces.'),
                        entry('m2-basic-robot', 'Computación física y Robótica', 'Robot.', 'Reconocer qué es un robot, sus componentes y algunos de sus usos, mediante actividades lúdicas de exploración o programación guiada.'),
                        entry('m2-basic-science-data', 'Ciencia de datos e Inteligencia artificial', 'Dato (Ciencias de datos).', 'Identificar el dato y su importancia en situaciones cotidianas, reconociendo diferentes tipos como texto, imagen, sonido o video.'),
                        entry('m2-basic-data-presentation', 'Ciencia de datos e Inteligencia artificial', 'Estrategias para presentar datos.', 'Reconocer gráficos pictóricos como estrategia para representar datos recolectados en actividades lúdicas.')
                    ])
                }),
                'module-1:optimal': Object.freeze({
                    id: 'module-1:optimal',
                    module: 1,
                    route: 'optimal',
                    label: 'Módulo 1 - Óptimo',
                    sourcePages: SOURCE.pages.module1Optimal,
                    entries: Object.freeze([
                        entry('m1-optimal-computer', 'Apropiación tecnológica y Digital', 'Computadora.', 'Identificar qué es una computadora y sus características funcionales, explorando su utilidad al interactuar con diversos dispositivos digitales.'),
                        entry('m1-optimal-hardware', 'Apropiación tecnológica y Digital', 'Hardware.', 'Reconocer componentes básicos del hardware, como dispositivos de entrada y salida de datos, explorando su función al encender, usar o interactuar con la computadora en actividades cotidianas.'),
                        entry('m1-optimal-software', 'Apropiación tecnológica y Digital', 'Software.', 'Reconocer elementos del software relacionados con la interfaz de usuario, como iconos, botones de minimizar, maximizar y cerrar, barra de tareas y área de trabajo, interactuando con ellos mediante el uso de dispositivos digitales.'),
                        entry('m1-optimal-multimedia', 'Apropiación tecnológica y Digital', 'Herramientas de creación de contenido multimedia.', 'Seleccionar las herramientas de creación de contenido multimedia según su utilidad: editor gráfico, grabadora de audio y video en la creación de recursos digitales.'),
                        entry('m1-optimal-internet', 'Apropiación tecnológica y Digital', 'Internet.', 'Reconocer qué es Internet y los requerimientos de un dispositivo para conectarse a Internet, realizando una exploración dirigida.'),
                        entry('m1-optimal-iconographic-environment', 'Programación y Algoritmos', 'Entorno de programación iconográfico.', 'Reconocer el entorno de programación iconográfico, según su función con bloques de la interfaz, como desplazamiento, orientación, apariencia, evento, sonido y control, en actividades de creación digital guiada.'),
                        entry('m1-optimal-laterality', 'Programación y Algoritmos', 'Lateralidad y orientación espacial.', 'Reconocer los conceptos de lateralidad y orientación espacial en la construcción de secuencias de acciones para la solución de retos de programación.'),
                        entry('m1-optimal-event', 'Programación y Algoritmos', 'Evento.', 'Reconocer que un evento desencadena una acción, identificando la relación de causa y efecto en juegos o actividades.')
                    ])
                }),
                'module-2:optimal': Object.freeze({
                    id: 'module-2:optimal',
                    module: 2,
                    route: 'optimal',
                    label: 'Módulo 2 - Óptimo',
                    sourcePages: SOURCE.pages.module2Optimal,
                    entries: Object.freeze([
                        entry('m2-optimal-device-connection', 'Apropiación tecnológica y Digital', 'Conexión entre dispositivos.', 'Reconocer formas de conexión entre dispositivos por bluetooth y wifi, así como los requerimientos de dispositivos digitales para conectarse, a través de una exploración dirigida.'),
                        entry('m2-optimal-state', 'Programación y Algoritmos', 'Estado.', 'Reconocer el concepto de estado programando objetos que modifican las propiedades de orientación, dirección y/o tamaño.'),
                        entry('m2-optimal-algorithm', 'Programación y Algoritmos', 'Algoritmo.', 'Reconocer patrones de repetición en secuencias lógicas y ordenadas, como parte de un algoritmo, al construir soluciones a desafíos propuestos.'),
                        entry('m2-optimal-programming-data', 'Programación y Algoritmos', 'Dato (programación).', 'Reconocer la importancia del dato en contexto físico y en contexto digital mientras soluciona desafíos propuestos.'),
                        entry('m2-optimal-loops', 'Programación y Algoritmos', 'Estructuras repetitivas.', 'Identificar estructuras repetitivas en el contexto del ciclo finito e infinito, en el diseño de secuencias de programación.'),
                        entry('m2-optimal-robot', 'Computación física y Robótica', 'Robot.', 'Reconocer qué es un robot, sus componentes y algunos de sus usos, mediante actividades lúdicas de exploración o programación guiada.'),
                        entry('m2-optimal-science-data', 'Ciencia de datos e Inteligencia artificial', 'Dato (ciencias de datos).', 'Reconocer el dato según su tipo (texto, imagen, sonido o video) y su importancia al participar en actividades que le permiten organizar información.'),
                        entry('m2-optimal-data-presentation', 'Ciencia de datos e Inteligencia artificial', 'Estrategias para presentar datos.', 'Crear gráficos pictóricos como una estrategia para representar datos al resolver problemas que estimulen la curiosidad y el pensamiento crítico al analizarlos.'),
                        entry('m2-optimal-data-visualization', 'Ciencia de datos e Inteligencia artificial', 'Visualización de datos.', 'Interpretar gráficos pictóricos como parte de la visualización de datos (colores, formas, cantidades), con apoyo del docente, relacionándolos con datos conocidos del entorno.'),
                        entry('m2-optimal-augmented-reality', 'Ciencia de datos e Inteligencia artificial', 'Realidad aumentada.', 'Experimentar con realidad aumentada en entornos físicos mediante actividades sensoriales y lúdicas, con acompañamiento del docente.')
                    ])
                })
            });

            const ROUTE_ALIASES = Object.freeze({
                'basic-required': 'basic-required',
                basic: 'basic-required',
                basico: 'basic-required',
                'básico': 'basic-required',
                'básico requerido': 'basic-required',
                optimal: 'optimal',
                optimo: 'optimal',
                'óptimo': 'optimal'
            });

            function normalizeRoute(route) {
                return ROUTE_ALIASES[String(route || '').trim().toLocaleLowerCase('es')] || null;
            }

            function getItinerary(module, route) {
                const moduleNumber = Number(module);
                const normalizedRoute = normalizeRoute(route);
                if (![1, 2].includes(moduleNumber) || !normalizedRoute) return null;
                return itineraries[`module-${moduleNumber}:${normalizedRoute}`] || null;
            }

            function getLevelData(route) {
                const normalizedRoute = normalizeRoute(route) || 'optimal';
                const levelData = {};
                [1, 2].forEach(moduleNumber => {
                    const itinerary = getItinerary(moduleNumber, normalizedRoute);
                    const moduleData = {};
                    itinerary.entries.forEach(item => {
                        moduleData[item.area] ||= { saberes: [] };
                        moduleData[item.area].saberes.push({
                            nombre: item.conceptualKnowledge,
                            indicadores: [item.achievementIndicator]
                        });
                    });
                    levelData[`Módulo ${moduleNumber}`] = moduleData;
                });
                return levelData;
            }

            return Object.freeze({
                SOURCE,
                COMPETENCIES_BY_AREA,
                EXIT_PROFILE_BY_AREA,
                RDA_BY_AREA,
                PROCEDURAL_KNOWLEDGE,
                ATTITUDINAL_KNOWLEDGE,
                itineraries,
                getItinerary,
                getLevelData,
                normalizeRoute
            });
        })();
        // PIA_PRESCHOOL_CURRICULUM_JS_END
