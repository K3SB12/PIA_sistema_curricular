        // PIA_PROJECT_COMPONENT_CATALOG_JS_START
        // Catálogo independiente y versionado. No modifica PNFT_DATA ni los indicadores curriculares.
        const PIAProjectComponentCatalog = (() => {
            const CATALOG_VERSION = '2026.2';
            const SOURCE = Object.freeze({
                title: 'Conceptualización-Componente-Proyecto 2026',
                file: 'Conceptualización-Componente-Proyecto 2026.docx',
                authority: 'Programa Nacional de Formación Tecnológica, DRTE-MEP',
                reviewedAt: '2026-08-28',
                scope: Object.freeze(['III Ciclo', 'Educación Diversificada'])
            });

            function evaluationIndicator(id, text) {
                return Object.freeze({ id, text, official: true });
            }

            function achievementIndicator(id, phaseId, text, evaluationIndicators) {
                return Object.freeze({
                    id,
                    phaseId,
                    text,
                    official: true,
                    catalogVersion: CATALOG_VERSION,
                    source: SOURCE,
                    evaluationIndicators: Object.freeze(evaluationIndicators)
                });
            }

            const indicators = Object.freeze([
                achievementIndicator(
                    'project.initial.empathize.001',
                    'empathize',
                    'Describir las necesidades, deseos y motivaciones de usuarios o clientes que tienen un problema o situación por resolver.',
                    [
                        evaluationIndicator(
                            'project.initial.empathize.001.evaluation.01',
                            'Describe un problema o situación por resolver que es importante para un usuario o cliente.'
                        ),
                        evaluationIndicator(
                            'project.initial.empathize.001.evaluation.02',
                            'Registra los intereses y necesidades del usuario ante un problema o situación a resolver, por medio de entrevistas, observaciones, grabaciones, encuestas, entre otras.'
                        )
                    ]
                ),
                achievementIndicator(
                    'project.initial.define.001',
                    'define',
                    'Sintetizar los hallazgos relacionados con los intereses y necesidades del usuario o cliente, de modo que se entienda con claridad el problema o situación por resolver.',
                    [
                        evaluationIndicator(
                            'project.initial.define.001.evaluation.01',
                            'Sintetiza los intereses y necesidades del usuario o cliente en la construcción de un producto comunicativo.'
                        )
                    ]
                ),
                achievementIndicator(
                    'project.initial.ideate.001',
                    'ideate',
                    'Seleccionar la idea más eficiente para ofrecer una posible solución a un problema o situación por resolver.',
                    [
                        evaluationIndicator(
                            'project.initial.ideate.001.evaluation.01',
                            'Selecciona la idea que ofrezca la solución más eficiente para resolver el problema o situación.'
                        ),
                        evaluationIndicator(
                            'project.initial.ideate.001.evaluation.02',
                            'Justifica de manera clara, con al menos dos ideas, por qué la solución elegida es la más eficiente, comparándola con otras.'
                        )
                    ]
                )
            ]);

            const phases = Object.freeze([
                Object.freeze({ id:'empathize', stageId:'initial', name:'Empatizar', order:1, indicatorStatus:'official', indicatorIds:Object.freeze(['project.initial.empathize.001']) }),
                Object.freeze({ id:'define', stageId:'initial', name:'Definir', order:2, indicatorStatus:'official', indicatorIds:Object.freeze(['project.initial.define.001']) }),
                Object.freeze({ id:'ideate', stageId:'initial', name:'Idear', order:3, indicatorStatus:'official', indicatorIds:Object.freeze(['project.initial.ideate.001']) }),
                Object.freeze({ id:'prototype', stageId:'development', name:'Prototipar', order:4, indicatorStatus:'pending-official-source', indicatorIds:Object.freeze([]) }),
                Object.freeze({ id:'test-evaluate', stageId:'final', name:'Probar/Evaluar', order:5, indicatorStatus:'pending-official-source', indicatorIds:Object.freeze([]) })
            ]);

            const stages = Object.freeze([
                Object.freeze({ id:'initial', name:'Etapa inicial', order:1, phaseIds:Object.freeze(['empathize','define','ideate']), indicatorStatus:'official' }),
                Object.freeze({ id:'development', name:'Etapa de desarrollo', order:2, phaseIds:Object.freeze(['prototype']), indicatorStatus:'pending-official-source' }),
                Object.freeze({ id:'final', name:'Etapa final', order:3, phaseIds:Object.freeze(['test-evaluate']), indicatorStatus:'pending-official-source' })
            ]);

            const byId = (items, id) => items.find(item => item.id === id) || null;
            function getStage(id) { return byId(stages, id); }
            function getPhase(id) { return byId(phases, id); }
            function getIndicator(id) { return byId(indicators, id); }
            function phasesForStage(stageId) {
                const stage = getStage(stageId);
                return stage ? Object.freeze(stage.phaseIds.map(getPhase).filter(Boolean)) : Object.freeze([]);
            }
            function indicatorsForPhase(phaseId) {
                const phase = getPhase(phaseId);
                return phase ? Object.freeze(phase.indicatorIds.map(getIndicator).filter(Boolean)) : Object.freeze([]);
            }
            function indicatorsForStage(stageId) {
                return Object.freeze(phasesForStage(stageId).flatMap(phase => indicatorsForPhase(phase.id)));
            }
            function appliesTo(cycle) {
                return SOURCE.scope.includes(String(cycle || '').trim());
            }
            function teacherIndicatorForPhase(phase) {
                if (!phase || phase.indicatorStatus === 'official') return null;
                const prefix = `project.teacher.${phase.id}`;
                return {
                    id:`${prefix}.achievement.01`,
                    catalogVersion:CATALOG_VERSION,
                    sourceType:'teacher-authored',
                    officialText:'',
                    teacherText:'',
                    placeholder:`Agregue o edite el indicador de logro para ${getStage(phase.stageId)?.name || 'la etapa'} – ${phase.name}.`,
                    evaluationIndicators:[1,2].map(number=>({
                        id:`${prefix}.evaluation.0${number}`,
                        sourceType:'teacher-authored',
                        officialText:'',
                        teacherText:'',
                        placeholder:`Agregue el indicador de evaluación ${number} para ${phase.name}.`,
                        selected:true
                    }))
                };
            }
            function phaseRecord(phaseId) {
                const phase = getPhase(phaseId);
                const achievementIndicators = indicatorsForPhase(phaseId).map(indicator => ({
                    id:indicator.id,
                    catalogVersion:indicator.catalogVersion,
                    sourceType:'official-project',
                    officialText:indicator.text,
                    teacherText:indicator.text,
                    evaluationIndicators:indicator.evaluationIndicators.map(item => ({id:item.id,sourceType:'official-project',officialText:item.text,teacherText:item.text,selected:true}))
                }));
                return {phaseId:phase?.id || '',stageId:phase?.stageId || '',achievementIndicators};
            }
            function defaultWeekProject() {
                return {mode:'curricular',stageId:'',phaseId:'',records:{}};
            }
            function normalizeWeekProject(value) {
                const base=defaultWeekProject(),source=value&&typeof value==='object'?value:{};
                const mode=['curricular','mixed','integrated'].includes(source.mode)?source.mode:'curricular';
                const records=source.records&&typeof source.records==='object'?JSON.parse(JSON.stringify(source.records)):{};
                return {...base,...source,mode,records};
            }
            function effectiveText(item) {
                const teacherText=String(item?.teacherText||'').trim();
                return teacherText||String(item?.officialText||'').trim();
            }
            function exportSelection(value, selectedIndicatorIds=[]) {
                const project=normalizeWeekProject(value),empty={active:false,mode:project.mode,stageId:project.stageId,phaseId:project.phaseId,achievement:[],evaluation:[]};
                if(project.mode==='curricular'||!project.phaseId)return empty;
                const record=project.records?.[project.phaseId];
                if(!record)return empty;
                const selected=new Set(Array.isArray(selectedIndicatorIds)?selectedIndicatorIds:[]);
                const indicators=(record.achievementIndicators||[]).filter(item=>['teacher-authored','official-curriculum'].includes(item.sourceType)||selected.has(item.id));
                return {
                    active:true,
                    mode:project.mode,
                    stageId:project.stageId,
                    phaseId:project.phaseId,
                    achievement:indicators.map(item=>({id:item.id,text:effectiveText(item),officialText:String(item.officialText||''),sourceType:item.sourceType||'official-project'})).filter(item=>item.text),
                    evaluation:indicators.flatMap(indicator=>(indicator.evaluationIndicators||[]).filter(item=>item.selected!==false).map(item=>({id:item.id,achievementId:indicator.id,text:effectiveText(item),officialText:String(item.officialText||''),sourceType:item.sourceType||indicator.sourceType||'official-project'}))).filter(item=>item.text)
                };
            }

            return Object.freeze({
                CATALOG_VERSION,
                SOURCE,
                stages,
                phases,
                indicators,
                getStage,
                getPhase,
                getIndicator,
                phasesForStage,
                indicatorsForPhase,
                indicatorsForStage,
                appliesTo,
                teacherIndicatorForPhase,
                phaseRecord,
                defaultWeekProject,
                normalizeWeekProject,
                effectiveText,
                exportSelection
            });
        })();
        // PIA_PROJECT_COMPONENT_CATALOG_JS_END
