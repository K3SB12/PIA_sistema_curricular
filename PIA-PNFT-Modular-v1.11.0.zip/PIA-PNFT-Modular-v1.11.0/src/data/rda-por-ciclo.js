            // ===== RESULTADOS DE APRENDIZAJE (RdA) POR CICLO Y ÁREA =====
            const RDA_POR_CICLO = {
            "Materno Infantil/Transición": {
                "Apropiación tecnológica y Digital": "Identifica los dispositivos digitales considerando características funcionales, experimentando su utilidad y reconociendo la autoría, durante la accesibilidad, interacción y comunicación en la creación de recursos digitales.",
                "Programación y Algoritmos": "Ordena secuencias integrando conceptos de programación como dato, evento, estado, ciclos, así como nociones de lateralidad y orientación espacial, en la solución de desafíos propuestos, utilizando la programación iconográfica por bloques.",
                "Computación física y Robótica": "Reconoce el funcionamiento de los robots, así como sus componentes (cuerpo, sistema sensorial, sistemas de control), al clasificarlos por su uso y programarlos para resolver retos.",
                "Ciencia de datos e Inteligencia artificial": "Reconoce los conceptos básicos relacionados con la recopilación, organización e interpretación de datos, mediante gráficos pictóricos en la resolución de problemas, fomentando el pensamiento crítico y la curiosidad hacia el mundo que lo rodea."
            },
            "I Ciclo": {
                "Apropiación tecnológica y Digital": "Selecciona los dispositivos digitales y herramientas de productividad, mediante el uso de software y hardware, en la creación de archivos, creación y edición de contenido multimedia, aprovechando Internet y respetando la propiedad intelectual en la realización de tareas para la accesibilidad a la información de forma segura y responsable.",
                "Programación y Algoritmos": "Selecciona conceptos de programación como dato, secuencia, evento, estado, variables, operadores aritméticos y relacionales, condicionales simples, ciclo finito e infinito, en la programación por bloques para la solución de problemas.",
                "Computación física y Robótica": "No aplica para este ciclo.",
                "Ciencia de datos e Inteligencia artificial": "Reconoce los fundamentos de la inteligencia artificial y su presencia en la vida cotidiana, mediante ejemplos concretos como asistentes virtuales, valorando el uso seguro y responsable de estas tecnologías."
            },
            "II Ciclo": {
                "Apropiación tecnológica y Digital": "Selecciona la configuración de programas locales y en línea para su correcto uso al crear, buscar, compartir, organizar y administrar información en la realización de diferentes tareas de manera comprensiva, segura y responsable.",
                "Programación y Algoritmos": "Crea algoritmos que integran los conceptos de programación como secuencia, evento, estructuras de control (condicionales simples y ciclos), en la solución a problemas del contexto mediante la programación por bloques.",
                "Computación física y Robótica": "Crea algoritmos que permiten la simulación de comportamientos de aparatos tecnológicos, aplicando elementos de computación física, programación y electrónica para la resolución de un problema.",
                "Ciencia de datos e Inteligencia artificial": "Reconoce el uso de la inteligencia artificial en contextos cotidianos y aplica técnicas básicas de recolección, análisis y representación de datos mediante tablas y gráficos."
            },
             "III Ciclo": {
        "Apropiación tecnológica y Digital": "Crea diferentes tipos de archivos digitales (como texto, presentaciones, hojas de cálculo y otros), aplicando técnicas de gestión y seguridad de la información para organizar, proteger y comunicar eficazmente su trabajo académico y proyectos personales en entornos digitales locales y en la nube.",
        "Programación y Algoritmos": "Crea algoritmos y programas que integren estructuras de control (condicionales, ciclos), colecciones de datos, operadores y funciones, aplicando la lógica de programación para resolver problemas de complejidad media en contextos cotidianos o escolares.",
        "Computación física y Robótica": "Crea prototipos que integren elementos de computación física y/o robótica, aplicando conocimientos de electrónica, programación de microcontroladores, y uso de sensores y actuadores para automatizar procesos o resolver problemas específicos de su entorno.",
        "Ciencia de datos e Inteligencia artificial": "Aplica técnicas básicas de ciencia de datos (recolección, organización, visualización) e identifica el funcionamiento y aplicaciones de la inteligencia artificial, reconociendo sus usos, beneficios y desafíos éticos en diferentes contextos cotidianos."
            },
        };

