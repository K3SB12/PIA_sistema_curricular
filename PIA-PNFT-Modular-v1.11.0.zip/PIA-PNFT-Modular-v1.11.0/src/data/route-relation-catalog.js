// PIA_ROUTE_RELATION_CATALOG_START
// Posibles relaciones revisadas para orientar la exploración. No son categorías
// oficiales del PNFT ni certifican una integración pedagógica.
const PIARouteRelationCatalog = Object.freeze([
    { names:['Computadora','Hardware'], type:'supports', reason:'La identificación del equipo puede apoyar el reconocimiento de sus componentes y funciones.' },
    { names:['Hardware','Software'], type:'supports', reason:'Permite contrastar componentes físicos y programas dentro del funcionamiento de un sistema informático.' },
    { names:['Redes de comunicación','Conexión entre dispositivos'], type:'supports', reason:'Ambos saberes permiten explorar formas, dispositivos y condiciones de comunicación entre equipos.' },
    { names:['Sistema operativo','Gestión de archivos'], type:'prepares', reason:'El uso del sistema operativo puede brindar el entorno necesario para organizar, recuperar y compartir archivos.' },
    { names:['Circuito eléctrico','Fundamentos de electrónica'], type:'prepares', reason:'Los circuitos ofrecen una base observable para comprender componentes y relaciones electrónicas.' },
    { names:['Fundamentos de electrónica','Microcontrolador'], type:'prepares', reason:'La comprensión de componentes y conexiones puede apoyar el uso responsable de un microcontrolador.' },
    { names:['Mecanismos','Mecánica aplicada a la robótica'], type:'prepares', reason:'El comportamiento de los mecanismos puede servir de base para analizar su aplicación en soluciones robóticas.' },
    { names:['Robot','Robótica'], type:'supports', reason:'El reconocimiento del robot puede apoyar la comprensión de la robótica como campo y proceso de diseño.' },
    { names:['Entorno de programación textual o bloques para programar mecanismos robóticos','Mecanismos'], type:'supports', reason:'Un entorno de programación o simulación puede permitir representar y probar el comportamiento de mecanismos.' },
    { names:['Entorno de programación textual o bloques para programar mecanismos robóticos','Mecánica aplicada a la robótica'], type:'supports', reason:'La programación o simulación puede aportar evidencia del control y comportamiento previsto del mecanismo.' },
    { names:['Internet de las cosas','Conexión entre dispositivos'], type:'prepares', reason:'La conexión entre dispositivos puede aportar una condición necesaria para comprender sistemas de Internet de las cosas.' },
    { names:['Internet de las cosas','Microcontrolador'], type:'supports', reason:'Un microcontrolador puede participar en la captura, procesamiento o intercambio de información de una solución conectada.' }
]);
// PIA_ROUTE_RELATION_CATALOG_END
