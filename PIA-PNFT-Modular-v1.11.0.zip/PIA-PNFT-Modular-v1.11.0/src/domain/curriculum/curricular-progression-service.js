// PIA_CURRICULAR_PROGRESSION_SERVICE_START
const PIACurricularProgression = (() => {
    const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es').replace(/[^a-z0-9]+/g, ' ').trim();
    const familyById = new Map(PIACurricularProgressionData.families.map(family => [family.id, family]));

    const exactAliases = new Map();
    function register(area, familyId, names) {
        names.forEach(name => exactAliases.set(`${normalize(area)}::${normalize(name)}`, familyId));
    }

    const DIGITAL = 'Apropiación tecnológica y Digital';
    const PROGRAMMING = 'Programación y Algoritmos';
    const PHYSICAL = 'Computación física y Robótica';
    const DATA = 'Ciencia de datos e Inteligencia artificial';

    register(PROGRAMMING, 'programming.environments', [
        'Entorno de programación iconográfico', 'Entorno de programación por bloques',
        'Entorno de programación por bloques para computación física',
        'Entorno de programación textual o bloques para programar mecanismos robóticos',
        'Entorno de programación textual o por bloques'
    ]);
    register(PROGRAMMING, 'programming.logic', [
        'Lateralidad y orientación espacial', 'Estado', 'Reconocimiento de patrones',
        'Lógica de programación', 'Lógica de programación (tablas de verdad)'
    ]);
    register(PROGRAMMING, 'programming.algorithms', ['Algoritmo', 'Algoritmo (pseudocódigo)', 'Algoritmo (Diagrama de flujo)']);
    register(PROGRAMMING, 'programming.data-structures', ['Dato', 'Variable', 'Colección de datos']);
    register(PROGRAMMING, 'programming.control-structures', ['Estructuras condicionales', 'Estructuras repetitivas']);
    register(PROGRAMMING, 'programming.operators', ['Operador relacional', 'Operadores relacionales', 'Operadores Lógicos', 'Operadores lógicos', 'Operadores aritméticos']);
    register(PROGRAMMING, 'programming.events-functions', ['Evento', 'Eventos', 'Procedimientos y/o funciones', 'Procedimientos/funciones']);

    register(DIGITAL, 'digital.fundamentals', ['Computadora', 'Hardware', 'Software', 'Software (programas)']);
    register(DIGITAL, 'digital.connections', ['Conexión entre dispositivos', 'Conexión entre dispositivos (bluetooth)', 'Conexión entre dispositivos (wifi)', 'Redes de comunicación']);
    register(DIGITAL, 'digital.operating-systems', ['Gestión de archivos', 'Sistema Operativo', 'Sistema operativo']);
    register(DIGITAL, 'digital.productivity', [
        'Herramienta de productividad', 'Herramienta de productividad (editor de presentaciones)',
        'Herramienta de productividad (gestor de bases de datos)', 'Herramienta de productividad (hoja de cálculo)',
        'Herramienta de productividad (procesador de texto)',
        'Herramienta de productividad (procesador de texto, editor de presentaciones)'
    ]);
    register(DIGITAL, 'digital.multimedia', [
        'Herramientas de creación de contenido multimedia', 'Herramientas de creación de contenido multimedia (Editor gráfico)',
        'Herramientas de creación de contenido multimedia (audio y video)', 'Herramientas de creación de contenido multimedia (audio, imágenes)',
        'Herramientas de creación de contenido multimedia (edición de audio y video)', 'Herramientas de creación de contenido multimedia (editor de gráficos)',
        'Herramientas de creación de contenido multimedia (grabadora de audio y editores de gráficos)',
        'Herramientas de creación de contenido multimedia (video)'
    ]);
    register(DIGITAL, 'digital.internet', ['Internet', 'Navegador', 'Buscador', 'Navegador y Buscador', 'Plataformas de creación de contenido']);
    register(DIGITAL, 'digital.collaboration', ['Netiqueta', 'Netiqueta, Comunicación y colaboración sincrónica/asincrónica', 'Comunicación y colaboración sincrónica y asincrónica', 'Comunicación y colaboración sincrónica y asincrónica (chat)', 'Almacenamiento en la nube']);
    register(DIGITAL, 'digital.intellectual-property', ['Derechos de autor', 'Derechos de autor y licenciamiento', 'Referencias bibliográficas', 'Licencia']);
    register(DIGITAL, 'digital.iot', ['Internet de las cosas']);
    register(DIGITAL, 'digital.crypto', ['Moneda virtual', 'Criptomonedas']);
    register(DIGITAL, 'digital.citizenship', ['Huella digital']);
    register(DIGITAL, 'digital.authentication', ['Contraseñas seguras']);
    register(DIGITAL, 'digital.hacking', ['Hackeo']);
    register(DIGITAL, 'digital.malware', ['Software malicioso', 'Software malicioso y Antivirus', 'Antivirus']);
    register(DIGITAL, 'digital.online-risks', ['Riesgo en línea', 'Riesgos en línea', 'Medidas de seguridad en la web', 'Medidas de seguridad web']);

    register(PHYSICAL, 'physical.robotics', ['Robot', 'Robótica', 'Computación física']);
    register(PHYSICAL, 'physical.mechanics', ['Mecánica aplicada a la robótica']);
    register(PHYSICAL, 'physical.mechanisms', ['Mecanismos', 'Movimiento en mecanismos']);
    register(PHYSICAL, 'physical.electronics', ['Circuito eléctrico', 'Fundamentos de electrónica']);
    register(PHYSICAL, 'physical.interfaces', ['Microcontrolador', 'Sensor', 'Actuador']);
    register(PHYSICAL, 'physical.domotics', ['Domótica', 'Prototipos']);

    register(DATA, 'data.importance', ['Dato', 'Dato (Ciencias de datos)', 'Dato (registros)']);
    register(DATA, 'data.management', ['Recolección de datos', 'Almacenamiento de datos']);
    register(DATA, 'data.visualization-intro', ['Estrategias para presentar datos', 'Visualización de datos']);
    register(DATA, 'data.augmented-reality', ['Realidad aumentada']);
    register(DATA, 'data.ai', ['Fundamentos de la IA', 'Asistentes virtuales', 'Herramientas generativas', 'Desafíos de la IA']);

    function familyIdFor(area, name) {
        return exactAliases.get(`${normalize(area)}::${normalize(name)}`) || '';
    }
    function getFamily(id) { return familyById.get(id) || null; }
    function stepFor(id, level) { return getFamily(id)?.levels?.[level] || null; }
    function pathToExplicit(family, level, direction) {
        const levels = PIACurricularProgressionData.levelOrder;
        const start = levels.indexOf(level);
        const transition = [];
        for (let index = start + direction; index >= 0 && index < levels.length; index += direction) {
            const step = family.levels[levels[index]];
            if (step?.status === 'explicit-evaluable') return { explicit: { level: levels[index], ...step }, transition: direction < 0 ? [...transition].reverse() : transition };
            transition.push({ level: levels[index], ...(step || { status: 'no-curricular-record', scope: '' }) });
        }
        return { explicit: null, transition: direction < 0 ? [...transition].reverse() : transition };
    }
    function resolveConcept(concept, level) {
        const familyId = familyIdFor(concept?.area, concept?.name);
        const family = getFamily(familyId);
        if (!family) return null;
        return {
            familyId,
            familyLabel: family.label,
            area: family.area,
            selectedConcept: concept.name,
            current: { level, ...(family.levels[level] || { status: 'not-applicable', scope: '' }) },
            previousPath: pathToExplicit(family, level, -1),
            nextPath: pathToExplicit(family, level, 1)
        };
    }
    function contextFor({ level, concepts = [] } = {}) {
        const byFamily = new Map();
        concepts.forEach(concept => {
            const resolved = resolveConcept(concept, level);
            if (!resolved) return;
            if (!byFamily.has(resolved.familyId)) byFamily.set(resolved.familyId, { ...resolved, selectedConcepts: [] });
            byFamily.get(resolved.familyId).selectedConcepts.push(concept.name);
        });
        return [...byFamily.values()];
    }
    function curriculumRecordsForFamily(familyId, level, curriculum = {}) {
        const records = [];
        Object.entries(curriculum?.[level] || {}).forEach(([module, areas]) => Object.entries(areas || {}).forEach(([area, record]) => {
            (record?.saberes || []).forEach(saber => {
                if (familyIdFor(area, saber?.nombre) !== familyId) return;
                records.push({
                    module,
                    area,
                    name: saber.nombre,
                id: `${level}::${module}::${area}::${saber.nombre}`,
                indicators: [...(saber.indicadores || [])]
                });
            });
        }));
        return records;
    }
    function displayStage(path, familyId, curriculum) {
        return {
            explicit: path.explicit ? {
                level: path.explicit.level,
                status: path.explicit.status,
                scope: path.explicit.scope,
                records: curriculumRecordsForFamily(familyId, path.explicit.level, curriculum)
            } : null,
            transition: path.transition.map(step => ({ level:step.level, status:step.status, scope:step.scope || '' }))
        };
    }
    function trajectoryView({ level, concepts = [], curriculum = {} } = {}) {
        const selectedByFamily = new Map();
        concepts.forEach(concept => {
            const familyId = familyIdFor(concept?.area, concept?.name);
            if (!familyId) return;
            if (!selectedByFamily.has(familyId)) selectedByFamily.set(familyId, []);
            selectedByFamily.get(familyId).push({
                module: concept.module || '',
                area: concept.area,
                name: concept.name,
                id: concept.id || `${level}::${concept.module || ''}::${concept.area}::${concept.name}`,
                selected: concept.selected !== false,
                indicators: [...(concept.indicators || [])]
            });
        });
        return contextFor({ level, concepts }).map(item => ({
            familyId: item.familyId,
            familyLabel: item.familyLabel,
            area: item.area,
            before: displayStage(item.previousPath, item.familyId, curriculum),
            now: {
                level,
                status: item.current.status,
                scope: item.current.scope || '',
                records: selectedByFamily.get(item.familyId) || []
            },
            after: displayStage(item.nextPath, item.familyId, curriculum)
        }));
    }
    function promptContext(input) {
        const context = contextFor(input);
        if (!context.length) return 'Sin referencias relacionales adicionales para los saberes seleccionados.';
        const scopeLines = step => String(step?.scope || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
        const selectedScopeLines = (step, selectedNames = []) => {
            const lines = scopeLines(step);
            if (!lines.length || !selectedNames.length) return lines;
            const selectedNamesNormalized = selectedNames.map(normalize);
            const sections = [];
            let current = null;
            lines.forEach(line => {
                if (!/^-/.test(line)) {
                    current = { heading: line, lines: [line] };
                    sections.push(current);
                } else if (current) current.lines.push(line);
                else sections.push({ heading: '', lines: [line] });
            });
            const matching = sections.filter(section => {
                const heading = normalize(section.heading.replace(/[:.]$/, ''));
                return heading && selectedNamesNormalized.some(name => name === heading || name.startsWith(`${heading} `) || heading.startsWith(`${name} `));
            });
            return matching.length ? matching.flatMap(section => section.lines) : lines;
        };
        const scope = (step, selectedNames = []) => {
            if (!step?.scope) return 'No se registra un alcance explícito.';
            return selectedScopeLines(step, selectedNames).map(line => {
                if (/^--\s*/.test(line)) return `  ◦ ${line.replace(/^--\s*/, '')}`;
                if (/^-\s*/.test(line)) return `• ${line.replace(/^-\s*/, '')}`;
                return line;
            }).join('\n');
        };
        const selected = names => names.map(name => `• ${name}`).join('\n');
        const reinforced = steps => steps.filter(step => ['reinforced-non-evaluable','conceptual-non-evaluable'].includes(step.status));
        const hasGap = steps => steps.some(step => ['not-applicable','no-curricular-record'].includes(step.status));
        const reinforcementText = steps => reinforced(steps).map(step => `• En ${step.level} la fuente curricular registra presencia o fortalecimiento sin evaluación directa; no corresponde crear un indicador oficial adicional.`).join('\n');
        return context.map(item => {
            const currentMeaning = item.current.status === 'reinforced-non-evaluable'
                ? 'Se retoma o refuerza conceptualmente; no corresponde inventar un indicador ni una evaluación directa.'
                : item.current.status === 'conceptual-non-evaluable'
                    ? 'La fuente curricular registra presencia conceptual sin indicador directo.'
                : item.current.status === 'not-applicable'
                    ? 'La fuente curricular lo identifica como no aplicable para el nivel.'
                : item.current.status === 'no-curricular-record'
                    ? 'La matriz no registra abordaje conceptual en este nivel; no se infiere enseñanza, refuerzo ni dominio.'
                    : scope(item.current, item.selectedConcepts);
            const currentIndex = PIACurricularProgressionData.levelOrder.indexOf(item.current.level);
            const lastIndex = PIACurricularProgressionData.levelOrder.length - 1;
            const previousGap = hasGap(item.previousPath.transition);
            const nextGap = hasGap(item.nextPath.transition);
            const previous = item.previousPath.explicit
                ? `${previousGap ? 'ANTES — REFERENCIA ANTERIOR DE LA MISMA FAMILIA' : 'ANTES — REFERENCIA PARA EL DIAGNÓSTICO'}\n\nEn ${item.previousPath.explicit.level} se contempla:\n${scope(item.previousPath.explicit)}${reinforced(item.previousPath.transition).length ? `\n\nEntre esa referencia y el nivel actual:\n${reinforcementText(item.previousPath.transition)}` : ''}${previousGap ? '\n\nExisten niveles intermedios sin abordaje conceptual registrado o identificados como no aplicables. No se infiere refuerzo ni prerrequisito directo.' : '\n\nVerifique esta posible base mediante el diagnóstico. PIA no confirma que esos aprendizajes hayan sido enseñados o alcanzados.'}`
                : 'ANTES — REFERENCIA PARA EL DIAGNÓSTICO\n\nNo se registra un antecedente explícito antes del nivel actual. Determine el punto de partida mediante el diagnóstico.';
            let next;
            if (item.nextPath.explicit) {
                next = `${nextGap ? 'DESPUÉS — REFERENCIA POSTERIOR NO CONTINUA' : 'DESPUÉS — CONTINUIDAD CURRICULAR'}\n\n${reinforced(item.nextPath.transition).length ? `${reinforcementText(item.nextPath.transition)}\n\n` : ''}En ${item.nextPath.explicit.level} se contempla:\n${scope(item.nextPath.explicit)}${nextGap ? '\n\nExisten niveles intermedios sin abordaje conceptual registrado o identificados como no aplicables; la continuidad no es inmediata.' : ''}\n\nEsta información orienta la progresión, pero no corresponde planearla como contenido obligatorio del nivel actual.`;
            } else if (currentIndex === lastIndex) {
                next = 'DESPUÉS — CONTINUIDAD CURRICULAR\n\nLa continuidad posterior está fuera del alcance del catálogo actual, que finaliza en 9°. Esto no representa el final del aprendizaje.';
            } else {
                next = 'DESPUÉS — CONTINUIDAD CURRICULAR\n\nNo se registra otro desarrollo explícito de esta trayectoria hasta 9°.';
            }
            return `TRAYECTORIA: ${item.familyLabel.toLocaleUpperCase('es')}\nÁrea: ${item.area}\n\nAHORA — PLANIFIQUE EN ${item.current.level}\n\nSaberes seleccionados:\n${selected(item.selectedConcepts)}\n\nAlcance curricular actual:\n${currentMeaning}\n\nEste es el alcance que debe desarrollarse en la proyección del nivel actual.\n\n${previous}\n\n${next}`;
        }).join('\n\n────────────────────────────────────────\n\n');
    }
    function promptSummary(input) {
        const context = contextFor(input);
        if (!context.length) return 'Considere la integración horizontal entre las áreas seleccionadas y la progresión vertical de los saberes del nivel actual; no suponga aprendizajes previos ni adelante alcances de otros niveles.';
        const families = [...new Set(context.map(item => item.familyLabel))];
        return `Considere la integración horizontal entre las áreas seleccionadas y la progresión vertical de los saberes dentro de las familias curriculares relacionadas internamente por PIA (${families.join(', ')}); desarrolle únicamente el nivel actual, use los antecedentes para diagnóstico cuando existan sin suponer aprendizaje y no adelante alcances posteriores.`;
    }
    function unmappedCurriculumRecords(data) {
        const missing = [];
        Object.entries(data || {}).forEach(([level, modules]) => Object.entries(modules || {}).forEach(([module, areas]) => Object.entries(areas || {}).forEach(([area, record]) => (record.saberes || []).forEach(saber => {
            if (!familyIdFor(area, saber.nombre)) missing.push({ level, module, area, name: saber.nombre });
        }))));
        return missing;
    }

    return Object.freeze({ familyIdFor, getFamily, stepFor, resolveConcept, contextFor, curriculumRecordsForFamily, trajectoryView, promptContext, promptSummary, unmappedCurriculumRecords });
})();
// PIA_CURRICULAR_PROGRESSION_SERVICE_END
