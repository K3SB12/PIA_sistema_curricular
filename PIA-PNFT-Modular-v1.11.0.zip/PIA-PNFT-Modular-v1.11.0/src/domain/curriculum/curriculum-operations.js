        // PIA_PRESCHOOL_RUNTIME_ADAPTER_START
        function activarItinerarioPreescolar(itinerario) {
            const nivel = document.getElementById('nivel')?.value;
            if (nivel !== '0°' || typeof PIAPreschoolCurriculum === 'undefined') return;
            PNFT_DATA['0°'] = PIAPreschoolCurriculum.getLevelData(itinerario || document.getElementById('piaPreschoolTrack')?.value || 'optimal');
        }

        function obtenerRdaCurricular(ciclo, areaNombre) {
            if (document.getElementById('nivel')?.value === '0°' && typeof PIAPreschoolCurriculum !== 'undefined') {
                return PIAPreschoolCurriculum.RDA_BY_AREA[areaNombre] || '';
            }
            return RDA_POR_CICLO?.[ciclo]?.[areaNombre] || '';
        }

        function refrescarCurriculoSemanas() {
            if (!Array.isArray(semanas)) return;
            semanas.forEach((_, index) => {
                const numero = index + 1;
                actualizarSelectorCurricularSemana(numero);
                actualizarRdASemana(numero);
                actualizarOpcionesSaberesSemana(numero);
                actualizarIndicadoresSemana(numero);
            });
        }
        // PIA_PRESCHOOL_RUNTIME_ADAPTER_END

        // PIA_WEEKLY_CURRICULUM_SCOPE_START
        const PIA_WEEK_MODULES = ['Módulo 1', 'Módulo 2'];
        const PIA_WEEK_AREAS = [
            ['apropiacion', 'Apropiación tecnológica y Digital'],
            ['programacion', 'Programación y Algoritmos'],
            ['robotica', 'Computación física y Robótica'],
            ['ciencia', 'Ciencia de datos e Inteligencia artificial']
        ];

        function escaparCurriculoSemana(value) {
            if (typeof PIAProjectionCore !== 'undefined') return PIAProjectionCore.escapeHtml(String(value ?? ''));
            return String(value ?? '').replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
        }

        function modulosPredeterminadosSemana() {
            return document.getElementById('semestre')?.value === 'II' ? ['Módulo 2'] : ['Módulo 1'];
        }

        function normalizarModulosSemana(semana) {
            const guardados = Array.isArray(semana?.modulos) ? semana.modulos.filter(modulo => PIA_WEEK_MODULES.includes(modulo)) : [];
            if (guardados.length) return [...new Set(guardados)];
            if ((semana?.areas?.length || 0) > 0 || (semana?.saberes?.length || 0) > 0) return [...PIA_WEEK_MODULES];
            return modulosPredeterminadosSemana();
        }

        function normalizarReferenciasSaberesSemana(semana) {
            if (!Array.isArray(semana?.saberRefs)) return [];
            return semana.saberRefs.filter(referencia =>
                referencia && PIA_WEEK_MODULES.includes(referencia.modulo) && referencia.area && referencia.nombre
            ).map(referencia => ({modulo:referencia.modulo, area:referencia.area, nombre:referencia.nombre}));
        }

        function asegurarAlcanceCurricularSemana(semana) {
            if (!semana) return null;
            semana.modulos = normalizarModulosSemana(semana);
            semana.saberRefs = normalizarReferenciasSaberesSemana(semana);
            return semana;
        }

        function modulosDisponiblesNivel(nivel) {
            return PIA_WEEK_MODULES.filter(modulo => PNFT_DATA?.[nivel]?.[modulo]);
        }

        function areasDisponiblesSemana(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const nivel = document.getElementById('nivel')?.value || '';
            const areas = new Set();
            (semana?.modulos || []).forEach(modulo => {
                Object.keys(PNFT_DATA?.[nivel]?.[modulo] || {}).forEach(area => areas.add(area));
            });
            return areas;
        }

        function generarSelectorModulosSemana(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const nivel = document.getElementById('nivel')?.value || '';
            const disponibles = modulosDisponiblesNivel(nivel);
            return PIA_WEEK_MODULES.map(modulo => {
                const abreviado = modulo === 'Módulo 1' ? 'M1' : 'M2';
                const checked = semana?.modulos.includes(modulo);
                const disabled = Boolean(nivel) && !disponibles.includes(modulo);
                return `<label class="pia-week-module-option ${disabled ? 'is-disabled' : ''}"><input type="checkbox" data-pia-week-module="${numeroSemana}" value="${modulo}" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''} onchange="actualizarModuloSemana(${numeroSemana}, this)"><span>${abreviado}</span></label>`;
            }).join('');
        }

        function generarOpcionesAreasSemana(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const disponibles = areasDisponiblesSemana(numeroSemana);
            if (!document.getElementById('nivel')?.value) return '<div class="pia-week-scope-note">Seleccione primero el ciclo y el nivel.</div>';
            const opciones = PIA_WEEK_AREAS.filter(([, nombre]) => disponibles.has(nombre)).map(([clave, nombre]) => `
                <label class="area-item">
                    <input type="checkbox" name="area-semana-${numeroSemana}" value="${clave}" ${semana.areas.includes(nombre) ? 'checked' : ''} onchange="actualizarAreaSemana(${numeroSemana}, this)">
                    <span>${escaparCurriculoSemana(nombre)}</span>
                </label>`).join('');
            const conservadas = semana.areas.filter(area => !disponibles.has(area));
            const aviso = conservadas.length
                ? `<div class="pia-week-scope-note is-warning">Se conservan fuera del filtro: ${escaparCurriculoSemana(conservadas.join(', '))}. Active su módulo para revisarlas o retirarlas.</div>`
                : '';
            return opciones + aviso || '<div class="pia-week-scope-note">Seleccione al menos un módulo disponible.</div>';
        }

        function actualizarSelectorCurricularSemana(numeroSemana) {
            const modulos = document.querySelector(`[data-pia-week-modules="${numeroSemana}"]`);
            const areas = document.querySelector(`#semana-${numeroSemana} .areas-lista`);
            if (modulos) modulos.innerHTML = generarSelectorModulosSemana(numeroSemana);
            if (areas) areas.innerHTML = generarOpcionesAreasSemana(numeroSemana);
        }

        function actualizarModuloSemana(numeroSemana, checkbox) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const seleccionados = Array.from(document.querySelectorAll(`[data-pia-week-module="${numeroSemana}"]:checked`)).map(input => input.value);
            if (!seleccionados.length) {
                checkbox.checked = true;
                alert('Cada semana debe conservar al menos un módulo como filtro curricular.');
                return;
            }
            semana.modulos = seleccionados;
            actualizarSelectorCurricularSemana(numeroSemana);
            actualizarRdASemana(numeroSemana);
            actualizarOpcionesSaberesSemana(numeroSemana);
            actualizarIndicadoresSemana(numeroSemana);
        }

        function registroSaberCurricular(nivel, modulo, area, nombre) {
            return PNFT_DATA?.[nivel]?.[modulo]?.[area]?.saberes?.find(saber => saber.nombre === nombre) || null;
        }

        function registrosCurricularesSemana(semana, nivel) {
            const referencias = normalizarReferenciasSaberesSemana(semana);
            const registros = [];
            const claves = new Set();
            referencias.forEach(referencia => {
                const saber = registroSaberCurricular(nivel, referencia.modulo, referencia.area, referencia.nombre);
                if (!saber) return;
                const clave = `${referencia.modulo}\u0000${referencia.area}\u0000${referencia.nombre}`;
                if (!claves.has(clave)) registros.push({...referencia, saber});
                claves.add(clave);
            });
            const nombresReferenciados = new Set(referencias.map(referencia => referencia.nombre));
            (semana?.saberes || []).filter(nombre => !nombresReferenciados.has(nombre)).forEach(nombre => {
                const candidatos = [];
                normalizarModulosSemana(semana).forEach(modulo => Object.keys(PNFT_DATA?.[nivel]?.[modulo] || {}).forEach(area => {
                    const saber = registroSaberCurricular(nivel, modulo, area, nombre);
                    if (saber) candidatos.push({modulo, area, nombre, saber});
                }));
                const elegidos = candidatos.length ? candidatos : PIA_WEEK_MODULES.flatMap(modulo => Object.keys(PNFT_DATA?.[nivel]?.[modulo] || {}).map(area => {
                    const saber = registroSaberCurricular(nivel, modulo, area, nombre);
                    return saber ? {modulo, area, nombre, saber} : null;
                }).filter(Boolean));
                elegidos.forEach(registro => {
                    const clave = `${registro.modulo}\u0000${registro.area}\u0000${registro.nombre}`;
                    if (!claves.has(clave)) registros.push(registro);
                    claves.add(clave);
                });
            });
            return registros;
        }
        // PIA_WEEKLY_CURRICULUM_SCOPE_END

        function actualizarAreaSemana(numeroSemana, checkbox) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const areaNombre = PIA_WEEK_AREAS.find(([clave]) => clave === checkbox.value)?.[1];
            if (!semana || !areaNombre) return;
            if (checkbox.checked) {
                if (!semana.areas.includes(areaNombre)) semana.areas.push(areaNombre);
            } else {
                const nombresDelArea = new Set(PIA_WEEK_MODULES.flatMap(modulo =>
                    (PNFT_DATA?.[document.getElementById('nivel')?.value]?.[modulo]?.[areaNombre]?.saberes || []).map(saber => saber.nombre)
                ));
                const seleccionados = semana.saberes.filter(nombre => nombresDelArea.has(nombre));
                if (seleccionados.length && !confirm(`Al retirar esta área se desmarcarán ${seleccionados.length} saber(es) de esta semana. ¿Desea continuar?`)) {
                    checkbox.checked = true;
                    return;
                }
                semana.areas = semana.areas.filter(area => area !== areaNombre);
                const teniaReferencias = semana.saberRefs.length > 0;
                semana.saberRefs = semana.saberRefs.filter(referencia => referencia.area !== areaNombre);
                semana.saberes = semana.saberes.filter(nombre => {
                    if (!nombresDelArea.has(nombre)) return true;
                    return teniaReferencias && semana.saberRefs.some(referencia => referencia.nombre === nombre);
                });
            }
            actualizarRdASemana(numeroSemana);
            actualizarOpcionesSaberesSemana(numeroSemana);
            actualizarIndicadoresSemana(numeroSemana);
        }

        function actualizarRdASemana(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const ciclo = document.getElementById('ciclo')?.value || '';
            const container = document.getElementById(`rda-semana-${numeroSemana}`);
            if (!container) return;
            if (!ciclo || !semana?.areas.length) {
                container.innerHTML = '<div class="pia-week-scope-note">Seleccione al menos un área de conocimiento.</div>';
                return;
            }
            container.innerHTML = semana.areas.map(area => {
                const rda = obtenerRdaCurricular(ciclo, area);
                return rda ? `<div class="rda-item"><strong>${escaparCurriculoSemana(area)}:</strong><br>${escaparCurriculoSemana(rda)}</div>` : '';
            }).join('') || '<div class="pia-week-scope-note">No existe un RdA autorizado para esta selección.</div>';
        }

        function actualizarOpcionesSaberesSemana(numeroSemana) {
            const container = document.getElementById(`saberes-conceptuales-${numeroSemana}`);
            if (container) container.innerHTML = generarSaberesConceptuales(numeroSemana);
            actualizarSaberesConceptualesContenedor(numeroSemana);
        }

        function saberEstaSeleccionado(semana, modulo, area, nombre) {
            const referencias = normalizarReferenciasSaberesSemana(semana);
            return referencias.length
                ? referencias.some(referencia => referencia.modulo === modulo && referencia.area === area && referencia.nombre === nombre)
                : semana.saberes.includes(nombre);
        }

        function generarSaberesConceptuales(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const nivel = document.getElementById('nivel')?.value || '';
            if (!nivel || !semana?.areas.length) return '<div class="pia-week-scope-note">Seleccione ciclo, nivel, módulo y al menos un área de conocimiento.</div>';
            let html = '';
            const nombresVisibles = new Set();
            semana.areas.forEach(area => {
                const bloques = semana.modulos.map(modulo => {
                    const saberes = PNFT_DATA?.[nivel]?.[modulo]?.[area]?.saberes || [];
                    if (!saberes.length) return '';
                    const numeroModulo = modulo === 'Módulo 1' ? '1' : '2';
                    saberes.forEach(saber => nombresVisibles.add(saber.nombre));
                    return `<div class="pia-week-module-block"><div class="pia-week-module-label">${modulo}</div>${saberes.map(saber => {
                        const seleccionado = saberEstaSeleccionado(semana, modulo, area, saber.nombre);
                        return `<label class="saber-conceptual-item ${seleccionado ? 'seleccionado' : ''}"><input type="checkbox" data-pia-week-knowledge="${numeroSemana}" data-module="${escaparCurriculoSemana(modulo)}" data-area="${escaparCurriculoSemana(area)}" data-name="${escaparCurriculoSemana(saber.nombre)}" ${seleccionado ? 'checked' : ''} onchange="manejarSeleccionSaberDesdeControl(${numeroSemana}, this)"><span><strong>${escaparCurriculoSemana(saber.nombre)}</strong><span class="pia-module-badge">M${numeroModulo}</span><span class="indicador-logro">${escaparCurriculoSemana((saber.indicadores || [])[0] || '')}</span></span></label>`;
                    }).join('')}</div>`;
                }).join('');
                if (bloques) html += `<section class="pia-week-area-block"><h5>${escaparCurriculoSemana(area)}</h5>${bloques}</section>`;
            });
            const fueraDelFiltro = semana.saberes.filter(nombre => !nombresVisibles.has(nombre));
            if (fueraDelFiltro.length) html += `<div class="pia-week-scope-note is-warning">${fueraDelFiltro.length} saber(es) se conservan fuera del filtro actual. Active el módulo correspondiente para revisarlos.</div>`;
            return html || '<div class="pia-week-scope-note">Las áreas seleccionadas no contienen saberes en el módulo elegido.</div>';
        }

        function actualizarSaberesConceptualesContenedor(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const container = document.getElementById(`conceptuales-semana-${numeroSemana}`);
            if (!container) return;
            if (!semana?.saberes.length) {
                container.innerHTML = '<div class="pia-week-scope-note">Los saberes seleccionados para esta semana se mostrarán aquí.</div>';
                return;
            }
            const nivel = document.getElementById('nivel')?.value || '';
            const registros = registrosCurricularesSemana(semana, nivel);
            container.innerHTML = semana.saberes.map(nombre => {
                const modulos = [...new Set(registros.filter(registro => registro.nombre === nombre).map(registro => registro.modulo === 'Módulo 1' ? 'M1' : 'M2'))];
                return `<div class="pia-week-selected-knowledge"><strong>${escaparCurriculoSemana(nombre)}</strong>${modulos.length ? `<span>${modulos.join(' · ')}</span>` : ''}</div>`;
            }).join('');
        }

        function manejarSeleccionSaberDesdeControl(numeroSemana, checkbox) {
            manejarSeleccionSaber(numeroSemana, checkbox.dataset.name, checkbox.checked, checkbox.dataset.area, '', checkbox.dataset.module);
        }

        function manejarSeleccionSaber(numeroSemana, nombreSaber, seleccionado, area, indicadoresStr = '', modulo = '') {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            if (!semana) return;
            const referencia = {modulo, area, nombre:nombreSaber};
            if (seleccionado) {
                if (!semana.saberes.includes(nombreSaber)) semana.saberes.push(nombreSaber);
                if (modulo && !semana.saberRefs.some(item => item.modulo === modulo && item.area === area && item.nombre === nombreSaber)) semana.saberRefs.push(referencia);
                saberesSeleccionados.add(nombreSaber);
            } else {
                const teniaReferencias = semana.saberRefs.length > 0;
                semana.saberRefs = semana.saberRefs.filter(item => !(item.modulo === modulo && item.area === area && item.nombre === nombreSaber));
                if (!teniaReferencias || !semana.saberRefs.some(item => item.nombre === nombreSaber)) semana.saberes = semana.saberes.filter(nombre => nombre !== nombreSaber);
                const enOtraSemana = semanas.some((item, index) => index !== numeroSemana - 1 && item.saberes.includes(nombreSaber));
                if (!enOtraSemana && !semana.saberes.includes(nombreSaber)) saberesSeleccionados.delete(nombreSaber);
            }
            actualizarOpcionesSaberesSemana(numeroSemana);
            actualizarIndicadoresSemana(numeroSemana);
        }

        function actualizarIndicadoresSemana(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const nivel = document.getElementById('nivel')?.value || '';
            const container = document.querySelector(`#semana-${numeroSemana} .contenedor-oficial[data-field-kind="official-indicator"]`);
            if (!container) return;
            const indicadores = [];
            const vistos = new Set();
            registrosCurricularesSemana(semana, nivel).forEach(registro => (registro.saber.indicadores || []).forEach(indicador => {
                const clave = `${registro.modulo}\u0000${indicador}`;
                if (vistos.has(clave)) return;
                vistos.add(clave);
                indicadores.push(`<div class="pia-official-indicator">• ${escaparCurriculoSemana(indicador)} <span>[${registro.modulo}]</span></div>`);
            }));
            const html = indicadores.join('') || '<div class="pia-week-scope-note">Los indicadores aparecerán automáticamente según los saberes conceptuales seleccionados.</div>';
            container.innerHTML = html;
            semana.indicadores = html;
        }

        function obtenerIndicadoresLogroSemana(numeroSemana) {
            const semana = asegurarAlcanceCurricularSemana(semanas[numeroSemana - 1]);
            const nivel = document.getElementById('nivel')?.value || '';
            return [...new Set(registrosCurricularesSemana(semana, nivel).flatMap(registro => registro.saber.indicadores || []))]
                .map(indicador => indicador.replace(/•/g, '').trim());
        }
