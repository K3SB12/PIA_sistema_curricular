// PIA_RDA_ROUTE_SERVICE_START
const PIARdaRouteService = (() => {
    const indexBy = list => new Map((list || []).map(item => [item.id, item]));
    const asSet = values => new Set(Array.isArray(values) ? values : []);
    const CYCLE_ORDER = Object.freeze(['Materno Infantil/Transición', 'I Ciclo', 'II Ciclo', 'III Ciclo']);

    function audit(graph) {
        const familyIds = new Set(graph?.nodes?.families?.map(item => item.id) || []);
        const rdaIds = new Set(graph?.nodes?.rdas?.map(item => item.id) || []);
        const knowledgeIds = new Set(graph?.nodes?.knowledge?.map(item => item.id) || []);
        const indicatorIds = new Set(graph?.nodes?.indicators?.map(item => item.id) || []);
        const invalidEdges = (graph?.edges || []).filter(edge => {
            if (edge.type === 'member-of-family') return !knowledgeIds.has(edge.from) || !familyIds.has(edge.to);
            if (edge.type === 'within-cycle-area-rda-scope') return !knowledgeIds.has(edge.from) || !rdaIds.has(edge.to) || edge.semanticClaim !== false;
            if (edge.type === 'indicator-of') return !indicatorIds.has(edge.from) || !knowledgeIds.has(edge.to);
            return true;
        });
        const indicatorsById = indexBy(graph?.nodes?.indicators || []);
        const rdasById = indexBy(graph?.nodes?.rdas || []);
        const invalidCorrespondences = (graph?.validatedPedagogicalCorrespondences || []).filter(item => {
            const indicator = indicatorsById.get(item.indicatorId);
            const rda = rdasById.get(item.rdaId);
            return !PIARdaContributionCatalog.validCorrespondenceShape(item) || !indicatorIds.has(item.indicatorId)
                || !rdaIds.has(item.rdaId) || item.indicatorText !== indicator?.text || item.rdaText !== rda?.text;
        });
        return Object.freeze({
            valid: invalidEdges.length === 0 && invalidCorrespondences.length === 0,
            invalidEdges: Object.freeze(invalidEdges),
            invalidCorrespondences: Object.freeze(invalidCorrespondences),
            unresolved: Object.freeze([...(graph?.unresolved || [])])
        });
    }

    function nearestFamilyLevel(graph, familyId, level, direction) {
        if (!familyId) return null;
        const levels = graph.levelOrder || [];
        const start = levels.indexOf(level);
        for (let index = start + direction; index >= 0 && index < levels.length; index += direction) {
            const records = graph.nodes.knowledge.filter(item => item.level === levels[index] && item.familyId === familyId);
            if (records.length) return Object.freeze({ level: levels[index], records: Object.freeze(records) });
        }
        return null;
    }

    function correspondenceFor(graph, indicatorIds, rdaId) {
        const validated = (graph.validatedPedagogicalCorrespondences || []).filter(item =>
            indicatorIds.includes(item.indicatorId) && item.rdaId === rdaId && item.status === 'validated'
        );
        return Object.freeze({
            status: validated.length === indicatorIds.length && indicatorIds.length ? 'validated' : 'pending-validation',
            records: Object.freeze(validated)
        });
    }

    function stateForLevel(graph, family, area, level, records, rda) {
        if (rda && !rda.applicable) return 'not-applicable';
        if (records.length) return 'explicit-evaluable';
        const areaPresent = graph.nodes.knowledge.some(item => item.level === level && item.area === area);
        if (!areaPresent) return 'area-absent';
        return family?.levelStates?.find(item => item.level === level)?.status || 'no-curricular-record';
    }

    function cycleRoutes(graph, family, area, currentKnowledge, indicatorsByKnowledge) {
        const rdaById = indexBy(graph.nodes.rdas);
        return CYCLE_ORDER.map(cycle => {
            const levels = graph.levelOrder.filter(level => graph.cycleByLevel[level] === cycle);
            const rda = rdaById.get(PIARdaContributionCatalog.rdaId(cycle, area)) || null;
            const milestones = levels.map(level => {
                let records = graph.nodes.knowledge.filter(item => item.level === level && item.familyId === family?.id);
                if (level === currentKnowledge.level) records = records.filter(item => item.id === currentKnowledge.id);
                const enriched = records.map(record => Object.freeze({
                    ...record,
                    indicators: Object.freeze([...(indicatorsByKnowledge.get(record.id) || [])])
                }));
                return Object.freeze({
                    level,
                    current: level === currentKnowledge.level,
                    status: stateForLevel(graph, family, area, level, enriched, rda),
                    scope: family?.levelStates?.find(item => item.level === level)?.scope || '',
                    records: Object.freeze(enriched)
                });
            });
            return Object.freeze({
                cycle,
                current: cycle === currentKnowledge.cycle,
                rda,
                applicable: Boolean(rda?.applicable),
                milestones: Object.freeze(milestones)
            });
        });
    }

    function buildRoute(graph, selection = {}) {
        if (!graph?.nodes) return Object.freeze({ status: 'unavailable', items: Object.freeze([]) });
        const level = String(selection.level || '');
        const modules = asSet(selection.modules);
        const areas = asSet(selection.areas);
        const conceptIds = asSet(selection.conceptIds);
        const familyById = indexBy(graph.nodes.families);
        const rdaById = indexBy(graph.nodes.rdas);
        const indicatorsByKnowledge = new Map();
        graph.nodes.indicators.forEach(indicator => {
            if (!indicatorsByKnowledge.has(indicator.knowledgeId)) indicatorsByKnowledge.set(indicator.knowledgeId, []);
            indicatorsByKnowledge.get(indicator.knowledgeId).push(indicator);
        });

        const includeUnselected = selection.includeUnselected === true;
        const current = graph.nodes.knowledge.filter(item =>
            item.level === level && modules.has(item.module) && areas.has(item.area) && (includeUnselected || conceptIds.has(item.projectionConceptId))
        );
        const items = current.map(knowledge => {
            const indicators = Object.freeze([...(indicatorsByKnowledge.get(knowledge.id) || [])]);
            const rda = rdaById.get(PIARdaContributionCatalog.rdaId(knowledge.cycle, knowledge.area)) || null;
            const correspondence = correspondenceFor(graph, indicators.map(item => item.id), rda?.id || '');
            return Object.freeze({
                id: knowledge.id,
                family: familyById.get(knowledge.familyId) || null,
                area: knowledge.area,
                rda,
                selected: conceptIds.has(knowledge.projectionConceptId),
                before: nearestFamilyLevel(graph, knowledge.familyId, level, -1),
                now: Object.freeze({ ...knowledge, indicators }),
                after: nearestFamilyLevel(graph, knowledge.familyId, level, 1),
                cycles: Object.freeze(cycleRoutes(graph, familyById.get(knowledge.familyId) || null, knowledge.area, knowledge, indicatorsByKnowledge)),
                structuralRelation: rda?.applicable ? 'within-cycle-area-rda-scope' : 'not-applicable',
                pedagogicalCorrespondence: correspondence
            });
        });
        return Object.freeze({
            status: items.length ? 'ready' : 'empty-selection',
            level,
            cycle: graph.cycleByLevel[level] || '',
            preschoolTrack: level === '0°' ? graph.preschoolTrack : '',
            items: Object.freeze(items),
            readOnly: true,
            currentCurriculumScope: 'AHORA',
            referenceScopes: Object.freeze(['ANTES', 'DESPUÉS'])
        });
    }

    return Object.freeze({ CYCLE_ORDER, audit, buildRoute });
})();
// PIA_RDA_ROUTE_SERVICE_END
