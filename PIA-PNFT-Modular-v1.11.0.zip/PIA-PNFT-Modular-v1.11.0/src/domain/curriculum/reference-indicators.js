        // PIA_REFERENCE_INDICATORS_JS_START
        const PIAReferenceCurriculum = (() => {
            const clone = value => JSON.parse(JSON.stringify(value));
            const uid = () => `ref-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
            function levels(data = PNFT_DATA) { return Object.keys(data || {}).filter(level => /^\d+°$/.test(level)); }
            function modules(level, data = PNFT_DATA) { return Object.keys(data?.[level] || {}); }
            function areas(level, moduleName, data = PNFT_DATA) { return Object.keys(data?.[level]?.[moduleName] || {}); }
            function concepts(level, moduleName, area, data = PNFT_DATA) { return clone(data?.[level]?.[moduleName]?.[area]?.saberes || []); }
            function normalize(item) {
                if (!item || typeof item !== 'object') return null;
                const officialText = String(item.officialText || '').trim();
                if (!officialText) return null;
                return {
                    id:String(item.id || uid()), sourceLevel:String(item.sourceLevel || ''), module:String(item.module || ''),
                    area:String(item.area || ''), concept:String(item.concept || ''), officialText,
                    reason:String(item.reason || ''), contextualization:String(item.contextualization || '')
                };
            }
            function normalizeList(items) { return (Array.isArray(items) ? items : []).map(normalize).filter(Boolean); }
            function selectedForWeek(week, references) {
                const ids = new Set(Array.isArray(week?.referenceIndicatorIds) ? week.referenceIndicatorIds : []);
                return normalizeList(references).filter(item => ids.has(item.id));
            }
            function exportForWeek(week, references) {
                return selectedForWeek(week, references).map(item => ({
                    ...item,
                    text:`[Referencia PNFT · ${item.sourceLevel} · ${item.module} · ${item.area}] ${item.officialText}${item.contextualization ? `\nContextualización docente: ${item.contextualization}` : ''}`
                }));
            }
            function promptBlock(references) {
                const items = normalizeList(references);
                if (!items.length) return '';
                return `\n\nINDICADORES DE REFERENCIA AUTORIZADOS DEL CURRÍCULO DEL PNFT\n${items.map((item,index)=>`${index+1}. Procedencia: ${item.sourceLevel} · ${item.module} · ${item.area} · ${item.concept}\n   Indicador (copiar literalmente): ${item.officialText}\n   Razón pedagógica: ${item.reason || 'Pendiente de justificar por la persona docente'}\n   Contextualización docente: ${item.contextualization || 'Pendiente'}`).join('\n')}\n\nEstos indicadores son referencias de otro nivel del currículo del PNFT. No los presente como indicadores oficiales del nivel administrativo actual, no cambie su procedencia, no infiera por sí sola una adecuación curricular significativa y no sustituya los indicadores del nivel actual. Úselos únicamente cuando la persona docente los haya incorporado y conserve por separado el texto literal y la contextualización.`;
            }
            return Object.freeze({levels,modules,areas,concepts,normalize,normalizeList,selectedForWeek,exportForWeek,promptBlock});
        })();
        // PIA_REFERENCE_INDICATORS_JS_END
