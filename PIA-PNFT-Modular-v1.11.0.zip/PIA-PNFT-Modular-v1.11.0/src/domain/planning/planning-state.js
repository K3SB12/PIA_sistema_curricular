        // Variables globales - SOLO UNA DECLARACIÓN DE formatoExportacion
        let semanas = [];
        let saberesSeleccionados = new Set();
        let saberesProcedimentalesGlobales = new Set();
        let saberesActitudinalesGlobales = new Set();
        let formatoExportacion = 'pdf'; // ← Cambiado a PDF por defecto

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            inicializarSemanas();
            configurarEventListeners();
        });

