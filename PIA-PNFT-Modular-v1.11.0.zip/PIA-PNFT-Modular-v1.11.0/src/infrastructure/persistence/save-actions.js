        // ===== FUNCIONES PARA EL MENÚ DE GUARDADO =====
        function toggleMenuGuardar(event) {
            event.stopPropagation();
            const menu = document.getElementById('menuGuardar');
            menu.classList.toggle('abierto');
        }

        function ejecutarGuardarNormal() {
            // Cerrar menú
            document.getElementById('menuGuardar').classList.remove('abierto');
            
            // Ejecutar guardado normal
            const plan = obtenerDatosPlan();
            const dataStr = JSON.stringify(plan, null, 2);
            const dataBlob = new Blob([dataStr], {type: 'application/json'});
            
            const enlace = document.createElement('a');
            enlace.download = 'planeamiento-didáctico.json';
            enlace.href = URL.createObjectURL(dataBlob);
            enlace.click();
            
            setTimeout(() => URL.revokeObjectURL(enlace.href), 100);
            
            // Mostrar retroalimentación sutil
            mostrarMensaje('✅ Archivo .json guardado exitosamente');
        }

        function ejecutarGuardarOffline() {
            // Cerrar menú
            document.getElementById('menuGuardar').classList.remove('abierto');
            
            // Ejecutar guardado offline
            descargarVersionPortable();
        }

        // Cerrar menú si se hace clic fuera
        document.addEventListener('click', function(e) {
            const menu = document.getElementById('menuGuardar');
            const contenedor = document.querySelector('.guardar-container');
            
            if (menu && contenedor && !contenedor.contains(e.target)) {
                menu.classList.remove('abierto');
            }
        });

