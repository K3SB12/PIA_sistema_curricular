        function generarPromptCompleto() {
            const ciclo = document.getElementById('ciclo').value;
            const nivel = document.getElementById('nivel').value;
            
            if (!ciclo || !nivel) {
                alert('Por favor, seleccione ciclo y nivel');
                return;
            }

            // Obtener información de ejes y metodología
            const ejesSeleccionados = obtenerEjesTransversales();
            const metodologiaSeleccionada = obtenerMetodologiaActiva();

            // Obtener TODOS los indicadores de logro de todas las semanas
            let todosIndicadoresLogro = [];
            semanas.forEach((semana, index) => {
                const indicadoresSemana = obtenerIndicadoresLogroSemana(index + 1);
                todosIndicadoresLogro = todosIndicadoresLogro.concat(indicadoresSemana);
            });
            
            // Filtrar duplicados
            todosIndicadoresLogro = [...new Set(todosIndicadoresLogro)];
            
            let prompt = `CONTEXTO GENERAL:\n`;
            prompt += `• Curso lectivo: ${document.getElementById('cursoLectivo').value}\n`;
            prompt += `• Semestre: ${document.getElementById('semestre').value}\n`;
            prompt += `• Total de lecciones: ${document.getElementById('leccionesPlanificadas').value}\n`;
            prompt += `• Meses: ${document.getElementById('mesInicio').value} a ${document.getElementById('mesFinal').value}\n`;
            prompt += `• Total de semanas: ${semanas.length}\n\n`;

            // EJES Y METODOLOGÍA
            prompt += `• Eje(s) transversal(es): ${ejesSeleccionados.length > 0 ? ejesSeleccionados.join(', ') : 'No seleccionado'}\n`;
            prompt += `• Metodología activa: ${metodologiaSeleccionada}\n\n`;

            // RESUMEN POR SEMANAS
            prompt += `RESUMEN POR SEMANAS:\n`;
            semanas.forEach((semana, index) => {
                prompt += `SEMANA ${index + 1} (${semana.lecciones}):\n`;
                const project = typeof PIAProjectComponentCatalog !== 'undefined' ? PIAProjectComponentCatalog.normalizeWeekProject(semana.project) : null;
                const phase = project?.phaseId ? PIAProjectComponentCatalog.getPhase(project.phaseId) : null;
                const record = phase ? project.records?.[phase.id] : null;
                const projectIndicator = record?.achievementIndicators?.[0];
                prompt += `• Modalidad semanal: ${{curricular:'curricular (80 minutos)',mixed:'mixta (40 minutos currículo + 40 minutos Proyecto)',integrated:'integrada mediante el Proyecto (80 minutos)'}[project?.mode] || 'curricular (80 minutos)'}\n`;
                if(project?.mode && project.mode!=='curricular') prompt += `• Proyecto: ${PIAProjectComponentCatalog.getStage(project.stageId)?.name || 'Pendiente'} → ${phase?.name || 'Pendiente'} | ${projectIndicator?.sourceType==='teacher-authored'?'indicador editable aportado por la persona docente (no oficial)':'indicador oficial'}: ${projectIndicator?.teacherText || projectIndicator?.officialText || 'Pendiente'}\n`;
                prompt += `• Áreas: ${semana.areas.join(', ') || 'No seleccionadas'}\n`;
                
                // ✅ SABERES CONCEPTUALES GLOBALES
                prompt += `• Saberes conceptuales: `;
                if (semana.saberes.length > 0) {
                    prompt += semana.saberes.join(', ');
                } else {
                    prompt += 'No seleccionados';
                }
                prompt += `\n`;
                
                // ✅ SABERES PROCEDIMENTALES GLOBALES
                prompt += `• Saberes procedimentales: `;
                if (semana.procedimentales.length > 0) {
                    const procMap = {
                        'reconoce': 'Reconoce patrones',
                        'abstrae': 'Abstrae',
                        'generaliza': 'Generaliza',
                        'transfiere': 'Transfiere',
                        'modulariza': 'Modulariza',
                        'formula': 'Formula algoritmos',
                        'remezcla': 'Remezcla',
                        'depura': 'Depura',
                        'programa': 'Programa',
                        'comunica': 'Comunica',
                        'colabora': 'Colabora',
                        'piensa': 'Piensa creativamente',
                        'maneja': 'Maneja tecnologías éticamente'
                    };
                    const procNombres = semana.procedimentales.map(p => procMap[p] || p);
                    prompt += procNombres.join(', ');
                } else {
                    prompt += 'No seleccionados';
                }
                prompt += `\n`;
                
                // ✅ SABERES ACTITUDINALES GLOBALES
                prompt += `• Saberes actitudinales: `;
                if (semana.actitudinales.length > 0) {
                    const actMap = {
                        'gusto': 'Gusto por la precisión',
                        'aprender': 'Aprender del error',
                        'flexibilidad': 'Flexibilidad',
                        'tolerancia': 'Tolerancia a la frustración'
                    };
                    const actNombres = semana.actitudinales.map(a => actMap[a] || a);
                    prompt += actNombres.join(', ');
                } else {
                    prompt += 'No seleccionados';
                }
                prompt += `\n`;
                
                // ✅ INDICADORES DE LOGRO
                prompt += `• Indicadores de logro: `;
                const indicadoresSemana = obtenerIndicadoresLogroSemana(index + 1);
                if (indicadoresSemana.length > 0) {
                    prompt += indicadoresSemana.join(' | ');
                } else {
                    prompt += 'No seleccionados';
                }
                prompt += `\n`;
            });
            prompt += `\n`;

            // INDICADORES DE LOGRO GLOBALES
            prompt += `🎯 INDICADORES DE LOGRO GLOBALES (Todas las semanas):\n`;
            prompt += `Total de indicadores únicos: ${todosIndicadoresLogro.length}\n\n`;
            
            if (todosIndicadoresLogro.length > 0) {
                prompt += `Indicadores de logro que eligió en las semanas:\n`;
                todosIndicadoresLogro.forEach((indicador, index) => {
                    prompt += `${index + 1}. ${indicador}\n`;
                });
                prompt += `\n`;
            }

            // SABERES CONCEPTUALES GLOBALES
            prompt += `📚 SABERES CONCEPTUALES GLOBALES (Todas las semanas):\n`;
            if (saberesSeleccionados.size > 0) {
                Array.from(saberesSeleccionados).forEach(saber => {
                    prompt += `• ${saber}\n`;
                });
            } else {
                prompt += `No se han seleccionado saberes conceptuales\n`;
            }
            prompt += `\n`;

            // SOLICITUD
            
            prompt += `🤖 Sugerencia: Para mejores resultados entre más específico y detallado sea cada campo, mejor será la calidad del prompt generado. Puedes editar el prompt antes de compartirlo con tu herramienta de IA favorita.\n\n`;
            prompt += `• Define la acción principal que deseas que se realice, ¿Qué acción debe realizar la IA? Ejemplo: Crear una actividad interactiva, Diseñar una rúbrica: \n\n`;
            prompt += `• Describe el entorno educativo y temático, ¿En qué áreas de conocimiento o situación? Ejemplo: Apropiación Tecnológica y Digital, Programación y Algoritmos, temas Computadora, Entornos de programación: \n\n`;
            prompt += `• Especifica el público objetivo y sus características: \n\n`;
            prompt += `• Añade requisitos específicos, formato y restricciones por ejemplo ¿Qué especificaciones adicionales? Ejemplo: Trabajo colaborativo, recursos digitales, semanas de duración, incluir evaluación formativa o sumativa:  \n\n`;
            prompt += `• Define el objetivo pedagógico que se busca lograr, ¿Cuál es el objetivo de aprendizaje? Ejemplo: Desarrollar pensamiento crítico, fortalecer comprensión lectora:  \n\n`;
            prompt += `• Distribuye los indicadores de logro por la cantidad de semanas y lecciones del ciclo, nivel y Módulo seleccionado, en una tabla que incluya: semana, fecha aproximada, lección, saber conceptual, Metodología y el indicador de evaluación sugerido. Mostrando claridad y organización.\n`;
            prompt += `• Sugiera estrategias transversales aplicables que integren el/los eje(s) transversal(es) seleccionado(s).\n`;
            prompt += `• Aplique la metodología ${metodologiaSeleccionada || 'Pendiente'} en las propuestas de actividades.\n`;
            prompt += `• Redacta para cada semana estrategias de mediación que se integren con la estructura de inicio, desarrollo y cierre articulando los saberes conceptuales, procedimentales, actitudinales e indicadores seleccionados mediante una progresión y secuencialidad coherente.\n`;
            prompt += `• Evidenciar los saberes procedimentales y fortalezcan los saberes actitudinales.\n`;
            prompt += `• A partir de cada indicador de logro seleccionado, redactar dos propuestas distintas de indicador de evaluación en tercera persona singular.
                        -Cada propuesta debe incluir un verbo observable y medible, mantener coherencia directa con el indicador de logro y no agregar contenidos nuevos.
                        -No debe limitarse a una simple transformación verbal.
                        -Redactar en una sola oración clara y objetiva.\n\n`;

            prompt += `📝 Nota para el docente:
                
                Las dos propuestas generadas tienen como finalidad facilitar el análisis y la comparación técnica. Revise ambas opciones y seleccione aquella que sea más clara, observable, medible y que se ajuste a su contexto.\n\n`;

            // INSTRUMENTO SUGERIDO
            prompt += `• Instrumento sugerido según el reglamento de evaluación del MEP: indique por qué corresponde a la evidencia, requisitos de construcción, momento y tiempo de aplicación, comunicación y devolución/realimentación. No invente plazos, cantidades ni porcentajes; marque lo que requiera confirmación institucional.\n\n`;
            prompt += `CONTRATO OBLIGATORIO PARA LA IA:\n`;
            prompt += `1. Copie cada indicador de logro oficial completo y literalmente; queda prohibido resumirlo, acortarlo, parafrasearlo, combinarlo o corregirlo.\n`;
            prompt += `2. Priorice integrar saberes por afinidad y pertinencia. Si trabaja uno solo, rotule “tratamiento individual justificado” y explique una razón pedagógica de peso.\n`;
            prompt += `3. En cada semana identifique los saberes procedimentales y actitudinales utilizados y explique cómo se evidencian.\n`;
            prompt += `4. Desarrolle inicio, desarrollo y cierre con consignas, acciones del estudiantado, acompañamiento docente, recursos, evidencia, DUA, realimentación y continuidad; no entregue actividades escuetas.\n`;
            prompt += `5. No invente currículo, reglas del MEP, porcentajes, cantidades ni plazos. Diferencie siempre texto oficial de sugerencias editables.\n`;
            prompt += `6. Diseñe primero actividades y evidencias; luego recomiende los instrumentos pertinentes, explicando propósito, función, justificación, construcción, aplicación, comunicación y realimentación.\n`;
            prompt += `7. Cuando una semana sea mixta o integrada mediante Proyecto, articule ambos procesos en una sola estrategia y conserve completos los indicadores oficiales curriculares y del Proyecto.\n`;
            
            document.getElementById('promptText').value = prompt;
            document.getElementById('promptModal').style.display = 'block';
        }

        function cerrarPromptModal() {
            document.getElementById('promptModal').style.display = 'none';
        }

        function copiarPrompt() {
            const promptText = document.getElementById('promptText');
            promptText.select();
            document.execCommand('copy');
            alert('Prompt copiado al portapapeles');
        }

        function abrirEnCopilot() {
            const url = `https://copilot.microsoft.com/`;
            window.open(url, '_blank');
        }

        function abrirEnChatGPT() {
            const url = `https://chat.openai.com/`;
            window.open(url, '_blank');
        }

