        function cerrarPromptSemanaModal() {
            document.getElementById('promptSemanaModal').style.display = 'none';
        }

        function copiarPromptSemana() {
            const promptText = document.getElementById('promptSemanaText');
            promptText.select();
            document.execCommand('copy');
            alert('Prompt de semana copiado al portapapeles');
        }

        // ✅ FUNCIÓN DEPURADA PARA PROMPT POR SEMANA
        function generarPromptSemana(numeroSemana) {
            // El contrato exige mediaciones desarrolladas, evita actividades escuetas y protege los indicadores de logro oficiales y los saberes procedimentales y actitudinales.
            const semana = semanas[numeroSemana - 1];
            const ciclo = document.getElementById('ciclo').value;
            const nivel = document.getElementById('nivel').value;
            if (!ciclo || !nivel) { alert('⚠️ Seleccione primero el ciclo y el nivel.'); return; }
            if (!semana || !semana.areas.length) { alert('⚠️ Seleccione al menos un área de conocimiento para esta semana.'); return; }

            const ejes = obtenerEjesTransversales();
            const metodologia = obtenerMetodologiaActiva();
            const indicadores = obtenerIndicadoresLogroSemana(numeroSemana);
            const procedimentales = (semana.procedimentales || []).map(value => ({reconoce:'Reconoce patrones',abstrae:'Abstrae',generaliza:'Generaliza',transfiere:'Transfiere',modulariza:'Modulariza',formula:'Formula algoritmos',remezcla:'Remezcla',depura:'Depura',programa:'Programa',comunica:'Comunica',colabora:'Colabora',piensa:'Piensa de forma creativa',maneja:'Maneja las tecnologías de forma ética y segura'})[value] || value);
            const actitudinales = (semana.actitudinales || []).map(value => ({gusto:'Gusto por la precisión',aprender:'Aprender del error',flexibilidad:'Flexibilidad para manejar problemas',tolerancia:'Tolerancia a la frustración'})[value] || value);
            const textoPlano = html => { const node=document.createElement('div');node.innerHTML=html||'';return node.innerText.trim(); };
            const mediacionActual=textoPlano(semana.actividades),evaluacionActual=textoPlano(semana.evaluacion);
            const project = typeof PIAProjectComponentCatalog !== 'undefined' ? PIAProjectComponentCatalog.normalizeWeekProject(semana.project) : null;
            const phase = project?.phaseId ? PIAProjectComponentCatalog.getPhase(project.phaseId) : null;
            const exportProject = typeof PIAEnhancements !== 'undefined' ? PIAEnhancements.projectExportForWeek(semana) : {active:false,achievement:[],evaluation:[]};
            const modeLabels={curricular:'Curricular · 80 minutos',mixed:'Mixta · 40 minutos currículo + 40 minutos Proyecto',integrated:'Integrada mediante el Proyecto · 80 minutos'};
            const isDiagnosis=String(semana.fase||'').startsWith('diagnóstico');
            const isPreschool=nivel==='0°'||ciclo==='Materno Infantil/Transición';
            const projectBlock=exportProject.active?`\nCOMPONENTE PROYECTO EN ESTA SEMANA\n• Modo: ${modeLabels[project.mode]||modeLabels.curricular}\n• Etapa y fase: ${PIAProjectComponentCatalog.getStage(project.stageId)?.name||'Por revisar'} → ${phase?.name||'Por revisar'}\n• Indicador(es) incorporado(s):\n${exportProject.achievement.map(item=>`  - ${item.text}`).join('\n')||'  - No incorporado'}\n• Indicadores de evaluación editables:\n${exportProject.evaluation.map(item=>`  - ${item.text}`).join('\n')||'  - Por proponer y validar'}\nArticule currículo y Proyecto en una sola estrategia; no cree un segundo planeamiento ni contabilice dos veces una evidencia.`:'';
            const diagnosisBlock=isDiagnosis?`\nCONTRATO DIAGNÓSTICO\nEsta semana recoge información para orientar decisiones, no asigna una calificación. Diseñe evidencias pertinentes de las dimensiones cognitiva, socioemocional y psicomotriz sin forzarlas cuando no sean observables. Incluya cómo sistematizar, analizar, decidir y comunicar los hallazgos. No emita diagnósticos clínicos ni etiquete al estudiantado.`:'';

            const prompt=`AFINAR SEMANA ${numeroSemana} DEL PLANEAMIENTO DE FORMACIÓN TECNOLÓGICA\n\nPROPÓSITO\nRevise y fortalezca la semana ya proyectada. Conserve las decisiones curriculares y metodológicas aportadas. No reconstruya el semestre ni cambie silenciosamente su metodología. Si detecta una necesidad de cambio, explíquela como sugerencia separada para validación docente y mantenga también una versión coherente con la metodología original.\n\nDATOS DE LA SEMANA\n• Nivel y ciclo: ${nivel} — ${ciclo}\n• Lecciones: ${semana.lecciones}\n• Fase registrada: ${semana.fase||'No indicada'}\n• Metodología semestral: ${metodologia}\n• Ejes seleccionados: ${ejes.length?ejes.join(', '):'No aportados; no los invente'}\n• Áreas: ${semana.areas.join(', ')}\n• Saberes conceptuales: ${(semana.saberes||[]).join(' | ')||'No seleccionados'}\n• Indicadores de logro del PNFT — COPIAR COMPLETOS Y LITERALES:\n${indicadores.map(text=>`  - ${text}`).join('\n')||'  - No seleccionados; no invente indicadores'}\n• Saberes procedimentales: ${procedimentales.join(' | ')||'No seleccionados'}\n• Saberes actitudinales: ${actitudinales.join(' | ')||'No seleccionados'}\n${projectBlock}${diagnosisBlock}\n\nTEXTO ACTUAL PARA AFINAR\n• Estrategia de mediación: ${mediacionActual||'Pendiente de redacción'}\n• Indicadores de evaluación: ${evaluacionActual||'Pendientes de redacción'}\n\nTAREA PARA LA IA\n1. Evalúe la coherencia de la semana con los RdA, saberes e indicadores aportados, sin inventar ni acortar currículo del PNFT.\n2. Entregue una versión mejorada de la estrategia con inicio, desarrollo y cierre; detalle consignas, acciones del estudiantado, preguntas y acompañamiento docente, recursos, tiempos dentro del bloque, evidencia, realimentación y enlace con la semana siguiente. ${isPreschool?'En Preescolar organice una experiencia lúdica, breve y completa que puede iniciar y cerrar esta semana, con continuidad curricular hacia la siguiente.':'Mantenga la metodología como andamiaje continuo y no reinicie mecánicamente sus fases.'}\n3. Muestre cómo se moviliza cada saber conceptual, procedimental y actitudinal. Integre saberes cuando exista afinidad; si uno requiere trabajo individual, escriba “tratamiento individual justificado” y explique la razón.\n4. Mantenga al estudiantado en el centro mediante acciones como explorar, analizar, crear, programar, probar, argumentar, colaborar, tomar decisiones y reflexionar.\n5. Proponga apoyos DUA y una alternativa desconectada solo cuando sean pertinentes a las condiciones declaradas. No reduzca la intención de aprendizaje.\n6. Diseñe primero la actividad y su evidencia; después proponga dos indicadores de evaluación observables y medibles por cada indicador de logro, claramente rotulados como sugerencias editables, y recomiende uno o varios instrumentos pertinentes con su justificación, aplicación y realimentación. ${isPreschool?'Use únicamente función diagnóstica o formativa; no proponga porcentajes ni evaluación sumativa.':'No invente porcentajes, cantidades ni plazos.'}\n7. Señale aparte cualquier supuesto, dato faltante o decisión que requiera criterio docente o validación institucional.\n\nDEVUELVA EXACTAMENTE\nA) Revisión breve de coherencia; B) Estrategia de mediación afinada; C) Evidencias y manifestación de saberes; D) Indicadores e instrumentos de evaluación sugeridos; E) Apoyos y alternativa desconectada pertinentes; F) Decisiones pendientes de validación docente.`;
            const editor=document.getElementById('promptSemanaText');editor.value=prompt;document.getElementById('promptSemanaModal').style.display='block';
        }
