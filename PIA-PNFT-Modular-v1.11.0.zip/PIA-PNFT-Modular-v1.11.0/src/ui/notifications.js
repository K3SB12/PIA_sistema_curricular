        // Función para mostrar mensajes temporales
        function mostrarMensaje(texto, esError = false) {
            // Eliminar mensaje anterior si existe
            const mensajeAnterior = document.querySelector('.mensaje-temporal');
            if (mensajeAnterior) {
                mensajeAnterior.remove();
            }
            
            // Crear nuevo mensaje
            const mensaje = document.createElement('div');
            mensaje.className = 'mensaje-temporal';
            mensaje.style.background = esError ? 'var(--danger-color)' : 'var(--success-color)';
            mensaje.style.color = 'white';
            mensaje.style.padding = '12px 20px';
            mensaje.style.borderRadius = '6px';
            mensaje.style.position = 'fixed';
            mensaje.style.bottom = '20px';
            mensaje.style.right = '20px';
            mensaje.style.zIndex = '10000';
            mensaje.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
            mensaje.style.display = 'flex';
            mensaje.style.alignItems = 'center';
            mensaje.style.gap = '10px';
            mensaje.style.fontSize = '14px';
            mensaje.style.maxWidth = '400px';
            mensaje.style.wordWrap = 'break-word';
            mensaje.style.animation = 'slideIn 0.3s ease';
            
            mensaje.innerHTML = `
                ${esError ? '❌' : '✅'} 
                <span>${texto}</span>
            `;
            
            document.body.appendChild(mensaje);
            
            // Eliminar automáticamente después de 4 segundos
            setTimeout(() => {
                if (mensaje.parentNode) {
                    mensaje.style.animation = 'fadeOut 0.3s ease';
                    setTimeout(() => {
                        if (mensaje.parentNode) mensaje.remove();
                    }, 300);
                }
            }, 4000);
        }

