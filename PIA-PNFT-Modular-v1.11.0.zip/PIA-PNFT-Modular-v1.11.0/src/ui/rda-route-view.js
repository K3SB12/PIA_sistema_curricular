// PIA_RDA_ROUTE_VIEW_START
const PIARdaRouteView = (() => {
    const AREA_COLORS = Object.freeze({
        'Apropiación tecnológica y Digital': '#173d82',
        'Ciencia de datos e Inteligencia artificial': '#75a94e',
        'Computación física y Robótica': '#159b99',
        'Programación y Algoritmos': '#54259c'
    });
    const STATE_LABELS = Object.freeze({
        'explicit-evaluable': 'Desarrollo curricular con indicador',
        'conceptual-non-evaluable': 'Presencia conceptual sin indicador directo',
        'reinforced-non-evaluable': 'Fortalecimiento sin evaluación directa',
        'no-curricular-record': 'Sin abordaje conceptual registrado',
        'not-applicable': 'No aplica en este nivel',
        'area-absent': 'Área no presente en esta combinación'
    });
    const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[character]));
    const checkedValues = name => typeof document === 'undefined' ? [] : [...document.querySelectorAll(`input[name="${name}"]:checked`)].map(input => input.value);

    function sourceLine(record) {
        if (record?.level === '0°' && record.sourceItineraryLabel) return `Guía docente FT-Preescolar · ${record.sourceItineraryLabel}`;
        if (['1°', '2°', '3°', '4°', '5°', '6°'].includes(record?.level)) return `Guía docente FT-Primaria · ${record.level} · ${record.module} · ${record.area}`;
        return `Guía docente FT-Secundaria III C · ${record?.level || ''} · ${record?.module || ''} · ${record?.area || ''}`;
    }

    function levelCard(milestone) {
        const records = milestone.records || [];
        const explicit = milestone.status === 'explicit-evaluable';
        const state = STATE_LABELS[milestone.status] || milestone.status;
        const recordsHtml = records.map(record => `<article>
            <strong>${escapeHtml(record.module)} · ${escapeHtml(record.name)}</strong>
            ${record.indicators.length ? `<ul>${record.indicators.map(indicator => `<li>${escapeHtml(indicator.text)}</li>`).join('')}</ul>` : '<p>La fuente no incorpora un indicador directo.</p>'}
            <small class="pia-rda-source">Fuente: ${escapeHtml(sourceLine(record))}</small>
        </article>`).join('');
        const emptyMeaning = milestone.status === 'area-absent'
            ? 'El área no forma parte de esta combinación. Su ausencia no constituye pendiente ni rezago.'
            : milestone.status === 'not-applicable'
                ? 'El saber o el área no corresponde a este nivel según la fuente.'
                : milestone.status === 'reinforced-non-evaluable'
                    ? 'La fuente declara fortalecimiento dentro del proceso; no se crea un indicador oficial.'
                    : milestone.status === 'conceptual-non-evaluable'
                        ? 'La fuente registra presencia conceptual; no se crea un indicador oficial.'
                        : 'La fuente no registra abordaje conceptual en este nivel. PIA no interpreta el vacío como fortalecimiento.';
        return `<section class="pia-rda-level ${milestone.current ? 'is-current' : ''}">
            <h6>${escapeHtml(milestone.level)}${milestone.current ? ' · AHORA' : ''}</h6>
            <span class="pia-rda-state ${explicit ? 'is-explicit' : ''}">${escapeHtml(state)}</span>
            ${recordsHtml || `<p>${escapeHtml(emptyMeaning)}</p>`}
            ${milestone.scope && !recordsHtml ? `<details><summary>Ver alcance de la matriz</summary><p>${escapeHtml(milestone.scope)}</p></details>` : ''}
        </section>`;
    }

    function cycleCard(cycle, item) {
        const correspondence = item.pedagogicalCorrespondence.status === 'validated';
        const relationHtml = cycle.current ? `<div class="pia-rda-status">
            <div><strong>Vínculo estructural</strong><span>${cycle.applicable ? 'Verificado por nivel, ciclo y área. No constituye por sí solo una correspondencia pedagógica.' : 'No se construye una relación activa porque el RdA indica que no aplica.'}</span></div>
            <div><strong>Correspondencia pedagógica</strong><span>${correspondence ? 'Validada mediante una relación documental aprobada.' : 'Pendiente de validación curricular. PIA no completa esta relación mediante inferencias.'}</span></div>
        </div>` : '';
        const routeHtml = cycle.applicable
            ? `<div class="pia-rda-levels">${cycle.milestones.map(levelCard).join('')}</div>`
            : '<p class="pia-rda-empty">Este ciclo no genera una ruta de aporte para el área. No existe deuda ni alerta curricular.</p>';
        return `<details class="pia-rda-cycle" ${cycle.current ? 'open' : ''}>
            <summary>${escapeHtml(cycle.cycle)}${cycle.current ? ' · ciclo actual' : ' · referencia curricular'}</summary>
            <div class="pia-rda-cycle-body">
                <p class="pia-rda-official"><strong>RdA oficial:</strong><br>${escapeHtml(cycle.rda?.text || 'No existe un RdA registrado para esta área y ciclo.')}</p>
                ${relationHtml}${routeHtml}
                ${!cycle.current ? '<p class="pia-rda-source">Los niveles de este ciclo son referentes de trayectoria. No se incorporan desde esta vista al planeamiento actual.</p>' : ''}
            </div>
        </details>`;
    }

    function familyCard(item, index) {
        const color = AREA_COLORS[item.area] || '#173d82';
        const validated = item.pedagogicalCorrespondence.status === 'validated';
        return `<details class="pia-rda-family" data-pia-rda-card data-area="${escapeHtml(item.area)}" data-selected="${item.selected ? 'true' : 'false'}" style="--rda-color:${color}" ${index === 0 ? 'open' : ''}>
            <summary><span><strong>${escapeHtml(item.family?.label || 'Familia curricular por resolver')}</strong><small>${escapeHtml(item.area)} · ${escapeHtml(item.now.module)} · ${escapeHtml(item.now.name)}</small></span><span class="pia-rda-review-badge ${validated ? 'is-validated' : ''}">${validated ? 'Relación validada' : 'Pendiente de validación'}</span></summary>
            <div class="pia-rda-cycle-list">${item.cycles.map(cycle => cycleCard(cycle, item)).join('')}</div>
        </details>`;
    }

    function render(route) {
        if (!route || route.status !== 'ready') {
            return '<div class="pia-banner pia-warning"><strong>Complete la selección actual.</strong> Seleccione ciclo, nivel, módulo, área y al menos un saber conceptual para consultar la Ruta hacia el RdA.</div>';
        }
        const areas = [...new Set(route.items.map(item => item.area))];
        const selectedCount = route.items.filter(item => item.selected).length;
        const itinerary = route.level === '0°'
            ? `<div><dt>Itinerario activo</dt><dd>${escapeHtml(route.preschoolTrack === 'basic-required' ? 'Básico requerido' : 'Óptimo')}</dd></div>`
            : '';
        const areaFilters = [`<button type="button" class="pia-rda-filter" data-pia-rda-area="all" aria-pressed="true" style="--rda-color:#173d82">Todas las áreas</button>`, ...areas.map(area => `<button type="button" class="pia-rda-filter" data-pia-rda-area="${escapeHtml(area)}" aria-pressed="false" style="--rda-color:${AREA_COLORS[area] || '#173d82'}">${escapeHtml(area)}</button>`)].join('');
        return `<div class="pia-rda-shell">
            <div class="pia-rda-intro"><div class="pia-rda-intro-mark" aria-hidden="true">RdA</div><div><h4>Ruta hacia el RdA</h4><p>Trayectoria curricular de Preescolar a 9.º por familias, niveles, ciclos y áreas. Es una referencia de solo lectura.</p></div></div>
            <div class="pia-rda-boundary"><strong>Límite profesional:</strong> planificar y cubrir no equivale a demostrar aprendizaje. El RdA se valora mediante evidencias acumuladas y criterio profesional docente al cierre del ciclo.</div>
            <dl class="pia-rda-summary"><div><dt>Ciclo y nivel actual</dt><dd>${escapeHtml(route.cycle)} · ${escapeHtml(route.level)}</dd></div>${itinerary}<div><dt>Saberes seleccionados</dt><dd>${selectedCount}</dd></div><div><dt>Uso</dt><dd>Consulta local; no modifica el plan</dd></div></dl>
            <div class="pia-rda-filters" aria-label="Alcance de la consulta"><button type="button" class="pia-rda-filter" data-pia-rda-scope="selected" aria-pressed="true">Solo saberes incorporados en la proyección</button><button type="button" class="pia-rda-filter" data-pia-rda-scope="all" aria-pressed="false">Todos los saberes del módulo</button></div>
            <div class="pia-rda-filters" aria-label="Áreas de conocimiento">${areaFilters}</div>
            <div data-pia-rda-results>${route.items.map(familyCard).join('')}</div>
            <p class="pia-rda-empty" data-pia-rda-empty hidden>No existen registros para los filtros seleccionados.</p>
            <div class="pia-rda-boundary"><strong>Lectura responsable:</strong> el vínculo estructural ubica el indicador dentro del área y ciclo. Una correspondencia pedagógica específica solo puede presentarse como validada cuando exista fuente y aprobación curricular expresa. PIA no afirma dominio, promoción ni cumplimiento del RdA.</div>
            <div class="pia-actions"><button type="button" class="btn btn-secondary" id="piaRdaClose">Volver al planeamiento</button></div>
        </div>`;
    }

    function currentSelection() {
        return {
            level: document.getElementById('nivel')?.value || '',
            modules: checkedValues('piaModule'),
            areas: checkedValues('piaArea'),
            conceptIds: checkedValues('piaConcept'),
            preschoolTrack: document.getElementById('piaPreschoolTrack')?.value || 'optimal',
            includeUnselected: true
        };
    }

    function applyFilters(root) {
        const area = root.querySelector('[data-pia-rda-area][aria-pressed="true"]')?.dataset.piaRdaArea || 'all';
        const scope = root.querySelector('[data-pia-rda-scope][aria-pressed="true"]')?.dataset.piaRdaScope || 'selected';
        const cards = [...root.querySelectorAll('[data-pia-rda-card]')];
        cards.forEach(card => card.hidden = !((area === 'all' || card.dataset.area === area) && (scope === 'all' || card.dataset.selected === 'true')));
        const empty = root.querySelector('[data-pia-rda-empty]');
        if (empty) empty.hidden = cards.some(card => !card.hidden);
    }

    function close() {
        const modal = document.getElementById('piaAdvancedModal');
        modal?.classList.remove('open');
        modal?.querySelector('.pia-modal-panel')?.classList.remove('pia-trajectory-modal');
        document.getElementById('piaRdaRoute')?.focus();
    }

    function open() {
        if (typeof document === 'undefined') return null;
        const selection = currentSelection();
        const graph = PIARdaContributionCatalog.build({ preschoolTrack: selection.preschoolTrack });
        const route = PIARdaRouteService.buildRoute(graph, selection);
        const modal = document.getElementById('piaAdvancedModal');
        const title = document.getElementById('piaAdvancedTitle');
        const body = document.getElementById('piaAdvancedBody');
        if (!modal || !title || !body) return route;
        title.textContent = 'Ruta hacia el RdA';
        body.innerHTML = render(route);
        modal.querySelector('.pia-modal-panel')?.classList.add('pia-trajectory-modal');
        modal.classList.add('open');
        body.querySelector('#piaRdaClose')?.addEventListener('click', close);
        body.addEventListener('click', event => {
            const filter = event.target.closest?.('[data-pia-rda-area],[data-pia-rda-scope]');
            if (!filter) return;
            const selector = filter.hasAttribute('data-pia-rda-area') ? '[data-pia-rda-area]' : '[data-pia-rda-scope]';
            body.querySelectorAll(selector).forEach(button => button.setAttribute('aria-pressed', String(button === filter)));
            applyFilters(body);
        });
        applyFilters(body);
        document.getElementById('piaAdvancedClose')?.focus();
        return route;
    }

    function init(root = typeof document !== 'undefined' ? document : null) {
        const button = root?.querySelector?.('#piaRdaRoute');
        if (!button || button.dataset.piaRdaRouteBound === 'true') return false;
        button.dataset.piaRdaRouteBound = 'true';
        button.addEventListener('click', open);
        return true;
    }

    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => init(), { once: true });
        else init();
    }

    return Object.freeze({ render, currentSelection, applyFilters, open, close, init });
})();
// PIA_RDA_ROUTE_VIEW_END
