        // PIA_WEEK_FORMAT_HELPER_START
        function generarBarraFormatoSemana(numero) {
            return `<div class="pia-week-format-toolbar" data-pia-format-toolbar="${numero}" role="toolbar" aria-label="Formato de la semana ${numero}" hidden>
                <span class="pia-format-target" data-pia-format-target aria-live="polite">Seleccione texto en Mediación o Evaluación</span>
                <div class="pia-format-primary-actions">
                    <button type="button" data-pia-field-action="undo" title="Deshacer en este campo" aria-label="Deshacer en este campo">↶</button>
                    <button type="button" data-pia-field-action="redo" title="Rehacer en este campo" aria-label="Rehacer en este campo">↷</button>
                    <button type="button" data-pia-format-command="bold" title="Negrita" aria-label="Negrita" aria-pressed="false"><strong>N</strong></button>
                    <button type="button" data-pia-format-command="underline" title="Subrayado" aria-label="Subrayado" aria-pressed="false"><u>S</u></button>
                    <button type="button" data-pia-format-command="insertUnorderedList" title="Lista con viñetas" aria-label="Lista con viñetas" aria-pressed="false">• Lista</button>
                    <button type="button" data-pia-format-command="removeFormat" title="Quitar formato solamente de la selección" aria-label="Quitar formato de la selección">Tx</button>
                </div>
                <details class="pia-format-more">
                    <summary>Más opciones</summary>
                    <div class="pia-format-more-panel">
                        <button type="button" data-pia-format-command="italic" aria-label="Cursiva" aria-pressed="false"><em>K</em></button>
                        <button type="button" data-pia-format-command="insertOrderedList" aria-label="Lista numerada" aria-pressed="false">1. Lista</button>
                        <button type="button" data-pia-format-command="indent" aria-label="Aumentar sangría">→|</button>
                        <button type="button" data-pia-format-command="outdent" aria-label="Disminuir sangría">|←</button>
                        <button type="button" data-pia-format-command="justifyLeft" aria-label="Alinear a la izquierda" aria-pressed="false">⬅</button>
                        <button type="button" data-pia-format-command="justifyCenter" aria-label="Centrar" aria-pressed="false">↔</button>
                        <button type="button" data-pia-format-command="justifyRight" aria-label="Alinear a la derecha" aria-pressed="false">➡</button>
                        <button type="button" data-pia-format-command="foreColor" data-value="#08235c" aria-label="Texto azul institucional">A</button>
                        <button type="button" data-pia-format-command="hiliteColor" data-value="#ffd861" aria-label="Resaltar en amarillo">▰</button>
                        <select data-pia-font-size aria-label="Tamaño de texto"><option value="">Tamaño</option><option value="2">Pequeño</option><option value="3">Normal</option><option value="4">Grande</option></select>
                        <button type="button" data-pia-format-preset="Inicio" title="Insertar subtítulo Inicio">+ Inicio</button>
                        <button type="button" data-pia-format-preset="Desarrollo" title="Insertar subtítulo Desarrollo">+ Desarrollo</button>
                        <button type="button" data-pia-format-preset="Cierre" title="Insertar subtítulo Cierre">+ Cierre</button>
                        <button type="button" data-pia-field-action="plain-paste" aria-pressed="false" title="Cuando está activo, pega solamente texto sin estilos externos">Pegado limpio</button>
                        <button type="button" data-pia-field-action="link" title="Insertar un vínculo HTTPS validado por la persona docente">Vínculo</button>
                        <button type="button" data-pia-field-action="clear" title="Conservar el texto y quitar el formato de todo el campo">Limpiar campo</button>
                    </div>
                </details>
                <button type="button" class="pia-format-close" data-pia-field-action="close" title="Ocultar formato" aria-label="Ocultar formato">×</button>
            </div>`;
        }
        // PIA_WEEK_FORMAT_HELPER_END

        function crearElementoSemana(numero, leccionInicio, leccionFin) {
            const semanaDiv = document.createElement('div');
            semanaDiv.className = 'semana-item';
            semanaDiv.id = `semana-${numero}`;
            const faseActual = semanas[numero - 1]?.fase || (numero === 1 ? 'diagnóstico' : 'desarrollo');
            const opcionesFase = ['diagnóstico', 'diagnóstico e inicio del módulo', 'desarrollo', 'integración', 'refuerzo', 'retroalimentación', 'evaluación o cierre'];
            
            semanaDiv.innerHTML = `
                <div class="semana-header">
                    <div>
                        <strong>Semana ${numero}</strong>
                    </div>
                    <div>
                        <input type="text" class="semana-nombre input-field" value="Lecciones ${leccionInicio} y ${leccionFin}" 
                               onchange="actualizarLeccionesSemana(${numero}, this.value)">
                        <span style="font-size: 10px; color: #666; margin-left: 6px;">(${leccionInicio}-${leccionFin})</span>
                    </div>
                    <label class="pia-week-phase">Momento
                        <select data-pia-week-phase="${numero}" aria-label="Momento pedagógico de la semana ${numero}">${opcionesFase.map(fase => `<option value="${fase}" ${fase === faseActual ? 'selected' : ''}>${fase}</option>`).join('')}</select>
                    </label>
                    <fieldset class="pia-week-module-filter">
                        <legend>Módulo</legend>
                        <div data-pia-week-modules="${numero}">${generarSelectorModulosSemana(numero)}</div>
                    </fieldset>
                    <button type="button" class="btn btn-outline pia-week-format-toggle" data-pia-format-toggle="${numero}" aria-expanded="false">✎ Formato</button>
                    <button type="button" class="btn-eliminar-semana" onclick="eliminarSemana(${numero})" 
                            ${semanas.length <= 1 ? 'disabled' : ''}>✕</button>
                </div>
                ${generarBarraFormatoSemana(numero)}
                <section class="pia-week-project pia-screen-only" data-pia-week-project="${numero}" hidden>
                    <div class="pia-week-project-heading"><div><strong>Proyecto en esta semana <button type="button" class="pia-context-help" data-pia-help="weekly-project-mode" aria-label="Ayuda sobre la modalidad semanal del Proyecto" aria-expanded="false">i</button></strong><small>Identifique cómo se integra con el currículo.</small></div><span data-pia-project-mode-badge>Semana curricular</span></div>
                    <div class="pia-week-project-grid">
                        <label>Modalidad
                            <select data-pia-project-mode="${numero}">
                                <option value="curricular">Curricular — 80 minutos</option>
                                <option value="mixed">Mixta — 40 min currículo + 40 min Proyecto</option>
                                <option value="integrated">Integrada mediante el Proyecto — 80 minutos</option>
                            </select>
                        </label>
                        <label data-pia-project-stage-wrap>Etapa
                            <select data-pia-project-stage="${numero}"></select>
                        </label>
                        <label data-pia-project-phase-wrap>Fase
                            <select data-pia-project-phase="${numero}"></select>
                        </label>
                    </div>
                    <p data-pia-week-project-help>Seleccione Mixta o Integrada para incorporar el componente Proyecto.</p>
                </section>
                
                <details class="pia-week-curriculum-details" open>
                    <summary><strong>Selección curricular de la semana</strong><span>Áreas, RdA y saberes conceptuales</span></summary>

                <!-- ÁREAS DE CONOCIMIENTO Y RDA EN PARALELO -->
                <div class="areas-rda-container">
                    <div class="areas-container">
                        <div class="section-title">Áreas de conocimiento para esta semana</div>
                        <div class="areas-lista">${generarOpcionesAreasSemana(numero)}</div>
                    </div>
                    <div class="rda-container">
                        <div class="section-title">Resultados de aprendizaje (RdA)</div>
                        <div id="rda-semana-${numero}">
                            <div style="color: #666; font-style: italic; padding: 8px; font-size: 11px;">Seleccione al menos un área de conocimiento</div>
                        </div>
                    </div>
                </div>
                
                <!-- SABERES 2x3 -->
                <div class="section-title">Saberes a Desarrollar</div>
                <div class="saberes-grid">
                    <div class="saber-columna">
                        <div class="saber-titulo">Saberes Conceptuales (Saber)</div>
                        <div class="saber-contenido" id="conceptuales-semana-${numero}">
                            <div style="color: #666; font-style: italic; font-size: 11px;">"Los saberes conceptuales se mostrarán automáticamente según las áreas seleccionadas, junto con aquellos que elijas específicamente para esta semana en el espacio correspondiente."</div>
                        </div>
                    </div>
                    <div class="saber-columna">
                        <div class="saber-titulo">Saberes Procedimentales (Saber Hacer)</div>
                        <div class="saber-contenido">
                            ${generarOpcionesProcedimentales(numero)}
                        </div>
                    </div>
                    <div class="saber-columna">
                        <div class="saber-titulo">Saberes Actitudinales (Saber Ser)</div>
                        <div class="saber-contenido">
                            ${generarOpcionesActitudinales(numero)}
                        </div>
                    </div>
                </div>
                
                <!-- SABERES CONCEPTUALES PARA ESTA SEMANA -->
                <div class="section-title">Saberes conceptuales para esta semana</div>
                <div class="saberes-conceptuales-container" id="saberes-conceptuales-${numero}">
                    <div style="color: #666; font-style: italic; font-size: 11px;">Seleccione ciclo, nivel y áreas de conocimiento para ver los saberes disponibles</div>
                </div>
                </details>
                
                <!-- 3 COLUMNAS INFERIORES -->
                <div class="tres-columnas">
                    <div class="campo-editable">
                        <div class="columna-titulo">Indicadores de logro</div>
                        <div class="contenedor-oficial" data-field-kind="official-indicator" aria-label="Indicadores de logro oficiales protegidos"
                             data-placeholder="Los indicadores aparecerán automáticamente según los saberes conceptuales seleccionados..."></div>
                        <section class="pia-reference-column" data-pia-reference-achievement-section="${numero}" hidden>
                            <h5>Indicadores de referencia del currículo del PNFT</h5>
                            <div data-pia-reference-achievement-items="${numero}"></div>
                            <small>Se muestran con su nivel de procedencia; no sustituyen los indicadores oficiales del nivel administrativo.</small>
                        </section>
                        <section class="pia-project-column" data-pia-project-achievement-section="${numero}" hidden>
                            <h5>Indicador del componente Proyecto</h5>
                            <details class="pia-screen-only"><summary>Consultar indicador oficial</summary><p data-pia-project-achievement-official></p></details>
                            <div class="contenedor-editable pia-project-editable" contenteditable="true" data-pia-project-achievement-text="${numero}" aria-label="Indicador contextualizado del Proyecto para la semana ${numero}"></div>
                            <button type="button" class="pia-link-button pia-screen-only" data-pia-restore-project-achievement="${numero}">Restaurar texto oficial</button>
                        </section>
                    </div>
                    <div class="campo-editable">
                        <div class="columna-titulo">Estrategias de <strong>Mediación </strong> </div>
                        <div class="contenedor-editable" contenteditable="true" data-field-kind="mediation" aria-label="Estrategias de mediación de la semana ${numero}"
                             data-placeholder="Describa las estrategias de *Mediación*...(Recuerde vincular los saberes procedimentales y actitudinales en las actividades)" 
                             oninput="actualizarContenidoSemana(${numero}, 'actividades', this.innerHTML)"></div>
                    </div>
                    <div class="campo-editable">
                        <div class="columna-titulo">Indicadores de evaluación</div>
                        <div class="contenedor-editable" contenteditable="true" data-field-kind="evaluation" aria-label="Indicadores de evaluación de la semana ${numero}"
                             data-placeholder="Describa los indicadores de evaluación..." 
                             oninput="actualizarContenidoSemana(${numero}, 'evaluacion', this.innerHTML)"></div>
                        <section class="pia-project-column" data-pia-project-evaluation-section="${numero}" hidden>
                            <h5>Indicadores de evaluación del Proyecto</h5>
                            <div data-pia-project-evaluation-items></div>
                        </section>
                    </div>
                </div>
                
                <!-- BOTÓN PROMPT IA -->
                <div style="text-align: center; margin-top: 12px;">
                    <button onclick="generarPromptSemana(${numero})" class="btn btn-primary" style="padding: 6px 12px; font-size: 12px;">🤖 Afinar semana ${numero} con IA</button>
                </div>
            `;
            
            return semanaDiv;
        }

        function generarOpcionesProcedimentales(numeroSemana) {
            const procedimentales = [
                { value: "reconoce", label: "Reconoce patrones", tooltip: "Predice a partir de las regularidades, similitudes o características comunes de un conjunto de datos o situaciones, patrones que pueda aplicar en la solución a un problema o situación." },
                { value: "abstrae", label: "Abstrae", tooltip: "Concluye cuáles son las características relevantes que debe considerar y cuáles debe omitir al resolver un problema o situación." },
                { value: "generaliza", label: "Generaliza", tooltip: "Generaliza las funcionalidades o estructuras generales de un elemento que pueda aprovechar en otros contextos al resolver un problema o situación." },
                { value: "transfiere", label: "Transfiere", tooltip: "Transfiere conocimientos, habilidades y estrategias aprendidas previamente en un contexto específico, a situaciones diferentes y nuevas al resolver un problema o situación." },
                { value: "modulariza", label: "Modulariza", tooltip: "Resuelve un problema por partes menos complejas, sin perder de vista el todo que las origina, al resolver un problema o situación." },
                { value: "formula", label: "Formula algoritmos", tooltip: "Formula algoritmos por medio de una secuencia ordenada y detallada de pasos para resolver un problema o situación." },
                { value: "remezcla", label: "Remezcla", tooltip: "Combina diferentes ideas, técnicas o soluciones existentes, con la autorización correspondiente, de manera innovadora y creativa para resolver un problema o situación." },
                { value: "depura", label: "Depura", tooltip: "Valida el funcionamiento de los algoritmos en busca de errores para corregirlos, al resolver un problema o situación." },
                { value: "programa", label: "Programa", tooltip: "Programa mediante un entorno o IDE de programación para resolver un problema o situación." },
                { value: "comunica", label: "Comunica", tooltip: "Comunica ideas o soluciones a problemas o situaciones de manera creativa, coherente y comprensible, compartiendo conocimientos con otros al resolver un problema o situación." },
                { value: "colabora", label: "Colabora", tooltip: "Demuestra un trato constructivo y respetuoso para resolver un problema o situación específica, al trabajar con otros y así apoyar su aprendizaje y contribuir al de los demás, al resolver un problema o situación." },
                { value: "piensa", label: "Piensa de forma creativa", tooltip: "Desarrolla soluciones ingeniosas, innovadoras, originales con enfoques no convencionales, al resolver un problema o situación." },
                { value: "maneja", label: "Maneja las tecnologías de forma ética y segura", tooltip: "Aplica de manera consciente fundamentos de ética y seguridad digital al utilizar herramientas y recursos tecnológicos, al resolver un problema o situación." }
            ];
            
            return procedimentales.map(proc => `
                <div style="margin-bottom: 6px;">
                    <label class="tooltip-improved">
                        <input type="checkbox" name="procedimental-semana-${numeroSemana}" value="${proc.value}" onchange="actualizarProcedimentalSemana(${numeroSemana}, this)">
                        <span style="font-size: 11px;">${proc.label}</span>
                        <span class="tooltiptext-improved">${proc.tooltip}</span>
                    </label>
                </div>
            `).join('');
        }

        function generarOpcionesActitudinales(numeroSemana) {
            const actitudinales = [
                { value: "gusto", label: "Gusto por la precisión", tooltip: "Demuestra ante los procesos de aprendizaje un comportamiento hacia la búsqueda de la exactitud, al ser minucioso con los detalles." },
                { value: "aprender", label: "Aprender del error", tooltip: "Demuestra ante los errores un comportamiento que le permita ganar experiencia a partir de lecciones aprendidas producto de los errores, convirtiendo los desaciertos en oportunidades de aprendizaje." },
                { value: "flexibilidad", label: "Flexibilidad para manejar problemas", tooltip: "Demuestra un comportamiento hacia la adaptabilidad, flexibilidad y resiliencia ante los desafíos o situaciones imprevistas producto del entorno, la interacción con otros, o bien, con los recursos." },
                { value: "tolerancia", label: "Tolerancia a la frustración", tooltip: "Demuestra ante los desafíos, un comportamiento hacia la búsqueda de la autoconfianza, motivación, autocontrol, paciencia y persistencia." }
            ];
            
            return actitudinales.map(act => `
                <div style="margin-bottom: 6px;">
                    <label class="tooltip-improved">
                        <input type="checkbox" name="actitudinal-semana-${numeroSemana}" value="${act.value}" onchange="actualizarActitudinalSemana(${numeroSemana}, this)">
                        <span style="font-size: 11px;">${act.label}</span>
                        <span class="tooltiptext-improved">${act.tooltip}</span>
                    </label>
                </div>
            `).join('');
        }

