import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fragments } from '../scripts/fragment-manifest.mjs';

const root = resolve(import.meta.dirname, '..');
function maskRange(source, startMarker, endMarker, replacement, label) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  assert.notEqual(start, -1, `${label}: no se encontró el inicio`);
  assert.ok(end > start, `${label}: no se encontró el final`);
  return `${source.slice(0, start)}${replacement}${source.slice(end)}`;
}

function stripOptionalRange(source, startMarker, endMarker, label) {
  let start = source.indexOf(startMarker);
  if (start < 0) return source;
  const lineStart = source.lastIndexOf('\n', start - 1) + 1;
  if (/^[\t ]*$/.test(source.slice(lineStart, start))) start = lineStart;
  const end = source.indexOf(endMarker, start);
  assert.ok(end > start, `${label}: rango incompleto`);
  let resume = end + endMarker.length;
  if (source[resume] === '\r' && source[resume + 1] === '\n') resume += 2;
  else if (source[resume] === '\n') resume += 1;
  return source.slice(0, start) + source.slice(resume);
}

function normalizeWhitespace(source) {
  return source.replace(/\r\n/g, '\n').replace(/[\t ]+$/gm, '').replace(/\n{3,}/g, '\n\n');
}

function maskAuthorizedRanges(source) {
  let masked = source;
  masked = masked
    .replaceAll('.contenedor-oficial[data-field-kind="official-indicator"]', '.contenedor-editable[data-placeholder*="indicadores"]')
    .replaceAll('.contenedor-editable[data-field-kind="mediation"]', '.contenedor-editable[data-placeholder*="estrategias"]')
    .replaceAll('.contenedor-editable[data-field-kind="evaluation"]', '.contenedor-editable[data-placeholder*="evaluación"]')
    .replaceAll('<option value="0°">Grupo Interactivo II y Transición</option>', '<option value="0°">"Grupo Interactivo II y Transición"</option>');
  masked = stripOptionalRange(masked, '/* PIA_ENHANCEMENTS_CSS_START */', '/* PIA_ENHANCEMENTS_CSS_END */', 'CSS de mejoras');
  masked = stripOptionalRange(masked, '/* PIA_RDA_ROUTE_CSS_START */', '/* PIA_RDA_ROUTE_CSS_END */', 'CSS de Ruta hacia el RdA');
  masked = stripOptionalRange(masked, '<!-- PIA_ENHANCEMENTS_HTML_START -->', '<!-- PIA_ENHANCEMENTS_HTML_END -->', 'HTML de mejoras');
  masked = stripOptionalRange(masked, '<!-- PIA_IDENTITY_HTML_START -->', '<!-- PIA_IDENTITY_HTML_END -->', 'identidad institucional');
  masked = stripOptionalRange(masked, '<!-- PIA_SUPPORT_TOOLS_HTML_START -->', '<!-- PIA_SUPPORT_TOOLS_HTML_END -->', 'HTML de herramientas de apoyo');
  masked = stripOptionalRange(masked, '<!-- PIA_WEEK_NAVIGATOR_START -->', '<!-- PIA_WEEK_NAVIGATOR_END -->', 'navegador semanal');
  masked = stripOptionalRange(masked, '<!-- PIA_REVIEW_ACTION_START -->', '<!-- PIA_REVIEW_ACTION_END -->', 'acción de vista previa');
  masked = stripOptionalRange(masked, '<!-- PIA_CENTER_LOOKUP_HTML_START -->', '<!-- PIA_CENTER_LOOKUP_HTML_END -->', 'consulta interna de centros');
  masked = stripOptionalRange(masked, '<!-- PIA_WELCOME_HTML_START -->', '<!-- PIA_WELCOME_HTML_END -->', 'portada de bienvenida');
  masked = stripOptionalRange(masked, '<!-- PIA_OTHER_METHODOLOGY_HTML_START -->', '<!-- PIA_OTHER_METHODOLOGY_HTML_END -->', 'fundamentación de otra metodología');
  masked = stripOptionalRange(masked, '<!-- PIA_PROMPT_PERSISTENCE_GENERAL_START -->', '<!-- PIA_PROMPT_PERSISTENCE_GENERAL_END -->', 'persistencia de prompt general');
  masked = stripOptionalRange(masked, '<!-- PIA_PROMPT_PERSISTENCE_WEEKLY_START -->', '<!-- PIA_PROMPT_PERSISTENCE_WEEKLY_END -->', 'persistencia de prompt semanal');
  masked = stripOptionalRange(masked, '// PIA_PRESCHOOL_CURRICULUM_JS_START', '// PIA_PRESCHOOL_CURRICULUM_JS_END', 'catálogo oficial de preescolar');
  masked = stripOptionalRange(masked, '// PIA_CURRICULAR_FRAMEWORK_JS_START', '// PIA_CURRICULAR_FRAMEWORK_JS_END', 'marco curricular oficial de consulta');
  masked = stripOptionalRange(masked, '// PIA_INSTITUTIONAL_CENTERS_JS_START', '// PIA_INSTITUTIONAL_CENTERS_JS_END', 'catálogo mínimo de centros');
  masked = stripOptionalRange(masked, '// PIA_CURRICULAR_PROGRESSION_DATA_START', '// PIA_CURRICULAR_PROGRESSION_DATA_END', 'catálogo relacional de progresión curricular');
  masked = stripOptionalRange(masked, '// PIA_ROUTE_RELATION_CATALOG_START', '// PIA_ROUTE_RELATION_CATALOG_END', 'catálogo de relaciones posibles para la ruta');
  masked = stripOptionalRange(masked, '// PIA_THIRD_GRADE_RELATIONAL_OPERATOR_START', '// PIA_THIRD_GRADE_RELATIONAL_OPERATOR_END', 'corrección oficial de Operadores relacionales de tercer grado');
  masked = stripOptionalRange(masked, '// PIA_RDA_CONTRIBUTION_CATALOG_START', '// PIA_RDA_CONTRIBUTION_CATALOG_END', 'catálogo de correspondencias hacia el RdA');
  masked = stripOptionalRange(masked, '// PIA_CURRICULAR_PROGRESSION_SERVICE_START', '// PIA_CURRICULAR_PROGRESSION_SERVICE_END', 'servicio de progresión curricular');
  masked = stripOptionalRange(masked, '// PIA_RDA_ROUTE_SERVICE_START', '// PIA_RDA_ROUTE_SERVICE_END', 'servicio de Ruta hacia el RdA');
  masked = stripOptionalRange(masked, '// PIA_RDA_ROUTE_VIEW_START', '// PIA_RDA_ROUTE_VIEW_END', 'vista de Ruta hacia el RdA');
  masked = stripOptionalRange(masked, '// PIA_CENTER_LOOKUP_JS_START', '// PIA_CENTER_LOOKUP_JS_END', 'servicio de consulta de centros');
  masked = stripOptionalRange(masked, '// PIA_REFERENCE_INDICATORS_JS_START', '// PIA_REFERENCE_INDICATORS_JS_END', 'servicio de indicadores de referencia');
  masked = stripOptionalRange(masked, '// PIA_PRESCHOOL_RUNTIME_ADAPTER_START', '// PIA_PRESCHOOL_RUNTIME_ADAPTER_END', 'adaptador curricular de preescolar');
  masked = stripOptionalRange(masked, '// PIA_ENHANCEMENTS_JS_START', '// PIA_ENHANCEMENTS_JS_END', 'JS de mejoras');
  masked = stripOptionalRange(masked, '// PIA_EVALUATION_PROFILES_JS_START', '// PIA_EVALUATION_PROFILES_JS_END', 'perfiles de evaluación');
  masked = stripOptionalRange(masked, '// PIA_EVALUATION_INSTRUMENTS_JS_START', '// PIA_EVALUATION_INSTRUMENTS_JS_END', 'instrumentos de evaluación');
  masked = stripOptionalRange(masked, '// PIA_PROJECT_COMPONENT_CATALOG_JS_START', '// PIA_PROJECT_COMPONENT_CATALOG_JS_END', 'componente Proyecto');
  masked = stripOptionalRange(masked, '// PIA_SEMESTER_PROMPT_JS_START', '// PIA_SEMESTER_PROMPT_JS_END', 'constructor de prompt semestral');
  for (const key of ['WORD_IDENTITY','WORD_PROJECTION','PDF_RICH','PDF_IDENTITY','PDF_PROJECTION','PDF_PROJECT_HELPERS']) {
    masked = stripOptionalRange(masked, `// PIA_EXPORT_ENHANCEMENT_${key}_START`, `// PIA_EXPORT_ENHANCEMENT_${key}_END`, key);
  }
  masked = stripOptionalRange(masked, '// PIA_WEEK_FORMAT_HELPER_START', '// PIA_WEEK_FORMAT_HELPER_END', 'constructor de formato semanal');
  masked = maskRange(masked, '        function crearElementoSemana(numero, leccionInicio, leccionFin) {', '        function generarOpcionesProcedimentales(numeroSemana) {', '<WEEK_VIEW>\n', 'vista semanal');
  masked = maskRange(masked, '        function inicializarSemanas() {', '        function actualizarProcedimentalSemana(numeroSemana, checkbox) {', '<WEEK_INITIALIZATION>\n', 'inicialización semanal');
  masked = maskRange(masked, '        function agregarSemanaManual() {', '        function eliminarSemana(numero) {', '<MANUAL_WEEK>\n', 'semana manual');
  masked = maskRange(masked, '        function generarPromptCompleto() {', '        function cerrarPromptModal() {', '<GENERAL_PROMPT>\n', 'prompt general');
  masked = maskRange(masked, '        function generarPromptSemana(numeroSemana) {', '    </script>', '<WEEKLY_PROMPT>\n', 'prompt semanal y módulos autorizados');
  masked = maskRange(masked, '        .export-options {', '        .checkbox-group {', '<EXPORT_CSS>\n', 'CSS Word');
  masked = maskRange(masked, '                <!-- FORMATOS DE EXPORTACIÓN', '    <!-- MODAL PARA PROMPT IA -->', '<EXPORT_DIALOG>\n', 'diálogo Word');
  masked = maskRange(masked, '        function eliminarSemana(numero) {', '        function actualizarContadoresSemanas() {', '<WEEK_DELETION>\n', 'eliminación semanal');
  masked = maskRange(masked, '        function mostrarOpcionesExportar() {', '        function exportarAPDF() {', '<WORD_EXPORT>\n', 'exportación Word');
  masked = maskRange(masked, '        // ✅ PLANIFICACIÓN POR SEMANAS - VERSIÓN MEJORADA CON AJUSTE AUTOMÁTICO', '        // REFLEXIONES', '<PDF_WEEK_EXPORT>\n', 'exportación PDF semanal');
  return masked;
}

test('la fuente ensamblada conserva el núcleo fuera de los rangos autorizados', async () => {
  const reference = await readFile(join(root, 'reference/index.original.html'), 'utf8');
  const sourceChunks = await Promise.all(fragments.map((file) => readFile(join(root, file))));
  const assembledSource = Buffer.concat(sourceChunks).toString('utf8');
  assert.equal(
    normalizeWhitespace(maskAuthorizedRanges(assembledSource)),
    normalizeWhitespace(maskAuthorizedRanges(reference)),
    'Se detectó una diferencia fuera de los rangos autorizados',
  );
});

test('las tres salidas HTML corresponden exactamente a la fuente ensamblada', async () => {
  const sourceChunks = await Promise.all(fragments.map((file) => readFile(join(root, file))));
  const iconSprite = await readFile(join(root, 'src/assets/pnft-area-icons.png'));
  const learningJS = await readFile(join(root, 'src/learning/experience.js'), 'utf8');
  const learningCSS = await readFile(join(root, 'src/learning/experience.css'), 'utf8');
  const assembledSource = Buffer.from(Buffer.concat(sourceChunks).toString('utf8')
    .replace('__PIA_LEARNING_EXPERIENCE__', () => learningJS)
    .replace('/* __PIA_LEARNING_STYLES__ */', () => learningCSS)
    .replaceAll('__PIA_PNFT_AREA_ICONS__', `data:image/png;base64,${iconSprite.toString('base64')}`));
  const outputs = ['index.html', 'dist/web/index.html', 'dist/portable/index.html'];

  for (const output of outputs) {
    const actual = await readFile(join(root, output));
    assert.deepEqual(actual, assembledSource, `${output} no coincide byte por byte con la fuente modular ensamblada`);
  }
});
