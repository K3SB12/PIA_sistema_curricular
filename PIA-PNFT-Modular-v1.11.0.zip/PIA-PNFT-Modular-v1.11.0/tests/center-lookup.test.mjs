import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { extractCentersFromXlsx, summarizeCenters } from '../scripts/import-centers.mjs';

const root = resolve(import.meta.dirname, '..');
const catalogSource = await readFile(resolve(root, 'src/data/institutional-centers.js'), 'utf8');
const serviceSource = await readFile(resolve(root, 'src/domain/institution/center-lookup-service.js'), 'utf8');
const context = vm.createContext({ result: null });
vm.runInContext(`${catalogSource}\n${serviceSource}\nresult={catalog:PIAInstitutionalCenters,service:PIACenterLookup};`, context);
const INSTITUTIONAL_CENTERS = context.result.catalog;
const { create: createCenterLookup, lookup: lookupCenterByBudgetCode, normalizeBudgetCode } = context.result.service;

function storedZip(name, content) {
  const fileName = Buffer.from(name);
  const data = Buffer.from(content);
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(20, 4);
  local.writeUInt32LE(data.length, 18);
  local.writeUInt32LE(data.length, 22);
  local.writeUInt16LE(fileName.length, 26);

  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0);
  central.writeUInt16LE(20, 4);
  central.writeUInt16LE(20, 6);
  central.writeUInt32LE(data.length, 20);
  central.writeUInt32LE(data.length, 24);
  central.writeUInt16LE(fileName.length, 28);

  const centralDirectory = Buffer.concat([central, fileName]);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(1, 8);
  end.writeUInt16LE(1, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(local.length + fileName.length + data.length, 16);
  return Buffer.concat([local, fileName, data, centralDirectory, end]);
}

test('el catálogo público conserva únicamente centro, codPres y codSaber', () => {
  assert.equal(INSTITUTIONAL_CENTERS.length, 4_651);
  for (const record of INSTITUTIONAL_CENTERS) {
    assert.deepEqual(Array.from(Object.keys(record)).sort(), ['centro', 'codPres', 'codSaber']);
    assert.notEqual(record.codPres, '0000');
  }
});

test('los conteos de códigos únicos y ambiguos coinciden con la fuente autorizada', () => {
  assert.deepEqual(summarizeCenters(INSTITUTIONAL_CENTERS), {
    records: 4_651,
    distinctCodes: 4_511,
    uniqueCodes: 4_448,
    ambiguousCodes: 63,
    ambiguousRecords: 203,
    uniqueCodSaber: 4_651
  });
});

test('preserva los ceros iniciales y resuelve código único, ambiguo e inexistente', () => {
  assert.equal(normalizeBudgetCode('904'), '0904');
  assert.equal(normalizeBudgetCode(' 0904 '), '0904');
  assert.equal(normalizeBudgetCode('abc'), '');

  const unique = lookupCenterByBudgetCode('0904');
  assert.equal(unique.status, 'unique');
  assert.equal(unique.codPres, '0904');
  assert.equal(unique.center.centro, 'LA LIRA');

  const ambiguous = lookupCenterByBudgetCode('4870');
  assert.equal(ambiguous.status, 'ambiguous');
  assert.ok(ambiguous.matches.length > 1);

  assert.equal(lookupCenterByBudgetCode('0000').status, 'notFound');
  assert.equal(lookupCenterByBudgetCode('0000').codPres, '0000');
  assert.equal(lookupCenterByBudgetCode('99999').status, 'notFound');
  assert.equal(lookupCenterByBudgetCode('99999').codPres, '');
});

test('el servicio permite catálogos inyectados sin depender de la interfaz', () => {
  const lookup = createCenterLookup([
    { centro: 'A', codPres: '1234', codSaber: '1' },
    { centro: 'B', codPres: '1234', codSaber: '2' },
    { centro: 'Excluido', codPres: '0000', codSaber: '3' }
  ]);
  assert.equal(lookup('1234').status, 'ambiguous');
  assert.equal(lookup('0000').status, 'notFound');
});

test('el importador reproduce el catálogo desde XLSX sin dependencias externas', async () => {
  const worksheet = `<?xml version="1.0"?><worksheet><sheetData>
    <row><c r="A1" t="str"><v>centro</v></c><c r="B1" t="str"><v>cod_saber</v></c><c r="C1" t="str"><v>cod_pres</v></c></row>
    <row><c r="A2" t="str"><v>LA LIRA</v></c><c r="B2" t="str"><v>101094-00</v></c><c r="C2" t="str"><v>0904</v></c></row>
    <row><c r="A3" t="str"><v>CEN CINAI</v></c><c r="B3" t="str"><v>000001-00</v></c><c r="C3" t="str"><v>0000</v></c></row>
  </sheetData></worksheet>`;
  const { centers, excluded } = extractCentersFromXlsx(storedZip('xl/worksheets/sheet1.xml', worksheet));
  assert.equal(excluded, 1);
  assert.deepEqual(centers, [{ centro: 'LA LIRA', codPres: '0904', codSaber: '101094-00' }]);
});
