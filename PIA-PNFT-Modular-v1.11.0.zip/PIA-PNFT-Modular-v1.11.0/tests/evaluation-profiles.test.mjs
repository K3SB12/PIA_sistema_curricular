import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const source=await readFile(resolve(root,'src/data/evaluation-profiles.js'),'utf8');
const context=vm.createContext({result:null});
vm.runInContext(`${source}\nresult=PIAEvaluationProfiles;`,context);
const api=context.result;

test('cada perfil porcentual suma 100 y preescolar permanece formativo',()=>{
  for(const profile of Object.values(api.profiles)){
    if(!profile.components.length){assert.equal(profile.id,'preschool');continue;}
    assert.equal(profile.components.reduce((sum,item)=>sum+item[1],0),100,profile.id);
  }
});

test('el ciclo muestra solamente perfiles aplicables',()=>{
  assert.deepEqual(Array.from(api.availableForCycle('I Ciclo'),x=>x.id),['primary','hearing']);
  assert.deepEqual(Array.from(api.availableForCycle('III Ciclo'),x=>x.id),['secondary','vocational','adult']);
  assert.equal(api.defaultForCycle('Materno Infantil/Transición').id,'preschool');
});
