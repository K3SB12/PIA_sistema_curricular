import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const source = await readFile(resolve(root, 'src/data/preschool-curriculum.js'), 'utf8');
const context = vm.createContext({ result: null });
vm.runInContext(`${source}\nresult=PIAPreschoolCurriculum;`, context);
const api = context.result;

const expectedConcepts = {
    'module-1:basic-required': [
        'Computadora.',
        'Software.',
        'Herramientas de creación de contenido multimedia.',
        'Entorno de programación iconográfico.',
        'Lateralidad y orientación espacial.',
        'Evento.'
    ],
    'module-2:basic-required': [
        'Conexión entre dispositivos.',
        'Estado.',
        'Algoritmo.',
        'Dato (programación).',
        'Estructuras repetitivas.',
        'Robot.',
        'Dato (Ciencias de datos).',
        'Estrategias para presentar datos.'
    ],
    'module-1:optimal': [
        'Computadora.',
        'Hardware.',
        'Software.',
        'Herramientas de creación de contenido multimedia.',
        'Internet.',
        'Entorno de programación iconográfico.',
        'Lateralidad y orientación espacial.',
        'Evento.'
    ],
    'module-2:optimal': [
        'Conexión entre dispositivos.',
        'Estado.',
        'Algoritmo.',
        'Dato (programación).',
        'Estructuras repetitivas.',
        'Robot.',
        'Dato (ciencias de datos).',
        'Estrategias para presentar datos.',
        'Visualización de datos.',
        'Realidad aumentada.'
    ]
};

test('los cuatro itinerarios oficiales conservan los conteos 6, 8, 8 y 10', () => {
    const counts = Object.fromEntries(Object.entries(api.itineraries).map(([key, value]) => [key, value.entries.length]));
    assert.deepEqual(counts, {
        'module-1:basic-required': 6,
        'module-2:basic-required': 8,
        'module-1:optimal': 8,
        'module-2:optimal': 10
    });
});

test('cada itinerario contiene literalmente sus saberes oficiales y no mezcla rutas', () => {
    for (const [key, concepts] of Object.entries(expectedConcepts)) {
        assert.deepEqual(Array.from(api.itineraries[key].entries, entry => entry.conceptualKnowledge), concepts, key);
        assert.equal(new Set(api.itineraries[key].entries.map(entry => entry.id)).size, concepts.length, `${key}: identificadores únicos`);
    }
    assert.equal(api.itineraries['module-1:basic-required'].entries.some(entry => entry.conceptualKnowledge === 'Hardware.'), false);
    assert.equal(api.itineraries['module-1:basic-required'].entries.some(entry => entry.conceptualKnowledge === 'Internet.'), false);
    assert.equal(api.itineraries['module-2:basic-required'].entries.some(entry => entry.conceptualKnowledge === 'Visualización de datos.'), false);
    assert.equal(api.itineraries['module-2:basic-required'].entries.some(entry => entry.conceptualKnowledge === 'Realidad aumentada.'), false);
});

test('los indicadores que diferencian básico y óptimo permanecen vinculados a su ruta', () => {
    const find = (key, concept) => api.itineraries[key].entries.find(entry => entry.conceptualKnowledge === concept);
    assert.equal(
        find('module-1:basic-required', 'Software.').achievementIndicator,
        'Reconocer elementos visuales básicos de la interfaz de software (iconos, botones, ventanas), interactuando con ellos mediante el uso guiado de dispositivos digitales.'
    );
    assert.equal(
        find('module-1:optimal', 'Software.').achievementIndicator,
        'Reconocer elementos del software relacionados con la interfaz de usuario, como iconos, botones de minimizar, maximizar y cerrar, barra de tareas y área de trabajo, interactuando con ellos mediante el uso de dispositivos digitales.'
    );
    assert.equal(
        find('module-2:basic-required', 'Algoritmo.').achievementIndicator,
        'Reconocer el concepto de algoritmo mediante secuencias de acciones lógicas y ordenadas, en la construcción de soluciones a desafíos propuestos.'
    );
    assert.equal(
        find('module-2:optimal', 'Algoritmo.').achievementIndicator,
        'Reconocer patrones de repetición en secuencias lógicas y ordenadas, como parte de un algoritmo, al construir soluciones a desafíos propuestos.'
    );
});

test('cada registro conserva área, RdA e indicador completos', () => {
    for (const itinerary of Object.values(api.itineraries)) {
        for (const entry of itinerary.entries) {
            assert.ok(api.RDA_BY_AREA[entry.area], `${itinerary.id}: área oficial`);
            assert.equal(entry.rda, api.RDA_BY_AREA[entry.area], `${itinerary.id}: RdA por área`);
            assert.ok(entry.achievementIndicator.endsWith('.'), `${itinerary.id}: indicador completo`);
        }
    }
    assert.match(api.RDA_BY_AREA['Ciencia de datos e Inteligencia artificial'], /datos simples/);
});

test('la consulta acepta las etiquetas docentes sin exponer una ruta combinada inexistente', () => {
    assert.equal(api.getItinerary(1, 'Básico requerido').id, 'module-1:basic-required');
    assert.equal(api.getItinerary('2', 'óptimo').id, 'module-2:optimal');
    assert.equal(api.getItinerary(1, 'combinado'), null);
    assert.equal(api.getItinerary(3, 'óptimo'), null);
});

test('el catálogo aislado no reasigna ni declara las fuentes curriculares protegidas', () => {
    assert.equal(/\bconst\s+PNFT_DATA\b/.test(source), false);
    assert.equal(/\bconst\s+RDA_POR_CICLO\b/.test(source), false);
    assert.match(api.SOURCE.authority, /Guía docente oficial/);
});

test('adapta cada ruta a la estructura modular consumida por PIA', () => {
    const basic = api.getLevelData('basic');
    const optimal = api.getLevelData('optimal');
    assert.equal(basic['Módulo 1']['Apropiación tecnológica y Digital'].saberes.length, 3);
    assert.equal(optimal['Módulo 1']['Apropiación tecnológica y Digital'].saberes.length, 5);
    assert.equal(basic['Módulo 2']['Ciencia de datos e Inteligencia artificial'].saberes.length, 2);
    assert.equal(optimal['Módulo 2']['Ciencia de datos e Inteligencia artificial'].saberes.length, 4);
    assert.equal(basic['Módulo 1']['Apropiación tecnológica y Digital'].saberes[1].nombre, 'Software.');
});

test('conserva las cuatro competencias específicas oficiales de Preescolar', () => {
    assert.equal(Object.keys(api.COMPETENCIES_BY_AREA).length, 4);
    assert.equal(
        api.COMPETENCIES_BY_AREA['Programación y Algoritmos'],
        'Resuelve problemas mediante la programación de algoritmos para desarrollar el pensamiento lógico matemático, tomando en cuenta las prácticas y actitudes del pensador computacional.'
    );
    assert.match(api.COMPETENCIES_BY_AREA['Apropiación tecnológica y Digital'], /ciberseguridad y ética digital/);
});

test('conserva el perfil de salida de Preescolar organizado por las cuatro áreas', () => {
    assert.deepEqual(
        Object.fromEntries(Object.entries(api.EXIT_PROFILE_BY_AREA).map(([area, statements]) => [area, statements.length])),
        {
            'Apropiación tecnológica y Digital': 5,
            'Programación y Algoritmos': 6,
            'Computación física y Robótica': 4,
            'Ciencia de datos e Inteligencia artificial': 3
        }
    );
    assert.match(api.EXIT_PROFILE_BY_AREA['Computación física y Robótica'][0], /Reconoce qué es un robot/);
});
