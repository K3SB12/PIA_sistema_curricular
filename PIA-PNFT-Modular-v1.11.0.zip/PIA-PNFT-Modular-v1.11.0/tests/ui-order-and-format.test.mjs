import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');

test('el orden validado conserva encabezado oficial y ubica las nuevas etapas',async()=>{
  const {fragments}=await import('../scripts/fragment-manifest.mjs');
  const position=path=>fragments.indexOf(path);
  assert.ok(position('src/templates/header.html')<position('src/templates/institutional-identity.html'));
  assert.ok(position('src/templates/institutional-identity.html')<position('src/templates/general-information.html'));
  assert.ok(position('src/templates/general-information.html')<position('src/templates/transversal-axes.html'));
  assert.ok(position('src/templates/methodology.html')<position('src/templates/enhancements.html'));
  assert.ok(position('src/templates/enhancements.html')<position('src/templates/support-tools.html'));
  assert.ok(position('src/templates/support-tools.html')<position('src/templates/weeks.html'));
});

test('solo mediación y evaluación tienen formato local por semana; el indicador oficial queda protegido',async()=>{
  const week=await readFile(resolve(root,'src/ui/week-view.js'),'utf8');
  const support=await readFile(resolve(root,'src/templates/support-tools.html'),'utf8');
  const weeks=await readFile(resolve(root,'src/templates/weeks.html'),'utf8');
  assert.match(week,/data-field-kind="official-indicator"/);
  assert.match(week,/data-field-kind="mediation"/);
  assert.match(week,/data-field-kind="evaluation"/);
  assert.doesNotMatch(week,/contenteditable="true"[^>]+data-field-kind="official-indicator"/);
  assert.match(week,/data-pia-format-toggle/);
  assert.match(week,/data-pia-field-action="undo"/);
  assert.match(week,/data-pia-field-action="redo"/);
  assert.match(week,/data-pia-week-phase/);
  assert.match(weeks,/id="piaWeekNavigator"/);
  assert.match(weeks,/id="piaWeekChips"/);
  assert.doesNotMatch(support,/piaToggleFormat|piaResetFormat|piaCopyMediation|piaStrategy/);
});

test('PDF y Word oficiales no incorporan proyección ni cobertura',async()=>{
  const exporter=await readFile(resolve(root,'src/infrastructure/export/pdf-exporter.js'),'utf8');
  assert.doesNotMatch(exporter,/projectionExportHtml/);
  assert.doesNotMatch(exporter,/pia-export-projection/);
});
