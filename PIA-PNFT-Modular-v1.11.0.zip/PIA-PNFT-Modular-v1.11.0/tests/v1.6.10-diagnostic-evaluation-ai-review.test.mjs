import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=path=>readFile(resolve(root,path),'utf8');

test('el diagnóstico dispone de flujo propio, modos asesor y docente y persistencia local',async()=>{
  const [html,runtime,core]=await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/domain/projection/projection-core.js')]);
  for(const id of ['piaDiagnosisModal','piaDiagnosticMode','piaDiagnosticPriorSource','piaDiagnosticCognitive','piaDiagnosticSocioaffective','piaDiagnosticPsychomotor','piaSaveDiagnostic','piaGenerateDiagnosticPrompt'])assert.match(html,new RegExp(`id="${id}"`));
  for(const text of ['MODELO PARA ASESORÍA','APLICACIÓN DOCENTE','no son tres pruebas ni tres etapas consecutivas','máximo 80 minutos en total','Sistematización de desempeños y logros'])assert.match(runtime,new RegExp(text,'i'));
  assert.match(core,/diagnostic:\{enabled:false,mode:'advisor'/);
  assert.match(runtime,/diagnostic\.prompt=\$\('piaDiagnosisPromptText'\)/);
});

test('las sugerencias evaluativas son editables, confirmables y no escriben semanas',async()=>{
  const [html,runtime,prompt]=await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/prompts/semester-projection-prompt.js')]);
  assert.match(html,/id="piaGenerateEvaluationGuidance"/);
  for(const value of ['suggested','confirmed','discarded'])assert.match(runtime,new RegExp(`value="${value}"`));
  for(const text of ['al menos tres tareas por periodo, excepto CONED','mínimo dos días naturales','ocho días hábiles','Prueba de ejecución','Proceso progresivo durante el periodo'])assert.match(runtime,new RegExp(text,'i'));
  assert.match(runtime,/MOMENTOS EVALUATIVOS CONFIRMADOS POR LA PERSONA DOCENTE/);
  assert.doesNotMatch(runtime,/function generateEvaluationGuidance[\s\S]{0,6000}semanas\[[^\]]+\]\s*=/);
  assert.match(prompt,/condicione la asignación a necesidades de repaso o reforzamiento/i);
});

test('la respuesta de IA se guarda y audita sin incorporarse al planeamiento oficial',async()=>{
  const [dialogs,runtime,core]=await Promise.all([read('src/templates/dialogs.html'),read('src/application/enhancements.js'),read('src/domain/projection/projection-core.js')]);
  assert.match(dialogs,/data-pia-review-ai="general"/);
  assert.match(dialogs,/data-pia-review-ai="weekly"/);
  assert.match(runtime,/function auditAIResponse/);
  assert.match(runtime,/no sustituye la revisión curricular ni el criterio profesional/i);
  assert.match(runtime,/Guardar sin incorporar/);
  assert.match(core,/aiReview:\{generalResponse:'',semesterResponse:'',weeklyResponses:\{\}/);
});

test('la migración conserva diagnóstico, decisiones evaluativas y respuestas revisadas',async()=>{
  const source=await read('src/domain/projection/projection-core.js');
  const context=vm.createContext({result:null,encodeURIComponent});
  vm.runInContext(`${source}\nresult=PIAProjectionCore;`,context);
  const migrated=context.result.migrate({pia:{diagnostic:{mode:'teacher',strengths:'Explora con autonomía',prompt:'Prompt propio'},evaluation:{guidance:{suggestions:[{id:'task-1',status:'confirmed',week:6}]}},aiReview:{generalResponse:'Respuesta general',semesterResponse:'Respuesta semestral',weeklyResponses:{'3':'Respuesta semanal'},reports:{general:[{ok:true,text:'Revisada'}],semester:[],weekly:{}}}}});
  assert.equal(migrated.diagnostic.mode,'teacher');
  assert.equal(migrated.diagnostic.prompt,'Prompt propio');
  assert.equal(migrated.evaluation.guidance.suggestions[0].status,'confirmed');
  assert.equal(migrated.aiReview.generalResponse,'Respuesta general');
  assert.equal(migrated.aiReview.weeklyResponses['3'],'Respuesta semanal');
});

test('Afinar semana recibe diagnóstico, referencias y momentos confirmados sin reescribir la semana',async()=>{
  const runtime=await read('src/application/enhancements.js');
  assert.match(runtime,/function weeklyEnhancementPromptBlock/);
  assert.match(runtime,/startsWith\('diagnóstico'\)\?diagnosticSemesterPromptBlock/);
  assert.match(runtime,/confirmedEvaluationPromptBlock\(weekNumber\)/);
  assert.match(runtime,/const generated=editor\.value\+weeklyEnhancementPromptBlock\(number\)/);
});
