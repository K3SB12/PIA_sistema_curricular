import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,styles,enhancements,promptSource,catalogSource,pdfExporter]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/styles/08-enhancements.css'),read('src/application/enhancements.js'),
  read('src/prompts/semester-projection-prompt.js'),read('src/data/project-component-catalog.js'),read('src/infrastructure/export/pdf-exporter.js')
]);

test('la trayectoria se abre desde Proyección y usa identidad, filtros y vistas acordadas',()=>{
  assert.match(template,/id="piaTrajectory"[^>]*>Explorar trayectoria curricular/);
  for(const color of ['#173d82','#8fcf69','#2bb7b3','#54259c'])assert.match(`${styles}\n${enhancements}`,new RegExp(color,'i'));
  for(const text of ['Integración · Progresión · Escalabilidad','Antes · referente curricular','Ahora · currículo que se proyecta','Después · continuidad curricular','Todos los saberes del módulo','Solo saberes de la proyección','Tabla comparativa','sin abordaje conceptual documentado','Fuente:'])assert.match(enhancements,new RegExp(text,'i'));
  assert.match(styles,/__PIA_PNFT_AREA_ICONS__/);
  assert.match(enhancements,/PIACurricularProgression\.trajectoryView/);
});

test('la trayectoria es informativa y permanece fuera de las exportaciones oficiales',()=>{
  assert.doesNotMatch(pdfExporter,/piaTrajectory|Trayectoria curricular del PNFT/);
  assert.match(enhancements,/no modifica el planeamiento ni sustituye el criterio profesional docente/i);
  assert.doesNotMatch(enhancements,/state\.projection\.trajectory|schemaVersion\s*:\s*7/);
});

test('el prompt exige auditoría temporal posterior sin juzgar por conteo aislado',()=>{
  for(const expected of ['Después de construir la matriz y el desarrollo semanal','semanas, lecciones y minutos disponibles','No determine la viabilidad únicamente','18 indicadores para 19 bloques no constituye por sí sola un problema','Viabilidad temporal confirmada','Revisión temporal sugerida','Requiere ajuste temporal','F) Auditoría temporal'])assert.equal(promptSource.toLocaleLowerCase('es').includes(expected.toLocaleLowerCase('es')),true,expected);
});

test('la revisión local exige ocho secciones y una sola conclusión temporal en la respuesta semestral',()=>{
  assert.match(enhancements,/kind==='semester'\?\['A\)','B\)','C\)','D\)','E\)','F\)','G\)','H\)'\]/);
  assert.match(enhancements,/conclusions\.length===1/);
  assert.match(enhancements,/La auditoría temporal debe presentar exactamente una conclusión controlada/);
});

test('la etapa técnica development se presenta en español en el prompt de Proyecto',()=>{
  const context=vm.createContext({result:null});
  vm.runInContext(`const PIAEvaluationProfiles={describe:()=>''};\n${catalogSource}\n${promptSource}\nresult={catalog:PIAProjectComponentCatalog,prompt:PIASemesterPrompt};`,context);
  const record=context.result.catalog.phaseRecord('prototype');
  record.achievementIndicators=[{id:'test',sourceType:'official-curriculum',officialText:'Indicador oficial de prueba',teacherText:'',evaluationIndicators:[]}];
  const text=context.result.prompt.build({level:'8°',cycle:'III Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:1,modules:['Módulo 1'],areas:['Programación y Algoritmos'],methodology:'APD',axes:[],rdas:['RdA'],rdaItems:[{area:'Programación y Algoritmos',text:'RdA'}],concepts:[{name:'Dato',module:'Módulo 1',area:'Programación y Algoritmos',indicators:['Indicador oficial de prueba']}],procedural:['Programa'],attitudinal:['Gusto por la precisión'],indicators:['Indicador oficial de prueba'],evaluationProfile:{id:'secondary',label:'III Ciclo',components:[['Proyecto',25]]},evaluationInstruments:[],projectPlanning:{enabled:true,phaseSnapshots:[{phase:context.result.catalog.getPhase('prototype'),record}],indicatorSnapshots:[]}});
  assert.match(text,/Etapa de desarrollo → Prototipar/);
  assert.doesNotMatch(text,/development → Prototipar/);
});
