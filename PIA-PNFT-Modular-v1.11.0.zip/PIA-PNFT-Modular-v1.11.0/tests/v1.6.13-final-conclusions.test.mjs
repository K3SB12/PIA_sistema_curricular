import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,core,promptSource,catalogSource,buildSource,iconBytes]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/domain/projection/projection-core.js'),
  read('src/prompts/semester-projection-prompt.js'),read('src/data/project-component-catalog.js'),read('scripts/build.mjs'),
  readFile(resolve(root,'src/assets/pnft-area-icons.png'))
]);

test('las celdas vacías quedan como ausencia de registro y no como fortalecimiento',async()=>{
  const importer=await read('scripts/import-curricular-progression.mjs');
  const progression=await read('src/data/curricular-progression.js');
  assert.match(importer,/if \(!text\) return \{ status: 'no-curricular-record'/);
  assert.doesNotMatch(importer,/if \(!text\) return \{ status: 'reinforced-non-evaluable'/);
  assert.match(progression,/"catalogVersion": "1\.1\.0"/);
  assert.match(progression,/"no-curricular-record"/);
});

test('la trayectoria incorpora las dos vistas, filtros, RdA, fuentes y el recurso gráfico aportado',()=>{
  for(const expected of ['Tabla comparativa','Todos los saberes del módulo','Solo saberes de la proyección','Ver RdA oficial del ciclo','Guía docente FT-Preescolar','Guía docente FT-Primaria','Guía docente FT-Secundaria III C'])assert.match(runtime,new RegExp(expected,'i'));
  assert.match(buildSource,/src\/assets\/pnft-area-icons\.png/);
  assert.equal(createHash('sha256').update(iconBytes).digest('hex'),'f91086477a6084d8b7279ac274f2593acf54a18cc570c148fdb3133317ce97ae');
});

test('el diagnóstico inicia desactivado, puede reiniciarse y solo se incorpora mediante activación expresa',()=>{
  for(const id of ['piaDiagnosticEnabled','piaResetDiagnostic'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(template,/id="piaDiagnosisLessons"[^>]*value="0"/);
  assert.match(runtime,/if\(!diagnostic\.enabled\|\|!state\.calendar\.diagnosisLessons\)return ''/);
  assert.match(runtime,/function resetDiagnostic\(\)/);
  assert.match(core,/calendar:\{weeks:22,diagnosisLessons:0/);
});

test('el prompt semestral omite diagnóstico y trayectoria cuando no fueron activados',()=>{
  const context=vm.createContext({result:null});
  vm.runInContext(`const PIAEvaluationProfiles={describe:()=>''};\n${catalogSource}\n${promptSource}\nresult=PIASemesterPrompt;`,context);
  const base={level:'2°',cycle:'I Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,modules:['Módulo 1'],areas:['Programación y Algoritmos'],methodology:'ABJ',axes:[],rdaItems:[{area:'Programación y Algoritmos',text:'RdA'}],concepts:[{name:'Algoritmo',module:'Módulo 1',area:'Programación y Algoritmos',indicators:['Indicador oficial']}],procedural:['Programa'],attitudinal:['Gusto por la precisión'],evaluationProfile:{id:'primary',label:'I Ciclo',components:[]},evaluationInstruments:[]};
  const inactive=context.result.build(base);
  assert.doesNotMatch(inactive,/DECISIONES DEL DIAGNÓSTICO|Evaluación diagnóstica pedagógica activada|ORIENTACIÓN PARA LA IA|TRAYECTORIA:/i);
  const active=context.result.build({...base,diagnosticPlanningBlock:'\nDECISIONES DEL DIAGNÓSTICO PEDAGÓGICO\n• Resultados pendientes: formule decisiones únicamente de manera condicional.'});
  assert.match(active,/Evaluación diagnóstica pedagógica activada/);
  assert.match(active,/Resultados pendientes: formule decisiones únicamente de manera condicional/);
});

test('la orientación evaluativa evita interpretar Nota como calificación y protege la frecuencia docente',()=>{
  assert.doesNotMatch(runtime,/<label>Nota</);
  assert.match(runtime,/Observación o decisión docente/);
  assert.match(template,/no exige evaluar cada semana ni fija una cantidad de observaciones/i);
  assert.match(runtime,/La frecuencia la determina la persona docente/i);
});
