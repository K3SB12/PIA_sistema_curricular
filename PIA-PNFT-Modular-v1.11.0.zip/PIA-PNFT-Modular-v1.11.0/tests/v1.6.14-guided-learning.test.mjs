import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

test('la portada identifica el recorrido como ejemplo formativo',async()=>{
  const [body,learning]=await Promise.all([read('src/templates/body-open.html'),read('src/learning/experience.js')]);
  assert.match(body,/Explorar un ejemplo de planeamiento/);
  for(const text of ['Un ejemplo, nunca una receta','No sustituye el criterio docente','Los números son momentos del recorrido, no grados escolares'])assert.match(learning,new RegExp(text,'i'));
});

test('el recorrido conecta siete momentos con las funciones existentes de PIA',async()=>{
  const learning=await read('src/learning/experience.js');
  for(const text of ['El horizonte','El punto de partida','La ruta curricular','Vivir la metodología','Mirar el semestre','Construir una semana','Revisar y continuar'])assert.match(learning,new RegExp(text,'i'));
  for(const text of ['RdA','diagnóstico','trayectoria','prompt semestral','Afinar semana con IA','Guardar · JSON','Exportar · PDF o Word'])assert.match(learning,new RegExp(text,'i'));
});

test('los tres laboratorios conservan la estructura documentada de las metodologías',async()=>{
  const learning=await read('src/learning/experience.js');
  for(const text of ['Objetivo, contenido en el juego, reto, normas, incentivos, realimentación y evaluación','Comprender (gran idea, pregunta esencial y reto), Investigar','Empatizar, Definir, Idear, Prototipar y Probar/Evaluar'])assert.ok(learning.includes(text),`Falta ${text}`);
  assert.match(learning,/La duración del reto se decide según su alcance; no se impone un único reto semestral/);
});

test('currículo, ejemplo y decisión docente permanecen diferenciados',async()=>{
  const learning=await read('src/learning/experience.js');
  for(const text of ['Referente oficial','Ejemplo formativo','Decisión docente'])assert.match(learning,new RegExp(text,'i'));
  assert.match(learning,/PNFT_DATA/);
  assert.match(learning,/RDA_POR_CICLO/);
  assert.match(learning,/PIACurricularProgression\.resolveConcept/);
  assert.doesNotMatch(learning,/\b(obtenerDatosPlan|markDirty|cargarPlan|state\.projection)\b/);
});

test('Proyecto en secundaria conserva etapas, indicadores y tiempo sin duplicar evidencia',async()=>{
  const learning=await read('src/learning/experience.js');
  for(const text of ['Etapa inicial','Etapa de desarrollo','Etapa final','Prototipar','Probar/Evaluar','evite contabilizar dos veces la misma evidencia'])assert.match(learning,new RegExp(text,'i'));
  assert.match(learning,/PIAProjectComponentCatalog\.indicators/);
  assert.match(learning,/La propuesta excede el bloque disponible/);
});

test('la experiencia es local, independiente, accesible y no forma parte de la salida oficial',async()=>{
  const [learning,css,runtime]=await Promise.all([read('src/learning/experience.js'),read('src/learning/experience.css'),read('src/application/enhancements.js')]);
  assert.match(learning,/pia\.learning\.example\.v1/);
  assert.match(learning,/previousFocus/);
  assert.match(learning,/aria-current="step"/);
  assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);
  assert.match(css,/@media print[^}]+#piaMethodologyGame/s);
  assert.match(runtime,/if\(event\.target\.closest\?\.\('#piaMethodologyGame'\)\)return/);
  assert.match(runtime,/portableDocument\.querySelector\('#piaLearningRoot'\)\?\.replaceChildren\(\)/);
});
