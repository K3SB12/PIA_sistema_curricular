import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,coreSource,dataSource,rdaSource,profileSource,promptSource]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/domain/projection/projection-core.js'),
  read('src/data/pnft-data.js'),read('src/data/rda-por-ciclo.js'),read('src/data/evaluation-profiles.js'),read('src/prompts/semester-projection-prompt.js')
]);

test('el perfil mostrado requiere confirmación explícita y Proyecto permanece condicionado',()=>{
  for(const id of ['piaEvaluationProfileConfirmed','piaEvaluationConfirmationStatus'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/if\(!state\.evaluation\.confirmed\)return notify\('Confirme explícitamente el perfil/);
  assert.match(runtime,/const compatible=Boolean\(state\.evaluation\.confirmed\)&&profileHasProject/);
  assert.doesNotMatch(runtime,/piaEvaluationProfile'\)\.value;state\.evaluation\.confirmed=true/);
});

test('ambos módulos requieren confirmación de un marco temporal que cubra los dos periodos',()=>{
  assert.match(template,/id="piaMultiModuleConfirmed"/);
  assert.match(template,/Para una proyección semestral ordinaria seleccione un solo módulo/);
  assert.match(runtime,/modules\.length===2&&!state\.projection\.multiModuleConfirmed/);
  assert.match(runtime,/marco temporal cubre expresamente los dos periodos/i);
});

test('el presupuesto neto descuenta reservas declaradas y se conserva en planes v6',()=>{
  for(const id of ['piaNonTeachingLessons','piaEvaluationReserveLessons','piaNetTimeBudget'])assert.match(template,new RegExp(`id="${id}"`));
  const context=vm.createContext({result:null,encodeURIComponent});
  vm.runInContext(`${coreSource}\nresult=PIAProjectionCore;`,context);
  const migrated=context.result.migrate({pia:{calendar:{weeks:22,diagnosisLessons:2,nonTeachingLessons:4,evaluationReserveLessons:2}}});
  assert.equal(migrated.calendar.nonTeachingLessons,4);
  assert.equal(migrated.calendar.evaluationReserveLessons,2);
  assert.match(runtime,/net=Math\.max\(0,administrative-reserved\)/);
  assert.match(promptSource,/minutos netos disponibles, minutos asignados y diferencia/i);
});

test('la comprobación de IA declara sus límites y usa los catálogos propios de Preescolar',()=>{
  assert.match(runtime,/comprobaciones técnicas verificables/i);
  assert.match(runtime,/No sustituye la revisión curricular ni el criterio profesional/i);
  assert.match(runtime,/PIAPreschoolCurriculum\.PROCEDURAL_KNOWLEDGE/);
  assert.match(runtime,/PIAPreschoolCurriculum\.ATTITUDINAL_KNOWLEDGE/);
  assert.match(runtime,/Trazabilidad de saberes/);
  assert.match(runtime,/Trazabilidad de RdA/);
  assert.match(runtime,/Balance temporal verificable/);
});

test('los 236 indicadores de las 20 combinaciones llegan completos al prompt semestral',()=>{
  const context=vm.createContext({result:null});
  vm.runInContext(`${dataSource}\n${rdaSource}\n${profileSource}\n${promptSource}\nresult={data:PNFT_DATA,rdas:RDA_POR_CICLO,profiles:PIAEvaluationProfiles,prompt:PIASemesterPrompt};`,context);
  const cycleFor=level=>level==='0°'?'Materno Infantil/Transición':['1°','2°','3°'].includes(level)?'I Ciclo':['4°','5°','6°'].includes(level)?'II Ciclo':'III Ciclo';
  let combinations=0,indicatorsChecked=0;
  for(const [level,modules] of Object.entries(context.result.data))for(const [module,areas] of Object.entries(modules)){
    combinations++;
    const cycle=cycleFor(level),concepts=[];
    for(const [area,payload] of Object.entries(areas))for(const saber of payload.saberes||[])concepts.push({name:saber.nombre,module,area,indicators:[...(saber.indicadores||[])]});
    const rdaItems=Object.keys(areas).map(area=>({area,text:context.result.rdas[cycle]?.[area]})).filter(item=>item.text);
    const indicators=concepts.flatMap(item=>item.indicators);
    const profile=context.result.profiles.defaultForCycle(cycle);
    const text=context.result.prompt.build({level,cycle,weeks:22,lessons:44,netLessons:40,netMinutes:1600,nonTeachingLessons:1,evaluationReserveLessons:1,blockMinutes:profile.blockMinutes,diagnosisLessons:2,modules:[module],areas:Object.keys(areas),methodology:level==='0°'?'ABJ':['1°','2°','3°'].includes(level)?'ABJ':['4°','5°','6°'].includes(level)?'ABR':'APD',axes:[],rdas:rdaItems.map(item=>item.text),rdaItems,concepts,procedural:['Colabora'],attitudinal:['Aprender del error'],indicators,evaluationProfile:profile,evaluationProfileConfirmed:true,evaluationInstruments:[],projectPlanning:{enabled:false}});
    for(const indicator of indicators){assert.ok(text.includes(indicator),`${level} ${module}: indicador omitido`);indicatorsChecked++;}
    for(const item of rdaItems)assert.ok(text.includes(item.text),`${level} ${module}: RdA omitido`);
  }
  assert.equal(combinations,20);
  assert.equal(indicatorsChecked,236);
});
