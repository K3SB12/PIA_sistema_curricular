import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

test('la portada es local, reversible y queda fuera de impresión', async () => {
  const [body, identity, css, runtime] = await Promise.all([read('src/templates/body-open.html'),read('src/templates/institutional-identity.html'),read('src/styles/08-enhancements.css'),read('src/application/enhancements.js')]);
  assert.match(body, /id="piaStartPlanning"/); assert.match(body, /id="piaWelcomeLoad"/);
  assert.match(identity, /id="piaShowWelcome"/); assert.match(css, /@media print[^}]+\.pia-welcome/s);
  assert.match(runtime, /pia\.skipWelcome/);
});

test('diagnóstico admite hasta dos lecciones sin eliminar semanas', async () => {
  const [html, runtime] = await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js')]);
  assert.match(html, /id="piaDiagnosisLessons"[^>]+max="2"/);
  assert.match(runtime, /Math\.min\(2/); assert.match(runtime, /value\)>2\).*value='2'/); assert.match(runtime, /apply\(0,first\);apply\(1,second\)/);
  assert.doesNotMatch(runtime, /splice\([^\n]+diagn/i);
});

test('contexto DUA separa perfil, tecnología, punto de partida y referencias PNFT', async () => {
  const [html,runtime] = await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js')]);
  for (const id of ['piaImplementationProfile','piaTechnologyScenario','piaGroupDiagnosis','piaReferenceLevel','piaReferenceIndicator']) assert.match(html,new RegExp(`id="${id}"`));
  assert.match(html,/No incluya datos personales del estudiantado/);
  for(const label of ['Organización multigrado o grupos espejo','Atención a alta dotación, talentos y creatividad','Contexto de pueblos originarios y su cosmovisión','Apoyos educativos definidos institucionalmente'])assert.match(html,new RegExp(label,'i'));
  assert.match(html,/id="piaContextEnabled"/); assert.match(runtime,/state\.context\?\.enabled&&profiles/); assert.match(runtime,/if\(!state\.context\?\.enabled\)return otherMethod\+references/);
  assert.match(runtime,/Seleccione una metodología activa antes de generar el prompt semestral/);
});

test('los tres editores de prompt conservan borrador y exigen confirmación para sustituirlo', async () => {
  const [dialogs, runtime] = await Promise.all([read('src/templates/dialogs.html'),read('src/application/enhancements.js')]);
  for (const id of ['piaSavePrompt','piaUpdatePrompt','piaResetPrompt','piaSaveWeeklyPrompt','piaUpdateWeeklyPrompt','piaResetWeeklyPrompt']) assert.match(dialogs,new RegExp(`id="${id}"`));
  assert.match(runtime,/savePromptChanges/); assert.match(runtime,/¿Actualizar el prompt con los datos actuales/); assert.match(runtime,/¿Restablecer la propuesta generada/);
});

test('las referencias semanales se guardan y llegan a Word y PDF con procedencia', async () => {
  const [runtime, exporter] = await Promise.all([read('src/application/enhancements.js'),read('src/infrastructure/export/pdf-exporter.js')]);
  assert.match(runtime,/referenceIndicatorIds/); assert.match(runtime,/referenceExportForWeek/);
  assert.match(exporter,/Indicadores de referencia del currículo del PNFT/g);
});
