// PIA_RDA_ROUTE_TEST_START
import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = file => readFile(resolve(root, file), 'utf8');
const files = {
    pnft: await read('src/data/pnft-data.js'),
    rda: await read('src/data/rda-por-ciclo.js'),
    progression: await read('src/data/curricular-progression.js'),
    progressionService: await read('src/domain/curriculum/curricular-progression-service.js'),
    preschool: await read('src/data/preschool-curriculum.js'),
    catalog: await read('src/data/rda-contribution-catalog.js'),
    route: await read('src/domain/curriculum/rda-route-service.js'),
    view: await read('src/ui/rda-route-view.js')
};

function api(track = 'optimal') {
    const context = vm.createContext({ result: null, console });
    vm.runInContext(`${files.pnft}\n${files.rda}\n${files.progression}\n${files.progressionService}\n${files.preschool}\n${files.catalog}\n${files.route}\n${files.view}\nresult={catalog:PIARdaContributionCatalog,service:PIARdaRouteService,view:PIARdaRouteView,graph:PIARdaContributionCatalog.build({preschoolTrack:${JSON.stringify(track)}})};`, context);
    return context.result;
}

test('el grafo estructural cubre 0°–9°, las 38 familias y conserva separados los RdA', () => {
    const { graph, service } = api();
    assert.deepEqual(Array.from(graph.levelOrder), ['0°','1°','2°','3°','4°','5°','6°','7°','8°','9°']);
    assert.equal(graph.nodes.families.length, 38);
    assert.equal(graph.nodes.rdas.length, 16);
    assert.equal(new Set(graph.nodes.knowledge.map(item => item.level)).size, 10);
    assert.equal(graph.nodes.knowledge.length, 236);
    assert.equal(graph.nodes.indicators.length, 236);
    assert.equal(service.audit(graph).valid, true);
    assert.equal(service.audit(graph).unresolved.length, 0);
});

test('las correspondencias pedagógicas están separadas y permanecen vacías sin fuente', () => {
    const { catalog, graph } = api();
    assert.equal(catalog.VALIDATED_PEDAGOGICAL_CORRESPONDENCES.length, 0);
    assert.equal(graph.validatedPedagogicalCorrespondences.length, 0);
    assert.ok(graph.edges.some(edge => edge.type === 'within-cycle-area-rda-scope'));
    assert.equal(graph.edges.some(edge => edge.type === 'validated-contribution'), false);
    assert.equal(graph.edges.every(edge => edge.semanticClaim === false), true);
});

test('una correspondencia solo se valida con literalidad, fuente, aprobación y límite expreso', () => {
    const base = api().graph;
    const indicator = base.nodes.indicators[0];
    const knowledge = base.nodes.knowledge.find(item => item.id === indicator.knowledgeId);
    const rdaId = api().catalog.rdaId(knowledge.cycle, knowledge.area);
    const rda = base.nodes.rdas.find(item => item.id === rdaId);
    const valid = {
        correspondenceId:'fixture-validado', indicatorId:indicator.id, rdaId, relation:'validated-contribution', status:'validated',
        indicatorText:indicator.text, rdaText:rda.text, partialContribution:true,
        source:{file:'fuente-validada',locator:'registro 1',version:'1'},
        approval:{authority:'Autoridad curricular de prueba',date:'2026-09-14',version:'1'}
    };
    const validGraph = api().catalog.build({validatedPedagogicalCorrespondences:[valid]});
    assert.equal(api().service.audit(validGraph).invalidCorrespondences.length, 0);
    const invalidGraph = api().catalog.build({validatedPedagogicalCorrespondences:[{...valid,approval:{}}]});
    assert.equal(api().service.audit(invalidGraph).invalidCorrespondences.length, 1);
});

test('Preescolar usa exclusivamente el itinerario activo y no mezcla Básico con Óptimo', () => {
    const basic = api('basic').graph;
    const optimal = api('optimal').graph;
    const current = graph => graph.nodes.knowledge.filter(item => item.level === '0°');
    assert.equal(current(basic).length, 14);
    assert.equal(current(optimal).length, 18);
    assert.equal(current(basic).every(item => item.preschoolTrack === 'basic-required'), true);
    assert.equal(current(optimal).every(item => item.preschoolTrack === 'optimal'), true);
    assert.equal(current(basic).some(item => item.name === 'Hardware.'), false);
    assert.equal(current(optimal).some(item => item.name === 'Hardware.'), true);
    assert.equal(current(basic).some(item => item.name === 'Realidad aumentada.'), false);
    assert.equal(current(optimal).some(item => item.name === 'Realidad aumentada.'), true);
});

test('las 20 combinaciones nivel–módulo producen rutas estructurales resolubles', () => {
    const { graph, service } = api();
    for (const level of graph.levelOrder) {
        for (const moduleName of ['Módulo 1','Módulo 2']) {
            const records = graph.nodes.knowledge.filter(item => item.level === level && item.module === moduleName);
            assert.ok(records.length > 0, `${level} ${moduleName}: sin saberes`);
            const areas = [...new Set(records.map(item => item.area))];
            const route = service.buildRoute(graph, {level,modules:[moduleName],areas,conceptIds:records.map(item => item.projectionConceptId)});
            assert.equal(route.items.length, records.length, `${level} ${moduleName}: ruta incompleta`);
            assert.equal(route.items.every(item => item.family && item.rda && item.now.indicators.length), true, `${level} ${moduleName}: relación sin resolver`);
            assert.equal(route.items.every(item => item.cycles.flatMap(cycle => cycle.milestones).length === 10), true, `${level} ${moduleName}: trayectoria 0°–9° incompleta`);
        }
    }
});

test('la Ruta presenta solo la selección AHORA y mantiene ANTES/DESPUÉS como referencia', () => {
    const { graph, service } = api();
    const selected = graph.nodes.knowledge.find(item => item.level === '7°' && item.module === 'Módulo 1' && item.area === 'Programación y Algoritmos' && item.name === 'Algoritmo');
    const route = service.buildRoute(graph, { level:'7°', modules:['Módulo 1'], areas:['Programación y Algoritmos'], conceptIds:[selected.projectionConceptId] });
    assert.equal(route.status, 'ready');
    assert.equal(route.readOnly, true);
    assert.equal(route.currentCurriculumScope, 'AHORA');
    assert.equal(route.items.length, 1);
    assert.equal(route.items[0].now.name, 'Algoritmo');
    assert.equal(route.items[0].before.level, '5°');
    assert.equal(route.items[0].after.level, '9°');
    assert.equal(route.items[0].pedagogicalCorrespondence.status, 'pending-validation');
    assert.deepEqual(Array.from(route.items[0].cycles, cycle => cycle.cycle), ['Materno Infantil/Transición','I Ciclo','II Ciclo','III Ciclo']);
    assert.deepEqual(Array.from(route.items[0].cycles.flatMap(cycle => cycle.milestones), item => item.level), ['0°','1°','2°','3°','4°','5°','6°','7°','8°','9°']);
    const secondCycle = route.items[0].cycles.find(cycle => cycle.cycle === 'II Ciclo');
    assert.equal(secondCycle.milestones.find(item => item.level === '6°').status, 'no-curricular-record');
});

test('la vista es de solo lectura, presenta ciclos completos y no ofrece incorporación curricular', () => {
    const { graph, service, view } = api();
    const selected = graph.nodes.knowledge.find(item => item.level === '8°' && item.module === 'Módulo 1' && item.area === 'Computación física y Robótica' && item.name === 'Robot');
    const route = service.buildRoute(graph, { level:'8°', modules:['Módulo 1'], areas:['Computación física y Robótica'], conceptIds:[selected.projectionConceptId] });
    const html = view.render(route);
    for (const text of ['Ruta hacia el RdA','Trayectoria curricular de Preescolar a 9.º','Materno Infantil/Transición','I Ciclo','II Ciclo','III Ciclo','AHORA','Correspondencia pedagógica','Pendiente de validación curricular','solo lectura','no modifica el plan','no afirma dominio']) assert.match(html, new RegExp(text, 'i'));
    assert.match(html, /No aplica para este ciclo/);
    assert.match(html, /Área no presente en esta combinación/);
    assert.match(html, /Sin abordaje conceptual registrado/);
    assert.doesNotMatch(html, /Incorporar al planeamiento|Seleccionar para el plan|Marcar como alcanzado/i);
    assert.doesNotMatch(html, /\b\d+\s*%|porcentaje/i);
});

test('los cuatro archivos mantienen el alcance aislado y los marcadores autorizados', () => {
    assert.match(files.catalog, /PIA_RDA_CONTRIBUTION_CATALOG_START[\s\S]*PIA_RDA_CONTRIBUTION_CATALOG_END/);
    assert.match(files.route, /PIA_RDA_ROUTE_SERVICE_START[\s\S]*PIA_RDA_ROUTE_SERVICE_END/);
    assert.match(files.view, /PIA_RDA_ROUTE_VIEW_START[\s\S]*PIA_RDA_ROUTE_VIEW_END/);
    assert.match(files.view, /#piaRdaRoute/);
    assert.match(files.view, /piaAdvancedModal/);
    for (const source of [files.catalog, files.route, files.view]) {
        assert.doesNotMatch(source, /localStorage|schemaVersion|aiPrompts|obtenerDatosPlan|cargarPlan|generarPrompt|exportarPDF|exportarWord/);
    }
});
// PIA_RDA_ROUTE_TEST_END
