import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,dialogs,readme]=await Promise.all([
  read('src/templates/enhancements.html'),
  read('src/application/enhancements.js'),
  read('src/styles/08-enhancements.css'),
  read('src/templates/dialogs.html'),
  read('README.md')
]);

test('secundaria presenta una sola proyección con varias organizaciones posibles',()=>{
  assert.match(template,/Organice la ruta curricular del semestre/);
  assert.match(template,/(?:no|sin) crea(?:r)? otro planeamiento/i);
  assert.match(template,/Desarrollar la mayoría de los aprendizajes mediante el Proyecto/);
  assert.match(template,/Iniciar el Proyecto y alternarlo con otros aprendizajes/);
  assert.match(template,/Preparar algunos aprendizajes antes de iniciar el Proyecto/);
  assert.match(runtime,/Existe una sola proyección del módulo/);
  assert.match(template,/no se suman automáticamente como un segundo proceso/i);
});

test('la segunda metodología completa permanece como decisión excepcional explícita',()=>{
  assert.match(template,/id="piaSecondMethodWrap"/);
  assert.match(template,/Segunda metodología completa antes del Proyecto/);
  assert.match(template,/Dos metodologías completas coordinadas/);
  assert.match(runtime,/completeMode=\['sequential-complete','coordinated-complete'\]\.includes\(mode\)/);
  assert.doesNotMatch(runtime,/secondMethodWrap\.hidden=!completeMode/);
});

test('diagnóstico conserva y explica las condiciones de entrada',()=>{
  assert.match(template,/value="current-entry">Condiciones de entrada para los saberes actuales/);
  assert.match(template,/id="piaDiagnosticPriorSourceHelp"/);
  assert.match(runtime,/necesarios para iniciar los saberes actuales/);
  assert.match(runtime,/sin exigir como dominio previo sus indicadores finales/);
});

test('los diálogos de prompt se adaptan a monitores de menor altura',()=>{
  assert.match(styles,/\.modal\s*\{[^}]*overflow-y:auto/s);
  assert.match(styles,/\.modal>\.modal-content\s*\{[^}]*max-height:calc\(100dvh/s);
  assert.match(styles,/\.modal>\.modal-content\s*\{[^}]*overflow-y:auto/s);
  for(const label of ['Copiar Prompt','Abrir en Copilot','Abrir en ChatGPT','Cerrar'])assert.match(dialogs,new RegExp(label));
});

test('la terminología visible usa lecciones pedagógicas',()=>{
  assert.doesNotMatch(template,/lecciones administrativas|lecciones curriculares/i);
  assert.doesNotMatch(runtime,/lecciones administrativas|lecciones curriculares|\badministrativas\b/i);
  assert.match(runtime,/lecciones pedagógicas/);
  assert.match(readme,/dos lecciones pedagógicas/);
});
