import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const runtime = readFileSync(new URL('../src/application/enhancements.js', import.meta.url), 'utf8');
const template = readFileSync(new URL('../src/templates/enhancements.html', import.meta.url), 'utf8');
const core = readFileSync(new URL('../src/domain/projection/projection-core.js', import.meta.url), 'utf8');

test('la selección manual permanece oculta y desactivada por defecto', () => {
  assert.match(template, /id="piaDiagnosticManualInstrument" type="checkbox"/);
  assert.match(template, /id="piaDiagnosticManualInstrumentPanel" hidden/);
  assert.match(core, /manualInstrumentSelection:false/);
  assert.match(runtime, /panel\.hidden=!manual/);
});

test('sin selección manual la IA recomienda una sola combinación con criterios MEP y PNFT', () => {
  assert.match(runtime, /Con base en las orientaciones del MEP y del PNFT, recomiende una sola técnica pertinente/);
  assert.match(runtime, /Recomiende un solo instrumento congruente con la técnica, la actividad y la evidencia/);
  assert.match(runtime, /No enumere varias alternativas como respuesta final/);
});

test('el alcance diagnóstico coincide con saberes C-P-A del módulo y máximo dos lecciones', () => {
  assert.match(runtime, /saberes conceptuales, procedimentales y actitudinales del módulo correspondiente/);
  assert.match(runtime, /sin convertir los indicadores de logro del nivel actual en requisitos de dominio previo/);
  assert.match(runtime, /sin fragmentar el diagnóstico en una actividad independiente por cada saber/);
  assert.match(runtime, /en un período no mayor a dos lecciones/);
  assert.doesNotMatch(runtime, /\.replace\([^\n]*conjunto acotado[^\n]*no evalúe todo el semestre[^\n]*mismo texto/);
});

test('la migración activa el panel para selecciones explícitas históricas', () => {
  const context = { console };
  vm.createContext(context);
  vm.runInContext(`${core}\nresult=PIAProjectionCore;`, context);
  const migrated = context.result.migrate({ pia: { diagnostic: { technique: 'observation', instrument: 'checklist' } } });
  assert.equal(migrated.diagnostic.manualInstrumentSelection, true);
  const automatic = context.result.migrate({ pia: { diagnostic: { technique: 'ai-recommend', instrument: 'ai-recommend' } } });
  assert.equal(automatic.diagnostic.manualInstrumentSelection, false);
});

test('la selección manual incompleta no genera un prompt ambiguo', () => {
  assert.match(runtime, /Complete la técnica y el instrumento o desactive la selección manual/);
  assert.match(runtime, /diagnostic\.manualInstrumentSelection&&\(diagnostic\.technique==='ai-recommend'\|\|diagnostic\.instrument==='ai-recommend'\)/);
});
