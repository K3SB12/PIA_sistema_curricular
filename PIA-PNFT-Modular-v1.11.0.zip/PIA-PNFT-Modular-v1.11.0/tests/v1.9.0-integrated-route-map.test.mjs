import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,core,catalog]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/styles/08-enhancements.css'),read('src/domain/projection/projection-core.js'),read('src/data/project-component-catalog.js')
]);

test('el mapa integral representa una sola ruta con Proyecto, semanas, capas e inspector',()=>{
  for(const id of ['piaRouteMap','piaRouteInspector','piaRouteTimeline','piaRouteAssignments','piaRouteAnalyze','piaRoutePlannerApply'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/mediación curricular \+ componente Proyecto/);
  assert.match(runtime,/PIAProjectComponentCatalog\.phases\.map/);
  for(const layer of ['procedural','attitudinal','axes','rda','evaluation'])assert.match(template,new RegExp(`data-pia-route-layer="${layer}"`));
});

test('las herramientas del mapa son locales, accesibles y no dependen de arrastrar',()=>{
  for(const id of ['piaRouteAddGroup','piaRouteConnect','piaRouteUndo','piaRouteRedo','piaRouteZoomOut','piaRouteZoomIn','piaRouteCenter','piaRouteExport','piaRoutePrint'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/function exportRoutePng/);
  assert.match(runtime,/data-pia-route-node/);
  assert.doesNotMatch(runtime,/fetch\(|XMLHttpRequest|WebSocket/);
  assert.match(styles,/@media\(max-width:520px\)/);
});

test('el esquema v6 migra y sanea el mapa sin perder asignaciones históricas',()=>{
  const context=vm.createContext({result:null,encodeURIComponent,Set,Object,Array,Math,Number,String,Boolean,JSON});
  vm.runInContext(`${core}\nresult=PIAProjectionCore;`,context);
  const migrated=context.result.migrate({pia:{methodology:{routeAssignments:{a:{role:'direct',note:'Histórico',phaseId:'prototype',weekStart:4,weekEnd:7,color:'#123456'}}},routeMap:{confirmed:true,view:'map-weeks',zoom:999,groups:[{id:'g1',title:'Grupo'}],connections:[{from:'a',to:'a'}]}}});
  assert.equal(migrated.schemaVersion,6);
  assert.equal(migrated.methodology.routeAssignments.a.note,'Histórico');
  assert.equal(migrated.methodology.routeAssignments.a.phaseId,'prototype');
  assert.equal(migrated.routeMap.zoom,180);
  assert.equal(migrated.routeMap.connections.length,0,'el autoenlace inválido no se conserva');
});

test('el prompt de análisis compara enfoques sin modificar ni certificar currículo',()=>{
  assert.match(runtime,/ANÁLISIS COMPARADO DE LA RUTA CURRICULAR DE III CICLO/);
  assert.match(runtime,/Devuelva 2 o 3 enfoques técnicamente válidos/);
  assert.match(runtime,/No cambie silenciosamente ninguna decisión/);
  assert.match(runtime,/no certifica el RdA/i);
  assert.match(runtime,/PIA no lo envía automáticamente/);
});

test('Proyecto conserva literalmente las cinco fases y los tres indicadores iniciales protegidos',()=>{
  for(const phase of ['Empatizar','Definir','Idear','Prototipar','Probar/Evaluar'])assert.match(catalog,new RegExp(phase.replace('/','\\/')));
  for(const text of [
    'Describir las necesidades, deseos y motivaciones de usuarios o clientes que tienen un problema o situación por resolver.',
    'Sintetizar los hallazgos relacionados con los intereses y necesidades del usuario o cliente, de modo que se entienda con claridad el problema o situación por resolver.',
    'Seleccionar la idea más eficiente para ofrecer una posible solución a un problema o situación por resolver.'
  ])assert.ok(catalog.includes(text));
  assert.match(runtime,/Vincule indicador\(es\) oficiales del módulo/);
});

test('la tabla y el mapa comparten los mismos atributos editables',()=>{
  for(const attribute of ['data-pia-route-role','data-pia-route-phase','data-pia-route-start','data-pia-route-end','data-pia-route-note'])assert.match(runtime,new RegExp(attribute));
  assert.match(template,/Seleccione “Tabla accesible”.*misma información/i);
  assert.match(styles,/pia-route-sticky-actions/);
});
