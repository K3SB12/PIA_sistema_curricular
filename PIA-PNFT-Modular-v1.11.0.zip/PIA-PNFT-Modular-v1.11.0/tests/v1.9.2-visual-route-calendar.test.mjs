import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,agents,spec]=await Promise.all([
  read('src/templates/enhancements.html'),
  read('src/application/enhancements.js'),
  read('src/styles/08-enhancements.css'),
  read('AGENTS.md'),
  read('SPEC.md')
]);

test('el calendario pertenece al constructor de la ruta y no al planeamiento semanal',()=>{
  assert.match(template,/id="piaRouteTimelineSection"/);
  assert.match(template,/Calendario visual de la ruta/);
  assert.match(template,/El mapa muestra qué se relaciona; esta línea temporal permite revisar cuándo ocurre/);
  assert.match(styles,/data-view="map".*#piaRouteTimelineSection/);
});

test('la línea temporal contiene las cinco capas acordadas',()=>{
  for(const label of ['Diagnóstico','Mediación curricular','Proyecto · APD','Trabajo cotidiano','Tareas y calendario'])assert.ok(runtime.includes(label),label);
  for(const label of ['Desarrollo y práctica en lecciones pedagógicas','Desarrollo en lecciones y aplicación en el Proyecto','Inicial · Empatizar / Definir / Idear','Desarrollo · Prototipar','Cierre · Probar / Evaluar'])assert.ok(runtime.includes(label),label);
});

test('PIA no inventa inicio del Proyecto, conflictos ni fechas',()=>{
  assert.doesNotMatch(runtime,/projectStart=projectWeeks\?Math\.max/);
  assert.match(runtime,/PIA no lo ubica hasta que se confirmen semanas/);
  assert.match(runtime,/PIA no inventa su semana ni las convierte automáticamente en conflicto/);
  assert.match(spec,/calendario visual/i);
});

test('solo las decisiones evaluativas vigentes y confirmadas se ubican',()=>{
  assert.match(runtime,/guidanceStale/);
  assert.match(runtime,/item\.status==='confirmed'/);
  assert.match(runtime,/Las ventanas evaluativas confirmadas corresponden a una configuración anterior/);
  assert.match(runtime,/Seguimiento continuo según evidencia; no implica registrar cada semana/);
});

test('la visualización tiene desplazamiento móvil y alternativa tabular accesible',()=>{
  assert.match(template,/Solo ubica semanas y decisiones declaradas o confirmadas/);
  assert.match(runtime,/role="region"/);
  assert.match(runtime,/Consultar el calendario como tabla accesible/);
  assert.match(styles,/\.pia-route-calendar-scroll\{overflow-x:auto/);
  assert.match(styles,/position:sticky/);
});

test('la política conserva una sola ruta y el calendario no certifica viabilidad',()=>{
  assert.match(agents,/calendario visual/);
  assert.match(agents,/no escribe semanas/i);
  assert.match(agents,/no certifica viabilidad/i);
});

test('la revisión guiada usa lenguaje común y aclara que no crea categorías oficiales',()=>{
  for(const key of ['prepares','supports','evidences','continues','depends-on'])assert.ok(runtime.includes(key),key);
  assert.match(runtime,/Relacionar saberes/);
  assert.match(runtime,/No debe justificar cada conexión/);
  assert.doesNotMatch(runtime,/if\(!note\)return notify/);
  assert.match(runtime,/Ayuda de PIA, no categoría oficial del PNFT/);
  assert.match(runtime,/function routeRelationReview/);
  assert.match(runtime,/Relación registrada/);
});

test('los candidatos por color exponen señales textuales sin crear ni validar conexiones',()=>{
  assert.match(runtime,/Posibles relaciones para explorar/);
  assert.match(runtime,/Términos coincidentes/);
  assert.match(runtime,/Verbos iniciales/);
  assert.match(runtime,/El color explica por qué PIA muestra cada opción; no certifica la integración/);
  assert.match(runtime,/data-pia-route-candidate/);
  assert.match(runtime,/data-pia-route-candidate-type/);
  assert.match(styles,/\.pia-route-candidate\.is-content-area/);
  assert.match(styles,/\.pia-route-candidate\.is-reviewed/);
});

test('la ruta usa únicamente ubicaciones comprensibles y migra etiquetas anteriores',()=>{
  for(const label of ['Pendiente de ubicar','Lecciones pedagógicas','Componente Proyecto','Lecciones y Proyecto'])assert.ok(runtime.includes(label),label);
  assert.match(runtime,/ROUTE_ROLE_ALIASES/);
  assert.match(template,/Ubicación prevista de cada saber e indicador/);
  assert.doesNotMatch(template,/Función prevista de cada saber/);
});

test('el producto permanece flexible sin perder la acción del indicador',()=>{
  assert.match(template,/Explorar formatos posibles según el currículo/);
  assert.match(runtime,/function routeProductOptions/);
  assert.match(runtime,/Producto multimedia/);
  assert.match(runtime,/Alternativa de baja tecnología/);
  assert.match(runtime,/sin imponer que sea programado/);
  assert.match(runtime,/no sustituye una acción técnica exigida/i);
});

test('la trayectoria distingue inicio curricular sin inventar antecedentes',()=>{
  assert.match(runtime,/Este saber inicia en el nivel actual/);
  assert.match(runtime,/no inventará antecedentes/);
  assert.match(runtime,/Antecedente curricular identificado/);
});

test('computadora, tableta y celular conservan controles y alternativas accesibles',()=>{
  assert.match(styles,/@media\(max-width:900px\)/);
  assert.match(styles,/@media\(max-width:700px\)/);
  assert.match(styles,/@media\(max-width:420px\)/);
  assert.match(styles,/\.pia-route-table td:nth-child\(2\)::before\{content:'Ubicación en la ruta'\}/);
  assert.match(styles,/\.pia-route-canvas-shell\{max-height:62dvh;overflow:auto/);
  assert.match(template,/Tabla accesible/);
});
