import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root = resolve(import.meta.dirname, '..');

async function curriculumContext({semester='I', level='2°'}={}) {
  const source = await readFile(resolve(root, 'src/domain/curriculum/curriculum-operations.js'), 'utf8');
  const fields = {semestre:{value:semester}, nivel:{value:level}, ciclo:{value:'I Ciclo'}};
  const context = vm.createContext({
    document:{
      getElementById:id=>fields[id] || null,
      querySelector:()=>null,
      querySelectorAll:()=>[]
    },
    PNFT_DATA:{
      '2°':{
        'Módulo 1':{
          'Apropiación tecnológica y Digital':{saberes:[{nombre:'Dato compartido',indicadores:['Indicador literal M1']}]}
        },
        'Módulo 2':{
          'Programación y Algoritmos':{saberes:[{nombre:'Dato compartido',indicadores:['Indicador literal M2']}]}
        }
      }
    },
    RDA_POR_CICLO:{'I Ciclo':{}},
    PIAProjectionCore:{escapeHtml:value=>String(value)},
    semanas:[],
    saberesSeleccionados:new Set(),
    alert:()=>{},
    confirm:()=>true
  });
  vm.runInContext(source, context);
  return context;
}

test('una semana nueva toma Módulo 1 o Módulo 2 según el semestre', async()=>{
  const first = await curriculumContext({semester:'I'});
  const second = await curriculumContext({semester:'II'});
  assert.deepEqual([...vm.runInContext('normalizarModulosSemana({areas:[],saberes:[]})', first)], ['Módulo 1']);
  assert.deepEqual([...vm.runInContext('normalizarModulosSemana({areas:[],saberes:[]})', second)], ['Módulo 2']);
});

test('un plan anterior con contenido conserva ambos módulos para evitar pérdida', async()=>{
  const context = await curriculumContext();
  const modules = vm.runInContext("normalizarModulosSemana({areas:['Programación y Algoritmos'],saberes:['Dato compartido']})", context);
  assert.deepEqual([...modules], ['Módulo 1','Módulo 2']);
});

test('las referencias compuestas resuelven el indicador del módulo exacto', async()=>{
  const context = await curriculumContext();
  context.semanas.push({
    modulos:['Módulo 2'],
    areas:['Programación y Algoritmos'],
    saberes:['Dato compartido'],
    saberRefs:[{modulo:'Módulo 2',area:'Programación y Algoritmos',nombre:'Dato compartido'}]
  });
  const indicators = vm.runInContext('obtenerIndicadoresLogroSemana(1)', context);
  assert.deepEqual([...indicators], ['Indicador literal M2']);
  assert.doesNotMatch(indicators.join(' '), /M1/);
});

test('la semana ofrece filtro por módulos y un panel curricular plegable', async()=>{
  const week = await readFile(resolve(root, 'src/ui/week-view.js'), 'utf8');
  assert.match(week, /data-pia-week-modules/);
  assert.match(week, /generarSelectorModulosSemana/);
  assert.match(week, /pia-week-curriculum-details/);
  assert.match(week, /Selección curricular de la semana/);
});

test('módulos y referencias semanales atraviesan creación, ajuste y saneamiento', async()=>{
  const initialization = await readFile(resolve(root, 'src/application/initialization.js'), 'utf8');
  const operations = await readFile(resolve(root, 'src/domain/planning/week-operations.js'), 'utf8');
  const enhancements = await readFile(resolve(root, 'src/application/enhancements.js'), 'utf8');
  assert.match(initialization, /modulos:\s*semanaBackup\s*\?\s*normalizarModulosSemana/);
  assert.match(initialization, /saberRefs:\s*semanaBackup\s*\?\s*normalizarReferenciasSaberesSemana/);
  assert.match(operations, /modulos:\s*modulosPredeterminadosSemana\(\)/);
  assert.match(operations, /saberRefs:\s*\[\]/);
  assert.match(enhancements, /modulos:normalizarModulosSemana\(week\)/);
  assert.match(enhancements, /saberRefs:normalizarReferenciasSaberesSemana\(week\)/);
});
