import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const exporterPath = resolve(root, 'src/infrastructure/export/pdf-exporter.js');
const dialogsPath = resolve(root, 'src/templates/dialogs.html');

function extractRange(source, startSignature, endSignature) {
  const start = source.indexOf(startSignature);
  const end = source.indexOf(endSignature, start);
  assert.notEqual(start, -1, `No se encontró ${startSignature}`);
  assert.ok(end > start, `No se pudo delimitar ${startSignature}`);
  return source.slice(start, end);
}

function classList() {
  const values = new Set();
  return {
    add(value) { values.add(value); },
    remove(value) { values.delete(value); },
    contains(value) { return values.has(value); },
  };
}

function field(value = '', checked = true) {
  return { value, checked, textContent: '', style: {}, classList: classList() };
}

function createWordHarness({ popupAllowed = true, includeHeader = true, includeFooter = true } = {}) {
  const fields = {
    nombreArchivo: field('Plan: Prueba/Docente'),
    exportarInformacionGeneral: field('', true),
    exportarSaberes: field('', true),
    exportarSemanas: field('', true),
    exportarReflexiones: field('', true),
    exportarSaberesGlobales: field('', true),
    incluirEncabezado: field('', includeHeader),
    incluirPiePagina: field('', includeFooter),
    direccionRegional: field('Heredia <Norte>'),
    centroEducativo: field('Centro & Escuela'),
    codigoCentro: field('1234'),
    circuito: field('01'),
    nombreDocente: field('Docente de prueba'),
    cursoLectivo: field('2026'),
    ciclo: field('II Ciclo'),
    nivel: field('5'),
    leccionesPlanificadas: field('2'),
    mesInicio: field('Agosto'),
    mesFinal: field('Agosto'),
    metodologiaActiva: field('ABR'),
    metodologiaPersonalizada: field(''),
    queFunciono: field('Colaboración <activa>'),
    queNoFunciono: field('Sin novedad'),
    queMejorar: field('Tiempo'),
    observaciones: field('Atender el contexto'),
  };

  const downloads = [];
  const blobs = [];
  const alerts = [];
  const preview = { html: '', printed: 0, closed: 0, focused: 0, toolbar: null };

  function makeNode(tagName) {
    return {
      tagName,
      children: [],
      style: {},
      className: '',
      textContent: '',
      download: '',
      href: '',
      appendChild(child) { this.children.push(child); },
      click() {
        if (tagName === 'a') downloads.push({ download: this.download, href: this.href });
        if (typeof this.onclick === 'function') this.onclick();
      },
    };
  }

  const previewDocument = {
    write(html) { preview.html = html; },
    close() {},
    createElement: makeNode,
    body: {
      appendChild(node) { preview.toolbar = node; },
    },
  };
  const previewWindow = {
    document: previewDocument,
    focus() { preview.focused += 1; },
    print() { preview.printed += 1; },
    close() { preview.closed += 1; },
  };
  const mainBody = {
    appendChild() {},
    removeChild() {},
  };

  const context = vm.createContext({
    document: {
      getElementById(id) { return fields[id] ?? null; },
      querySelectorAll(selector) {
        if (selector === 'input[name="eje"]:checked') return [{ value: 'pensamiento' }];
        return [];
      },
      createElement: makeNode,
      body: mainBody,
    },
    window: { open() { return popupAllowed ? previewWindow : null; } },
    URL: {
      createObjectURL(blob) { blobs.push(blob); return `blob:word-${blobs.length}`; },
      revokeObjectURL() {},
    },
    Blob,
    alert(message) { alerts.push(message); },
    setTimeout(callback) { callback(); return 1; },
    console: { log() {}, error() {} },
    semanas: [{
      id: 1,
      lecciones: 'Lecciones 1 y 2',
      areas: ['Programación y Algoritmos'],
      indicadores: '<p onclick="malicioso()">Indicador</p><script>malicioso()</script>',
      actividades: '<p>Actividad organizada</p>',
      evaluacion: '<p>Evaluación formativa</p>',
    }],
    RDA_POR_CICLO: {
      'II Ciclo': { 'Programación y Algoritmos': 'Resolver problemas mediante algoritmos.' },
    },
    saberesSeleccionados: new Set(['Algoritmos']),
    saberesProcedimentalesGlobales: new Set(['formula']),
    saberesActitudinalesGlobales: new Set(['aprender']),
    PIAEnhancements: {
      institutionalExportHtml() { return '<section id="identity-export">Lema institucional</section>'; },
      projectExportForWeek() { return {active:true,achievement:[{text:'Logro de Proyecto contextualizado'}],evaluation:[{text:'Evaluación de Proyecto contextualizada'}]}; },
    },
  });

  return { context, fields, downloads, blobs, alerts, preview };
}

test('el modal permite seleccionar Word y dirige la confirmación a exportarAWord', async () => {
  const source = await readFile(exporterPath, 'utf8');
  const dialogs = await readFile(dialogsPath, 'utf8');
  const functions = extractRange(source, '        function mostrarOpcionesExportar()', '        function exportarAWord()');
  const pdfOption = { classList: classList() };
  const wordOption = { classList: classList() };
  const button = field();
  const help = field();
  const modal = field();
  let wordCalls = 0;
  let pdfCalls = 0;
  const context = vm.createContext({
    formatoExportacion: 'pdf',
    document: {
      querySelectorAll(selector) { return selector === '.export-option' ? [pdfOption, wordOption] : []; },
      getElementById(id) {
        return { opcionPDF: pdfOption, opcionWord: wordOption, btnConfirmarExportacion: button, ayudaFormatoExportacion: help, exportarModal: modal }[id] ?? null;
      },
    },
    exportarAWord() { wordCalls += 1; },
    exportarAPDF() { pdfCalls += 1; },
    console: { log() {} },
  });
  vm.runInContext(`${functions}\nseleccionarFormato('word', __word); confirmarExportacion();`, Object.assign(context, { __word: wordOption }));
  assert.equal(context.formatoExportacion, 'word');
  assert.equal(wordCalls, 1);
  assert.equal(pdfCalls, 0);
  assert.equal(button.textContent, '📄 Exportar');
  assert.match(help.textContent, /vista continua/i);

  vm.runInContext('mostrarOpcionesExportar(); confirmarExportacion();', context);
  assert.equal(context.formatoExportacion, 'pdf');
  assert.equal(wordCalls, 1);
  assert.equal(pdfCalls, 1);
  assert.equal(button.textContent, '📄 Exportar');
  assert.match(help.textContent, /imprimirlo como PDF/i);
  assert.match(dialogs, /id="btnConfirmarExportacion"[^>]*>📄 Exportar<\/button>/);
  assert.doesNotMatch(dialogs, />🚀 Exportar PDF<\/button>/);
});

test('Word abre una vista continua, segura, guardable e imprimible', async () => {
  const source = await readFile(exporterPath, 'utf8');
  const wordFunction = extractRange(source, '        function exportarAWord()', '        function exportarAPDF()');
  const harness = createWordHarness();
  vm.runInContext(`${wordFunction}\nexportarAWord();`, harness.context);

  assert.match(harness.preview.html, /MINISTERIO DE EDUCACIÓN PÚBLICA/);
  assert.match(harness.preview.html, /Heredia &lt;Norte&gt;/);
  assert.match(harness.preview.html, /Actividad organizada/);
  assert.match(harness.preview.html, /Indicador de logro del Proyecto/);
  assert.match(harness.preview.html, /Logro de Proyecto contextualizado/);
  assert.match(harness.preview.html, /Indicadores de evaluación del Proyecto/);
  assert.match(harness.preview.html, /Evaluación de Proyecto contextualizada/);
  assert.ok(harness.preview.html.indexOf('identity-export') < harness.preview.html.indexOf('Dirección Regional de Educación'));
  assert.doesNotMatch(harness.preview.html, /projection-export|Matriz semestral aprobada/);
  assert.doesNotMatch(harness.preview.html, /<script/i);
  assert.doesNotMatch(harness.preview.html, /onclick=/i);
  assert.match(harness.preview.html, /page-break-inside:\s*auto/);
  assert.doesNotMatch(harness.preview.html, /page-break-after:\s*always/);
  assert.match(harness.preview.html, /xmlns:w="urn:schemas-microsoft-com:office:word"/);
  assert.match(harness.preview.html, /@page WordSection1/);
  assert.match(harness.preview.html, /mso-page-orientation:\s*landscape/);
  assert.match(harness.preview.html, /class="WordSection1"/);
  assert.match(harness.preview.html, /table-layout:\s*fixed/);
  assert.match(harness.preview.html, /overflow-wrap:\s*break-word/);
  assert.match(harness.preview.html, /class="word-reflection-area" height="100"/);
  assert.match(harness.preview.html, /class="word-observations-area" height="145"/);
  assert.match(harness.preview.html, /background:\s*#ffffff\s*!important/);
  assert.equal(harness.downloads.length, 0, 'La vista previa no debe descargar automáticamente');
  assert.equal(harness.preview.focused, 1);
  assert.equal(harness.preview.toolbar.children.length, 3);

  harness.preview.toolbar.children[0].click();
  assert.equal(harness.downloads.length, 1);
  assert.equal(harness.downloads[0].download, 'Plan- Prueba-Docente.doc');
  assert.equal(harness.blobs[0].type, 'application/msword;charset=utf-8');
  const savedWord = await harness.blobs[0].text();
  assert.match(savedWord, /mso-page-orientation:\s*landscape/);
  assert.match(savedWord, /class="WordSection1"/);

  harness.preview.toolbar.children[1].click();
  harness.preview.toolbar.children[2].click();
  assert.equal(harness.preview.printed, 1);
  assert.equal(harness.preview.closed, 1);

  const artifactDirectory = process.env.PIA_WORD_ARTIFACT_DIR;
  if (artifactDirectory) {
    await mkdir(artifactDirectory, { recursive: true });
    await writeFile(resolve(artifactDirectory, 'word-preview.html'), harness.preview.html, 'utf8');
    await writeFile(resolve(artifactDirectory, harness.downloads[0].download), Buffer.from(await harness.blobs[0].arrayBuffer()));
  }
});

test('si la ventana emergente está bloqueada, Word se descarga como respaldo', async () => {
  const source = await readFile(exporterPath, 'utf8');
  const wordFunction = extractRange(source, '        function exportarAWord()', '        function exportarAPDF()');
  const harness = createWordHarness({ popupAllowed: false });
  vm.runInContext(`${wordFunction}\nexportarAWord();`, harness.context);
  assert.equal(harness.downloads.length, 1);
  assert.match(harness.downloads[0].download, /\.doc$/);
  assert.match(harness.alerts[0], /bloqueó la vista previa/i);
});

test('el escudo institucional conserva un ancho máximo estable en Word', async () => {
  const runtime = await readFile(resolve(root, 'src/application/enhancements.js'), 'utf8');
  assert.match(runtime, /alt="Escudo institucional" width="90" style="width:90px;height:auto;max-height:70px;object-fit:contain"/);
});
