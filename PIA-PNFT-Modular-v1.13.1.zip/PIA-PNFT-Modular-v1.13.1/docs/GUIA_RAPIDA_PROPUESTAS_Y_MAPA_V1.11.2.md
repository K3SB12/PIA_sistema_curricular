# Guía rápida — propuestas, mapa y calendario de la ruta

## Qué hace este módulo

Ayuda a comparar formas posibles de organizar los saberes del módulo entre lecciones pedagógicas y componente Proyecto. No crea un segundo planeamiento, no impone un producto y no reemplaza el criterio docente.

La IA genera las propuestas. PIA prepara la información, comprueba la respuesta y la convierte en mapas y calendarios editables.

## Antes de comenzar

Revise que PIA tenga el nivel, módulo, áreas, saberes, tiempo, diagnóstico, contexto, recursos, DUA, Proyecto y decisiones evaluativas que correspondan. Los campos opcionales no completados se omiten; PIA no los inventa.

## Cinco pasos

1. **Revise la entrada.** Confirme que la selección curricular y el tiempo correspondan al periodo real.
2. **Pulse “Preparar y copiar consulta para la IA”.** PIA reúne la entrada completa y la copia. Si el navegador bloquea la copia, abre la consulta y la deja seleccionada.
3. **Consulte la IA de su preferencia.** Pegue la consulta sin modificarla. La IA debe devolver entre dos y cuatro propuestas realmente diferentes.
4. **Pegue la respuesta completa en PIA.** No necesita localizar ni editar JSON. Pulse “Comprobar y mostrar propuestas”.
5. **Compare y elija.** Abra “Ver mapa y calendario de esta propuesta”. Revise producto posible, agrupaciones, semanas, recursos, riesgos y ajustes. Pulse “Usar como borrador editable” solo en la alternativa que desea revisar con mayor detalle.

No escriba ni complete manualmente la consulta. Si PIA no puede construirla, revise que estén seleccionados el nivel, el módulo, las áreas y los saberes. El mensaje debe indicar esta condición y no continuar con un cuadro vacío.

Las opciones de recuperación no son pasos adicionales: “Regenerar después de cambiar datos” reconstruye la consulta y descarta propuestas anteriores; “Copiar consulta para la IA” vuelve a copiar la misma consulta ya visible.

## Qué comprueba PIA

- Que la respuesta corresponda a la selección actual.
- Que utilice únicamente saberes y fases reconocidos por PIA.
- Que incluya entre dos y cuatro propuestas.
- Que cada saber aparezca una sola vez.
- Que no queden saberes sin organizar.
- Que el tiempo propuesto no exceda el disponible.
- Que las semanas compartidas no se sumen dos veces.

Una propuesta incompleta permanece visible para entender el problema, pero su botón de aplicación queda desactivado.

## Cómo leer el mapa

- **Lecciones pedagógicas:** el saber se desarrolla o fortalece en la mediación curricular.
- **Componente Proyecto:** el saber participa directamente en una fase del Proyecto.
- **Lecciones y Proyecto:** se desarrolla o fortalece en lecciones y se aplica, prueba o mejora en el Proyecto.
- **Pendiente:** la respuesta no aportó una ubicación válida; PIA no la inventa.

El color ayuda a distinguir bloques, pero no demuestra calidad, profundidad ni relación pedagógica. La tabla accesible contiene la misma información para trabajar sin arrastrar elementos.

## Cómo leer el calendario

El calendario muestra cuándo podrían coincidir diagnóstico, lecciones, Proyecto, evaluación y realimentación. Las funciones que comparten semana se cuentan una sola vez. Es una estimación para revisión, no una distribución oficial ni una garantía de viabilidad.

## Ajustar el borrador

Después de elegir una propuesta puede cambiar la ubicación de un saber, la fase, el grupo, las semanas, la evidencia o las relaciones. También puede mover los bloques visualmente. Estos cambios no alteran el currículo oficial.

Use “Vista general” para observar todo el mapa, “Centrar” para recuperar el área de trabajo y “Tabla accesible” cuando utilice una pantalla pequeña o prefiera no arrastrar bloques.

## Responsabilidad profesional

PIA informa riesgos estructurales y temporales. La persona docente o asesora confirma si la organización es pertinente según el diagnóstico, el grupo, los recursos, el calendario institucional, los indicadores y las disposiciones vigentes. Planificar una actividad no certifica aprendizaje, competencia, perfil de salida o RdA alcanzado.
