# Guía rápida — propuestas, mapa y calendario de III Ciclo

## Propósito

Este módulo ayuda a organizar una sola ruta semestral que articula las lecciones pedagógicas y el componente Proyecto. Las propuestas provienen de la herramienta de IA elegida por la persona docente. PIA reúne la información oficial, comprueba la respuesta y la representa; no decide ni certifica la viabilidad pedagógica.

## Antes de solicitar propuestas

1. Seleccione III Ciclo, nivel, módulo, áreas y saberes.
2. Revise las semanas y lecciones disponibles.
3. Complete el contexto y los recursos cuando disponga de esa información.
4. Active **Planificar Proyecto** y revise sus indicadores y fases.
5. Confirme que el diagnóstico, DUA y evaluación reflejen las decisiones disponibles. Los campos opcionales no aportados permanecen como pendientes.

## Solicitar y comparar

1. Abra **Construir mi ruta**.
2. Revise la entrada que PIA muestra.
3. Pulse **Preparar y copiar consulta para la IA**.
4. Pegue la consulta en la herramienta de IA de su preferencia y envíela.
5. Copie la respuesta completa. La primera parte está escrita para la persona docente y la segunda contiene datos técnicos para PIA.
6. Regrese a PIA, pegue toda la respuesta y pulse **Comprobar y mostrar propuestas**.
7. Compare la matriz. Después abra el mapa y calendario de cada alternativa.

## Qué debe mostrar cada propuesta

- Metodología y función durante la ruta.
- Duración y ventana propuesta para el Proyecto.
- Producto o solución posible, recursos y alternativa cuando no exista equipo.
- Diagnóstico como punto de partida, sin resultados inventados.
- Mediación activa y guiada en las lecciones pedagógicas.
- Agrupaciones de saberes y semanas estimadas.
- Empatizar, Definir, Idear, Prototipar y Probar/Evaluar.
- Indicadores oficiales protegidos y saberes del módulo vinculados.
- Puentes que explican cómo lo aprendido en las lecciones se aplica, prueba o mejora en el Proyecto.
- Trabajo cotidiano, tareas, evidencias y decisiones pendientes.
- Saberes procedimentales, actitudinales y ejes como capas transversales.
- RdA, competencias específicas y perfil de salida como destino orientador, no como cumplimiento certificado.

## Elegir y ajustar

Pulse **Usar este enfoque como borrador editable** únicamente después de comparar cobertura, tiempo, recursos, evidencias y alertas. PIA trasladará la organización al mapa y al calendario. Luego puede mover bloques, cambiar la ubicación de un saber, modificar semanas, revisar fases o descartar la propuesta.

La propuesta no escribe automáticamente las semanas del planeamiento, no cambia indicadores oficiales y no reemplaza el criterio docente. Al guardar la ruta, esta alimenta posteriormente el prompt semestral como una decisión de organización revisable.

## Lectura del tiempo

- Las semanas compartidas por lecciones y Proyecto se cuentan una sola vez.
- El diagnóstico declarado ya está reservado y no se descuenta nuevamente.
- Una semana de margen no se presenta como semana curricular utilizada.
- Las tareas y el trabajo cotidiano son capas evaluativas de la misma ruta; no constituyen otro currículo.
- Una alerta temporal solicita revisión profesional: no autoriza eliminar saberes ni reducir la profundidad de los indicadores.

## Si no hay equipo de robótica o conectividad

La IA debe proponer una alternativa equivalente —simulada, documental, multimedia, física o de baja tecnología— únicamente cuando permita observar el verbo y la profundidad del indicador. El formato del producto no está predeterminado y un video, pódcast o revista no sustituye por sí mismo una acción técnica requerida.
