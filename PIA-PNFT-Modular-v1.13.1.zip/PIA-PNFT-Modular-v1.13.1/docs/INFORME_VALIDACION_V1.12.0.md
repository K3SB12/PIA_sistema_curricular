# Informe de validación — PIA-PNFT Modular 1.12.0

## Alcance

La actualización convierte la exploración previa de rutas de III Ciclo en una experiencia docente completa: respuesta humanizada de IA, matriz comparativa, mapa por alternativa, calendario y aplicación reversible como borrador.

## Controles curriculares

- La información oficial continúa protegida y se obtiene de los catálogos vigentes de PIA.
- La IA solo puede usar identificadores de saberes y fases entregados por PIA.
- Proyecto debe activarse antes de solicitar la articulación.
- Las propuestas no imponen tema, programación ni equipo físico.
- Procedimentales, actitudinales, ejes, competencias, perfil y RdA conservan su función transversal u orientadora.

## Controles temporales

- Las semanas integradas se cuentan una vez.
- El diagnóstico ya reservado se muestra aparte y no se descuenta nuevamente del tiempo neto.
- El margen exclusivo no se computa como tiempo curricular utilizado.
- Una propuesta que omite saberes o excede el tiempo neto no puede aplicarse.

## Controles de interfaz

- La persona docente lee una matriz antes de comparar tarjetas.
- Cada propuesta muestra metodología, producto, recursos, alternativa, etapas, indicadores, agrupaciones, puentes, evaluación y destino curricular.
- La parte técnica de la respuesta se reconoce mediante delimitadores y no requiere manipulación docente.
- La disposición se adapta a computadora, tableta y celular y mantiene mapa, calendario y tabla accesible.

## Resultado

`npm test` completó **249 pruebas aprobadas, 0 fallos**. La verificación confirmó fuente modular, cambios autorizados, integridad de publicación, compatibilidad de planes, currículo protegido, importación de propuestas, cálculo temporal, mapa, calendario y comportamiento responsivo contractual.

Huella SHA-256 de `index.html`, `dist/web/index.html` y `dist/portable/index.html`: `2fffb60a402bd8611c4f47d244068582df24d6ae93ad6e36418421142b828b03`.
