# Informe de validación — PIA-PNFT Modular 1.12.1

## Alcance

Intervención quirúrgica sobre 1.12.0 para conservar el mapa y la matriz editable, ampliar la libertad de producto final y añadir la decisión docente semanal de Trabajo cotidiano, tareas u otro.

## Salvaguardas

- No se modifican textos curriculares oficiales.
- La IA propone; PIA estructura y representa; la persona docente decide.
- El producto final puede quedar por definir o sustituirse por otra opción pertinente al módulo.
- La selección semanal no califica ni confirma automáticamente una evaluación.
- La justificación se solicita únicamente cuando se selecciona “Otro”.

## Pruebas

- Verificación de fuente y alcance autorizado: aprobada.
- Ensamblado web/portable: idéntico.
- Suite automatizada: 251/251 pruebas aprobadas.
- Pruebas nuevas: persistencia de decisión semanal y apertura de producto final.

## Huella SHA-256

27f2712f91d3f00f270d54c6ecbd6853ab1439177e33feafbb151dcc40ff2c0f
