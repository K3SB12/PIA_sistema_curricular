# Informe de validación — PIA-PNFT Modular 1.12.2

## Alcance

Intervención quirúrgica sobre 1.12.0 para conservar el mapa y la matriz editable, ampliar la libertad de producto final y añadir la decisión docente semanal de Trabajo cotidiano, tareas u otro.

## Salvaguardas

- No se modifican textos curriculares oficiales.
- La IA propone; PIA estructura y representa; la persona docente decide.
- El producto final puede quedar por definir o sustituirse por otra opción pertinente al módulo.
- La selección semanal no califica ni confirma automáticamente una evaluación.
- La justificación se solicita únicamente cuando se selecciona “Otro”.

## Pruebas

- Verificación de fuente y alcance autorizado: aprobada.
- Ensamblado web/portable: idéntico.
- Suite automatizada: 251/251 pruebas aprobadas.
- Pruebas nuevas: persistencia de decisión semanal y apertura de producto final.

## Huella SHA-256

d9d1f955fa1be85ffd48fb0dde6daf75cc3bef2afc807b682c041abea645edc5
