import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,agents,spec]=await Promise.all([
  read('src/templates/enhancements.html'),
  read('src/application/enhancements.js'),
  read('src/styles/08-enhancements.css'),
  read('AGENTS.md'),
  read('SPEC.md')
]);

test('la interfaz aclara que la IA propone y PIA no simula rutas',()=>{
  assert.match(template,/PIA prepara la información curricular y comprueba las propuestas recibidas/);
  assert.match(template,/La IA propone; PIA comprueba y representa; la persona docente decide/);
  assert.match(runtime,/PIA no suministra estrategias predeterminadas/);
});

test('una sola acción prepara y copia la consulta, con recuperación manual',()=>{
  assert.match(template,/id="piaRouteAIPrepareCopy"/);
  assert.match(runtime,/async function prepareAndCopyRouteAIExploration/);
  assert.match(runtime,/prepareRouteAIExploration\(\{announce:false\}\)/);
  assert.match(runtime,/El navegador no permitió copiar automáticamente/);
  assert.match(runtime,/String\(explorer\.prompt\|\|field\?\.value\|\|''\)\.trim\(\)/);
  assert.match(runtime,/field\.value!==text\)field\.value=text/);
  assert.match(template,/Copiar consulta para la IA/);
  assert.match(template,/Regenerar después de cambiar datos/);
});

test('el contrato acepta solo dos a cuatro propuestas actuales y con procedencia',()=>{
  assert.match(runtime,/\['pia-route-options-v2','pia-route-options-v3'\]\.includes\(raw\.schema\)/);
  assert.match(runtime,/source\.length<2\|\|source\.length>4/);
  assert.match(runtime,/routeAIInputFingerprint/);
  assert.match(runtime,/Prepare una consulta nueva/);
});

test('los faltantes quedan visibles pero impiden aplicar una propuesta incompleta',()=>{
  assert.match(runtime,/Saberes pendientes de organizar/);
  assert.match(runtime,/group\.role!=='pending'\)placed\.add/);
  assert.match(runtime,/m\.pending===0&&m\.occupied<=100/);
  assert.match(runtime,/data-pia-route-ai-apply=.*disabled/);
});

test('cada propuesta muestra mapa y calendario antes de elegirla',()=>{
  assert.match(runtime,/function routeAIMapPreview/);
  assert.match(runtime,/Ver mapa y calendario de esta propuesta/);
  assert.match(runtime,/Calendario propuesto por la IA/);
  assert.match(runtime,/function routeAITimelineTable/);
});

test('la posibilidad de producto conserva variedad y no impone programación',()=>{
  assert.match(runtime,/físico \| simulado \| programado \| multimedia \| documental \| baja tecnología/);
  assert.match(runtime,/No imponga programación, robótica física ni un tema/);
  assert.match(runtime,/Un producto comunicativo no sustituye una acción técnica/);
});

test('la navegación conserva alternativa accesible y vista general móvil',()=>{
  assert.match(template,/role="region" tabindex="0" aria-label="Lienzo del mapa/);
  assert.match(template,/Tabla accesible/);
  assert.match(runtime,/Math\.max\(12,Math\.min\(180/);
  assert.match(styles,/safe-area-inset-bottom/);
  assert.match(styles,/@media\(max-width:420px\)/);
});

test('los contratos documentales preservan criterio docente y respuesta no confiable',()=>{
  assert.match(agents,/Toda respuesta de IA para rutas se trata como dato no confiable/);
  assert.match(agents,/Una alternativa importada se aplica únicamente como borrador reversible/);
  assert.match(`${agents}\n${spec}`,/(?:no sustituya su criterio|no sustituye.*criterio profesional|sustituye el criterio profesional docente)/i);
});
