import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,core,agents,spec]=await Promise.all([
  read('src/templates/enhancements.html'),
  read('src/application/enhancements.js'),
  read('src/styles/08-enhancements.css'),
  read('src/domain/projection/projection-core.js'),
  read('AGENTS.md'),
  read('SPEC.md')
]);

test('la IA responde primero en lenguaje docente y conserva un bloque técnico delimitado',()=>{
  assert.match(runtime,/RESPUESTA PARA LA PERSONA DOCENTE/);
  assert.match(runtime,/PIA_DATOS_INICIO/);
  assert.match(runtime,/PIA_DATOS_FIN/);
  assert.match(runtime,/pia-route-options-v3/);
  assert.match(runtime,/marked=value\.match/);
  assert.match(template,/La respuesta incluye una comparación legible/);
});

test('PIA bloquea la exploración integrada si Proyecto no está activado',()=>{
  assert.match(runtime,/Active “Planificar Proyecto”/);
  assert.match(runtime,/sin Proyecto activado la IA no puede construir esa articulación/);
});

test('cada propuesta muestra los bloques completos del mapa del asesor',()=>{
  for(const text of ['Metodología de la propuesta','Producto o solución posible','Mediación activa y guiada','Trabajo cotidiano, tareas y evidencias','Puentes','Destino orientador'])assert.match(runtime,new RegExp(text));
  assert.match(runtime,/Indicador oficial:/);
  assert.match(runtime,/Capas curriculares transversales/);
});

test('la comparación docente precede a tarjetas, mapas y calendarios',()=>{
  assert.match(runtime,/function routeAIComparisonTable/);
  assert.match(runtime,/Comparación docente de las propuestas/);
  assert.match(runtime,/routeAIComparisonTable\(explorer\.proposals\)/);
  assert.match(runtime,/✓ Elegir esta propuesta/);
  assert.match(runtime,/MATRIZ DE PLANIFICACIÓN DERIVADA DE LA ESTRUCTURA/);
  assert.match(runtime,/DISTRIBUCIÓN RESUMIDA DE TAREAS/);
});

test('diagnóstico y margen no se suman otra vez como tiempo curricular',()=>{
  assert.match(runtime,/\['diagnosis','buffer'\]\.includes/);
  assert.match(runtime,/declaredBufferMinutes/);
  assert.match(runtime,/El diagnóstico reservado no se cuenta otra vez/);
  assert.match(core,/value==='pedagogical'\?'curriculum'/);
});

test('la presentación es responsiva y documentada como una sola ruta',()=>{
  assert.match(styles,/\.pia-route-ai-map-sequence/);
  assert.match(styles,/@media\(max-width:900px\).*pia-route-ai-map-sequence/);
  assert.match(`${agents}\n${spec}`,/una sola ruta/i);
});
