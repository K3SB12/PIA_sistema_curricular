import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'..');
const [runtime,core]=await Promise.all([readFile(resolve(root,'src/application/enhancements.js'),'utf8'),readFile(resolve(root,'src/domain/projection/projection-core.js'),'utf8')]);
test('la ruta conserva decisiones evaluativas editables por semana',()=>{
  assert.match(core,/weekEvaluation:\{\}/);
  assert.match(runtime,/Trabajo cotidiano/);
  assert.match(runtime,/Tarea 1/);
  assert.match(runtime,/Tarea 2/);
  assert.match(runtime,/Tarea 3/);
  assert.match(runtime,/Justificación cuando selecciona “Otro”/);
  assert.match(runtime,/data-pia-route-week-evaluation/);
});
test('el producto final permanece abierto a decisión docente y pertinencia curricular',()=>{
  assert.match(runtime,/familias abiertas de productos/);
  assert.match(runtime,/video, pódcast, revista digital, producto programado/);
  assert.match(runtime,/el producto permanezca por definir/);
  assert.match(runtime,/la persona docente decide/);
});
