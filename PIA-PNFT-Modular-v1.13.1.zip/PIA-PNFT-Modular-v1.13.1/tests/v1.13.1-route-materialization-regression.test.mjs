import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');

test('ROPM selection materializes without false fingerprint blocking', () => {
  assert.match(html, />✓ Elegir esta propuesta<\/button>/);
  assert.doesNotMatch(html, /Genere propuestas nuevas antes de elegir una/);
  assert.doesNotMatch(html, /Genere propuestas nuevas antes de aplicar una/);
  assert.match(html, /applyRouteAIProposalToMap\(id,\{skipConfirm:true\}\)/);
  assert.match(html, /state\.methodology\.routeAssignments\[conceptId\]=/);
});

test('duplicate distribution matrix is not rendered as a second empty section', () => {
  assert.doesNotMatch(html, /id="piaRouteDistributionMatrix"/);
  assert.doesNotMatch(html, /renderRouteIntegrationGuide\(concepts\);renderRouteDistributionMatrix\(concepts\);/);
});

test('proposal details expand to full comparison width and contain long text', () => {
  assert.match(html, /\.pia-route-ai-card:has\(details\[open\]\)\{grid-column:1\/-1\}/);
  assert.match(html, /overflow-wrap:anywhere/);
});

test('location help explains AI preload and manual pending state', () => {
  assert.match(html, /Si elige una ROPM, PIA precarga aquí su ubicación, fase y semanas/);
});
