import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,spec,agents]=await Promise.all([
  read('src/templates/enhancements.html'),
  read('src/application/enhancements.js'),
  read('src/styles/08-enhancements.css'),
  read('SPEC.md'),
  read('AGENTS.md')
]);

test('la ruta se dibuja como grafo de nodos HTML y conexiones SVG curvas',()=>{
  assert.match(runtime,/function routeGraphModel/);
  assert.match(runtime,/pia-route-edge-layer/);
  assert.match(runtime,/bezierCurveTo/);
  assert.match(runtime,/C \$\{x1\+bend\}/);
  assert.match(styles,/\.pia-route-graph-node\{/);
  assert.match(styles,/\.pia-route-edge\{/);
});

test('el mapa muestra una sola ruta con todas las capas validadas',()=>{
  for(const text of ['Diagnóstico pedagógico','Pensamiento de Diseño','Lecciones pedagógicas','Trabajo cotidiano, tareas y evidencias','Competencias y perfil de salida','RdA del ciclo por área'])assert.ok(runtime.includes(text),text);
  for(const phase of ['empathize','define','ideate','prototype','test-evaluate'])assert.ok(runtime.includes(`phase-${phase}`)||runtime.includes(phase),phase);
  assert.match(runtime,/PIAProjectComponentCatalog\.indicatorsForPhase/);
});

test('la entrada auditada cubre lo oficial, lo declarado, lo opcional y lo pendiente',()=>{
  assert.match(template,/Entrada que utilizarán el mapa y la IA/);
  for(const label of ['Identificación curricular','Textos oficiales protegidos','Marco curricular','Tiempo pedagógico','Diagnóstico pedagógico','Contexto, recursos y DUA','Proyecto y Pensamiento de Diseño','Ruta y relaciones docentes','Capas transversales','Evaluación'])assert.ok(runtime.includes(label),label);
  assert.match(runtime,/Opcional no activad[oa]/);
  assert.match(spec,/La ausencia de un campo opcional no permite completarlo por inferencia/);
});

test('el ejemplo abre el mapa en solo lectura y no confirma ni ensucia el plan',()=>{
  assert.match(runtime,/routeExampleMode=Boolean\(example\)/);
  assert.match(runtime,/if\(confirmRoute&&!routeExampleMode\)/);
  assert.match(runtime,/if\(!routeExampleMode\)markDirty\(\)/);
  assert.match(styles,/data-example="true"/);
  assert.match(template,/Ejemplo visual protegido/);
});

test('el prompt de análisis recibe toda la entrada acordada',()=>{
  assert.match(runtime,/ENTRADA TRAZABLE PARA REVISAR EL MAPA/);
  for(const heading of ['IDENTIFICACIÓN Y TIEMPO','CURRÍCULO OFICIAL PROTEGIDO','RdA POR ÁREA','COMPETENCIAS ESPECÍFICAS','PERFIL DE SALIDA','DESCRIPCIÓN O PROPÓSITO OFICIAL DEL MÓDULO','CAPAS TRANSVERSALES SELECCIONADAS','DIAGNÓSTICO PEDAGÓGICO','CONTEXTO, RECURSOS Y DUA','PROYECTO Y PENSAMIENTO DE DISEÑO','EVALUACIÓN','RELACIONES DOCENTES'])assert.ok(runtime.includes(heading),heading);
  assert.match(runtime,/No cambie silenciosamente ninguna decisión/);
  assert.match(runtime,/No reducir currículo automáticamente/);
});

test('las relaciones pueden crearse, verse y eliminarse sin depender del color',()=>{
  assert.match(runtime,/renderRouteConnectionControls/);
  assert.match(runtime,/data-pia-route-remove-connection/);
  assert.match(runtime,/ensureRouteMap\(\)\.connections=ensureRouteMap\(\)\.connections\.filter/);
  assert.match(agents,/nodos HTML accesibles y conexiones SVG/);
});
