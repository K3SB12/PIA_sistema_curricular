# Guía de uso — PIA Journey 1.14.0

## Propósito

PIA Journey ayuda a una persona docente o asesora, con o sin experiencia, a comprender cómo pasar del currículo del PNFT a la proyección y al planeamiento semanal. Es una experiencia formativa: no completa el plan, no califica y no sustituye el criterio profesional.

## Cómo ingresar

1. En la portada, seleccione **Explorar un ejemplo de planeamiento**.
2. Elija Preescolar, I Ciclo, II Ciclo o III Ciclo.
3. Puede seguir una de tres rutas:
   - **Realizar recorrido rápido por PIA:** siete explicaciones sobre la interfaz real.
   - **Explorar la ruta del ciclo seleccionado:** recorrido formativo completo.
   - **Ver trayectoria Preescolar–9.º:** mapa curricular, tabla accesible y PNG descargable.

El botón flotante **?** permite abrir nuevamente la experiencia desde el planeamiento.

## Los siete momentos

| Momento | Qué ayuda a comprender |
|---|---|
| 1. El horizonte | Nivel, áreas, indicadores y RdA. |
| 2. El punto de partida | Contexto, diagnóstico, condiciones de entrada y DUA. |
| 3. La ruta curricular | Profundidad, progresión y continuidad documentada. |
| 4. Vivir la metodología | ABJ, ABR y Pensamiento de Diseño como andamiaje. |
| 5. Mirar el semestre | Tiempo, proyección y apoyo opcional de IA. |
| 6. Construir una semana | Saberes, mediación, evidencias, evaluación y continuidad. |
| 7. Revisar y continuar | Autoguardado, JSON, vista previa, Word y PDF. |

## Uso en III Ciclo

PIA Journey explica el apoyo **Solicitar propuestas para organizar el módulo**:

1. PIA reúne currículo, indicadores, tiempo, contexto, recursos, DUA, Proyecto y evaluación.
2. La persona docente copia la consulta en la herramienta de IA que decida utilizar.
3. La IA devuelve de dos a cuatro propuestas contextualizadas.
4. PIA comprueba cobertura, identificadores y tiempo y presenta una matriz comprensible.
5. La opción elegida se convierte en un borrador de mapa, ubicación de saberes y calendario.
6. La persona docente ajusta semanas, puentes, producto, tareas y evidencias antes del prompt semestral.

Las semanas donde coinciden lecciones pedagógicas y Proyecto se cuentan una sola vez. El Proyecto, el trabajo cotidiano, las tareas y las evidencias son capas de la misma ruta, no planeamientos separados.

## Plantilla semanal

- **Semana y referente:** confirme módulo, área, saberes e indicadores.
- **Mediación:** describa acciones del estudiantado, acompañamiento, recursos y DUA en inicio, desarrollo y cierre.
- **Evaluación:** defina evidencia y criterios observables antes de elegir el instrumento.
- **Continuidad:** indique qué requiere práctica, realimentación o recuperación en la semana siguiente.

Duplicar una semana solo crea un punto de partida; siempre deben revisarse fechas, indicadores, evidencias y continuidad.

## Guardado y exportación

- **Autoguardado:** copia local de recuperación en el navegador; no sustituye un archivo descargado.
- **Guardar:** descarga el JSON editable que PIA puede volver a abrir.
- **Vista previa:** permite revisar la presentación.
- **Word/PDF:** sirven para compartir o imprimir; no recuperan el plan editable.
- **Prompt IA General:** prepara una consulta; no guarda ni modifica el plan.

## Accesibilidad

- Puede usar puntero, toque o teclado.
- En el recorrido rápido, use **Tab**, **Shift+Tab**, flechas izquierda/derecha y **Esc**.
- El mapa tiene una tabla equivalente.
- En celular, el mapa admite desplazamiento horizontal y el recorrido se presenta como panel inferior.
- La experiencia respeta reducción de movimiento y colores forzados del sistema.

## Responsabilidad profesional

PIA organiza y orienta; la IA puede proponer; la persona docente o asesora confirma, ajusta o descarta. Los ejemplos no constituyen una distribución oficial, no inventan resultados diagnósticos ni certifican el logro de indicadores, RdA, competencias o perfil de salida.
