# Informe de validación — PIA-PNFT Modular 1.14.0

## Alcance

Se incorporó PIA Journey sobre la línea 1.13.1 sin cambiar `schemaVersion: 6`, `PNFT_DATA`, `RDA_POR_CICLO`, el estado de las semanas ni las exportaciones oficiales.

## Controles incorporados

- Isla formativa separada del estado del plan.
- Recorrido de siete pasos sin escritura ni eventos sintéticos sobre campos reales.
- Mapa Preescolar–9.º con tabla accesible y PNG.
- Persistencia local exclusiva del avance formativo.
- Reingreso mediante ayuda flotante.
- Diseño adaptable para computadora, tableta y celular.
- Explicación del módulo de organización asistida de III Ciclo.
- Guía de plantilla semanal y funciones de botones.

## Verificaciones automatizadas

- Sintaxis de JavaScript.
- Fuente modular y construcción de los tres artefactos.
- Alcance autorizado frente a la referencia inalterable.
- Contratos de PIA Journey.
- Suite de regresión completa.
- Igualdad de hash entre raíz, web y portable.

Resultado final: **260 pruebas aprobadas, 0 fallos**.

Huella SHA-256 común de `index.html`, `dist/web/index.html` y
`dist/portable/index.html`:
`61c5d5868e9e7a52d21fc8f1572d0fe7350983b55218f50a48d8cfd683f8e204`.

La validación automatizada no reemplaza la revisión humana final en Chrome o Edge de foco, descarga PNG, impresión y apertura `file://`.
