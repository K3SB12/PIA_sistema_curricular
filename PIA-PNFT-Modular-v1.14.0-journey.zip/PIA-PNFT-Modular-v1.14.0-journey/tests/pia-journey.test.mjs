import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=path=>readFile(resolve(root,path),'utf8');

test('PIA Journey conserva su isla formativa y siete pasos',async()=>{
  const source=await read('src/learning/experience.js');
  assert.match(source,/pia\.learning\.example\.v1/);
  assert.match(source,/pia\.tour\.completed\.v1/);
  assert.match(source,/const liveTourSteps=\[/);
  assert.equal((source.match(/title:'[1-7]\./g)||[]).length,7);
  assert.match(source,/function startInterfaceTour\(\)/);
  assert.match(source,/function stopInterfaceTour\(/);
  assert.match(source,/function isolateForTour\(/);
  assert.match(source,/function restoreTourIsolation\(/);
  assert.match(source,/document\.addEventListener\('keydown',onTourKey,true\)/);
  assert.doesNotMatch(source,/\b(markDirty|obtenerDatosPlan|cargarPlan|state\.projection)\b/);
});

test('PIA Journey incluye ciclos, mapa, semana y III Ciclo',async()=>{
  const source=await read('src/learning/experience.js');
  for(const expected of ['Preescolar','I Ciclo','II Ciclo','III Ciclo','Mapa de la trayectoria curricular del PNFT','Descargar mapa en PNG','La plantilla semanal de PIA','Solicitar propuestas para organizar el módulo']) assert.match(source,new RegExp(expected));
  assert.match(source,/La IA propone entre dos y cuatro organizaciones; PIA comprueba y representa; la persona docente decide/);
  assert.match(source,/Guardar · JSON/);
  assert.match(source,/Exportar · PDF o Word/);
  assert.match(source,/ANTES/);
  assert.match(source,/AHORA/);
  assert.match(source,/DESPUÉS/);
  assert.match(source,/Calendario visual · las superposiciones se cuentan una vez/);
  assert.doesNotMatch(source,/<th>Duplicar<\/th>/);
});

test('la ayuda y los anclajes del recorrido se integran en bloques autorizados',async()=>{
  const html=await read('src/templates/enhancements.html');
  const app=await read('src/application/enhancements.js');
  assert.match(html,/id="piaJourneyHelp"/);
  for(const anchor of ['context-dua','time','curriculum','evaluation','projection']) assert.match(html,new RegExp(`data-pia-tour="${anchor}"`));
  assert.match(app,/\$\('piaJourneyHelp'\)\?\.addEventListener\('click',openMethodologyGame\)/);
  assert.match(app,/result\?\.destination==='plan'/);
  assert.match(app,/portableDocument\.querySelector\('#piaJourneyTour'\)\?\.remove\(\)/);
});

test('los estilos cubren mapa, foco, móvil y preferencias del usuario',async()=>{
  const css=await read('src/learning/experience.css');
  for(const expected of ['.pj-map-scroll','.pj-tour-highlight','.pia-journey-help','@media(max-width:720px)','prefers-reduced-motion','forced-colors','env(safe-area-inset-bottom)']) assert.match(css,new RegExp(expected.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
});

test('los tres artefactos construidos contienen la misma experiencia',async()=>{
  for(const file of ['index.html','dist/web/index.html','dist/portable/index.html']){
    const built=await read(file);
    assert.match(built,/PIA Journey · La Ruta del Docente/);
    assert.match(built,/pia\.tour\.completed\.v1/);
    assert.match(built,/id="piaJourneyHelp"/);
  }
});
