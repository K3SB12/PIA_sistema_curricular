# Guía de uso — PIA Journey 1.14.1

PIA Journey es una ayuda formativa opcional para comprender el recorrido de PIA. No completa el planeamiento, no certifica aprendizajes y no sustituye las orientaciones oficiales ni el criterio profesional docente.

## Cómo abrirlo

1. En la portada, pulse **Explorar un ejemplo de planeamiento**.
2. Seleccione Preescolar, I Ciclo, II Ciclo o III Ciclo para consultar la ruta correspondiente.
3. Elija el recorrido formativo o el recorrido breve sobre la interfaz real.
4. En cualquier momento puede repetirlo con el único botón flotante **?**.

La preferencia `pia.tour.completed.v1` solo evita una apertura automática repetida. No forma parte del plan, del respaldo JSON, del Word ni del PDF.

## Ocho pasos del recorrido breve

| Paso | Qué explica |
|---|---|
| 1 | Contexto del planeamiento y población atendida. |
| 2 | Tiempo, semanas, lecciones y diagnóstico. |
| 3 | Selección del currículo oficial: módulos, áreas, saberes e indicadores. |
| 4 | Metodología como andamiaje, no como fin ni como ruta rígida. |
| 5 | Contexto, DUA y evaluación bajo decisión docente. |
| 6 | Proyección semestral y apoyo consultivo de la IA. |
| 7 | Semanas, mediación, evidencias y respaldo del trabajo. |
| 8 | Guardar, exportar y volver a pedir ayuda. |

En el último paso, **Finalizar recorrido** cierra la ayuda y muestra una confirmación. No guarda ni modifica el planeamiento por sí mismo.

## Leyenda del mapa curricular

Dentro de **Ruta curricular del semestre**, pulse el botón circular de información ubicado sobre el mapa. La tarjeta distingue dos sistemas:

- **Áreas oficiales:** azul, morado, turquesa y verde corresponden a las cuatro áreas de conocimiento del PNFT.
- **Organización de la ruta:** otros colores ayudan a reconocer diagnóstico, decisiones de entrada, Proyecto, mediación, evaluación, capas transversales y relaciones creadas por la persona docente.

Los colores organizan la lectura; no representan logro, importancia, cumplimiento ni calificación. Pulse de nuevo el botón o presione **Esc** para cerrar únicamente la leyenda. El foco vuelve al botón y el mapa permanece abierto.

## Accesibilidad y dispositivos

- Use **Tab** y **Shift+Tab** para recorrer los controles.
- El foco visible permite reconocer el elemento activo.
- **Esc** cierra primero la leyenda y después, en una segunda acción, el modal.
- En tableta y celular, la leyenda limita su tamaño y permite desplazamiento interno.
- La tabla accesible continúa siendo la alternativa textual al mapa.
- La leyenda se oculta en la impresión para no interferir con el documento.

## Responsabilidad docente

PIA explica y organiza información; la IA propone; la persona docente o asesora comprueba el contexto, ajusta la ruta y decide. Ninguna explicación del recorrido constituye una distribución oficial, una aprobación institucional o una sustitución del currículo protegido.
