# Informe de validación — PIA 1.14.1

## Alcance

Se validan el cierre explícito del recorrido, la unicidad del botón flotante de ayuda, la leyenda del mapa curricular, la navegación por teclado, el comportamiento de `Esc`, la adaptación responsiva y la conservación de la arquitectura local de PIA.

## Controles incorporados

- Ocho pasos en el recorrido breve, con acción final **Finalizar recorrido**.
- Confirmación accesible al terminar y persistencia exclusiva de `pia.tour.completed.v1`.
- Un único botón global para abrir o repetir PIA Journey.
- Leyenda externa al lienzo reemplazable del mapa, colapsable y sin persistencia.
- Colores verificados contra `ROUTE_AREA_COLORS` y los estilos reales de las capas de la ruta.
- Cierre jerárquico con `Esc`: leyenda antes que modal.
- Reglas para foco visible, móvil, contraste forzado e impresión.

## Resultado

- **Huella SHA-256 común:** `d0c3f7659770f56895002a67f4bbffb51cc6c7a8b7f20fba5cb28aedc94bcb6f`.
- **Artefactos equivalentes:** `index.html`, `dist/web/index.html` y `dist/portable/index.html`.
- **Pruebas automatizadas:** 265 aprobadas, 0 fallos.

Continúa recomendándose una revisión humana en Chrome o Edge, en los dispositivos reales de publicación, para confirmar escala visual, tacto, descarga y apertura local `file://`.
