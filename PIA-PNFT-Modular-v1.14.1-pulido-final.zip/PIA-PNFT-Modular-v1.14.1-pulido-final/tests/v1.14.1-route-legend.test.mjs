import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=path=>readFile(resolve(root,path),'utf8');

test('la leyenda del mapa es única, accesible y externa al lienzo reemplazable',async()=>{
  const template=await read('src/templates/enhancements.html');
  for(const id of ['piaRouteLegendToggle','piaRouteLegend','piaRouteLegendTitle']){
    assert.equal((template.match(new RegExp(`id="${id}"`,'g'))||[]).length,1);
  }
  assert.match(template,/id="piaRouteLegendToggle"[^>]+aria-expanded="false"[^>]+aria-controls="piaRouteLegend"/);
  assert.match(template,/id="piaRouteLegend"[^>]+role="region"[^>]+hidden/);
  assert.match(template,/class="pia-route-canvas-stage">\s*<div class="pia-route-canvas-shell"[\s\S]+?<\/div>\s*<div class="pia-route-legend-control">/);
  const mapStart=template.indexOf('id="piaRouteMap"'),legendStart=template.indexOf('id="piaRouteLegend"');
  assert.ok(mapStart>=0&&legendStart>mapStart);
});

test('la leyenda reproduce los colores reales y explica que no representan logro',async()=>{
  const template=await read('src/templates/enhancements.html');
  const app=await read('src/application/enhancements.js');
  const css=await read('src/styles/08-enhancements.css');
  const expected=[
    ['Apropiación tecnológica y Digital','#244e94'],
    ['Programación y Algoritmos','#57249a'],
    ['Computación física y Robótica','#2aa9a1'],
    ['Ciencia de datos e Inteligencia artificial','#83b857']
  ];
  for(const [area,color] of expected){
    assert.match(app,new RegExp(`'${area.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}':'${color}'`));
    assert.match(template,new RegExp(`--legend-color:${color}`));
  }
  for(const color of ['#4b79cf','#dfa02b','#2b9f8d','#8058bb','#df941d','#65789a'])assert.match(template,new RegExp(color));
  assert.match(css,/#d44b92/);
  assert.match(template,/No representa logro, importancia, cumplimiento ni calificación/);
});

test('la leyenda abre, cierra y da prioridad a Escape antes de cerrar el modal',async()=>{
  const app=await read('src/application/enhancements.js');
  assert.match(app,/function setRouteLegend\(open=false,returnFocus=false\)/);
  assert.match(app,/legend\.hidden=!open/);
  assert.match(app,/button\.setAttribute\('aria-expanded',String\(open\)\)/);
  assert.match(app,/setRouteLegend\(false,true\);return/);
  assert.match(app,/event\.stopPropagation\(\)/);
  assert.doesNotMatch(app,/localStorage\.setItem\([^\n]*RouteLegend/);
});

test('la presentación de la leyenda contempla foco, móvil, contraste e impresión',async()=>{
  const css=await read('src/styles/08-enhancements.css');
  for(const expected of ['.pia-route-canvas-stage','.pia-route-legend-control','.pia-route-legend-card','overscroll-behavior:contain','touch-action:auto','@media(max-width:700px)','@media(max-width:420px)','@media(forced-colors:active)','@media print'])assert.match(css,new RegExp(expected.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  assert.match(css,/\.pia-route-legend-control>button:focus-visible/);
  assert.match(css,/\.pia-route-legend-control\{[^}]*right:78px/);
});

test('las tres salidas construidas incluyen una sola leyenda y un solo botón global de ayuda',async()=>{
  for(const path of ['index.html','dist/web/index.html','dist/portable/index.html']){
    const html=await read(path);
    assert.equal((html.match(/id="piaRouteLegendToggle"/g)||[]).length,1,`${path}: botón de leyenda`);
    assert.equal((html.match(/id="piaRouteLegend"/g)||[]).length,1,`${path}: tarjeta de leyenda`);
    assert.equal((html.match(/id="piaJourneyHelp"/g)||[]).length,1,`${path}: ayuda global`);
    assert.match(html,/Finalizar recorrido/);
  }
});
