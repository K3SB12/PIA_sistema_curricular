import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = path => readFile(join(root, path), 'utf8');

test('cada semana conserva las tres columnas y el bloque de observaciones originales', async () => {
  const [view, operations, initialization] = await Promise.all([
    read('src/ui/week-view.js'),
    read('src/domain/planning/week-operations.js'),
    read('src/application/initialization.js'),
  ]);
  for (const field of ['queFunciono', 'queNoFunciono', 'queMejorar', 'observaciones']) {
    assert.match(view, new RegExp(`data-pia-week-reflection-field="${field}"`));
    assert.match(operations, new RegExp(field));
    assert.match(initialization, new RegExp(field));
  }
  assert.match(view, /actualizarReflexionSemana/);
  assert.match(operations, /PIAEnhancements\.markDirty/);
  assert.match(view, /Reflexiones docentes/);
  assert.match(view, /¿Qué funcionó\?/);
  assert.match(view, /¿Qué no funcionó\?/);
  assert.match(view, /¿Qué puedo mejorar\?/);
  assert.match(view, /Observaciones y\/o recomendaciones didácticas por nivel/);
  assert.match(view, /En este apartado la persona docente podrá realizar los apuntes/);
  assert.doesNotMatch(view, /Se guarda y se exporta únicamente/);
});

test('Word y PDF ubican la reflexión dentro de cada semana seleccionada', async () => {
  const exporter = await read('src/infrastructure/export/pdf-exporter.js');
  assert.match(exporter, /function reflexionSemanaWord\(semana\)/);
  assert.match(exporter, /function reflexionSemanaPDF\(semana\)/);
  assert.match(exporter, /REFLEXIONES DOCENTES/);
  assert.match(exporter, /Observaciones y\/o recomendaciones didácticas por nivel/);
  assert.doesNotMatch(exporter, /REFLEXIÓN GENERAL DEL PERÍODO \(OPCIONAL\)/);
});

test('el prompt semanal usa la reflexión real y prohíbe inventar resultados', async () => {
  const prompt = await read('src/prompts/weekly-prompt.js');
  assert.match(prompt, /REFLEXIÓN DOCENTE YA REGISTRADA/);
  assert.match(prompt, /no invente resultados de aplicación/i);
  assert.match(prompt, /promptConReflexion/);
});

test('la portada no muestra mensajes técnicos y el tema oscuro cubre contenido pedagógico', async () => {
  const [header, welcome, theme] = await Promise.all([
    read('src/templates/header.html'),
    read('src/templates/body-open.html'),
    read('src/styles/08-enhancements.css'),
  ]);
  assert.doesNotMatch(header, /Revisión 2026-09-27/);
  assert.doesNotMatch(welcome, /archivo para publicación/);
  for (const selector of ['.semana-item', '.saber-contenido', '.pia-week-reflection', '.indicador-logro', ':focus-visible']) {
    assert.ok(theme.includes(selector), `Falta cobertura oscura para ${selector}`);
  }
  assert.match(theme, /#c4d0e2/);
});

test('Explorar un ejemplo conserva PIA Journey, la ruta del tesoro y el tour', async () => {
  const [experience, styles] = await Promise.all([
    read('src/learning/experience.js'),
    read('src/learning/experience.css'),
  ]);
  for (const contract of ['trajectoryMap', 'secondaryModuleDemo', 'startInterfaceTour', 'cycleProfiles']) {
    assert.ok(experience.includes(contract), `Falta el contrato ${contract}`);
  }
  assert.match(experience, /De Preescolar a 9\.º: continuidad con profundidad/);
  assert.match(experience, /PIA Journey · La Ruta del Docente/);
  assert.match(experience, /Pensamiento de Diseño organiza el componente Proyecto/);
  assert.match(styles, /\.pj-map/);
  assert.match(styles, /\.pj-tour-popover/);
  assert.match(styles, /\.pj-route-map/);
});
