# PIA-PNFT modular

División profesional y reversible de la línea base validada de PIA-PNFT. La versión funcional
actual es **PIA-PNFT Modular 1.14.4**.


## Actualización 1.14.4 — cierre del circuito IA y del constructor de rutas

**Revisión posterior a prueba real de propuestas:** la comparación recupera una vista preliminar por nodos; aclara `Solo Proyecto` frente a `Lecciones + Proyecto`; muestra presencia total del Proyecto; permite descargar localmente la respuesta de IA en `.md` y las propuestas validadas en `.json`; habilita movimiento visual efímero de bloques; corrige el doble clic mapa→tabla; y permite que la propuesta señale oportunidades orientadoras de Trabajo cotidiano o Tarea sin fijar instrumentos ni fechas.

- Corrige la selección inicial por ciclo: I Ciclo abre en 1.º, II Ciclo en 4.º y III Ciclo en 7.º.
- Añade selector claro/oscuro persistente con controles visibles en la portada y en PIA.
- El paso 3 del constructor se presenta como **Propuesta de la IA** y admite pegar una respuesta en Markdown o importar un archivo `.json` local.
- PIA valida esquema, huella de la selección, saberes, semanas y las cinco fases de Pensamiento de Diseño antes de permitir aplicar una propuesta. Una respuesta inválida no sustituye la ruta existente.
- La propuesta estructurada se traduce a una vista docente; los datos técnicos permanecen plegados y opcionales.
- Permite descargar `Consulta-para-IA.md`, `Ruta-curricular.json` y el mapa PNG, además de solicitar ajustes de una propuesta sin perder la ruta actual.
- Integra un panel **Continuar con el planeamiento** para generar la proyección semestral o solicitar estrategias semana a semana desde la misma ruta.
- El prompt semanal conserva contexto, diagnóstico declarado, DUA y accesibilidad, currículo literal, cinco fases APD, evidencias, trabajo cotidiano, tareas, instrumentos y auditoría temporal.
- El modal amplía su área de trabajo, evita cierre accidental al pulsar fuera, incorpora doble clic mapa→tabla y botón **Volver al mapa**.
- La barra inferior ya no usa margen negativo ni cubre “Criterio profesional”; en pantallas pequeñas reorganiza las cuatro acciones.

## Actualización 1.9.2 — calendario visual de la ruta

El constructor de la ruta curricular de III Ciclo incorpora una línea temporal por semanas con capas de diagnóstico, mediación curricular, Proyecto y APD, trabajo cotidiano y tareas. Se deriva del mismo estado del mapa, ofrece tabla accesible y no infiere fechas, duplica semanas integradas ni escribe el planeamiento semanal.

- Cada saber se ubica en lecciones pedagógicas, componente Proyecto, ambos o pendiente; las etiquetas históricas se migran.
- Las relaciones son opcionales. PIA combina un catálogo revisado con señales textuales y explica cada color sin certificar integración.
- Si no existe un antecedente explícito, PIA indica que el saber inicia en el nivel actual y no inventa una base.
- El Proyecto admite productos físicos, simulados, programados, multimedia, documentales o de baja tecnología; el producto debe evidenciar la acción del indicador.
- Mapa, tabla, calendario, inspector y acciones se reorganizan para computadora, tableta y celular sin perder decisiones esenciales.

## Actualización 1.9.1 — mapa conceptual y entrada trazable

El organizador de III Ciclo representa la ruta como un grafo de nodos y relaciones, incorpora un ejemplo visual de solo lectura y muestra un control de trazabilidad de toda la entrada antes de solicitar el análisis o generar el prompt semestral.

## Actualización 1.9.0 — mapa integral de la ruta curricular

PIA convierte el organizador de secundaria en un mapa semántico editable que articula, dentro de una sola proyección, diagnóstico y contexto, mediación curricular, fases de Pensamiento de Diseño, componente Proyecto, semanas, evaluación y horizonte curricular. Incluye modo guiado/directo, inspector, capas C-P-A/ejes, tabla accesible, auditorías, exportación visual y un prompt para comparar rutas sin reemplazar el criterio docente.

## Actualización 1.8.0 — mapa de organización curricular para secundaria

- Sustituye la ficha confusa de articulación por **Organice la ruta curricular del semestre**, ubicada fuera del formulario del Proyecto.
- Permite escoger tres organizaciones reales —Proyecto predominante, alternancia o preparación inicial— o mantener la decisión pendiente con apoyo de PIA.
- Incorpora un mapa conceptual local y su tabla accesible equivalente para clasificar la función prevista de cada saber e indicador sin modificar los textos oficiales.
- Distingue aplicación directa en el Proyecto, preparación, apoyo/documentación, otras lecciones pedagógicas, continuidad y decisión pendiente.
- Ofrece modo guiado y modo directo sobre los mismos datos; el nivel de ayuda cambia, pero no el currículo ni el prompt.
- Envía al prompt únicamente la ruta guardada y obliga a conservar pendientes, evitar doble contabilización de evidencias y auditar el tiempo después de construir la propuesta.
- Mantiene la segunda metodología completa como decisión excepcional que exige fases, puente curricular, semanas y revisión docente.
- Añade pruebas de mapas para 7.º, 8.º y 9.º, persistencia v6, accesibilidad, áreas ausentes e integridad de la entrega.

## Actualización 1.7.5 — diagnóstico integrado sin duplicaciones

- La técnica, el instrumento y el criterio docente manuales permanecen ocultos y desactivados por defecto.
- Un control explícito permite mostrarlos únicamente cuando la persona docente ya decidió qué técnica e instrumento utilizará.
- Sin selección manual, la IA recomienda una sola combinación congruente con la actividad, la evidencia, el nivel, el tiempo, los recursos, DUA y las orientaciones del MEP y del PNFT.
- El diagnóstico considera conocimientos y experiencias previas relacionados con los saberes conceptuales, procedimentales y actitudinales del módulo mediante situaciones integradas viables en un máximo de dos lecciones.
- Se elimina del resultado efectivo la regla propia “un conjunto acotado… no evalúe todo el semestre” y se evita fragmentar el diagnóstico en una prueba independiente por cada saber.

## Actualización 1.7.4 — procedencia de recomendaciones diagnósticas

- “Solicitar recomendación razonada a la IA” ya no se presenta como una selección docente.
- La interfaz, el prompt semestral y el modelo Word distinguen las opciones pendientes, las recomendaciones de IA pendientes de validación y las selecciones expresas de la persona docente.
- La respuesta revisada de la IA puede anexarse como propuesta editable, pero esa acción no confirma automáticamente la técnica ni el instrumento.
- La IA debe rotular expresamente sus recomendaciones y no puede atribuirlas a la persona docente.

## Actualización 1.7.3 — una sola ruta y diálogos adaptables

- La guía de secundaria presenta primero la ruta integrada: los saberes e indicadores se desarrollan dentro de Pensamiento de Diseño y alimentan el Proyecto; no son dos planeamientos.
- Las alternativas con una segunda metodología completa se identifican como excepciones y muestran sus campos temporales únicamente cuando corresponden.
- “Condiciones de entrada para los saberes actuales” permanece como opción diagnóstica y ahora explica claramente que no exige los indicadores finales como dominio previo.
- Los diálogos de prompt se ajustan a la altura disponible y permiten desplazamiento interno, de modo que todas sus acciones sean accesibles en monitores de menor altura.
- La interfaz utiliza “lecciones pedagógicas” en lugar de “lecciones administrativas”.

## Actualización 1.7.2 — diagnóstico, coordinación metodológica y tiempo real

- El diagnóstico permite elegir una técnica y un instrumento o solicitar a la IA una recomendación razonada; el prompt exige un instrumento completo, imprimible y editable, sin resultados inventados.
- PIA diferencia técnica, evidencia, instrumento y función de evaluación. El modelo Word incorpora la selección y una plantilla congruente para registrar después de aplicar el diagnóstico.
- En III Ciclo, la coordinación entre metodología curricular y Pensamiento de Diseño debe declarar si utiliza una ruta única, metodologías completas en secuencia o metodologías completas coordinadas.
- Las alertas explican que ABR requiere Comprender, Investigar y Actuar, y que ABJ requiere un diseño lúdico completo. PIA identifica riesgos de duplicación, pero la persona docente o asesora decide la viabilidad.
- El marco temporal conserva como oficial el bloque de 80 minutos y admite, de forma opcional, un escenario operativo preventivo menor —por ejemplo 60 minutos— claramente rotulado como no oficial.
- Se incorpora **Operadores relacionales** como saber independiente de 3.º, Módulo 1, según la guía oficial de Primaria; comparte el indicador integrado con Operadores aritméticos.
- La regresión automatizada de 1.7.2 aprobó 170 pruebas y recorre 236 saberes–indicadores; la entrega 1.7.4 aprueba 174 pruebas.

## Revisión de asesoría sobre 1.7.1

- Añade el marco oficial visible de competencias específicas, perfil de salida y propósito del módulo para la selección vigente.
- Mantiene como protegidos los saberes, indicadores y RdA, y diferencia orientación de la guía, propuesta de IA y decisión docente.
- Fortalece el prompt con integración pedagógica de dos o más saberes, DUA para el grupo y auditoría de contribución de la ruta.
- Incorpora inventario estructurado de recursos y un modelo diagnóstico editable en Word que no inventa resultados.
- Evita imponer un tema único al Proyecto y mantiene la selección sujeta a fuentes, contexto y criterio profesional.
- Conserva funcionamiento local, privacidad, `schemaVersion: 6`, compatibilidad histórica y exportaciones oficiales.

## Novedad 1.7.1 — Experiencia operativa y apoyos inclusivos

- Corrige el bloqueo de **Explorar un ejemplo de planeamiento**: la experiencia ya no vuelve inerte al contenedor que la incluye y restaura exactamente el foco y los estados de accesibilidad al cerrarse.
- Añade una ruta opcional para distinguir DUA, apoyos de acceso, apoyos curriculares no significativos y una adecuación significativa o PEI previamente aprobada.
- Incorpora apoyos seleccionables de representación, acción y expresión, participación, secuenciación de instrucciones, ritmo/tiempo y recursos accesibles.
- Amplía **III Ciclo y Ciclo Diversificado Vocacional — Plan Nacional** con coordinación pedagógica, criterio para seleccionar y dosificar saberes y la referencia de dos lecciones semanales.
- No aprueba adecuaciones, no interpreta PEI, no almacena datos personales y no modifica automáticamente currículo, indicadores o evaluación.
- Declara el límite vigente: el catálogo curricular de PIA llega hasta 9.º; para 10.º–12.º no inventa saberes ni indicadores.
- Mantiene la Ruta hacia el RdA, `schemaVersion: 6`, operación local, JSON, PDF, Word y funcionamiento portable.

## Novedad 1.7.0 — Ruta hacia el RdA

- Añade una consulta local de solo lectura que organiza las familias curriculares desde Preescolar hasta 9.º por ciclos y RdA oficiales.
- Distingue el vínculo estructural verificable de una correspondencia pedagógica validada. Si no existe aprobación humana documentada, la relación se muestra como pendiente.
- Conserva indicadores y RdA literales; no crea facetas, porcentajes, semáforos, evidencias ni afirmaciones de logro.
- Diferencia desarrollo explícito, presencia o fortalecimiento respaldados, ausencia de registro, no aplicable y área ausente.
- Mantiene ANTES y DESPUÉS como referencias; únicamente AHORA corresponde al currículo que puede planificarse.
- La Ruta no modifica semanas, proyección, prompts, diagnóstico, Proyecto, JSON, PDF, Word ni autoguardado.
- Conserva `schemaVersion: 6`, compatibilidad con planes 1.6.15 y funcionamiento autónomo.
- La regresión automatizada recorre 38 familias, 16 RdA, 10 niveles, 20 combinaciones nivel–módulo y 236 saberes–indicadores.
- La matriz de correspondencias pedagógicas inicia vacía: PIA informa el vínculo estructural, pero no inventa ni certifica contribuciones indicador–RdA sin aprobación documentada.

## Novedad 1.6.15 — Controles de responsabilidad y tiempo neto

- El perfil de evaluación mostrado es solo una referencia hasta que la persona docente confirme ciclo, modalidad y disposiciones aplicables.
- Seleccionar ambos módulos exige confirmar que el marco temporal cubre expresamente los dos periodos; para un semestre ordinario PIA orienta a seleccionar uno.
- El marco temporal calcula lecciones y minutos netos después de descontar diagnóstico, periodos sin desarrollo curricular y reserva para aplicación/realimentación.
- Las ventanas evaluativas se rotulan como referencias iniciales editables; la IA las relaciona después con actividades y evidencias, y la persona docente decide.
- La revisión de respuestas se denomina comprobación técnica y declara que no certifica pertinencia, profundidad, integración ni aprendizaje.
- La prueba permanente recorre 236 indicadores en las 20 combinaciones de Preescolar a 9.º, incluidos los catálogos propios de Preescolar.
- Se conserva `schemaVersion: 6`, operación local, currículo protegido, semanas, Proyecto, JSON, PDF, Word y portable.

## Novedad 1.6.14 — Explorar un ejemplo de planeamiento

La portada ofrece un recorrido formativo opcional para personas nuevas en PIA. Conecta nivel y horizonte curricular, contexto y diagnóstico, profundidad y trayectoria, metodologías, proyección semestral, planeamiento semanal, evaluación, Proyecto en secundaria y guardado. Los escenarios son ejemplos y nunca sustituyen el criterio profesional docente.

El recorrido es local e independiente: sus controles no cambian el planeamiento, su avance no forma parte del JSON y no aparece en PDF o Word. Consulte `docs/GUIA_EXPERIENCIA_FORMATIVA_V1.6.14.md` para la descripción completa y las pruebas pendientes de publicación.

## Conclusiones consolidadas 1.6.13

- Corrige la regla curricular crítica: una celda vacía significa **sin abordaje conceptual documentado**;
  no significa fortalecimiento. `N/A` conserva el significado de no aplicable.
- Amplía **Explorar trayectoria curricular** con tarjetas y tabla comparativa, filtros por módulo, área
  y alcance, encabezado contextual, RdA, fuente visible e íconos del recurso PNFT aportado.
- Mantiene antecedentes y continuidad fuera del prompt; la IA recibe únicamente el currículo del nivel
  y los saberes seleccionados para la proyección.
- El diagnóstico inicia en cero, permanece desactivado y solo se incorpora al prompt mediante selección
  expresa. Añade guía de interpretación y **Reiniciar diagnóstico** sin afectar el plan.
- Sustituye “Nota” por **Observación o decisión docente** y aclara que “Durante todo el periodo” no exige
  evaluación semanal ni fija una cantidad de observaciones.
- Conserva la auditoría temporal posterior, `schemaVersion: 6`, funcionamiento autónomo, JSON, PDF, Word
  y compatibilidad histórica.
- 132 pruebas automatizadas aprobadas.

## Trayectoria curricular y auditoría temporal histórica 1.6.12

- Añade **Explorar trayectoria curricular** bajo la cobertura de las semanas, con tarjetas interactivas
  por familia y filtros cromáticos para las cuatro áreas del PNFT.
- Organiza la lectura en **ANTES**, **AHORA** y **DESPUÉS**. AHORA contiene exclusivamente los saberes
  seleccionados del nivel y sus indicadores literales; ANTES orienta el diagnóstico y DESPUÉS informa
  la continuidad sin trasladarla al currículo vigente.
- Esta primera versión de la vista fue corregida y ampliada en 1.6.13. La vista continúa sin seleccionar,
  escribir, persistir ni exportar datos.
- El prompt semestral exige una auditoría temporal posterior a la propuesta, fundada en integración,
  profundidad, continuidad y evidencias; un conteo como 18 indicadores y 19 bloques no genera por sí solo una alerta.
- Corrige la presentación de `development → Prototipar` por **Etapa de desarrollo → Prototipar** sin
  modificar el identificador técnico interno ni la compatibilidad de planes.
- Conserva `schemaVersion: 6`, currículo, semanas, diagnóstico, Proyecto, JSON, PDF, Word y portable.
- 127 pruebas automatizadas aprobadas; revisión humana final en Edge/Chrome pendiente por control institucional.

## Mejora de experiencia 1.6.11

- Mantiene la cantidad de lecciones diagnósticas en el Marco temporal y ubica **Preparar evaluación
  diagnóstica** después de los saberes, cuando PIA ya conoce ciclo, nivel, módulo, área y saber conceptual.
- El acceso se habilita únicamente al disponer de esos referentes y de una o dos lecciones; el diagnóstico
  continúa siendo opcional y nunca bloquea la proyección semestral.
- Añade ayudas contextuales breves y centralizadas para conceptos curriculares y funciones de PIA.
- Las ayudas funcionan con puntero, foco, clic, toque y `Esc`, muestran una sola explicación a la vez,
  se posicionan sin bloquear la pantalla y quedan excluidas de impresión y exportación.
- Conserva `schemaVersion: 6`, currículo del PNFT, prompts, diagnóstico, Proyecto, semanas, JSON,
  autoguardado, PDF, Word, portable y la separación de PIA 1.7.x.
- 120 pruebas automatizadas aprobadas.

## Mejora integral 1.6.10

- Convierte el apoyo diagnóstico en un flujo persistente con modos **Modelo para asesoría** y
  **Aplicación docente**, sin inventar resultados cuando no existe un grupo observado.
- Distingue las áreas cognoscitiva, socioafectiva y psicomotora de una secuencia de etapas; permite
  precisar aprendizajes previos, diseñar la experiencia, registrar resultados generales y orientar decisiones.
- Mantiene el máximo de dos lecciones y separa el currículo actual —que se debe desarrollar— de los
  antecedentes que solo pueden explorarse diagnósticamente.
- Añade ventanas evaluativas orientadoras, editables y confirmables para trabajo cotidiano, tareas,
  prueba de ejecución y Proyecto. Ninguna sugerencia escribe automáticamente las semanas.
- Las decisiones evaluativas confirmadas llegan al prompt semestral y a **Afinar semana con IA** cuando
  corresponden, respetando calendario, evidencias, realimentación y criterio docente.
- Permite pegar y revisar localmente respuestas de IA: comprueba literalidad, estructura, currículo
  seleccionado y alertas básicas sin incorporar automáticamente el contenido al planeamiento.
- Diagnóstico, sugerencias, respuestas y reportes se conservan en JSON v6, autoguardado y portable.
- Conserva currículo, Preescolar, Proyecto, juego, semanas, PDF y Word de PIA 1.6.9; PIA 1.7.x continúa separado.
- 117 pruebas automatizadas aprobadas.

## Mejora integral 1.6.9

- Añade desde la portada un juego formativo de siete misiones sobre ABJ, ABR, Pensamiento de Diseño,
  Preescolar, secundaria con una o dos rutas metodológicas y evaluación diagnóstica/DUA.
- El juego funciona localmente, ofrece realimentación inmediata y no modifica ni califica el planeamiento.
- Contextualización y DUA incorpora un check explícito: solo lo activado se envía a los prompts.
- Añade “Preparar evaluación diagnóstica con IA”, con proceso completo y dimensiones cognitiva,
  socioemocional y psicomotriz, manteniendo el máximo de dos lecciones.
- “Otra metodología” dispone de fundamentación pedagógica condicional y trazable en los prompts.
- El prompt semanal se convierte en “Afinar semana con IA” y conserva currículo, metodología y texto previo.
- En Proyecto, Prototipar y Probar/Evaluar vinculan indicadores oficiales del módulo; los textos históricos
  de planes anteriores se conservan sin presentarlos como oficiales.
- Mantiene JSON v6, autoguardado, currículo, filtros semanales, Word, PDF y portable.

## Mejora integral 1.6.8

- Añade una portada local MEP–PNFT–PIA con acceso directo para iniciar o cargar un planeamiento,
  preferencia reversible por dispositivo y retorno sin pérdida de datos. No forma parte de PDF o Word.
- Mantiene el encabezado administrativo oficial y mejora la identidad opcional: escudo y lema alineados
  a la izquierda, sin duplicar el centro educativo y con dimensiones controladas en web y Word.
- Mantiene el diagnóstico entre 0 y 2 lecciones, sincronizado con marco temporal y semanas iniciales sin
  borrar contenido.
- Convierte Contextualización y DUA en una ayuda opcional más precisa: conserva los campos abiertos y
  agrega perfil de implementación, condiciones complementarias, escenario tecnológico y punto de
  partida grupal, siempre sin datos personales del estudiantado.
- Permite seleccionar indicadores de referencia de otro nivel desde el catálogo autorizado del PNFT.
  PIA protege su literalidad y procedencia, conserva por separado la contextualización docente y evita
  presentarlos como currículo oficial del nivel vigente.
- Fortalece los prompts General, Semestral y Semanal con guardado explícito, estado visible, actualización
  desde los datos actuales y restablecimiento protegido por confirmación. Cerrar el diálogo, guardar JSON
  o usar autoguardado conserva la edición docente.
- El contrato contextual de IA solicita DUA y alternativas equivalentes sin conexión, distingue
  currículo del nivel, referencias y textos docentes, y señala decisiones sujetas a validación institucional.
- El prompt semestral exige metodología activa, omite opciones no seleccionadas y campos vacíos, conserva
  fechas parciales sin inventarlas y muestra la ruta área → saber → indicador de logro del PNFT → RdA.
- Conserva la barra contextual de 1.6.7, el currículo del PNFT, Preescolar, Proyecto, progresión interna,
  JSON v6, autoguardado, exportaciones y funcionamiento portable.
- El resultado de pruebas se incorpora al cerrar la validación de entrega; no se anticipa una cifra.

## Mejora 1.6.7

- La barra de formato se abre al seleccionar texto en Estrategias de mediación o Indicadores de
  evaluación y conserva la selección mientras se aplican varios cambios.
- Identifica claramente el campo activo y permanece accesible durante el desplazamiento; las opciones
  menos frecuentes se agrupan en “Más opciones” para no estorbar la escritura.
- Añade sangría, limpieza de la selección, subtítulos rápidos Inicio–Desarrollo–Cierre, pegado limpio
  opcional y vínculos HTTPS sujetos a validación docente.
- Mantiene deshacer/rehacer independiente, opciones principales compactas, cierre con `Esc` y controles
  táctiles de al menos 44 px en pantallas pequeñas.
- Los Indicadores de logro del currículo de FT siguen protegidos y el formato enriquecido continúa
  conservándose mediante el guardado/carga y las exportaciones vigentes.
- 96 pruebas automatizadas aprobadas.

## Mejora 1.6.6

> Registro histórico: desde 1.6.13 la trayectoria sí se muestra en la interfaz local y no se envía
> al prompt semestral.

- Mantiene activas las 38 familias y la trayectoria curricular completa como una capa interna de
  análisis, sin exponer al usuario los bloques técnicos AHORA–ANTES–DESPUÉS.
- El prompt recibe una única orientación clara sobre integración horizontal, progresión vertical y
  familias relacionadas con los saberes elegidos.
- La orientación limita la propuesta al nivel actual, usa los antecedentes solo para diagnóstico y
  prohíbe adelantar alcances posteriores o convertir refuerzos en indicadores.
- Conserva íntegramente el contrato especializado de Preescolar incorporado en 1.6.5.
- No modifica currículo oficial, JSON v6, semanas, Proyecto, PDF, Word ni versión portable.
- 93 pruebas automatizadas aprobadas.

## Mejora 1.6.5

- Añade al prompt las competencias específicas y el perfil de salida oficiales de Preescolar,
  filtrados por las áreas seleccionadas.
- Aplica un contrato exclusivo para experiencias lúdicas de Preescolar, con bloques de 80 minutos
  continuos o fraccionados y continuidad curricular entre semanas.
- Mantiene la evaluación exclusivamente diagnóstica y formativa, sin porcentajes ni instrumentos
  propios de otros perfiles.
- No impone mínimos numéricos semanales de áreas, saberes o indicadores; exige integración auténtica.
- Omite toda referencia a Proyecto en Preescolar, I y II Ciclo. En III Ciclo conserva el estado
  “Componente Proyecto no seleccionado” cuando corresponde.
- 92 pruebas automatizadas aprobadas.

## Mejora 1.6.4

- Traduce la trayectoria al lenguaje docente: **AHORA–ANTES–DESPUÉS**.
- Destaca el alcance obligatorio del nivel seleccionado y reserva los antecedentes para diagnóstico.
- Oculta listas `N/A`, “Sin niveles intermedios” y separadores técnicos que no ayudan a decidir.
- Distingue una referencia anterior no continua de un prerrequisito directo.
- El alcance actual muestra solamente los saberes marcados por la persona docente, aunque la familia
  curricular contenga otros saberes del mismo nivel.
- Conserva la continuidad posterior como orientación y prohíbe trasladarla al semestre actual.
- 88 pruebas automatizadas aprobadas.

## Corrección 1.6.3

- Los antecedentes se rotulan expresamente como referencia curricular que no confirma enseñanza ni aprendizaje.
- El prompt obliga a planear íntegramente el nivel seleccionado y a verificar prerrequisitos mediante diagnóstico.
- En 9.º, la continuidad posterior se identifica como fuera del alcance del catálogo actual.
- Los niveles intermedios anteriores se presentan en orden cronológico.
- Se incluye `docs/infografia-como-utiliza-pia-la-progresion-v1.6.3.png` como apoyo para explicar
  al equipo asesor que la persona docente conduce, PIA orienta y la IA propone.
- 86 pruebas automatizadas aprobadas.

## Mejora 1.6.2

> Registro histórico: la interpretación del vacío y el envío de antecedentes al prompt fueron
> corregidos y sustituidos por las reglas de 1.6.13 descritas al inicio de este documento.

- Añade un catálogo relacional interno de 38 familias de saberes, desde Preescolar hasta 9.º,
  derivado de la matriz validada “Saberes por Año Escolar julio -2026”.
- Relaciona los 236 registros curriculares actuales de PIA con una familia mediante correspondencias
  exactas por área y nombre; no modifica `PNFT_DATA`, los RdA ni los indicadores oficiales.
- En esa versión el prompt recibía fundamentos previos, alcance y proyección posterior; desde 1.6.13
  esta información permanece exclusivamente en la consulta local.
- En esa versión el vacío se interpretaba como refuerzo; 1.6.13 lo corrige a ausencia de registro
  curricular. `N/A` conserva el significado de no aplicable.
- La referencia no selecciona saberes, no crea indicadores, no asigna evaluación y no declara
  dominio, aprendizaje alcanzado ni cumplimiento del RdA.
- Se preservan JSON v6, PDF, Word, portable, semanas y todas las funciones validadas de 1.6.1.
- 85 pruebas automatizadas aprobadas.

## Mejora 1.6.1

- Cada semana incorpora un selector compacto de Módulo 1, Módulo 2 o ambos junto al momento pedagógico.
- Áreas, RdA y saberes conceptuales se filtran según nivel y módulos activos, sin borrar selecciones previas.
- Los saberes nuevos conservan una referencia compuesta de módulo, área y nombre para obtener el indicador exacto.
- Los planes anteriores se abren con ambos módulos disponibles cuando ya contienen currículo semanal.
- La selección curricular semanal puede plegarse para reducir desplazamiento sin perder información.
- El prompt semestral puede actualizar el marco temporal vigente protegiendo el texto anterior mediante confirmación.
- Contextualización/DUA y Seguridad/recuperación se presentan como secciones desplegables.
- 80 pruebas automatizadas aprobadas.

## Mejora 1.6.0

- Prototipar y Probar/Evaluar se seleccionan también desde la proyección semestral.
- Cada fase posterior ofrece un indicador de logro y dos indicadores de evaluación editables,
  diferenciados expresamente del currículo y de los indicadores oficiales del Proyecto.
- Las semanas inicializan esos textos desde la proyección, pero una edición semanal existente nunca
  se sobrescribe al cambiar de fase, guardar o cargar.
- El JSON v6 conserva el prompt general, el prompt semestral y cada prompt semanal editado.
- La Proyección semestral puede ocultarse y mostrarse sin pérdida de datos.
- Word amplía y mantiene blancas las áreas de Reflexiones Docentes y Observaciones.
- 75 pruebas automatizadas aprobadas.

## Mejora 1.5.2

- PDF y Word incorporan el indicador de logro del Proyecto dentro de la columna oficial de logro.
- Los indicadores de evaluación seleccionados del Proyecto se incorporan dentro de la columna oficial de evaluación.
- Se exporta `teacherText` cuando existe; de lo contrario se utiliza la instantánea `officialText` guardada.
- Los indicadores de evaluación desmarcados se conservan en JSON, pero no aparecen en PDF ni Word.
- La misma selección efectiva se utiliza en ambos exportadores, evitando diferencias entre formatos.
- Guardar y cargar conserva texto oficial, texto docente y estado seleccionado de cada indicador.

## Base conservada de 1.5.1

- El catálogo de instrumentos pasa a ser conocimiento interno del prompt: la IA recomienda uno o
  varios instrumentos después de definir las actividades y evidencias, con justificación y uso.
- Proyecto conserva una ruta global por etapas y se concreta por semana mediante tres modalidades:
  curricular (80 min), mixta (40 + 40 min) e integrada mediante Proyecto (80 min).
- El indicador de logro y los indicadores de evaluación del Proyecto aparecen en las columnas
  oficiales de cada semana, sin crear un segundo planeamiento.
- Cada texto oficial se guarda como referencia inmutable y su contextualización docente se conserva
  aparte. Guardar, cargar, cambiar de fase u ocultar Proyecto no reemplaza la edición docente.
- Se eliminaron hitos, porcentajes y estados operativos que podían confundirse con aprendizaje o nota.
- JSON v6 con migración desde planes anteriores; backend y analítica continúan inactivos.

## Resultado

La fuente monolítica fue separada por responsabilidades en `src/`. El constructor concatena
los fragmentos en el orden aprobado y genera dos salidas:

- `dist/web/index.html`
- `dist/portable/index.html`

Ambas salidas son autónomas. La entrega conserva la referencia aprobada, las correcciones de
semanas y Word, e incorpora una capa reversible de proyección y herramientas de apoyo.

## Corrección 1.4.1

- El selector **Itinerario de preescolar** queda oculto y deshabilitado en I, II y III Ciclo.
- Solo aparece al seleccionar Materno Infantil/Transición y el nivel interno `0°`.
- Se añadió una regla CSS explícita para que ningún estilo de campo pueda anular `hidden`.

## Novedades 1.4.0

- Código presupuestario conectado a un catálogo local de 4.651 centros: completa coincidencias únicas
  y presenta una selección segura para códigos compartidos.
- Exclusión permanente de registros `0000` y de datos personales; no existe carga de Excel para docentes.
- `codSaber` se conserva internamente en el JSON vigente para una integración institucional futura.
- Preescolar incorpora cuatro rutas oficiales separadas: Módulo 1/2 Básico requerido y Módulo 1/2 Óptimo.
- Saberes, indicadores y RdA de Preescolar provienen de un catálogo aislado con trazabilidad documental.
- El punto metodológico del prompt semestral exige andamiaje continuo para ABJ, ABR y APD, sin reiniciar
  artificialmente la metodología cada semana.
- El escudo institucional conserva un ancho estable de 90 px en la exportación Word.

## Base conservada de 1.3.1

- Orden docente validado: identidad opcional antes del encabezado administrativo; contexto/DUA y proyección antes de las semanas.
- Proyección de referencia por uno o ambos módulos, áreas y saberes, con los RdA oficiales visibles.
- Perfiles de evaluación contextualizados por ciclo/modalidad, con fundamento visible y sin imponer cantidades no universales.
- Prompt semestral opcional para una herramienta de IA autorizada; PIA no recibe ni aplica automáticamente su respuesta.
- Prompt semestral con matriz, detalle bimestral/semanal, inicio–desarrollo–cierre, RdA, DUA, alternativa desconectada y dos indicadores sugeridos por indicador oficial.
- Indicadores oficiales protegidos; formato local por semana solo en mediación e indicadores de evaluación.
- Navegador para 22 o más semanas con anterior/siguiente, selector, estados, vista única y vista completa.
- Cobertura interna basada en las semanas reales; Proyección y Cobertura quedan fuera del PDF y Word oficial.
- JSON v5 compatible con planes anteriores, autoguardado recuperable y puente backend aún inactivo.

## Base conservada de 1.2.1

- Proyección semestral visible como etapa principal después de Metodología activa.
- Recorrido docente de tres pasos: tiempo, currículo y saberes.
- Resumen en vivo de semanas, lecciones, áreas y saberes seleccionados.
- Búsqueda y selección masiva de saberes conceptuales visibles.
- Diseño adaptable para computadora, tableta y móvil, con foco visible y mensajes orientadores.
- Recuperación y diagnóstico agrupados de forma compacta antes de las semanas.

## Funciones incorporadas desde 1.2.0

- Proyección por Módulo 1, Módulo 2 o ambos, áreas y saberes con identificadores sin colisiones.
- Una semana de 80 minutos equivale a dos lecciones pedagógicas; el diagnóstico queda visible en la semana 1.
- Saberes conceptuales, procedimentales y actitudinales, con cobertura incorporada/pendiente.
- Prompt semestral con inicio, desarrollo, cierre, DUA y dos alternativas por indicador.
- Identidad institucional, JSON v5, autoguardado, recuperación y formato offline.
- Revisión previa, diagnóstico técnico y formato independiente por campo semanal.
- Puente de backend y analítica presentes solo como contrato inactivo y sin red.

## Dónde está cada resultado

- JavaScript editable: carpetas de `src/`, organizado por responsabilidad.
- Plantilla web lista para abrir: `dist/web/index.html`.
- Plantilla offline autónoma: `dist/portable/index.html`.
- Copia de acceso rápido: `index.html` en la raíz.
- Exportación PDF: `src/infrastructure/export/pdf-exporter.js`; desde PIA se abre la vista de
  impresión y se elige **Guardar como PDF**. El navegador debe permitir la ventana emergente.
- Exportación Word: en el mismo modal seleccione **Word editable**. Se abre una vista continua con
  botones para guardar el archivo `.doc` compatible con Word o imprimirlo. El archivo declara A4
  horizontal también para Microsoft Word y permite que los encabezados largos se distribuyan en
  varias líneas. Si la ventana está bloqueada, PIA descarga el archivo como respaldo.
- Descarga portable desde PIA: el navegador la guarda en su carpeta habitual de Descargas.

## Comandos

```bash
npm test
```

El comando comprueba sintaxis, CSS, ausencia de APIs de red, construcción reproducible, alcance
autorizado, proyección, cobertura, migración, guardado/carga, Word y eliminación de semanas.

```text
referencia: 70a72f7c0218da49b9d748ff0a12648ec2364d04668625b1d8cd07428e3814e9
La huella vigente se registra en `CURRENT.sha256` después de cada entrega aprobada.
```

## Arquitectura

- `src/data`: contenido curricular base, catálogo oficial aislado de Preescolar y catálogo mínimo de centros.
- `src/domain`: currículo, consulta de centros, estado, operaciones de semanas y reglas puras de proyección.
- `src/application`: inicialización y coordinación del plan.
- `src/infrastructure`: persistencia, PDF y portable.
- `src/prompts`: prompt general y semanal.
- `src/ui`: construcción de semanas y notificaciones.
- `src/adapters`: contratos de integración; el puente backend está inactivo.
- `src/styles`: estilos separados en el orden original.
- `src/templates`: estructura HTML separada por secciones.
- `scripts`: construcción y puertas automáticas de equivalencia.

## Evolución posterior

No se implementó backend, API, autenticación ni analítica. React podrá sustituir posteriormente
la capa de interfaz, y PHP u otra tecnología podrá implementar el contrato de repositorio sin
reemplazar el dominio ni el guardado local. Esa activación requiere una fase independiente.

El selector de Preescolar aplica los itinerarios oficiales Básico requerido u Óptimo de forma
independiente para cada módulo. El nivel `0°` se conserva como identificador técnico compatible.

`reference/index.original.html` es inalterable y nunca debe generarse desde `src/`.

## Corrección autorizada de semanas

La secuencia comprobada es: 8 semanas/16 lecciones → eliminar semana 8 → 7/14 → eliminar
semana 7 → 6/12. Se preservan los datos de las semanas 1–6, sus identificadores, nombres y
contadores. Cada eliminación conserva su confirmación independiente.

## Integración con el repositorio vigente

`docs/source-snapshot/` conserva los documentos que acompañaron al HTML recibido. Pueden estar
desactualizados frente a T107–T108 y no deben sobrescribir la documentación operativa más
reciente de VS Code. Integre `src/`, `scripts/`, `package.json`, las salidas y los dos informes;
mantenga los tests, runs, evidencias, bitácora y tareas más recientes del repositorio vigente.
