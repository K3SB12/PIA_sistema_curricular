# Backend futuro — no implementado

PIA 1.2.0 funciona completamente en el navegador y no necesita servidor. Esta carpeta documenta
únicamente el punto de extensión futuro.

El contrato conceptual es `PlanRepository`: guardar, cargar, listar, eliminar y comprobar salud.
La implementación actual en `src/adapters/backend-bridge.js` declara `local-only`, lanza un error
claro si se intenta usar almacenamiento remoto y no contiene solicitudes, endpoints, credenciales
ni autenticación. La analítica está desactivada y descarta eventos.

Antes de activar un backend deben aprobarse arquitectura, privacidad, seguridad, autenticación,
retención, respaldo, recuperación, control de versiones y pruebas de migración. Nunca deben
enviarse datos personales del estudiantado ni texto libre del planeamiento como analítica.
