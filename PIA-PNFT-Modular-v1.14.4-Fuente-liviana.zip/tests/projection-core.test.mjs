import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const source = await readFile(resolve(root, 'src/domain/projection/projection-core.js'), 'utf8');
const context = vm.createContext({ result: null, encodeURIComponent });
vm.runInContext(`${source}\nresult = PIAProjectionCore;`, context);
const core = context.result;

const curriculum = {
  '2°': {
    'Módulo 1': {
      'Área A': { saberes: [{ nombre: 'Dato', indicadores: ['Indicador A'] }, { nombre: 'Algoritmo', indicadores: ['Indicador B'] }] },
      'Área B': { saberes: [{ nombre: 'Dato', indicadores: ['Indicador C'] }] },
    },
    'Módulo 2': { 'Área A': { saberes: [{ nombre: 'Evento', indicadores: ['Indicador D'] }] } },
  },
};

test('la proyección usa identificadores compuestos y admite ambos módulos', () => {
  const concepts = core.listConcepts(curriculum, '2°', ['Módulo 1', 'Módulo 2'], ['Área A', 'Área B']);
  assert.equal(concepts.length, 4);
  assert.equal(new Set(concepts.map(x => x.id)).size, 4, 'los nombres repetidos no deben colisionar');
  assert.deepEqual([...new Set(concepts.map(x => x.module))], ['Módulo 1', 'Módulo 2']);
});

test('distribuye con preferencia de dos y permite tres o más sin perder saberes', () => {
  const concepts = Array.from({ length: 7 }, (_, index) => ({ id: String(index), area: 'Área' }));
  const roomy = core.distribute(concepts, 4, 2);
  assert.deepEqual(structuredClone(roomy.map(x => x.concepts.length)), [2, 2, 2, 1]);
  const compact = core.distribute(concepts, 2, 2);
  assert.deepEqual(structuredClone(compact.map(x => x.concepts.length)), [4, 3]);
  assert.equal(compact.flatMap(x => x.concepts).length, 7);
});

test('reserva el diagnóstico sin perder la cobertura curricular', () => {
  const concepts = Array.from({ length: 5 }, (_, index) => ({ id: String(index), area: 'Área' }));
  const rows = core.distribute(concepts, 4, 2, 1);
  assert.equal(rows[0].phase, 'diagnóstico');
  assert.equal(rows[0].concepts.length, 0);
  assert.equal(rows.slice(1).flatMap(row => row.concepts).length, 5);
});

test('cobertura separa proyectado de ejecutado', () => {
  const concepts = [{ id:'1',area:'Área' },{ id:'2',area:'Área' },{ id:'3',area:'Área' }];
  const result = core.coverage(concepts,[{concepts:[concepts[0],concepts[1]],executed:true},{concepts:[concepts[2]],executed:false}])[0];
  assert.deepEqual(structuredClone(result), { area:'Área', total:3, projected:3, executed:2, projectedPct:100, executedPct:67 });
});

test('migra planes anteriores a esquema v6 sin exigir backend', () => {
  const migrated = core.migrate({ semanas: [], pia:{identity:{name:'duplicado'},calendar:{diagnosisWeeks:1}} });
  assert.equal(migrated.schemaVersion, 6);
  assert.deepEqual(structuredClone(migrated.aiPrompts), {general:'',semester:'',routeStrategies:'',weekly:{}});
  assert.equal(migrated.evaluation.projectPlanning.enabled, false);
  assert.equal(migrated.status, 'draft');
  assert.equal(migrated.calendar.weeks, 22);
  assert.equal(migrated.calendar.diagnosisLessons, 2);
  assert.equal(migrated.identity.name, '');
  assert.deepEqual(Array.from(migrated.projection.modules), []);
});

test('la migración v6 conserva literalmente los prompts editados y la preferencia visual', () => {
  const migrated=core.migrate({pia:{aiPrompts:{general:'Texto general propio',semester:'Texto semestral propio',weekly:{'1':'Texto semanal propio'}},ui:{projectionExpanded:false}}});
  assert.equal(migrated.aiPrompts.general,'Texto general propio');
  assert.equal(migrated.aiPrompts.semester,'Texto semestral propio');
  assert.equal(migrated.aiPrompts.weekly['1'],'Texto semanal propio');
  assert.equal(migrated.ui.projectionExpanded,false);
});
