import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [runtime,template,styles,initialization,header]=await Promise.all([
  read('src/application/enhancements.js'),read('src/templates/enhancements.html'),read('src/styles/08-enhancements.css'),read('src/application/initialization.js'),read('src/templates/header.html')
]);

test('cada ciclo abre en su primer nivel esperado',()=>{
  for(const pair of ["'I Ciclo': '1°'","'II Ciclo': '4°'","'III Ciclo': '7°'","'Materno Infantil/Transición': '0°'"])assert.ok(initialization.includes(pair),pair);
});

test('el constructor recibe propuestas por Markdown o JSON sin reemplazar la ruta automáticamente',()=>{
  for(const id of ['piaRouteAIResponse','piaRouteImportJson','piaRouteProcessAIResponse','piaRouteProposalSummary','piaRouteRequestAdjustments'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/pia-route-options-v3/);
  assert.match(runtime,/fingerprint!==routeSelectionFingerprint/);
  assert.match(runtime,/La propuesta corresponde a otra selección curricular/);
  assert.match(runtime,/Ninguna sustituye la ruta hasta que usted la seleccione/);
  assert.match(runtime,/function applyRouteProposal/);
});

test('la importación protege currículo, tiempo y las cinco fases de Pensamiento de Diseño',()=>{
  assert.match(runtime,/allowedIds=new Set\(concepts\.map/);
  assert.match(runtime,/weekEnd<weekStart\|\|weekEnd>weeks/);
  assert.match(runtime,/debe conservar las cinco fases de Pensamiento de Diseño/);
  for(const phase of ['empathize','define','ideate','prototype','test-evaluate'])assert.ok(runtime.includes(phase),phase);
  assert.match(runtime,/Probar\/Evaluar no tiene saber o evidencia vinculada/);
});

test('la respuesta técnica se traduce a una vista docente y los porcentajes no representan logro',()=>{
  assert.match(template,/Datos técnicos \(opcionales\)/);
  assert.match(runtime,/Porcentajes de organización curricular de los saberes; no representan participación, logro ni calificación/);
  assert.match(runtime,/Ver cambios antes de aplicar/);
});

test('el mismo flujo continúa a proyección semestral o estrategias semana a semana',()=>{
  for(const id of ['piaRouteContinueSemester','piaRouteWeeklyStrategies','piaRouteStickySemester','piaRouteStickyWeekly'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/function routeWeeklyStrategiesPrompt/);
  for(const heading of ['Inicio','Desarrollo','Cierre','Evidencia','DUA y accesibilidad','Trabajo cotidiano \/ tarea','Instrumento sugerido','Ajuste o alerta'])assert.match(runtime,new RegExp(heading));
  assert.match(runtime,/Las ventanas bimestrales son \*\*orientadoras\*\*/);
  assert.match(runtime,/no establezca que deba evaluarse todas las semanas/i);
});

test('la barra inferior no usa margen negativo y el modal protege el contenido',()=>{
  assert.match(styles,/\.pia-route-sticky-actions\{position:sticky;bottom:0[^}]*margin:16px -16px 0/);
  assert.doesNotMatch(styles,/\.pia-route-sticky-actions\{[^}]*margin:[^;}]*-84px/);
  assert.match(styles,/scroll-padding-bottom:120px/);
  assert.match(styles,/body\.pia-route-open .*help/i);
  assert.doesNotMatch(runtime,/event\.target===event\.currentTarget\)closeRoutePlanner/);
});

test('el mapa permite ir al saber editable y volver al mapa',()=>{
  assert.match(template,/id="piaRouteBackToMap"/);
  assert.match(runtime,/addEventListener\('dblclick'/);
  assert.match(runtime,/function focusRouteTableRow/);
  assert.match(runtime,/function backToRouteMap/);
  assert.match(styles,/pia-route-row-target/);
});

test('tema claro y oscuro tiene control visible y persistente',()=>{
  assert.match(header,/id="piaThemeToggleMain"/);
  assert.match(runtime,/THEME_STORAGE_KEY/);
  assert.match(runtime,/classList\.toggle\('pia-dark'/);
  assert.match(styles,/body\.pia-dark/);
});
