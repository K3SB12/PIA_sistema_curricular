import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [runtime,template,styles,agents]=await Promise.all([
  read('src/application/enhancements.js'),read('src/templates/enhancements.html'),read('src/styles/08-enhancements.css'),read('AGENTS.md')
]);

test('la comparación conserva la lectura nodal antes de aplicar una propuesta',()=>{
  assert.match(runtime,/function routeProposalPreviewHtml/);
  assert.match(runtime,/Vista conceptual preliminar/);
  assert.match(styles,/\.pia-route-proposal-node/);
  assert.match(runtime,/Solo Proyecto/);
  assert.match(runtime,/Presencia curricular/);
});

test('el 0 por ciento de solo Proyecto no oculta la presencia de saberes integrados',()=>{
  assert.match(runtime,/projectPresence=Math\.round\(\(\(counts\.direct\|\|0\)\+\(counts\.integrated\|\|0\)\)\*100\/total\)/);
  assert.match(runtime,/Lecciones \+ Proyecto/);
});

test('PIA genera localmente los archivos md y json de la respuesta validada',()=>{
  for(const id of ['piaRouteDownloadAIResponse','piaRouteDownloadValidatedJson'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/function downloadRouteAIResponse/);
  assert.match(runtime,/function downloadValidatedRouteProposal/);
  assert.match(runtime,/Respuesta-IA-ruta-/);
  assert.match(runtime,/Propuestas-validadas-/);
});

test('el prompt comparativo puede señalar oportunidades orientadoras de TC y tareas',()=>{
  assert.match(runtime,/evaluationComponent/);
  assert.match(runtime,/Trabajo cotidiano/);
  assert.match(runtime,/Tarea/);
  assert.match(runtime,/Los instrumentos se definirán después/);
});

test('el doble clic no pierde el nodo por un rerender en el primer clic',()=>{
  assert.match(runtime,/function refreshRouteSelection/);
  assert.match(runtime,/map\.selectedId=id;refreshRouteSelection\(\)/);
  assert.match(runtime,/addEventListener\('dblclick'/);
  assert.match(runtime,/focusRouteTableRow/);
});

test('los bloques se pueden mover de forma visual sin persistir coordenadas',()=>{
  assert.match(runtime,/const routeNodeOffsets = new Map/);
  assert.match(runtime,/startRouteNodeDrag/);
  assert.match(runtime,/moveRouteNodeDrag/);
  assert.match(runtime,/endRouteNodeDrag/);
  assert.match(styles,/cursor:grab/);
  assert.match(agents,/Las posiciones son efímeras y nunca forman parte del JSON/);
  assert.doesNotMatch(runtime,/routeAssignments\[[^\]]+\].*(?:offset|coordinate|position)/i);
});
