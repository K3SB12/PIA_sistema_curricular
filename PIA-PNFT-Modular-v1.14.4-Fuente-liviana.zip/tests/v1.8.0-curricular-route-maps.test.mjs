import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,coreSource,promptSource,dataSource]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/styles/08-enhancements.css'),
  read('src/domain/projection/projection-core.js'),read('src/prompts/semester-projection-prompt.js'),read('src/data/pnft-data.js')
]);

test('el bloque anterior fue sustituido por una ruta separada del formulario del Proyecto',()=>{
  assert.doesNotMatch(template,/Articular currículo y Proyecto como un solo proceso/);
  assert.match(template,/id="piaCurricularRoutePlannerWrap"/);
  assert.match(template,/id="piaProjectPlanningWrap"[\s\S]+id="piaCurricularRoutePlannerWrap"/);
  assert.match(template,/Decisión docente/);
});

test('docente nuevo y experto trabajan sobre el mismo modelo curricular',()=>{
  for(const id of ['piaRouteGuidedMode','piaRouteExpertMode','piaRouteMap','piaRouteAssignments','piaRouteAudit'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(coreSource,/routeMode:'guided'/);
  assert.match(runtime,/state\.methodology\.routeMode='expert'/);
  assert.match(runtime,/routeAssignments/);
  assert.match(styles,/\.pia-route-modal\[data-mode="expert"\]/);
});

test('las cuatro ubicaciones conservan pendientes visibles y articulan Proyecto con lecciones',()=>{
  for(const role of ['Pendiente de ubicar','Lecciones pedagógicas','Componente Proyecto','Lecciones y Proyecto'])assert.match(runtime,new RegExp(role));
  assert.match(runtime,/ROUTE_ROLE_ALIASES/);
  assert.match(runtime,/no los omitirá/);
  assert.match(runtime,/la misma evidencia no se contabilice en dos componentes/);
});

test('la ruta confirmada alimenta el prompt sin declarar logro o certificación',()=>{
  assert.match(runtime,/RUTA CURRICULAR CONFIRMADA O PENDIENTE POR LA PERSONA DOCENTE/);
  assert.match(runtime,/no como prueba de logro/i);
  assert.match(promptSource,/curricularRouteBlock/);
  assert.match(promptSource,/curricularRouteSection/);
});

test('la migración conserva planes 1.7.5 y agrega una ruta segura sin cambiar schema v6',()=>{
  const context=vm.createContext({result:null,encodeURIComponent});
  vm.runInContext(`${coreSource}\nresult=PIAProjectionCore;`,context);
  const migrated=context.result.migrate({pia:{methodology:{coordinationMode:'sequential-complete',coordinationNotes:'Histórico'}}});
  assert.equal(migrated.schemaVersion,6);
  assert.equal(migrated.methodology.coordinationMode,'sequential-complete');
  assert.equal(migrated.methodology.routePattern,'assisted');
  assert.deepEqual({...migrated.methodology.routeAssignments},{});
});

test('los mapas de 7°, 8° y 9° pueden asignar todos los saberes sin inventar áreas',()=>{
  const context=vm.createContext({result:null});vm.runInContext(`${dataSource}\nresult=PNFT_DATA;`,context);const data=context.result;
  const cases=[['7°','Módulo 1'],['7°','Módulo 2'],['8°','Módulo 1'],['9°','Módulo 1'],['9°','Módulo 2']];
  for(const [level,module] of cases){
    const entries=Object.entries(data[level][module]).flatMap(([area,value])=>(value.saberes||[]).map((saber,index)=>({id:`${level}|${module}|${area}|${index}`,area,name:saber.nombre})));
    const assignments=Object.fromEntries(entries.map((entry,index)=>[entry.id,{role:['direct','prepare','support','pedagogical','continuity'][index%5]}]));
    assert.equal(Object.keys(assignments).length,entries.length,`${level} ${module}`);
    assert.equal(new Set(entries.map(entry=>entry.id)).size,entries.length,`${level} ${module} sin duplicados`);
    const officialAreas=new Set(Object.keys(data[level][module]));
    assert.ok(entries.every(entry=>officialAreas.has(entry.area)),`${level} ${module} sin áreas inventadas`);
  }
  assert.ok(!Object.hasOwn(data['9°']['Módulo 2'],'Computación física y Robótica'),'9° M2 conserva el área ausente');
});

test('el mapa ofrece alternativa tabular, adaptación móvil y exclusión de impresión',()=>{
  assert.match(template,/tabla siguiente contiene la alternativa accesible/i);
  assert.match(runtime,/class="pia-route-table"/);
  assert.match(styles,/@media\(max-width:820px\)\{\.pia-route-map\{grid-template-columns:1fr\}/);
  assert.match(styles,/@media print\{\.pia-route-planner,\.pia-route-modal\{display:none!important\}\}/);
});
