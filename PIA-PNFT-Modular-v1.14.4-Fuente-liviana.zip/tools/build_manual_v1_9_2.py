from pathlib import Path
import re
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs" / "MANUAL_MAPA_Y_CALENDARIO_RUTA_V1.9.2.md"
OUTPUT = ROOT / "docs" / "Manual_de_uso_mapa_y_calendario_PIA_1.9.2.docx"

NAVY = "173B73"
TEAL = "168778"
PURPLE = "7547B8"
LIGHT_BLUE = "EAF0FB"
PALE = "F6F8FC"
BORDER = "D9D9D9"


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_border(cell, color=BORDER, size="6"):
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = qn(f"w:{edge}")
        element = borders.find(tag)
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:color"), color)


def set_cell_margins(cell, top=100, start=110, bottom=100, end=110):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def add_page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run("PIA 1.9.2   ·   ")
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr, fld_char2])


def add_inline(paragraph, text):
    parts = re.split(r"(\*\*.*?\*\*)", text)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            paragraph.add_run(part[2:-2]).bold = True
        elif part:
            paragraph.add_run(part)


def setup_document():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.82)
    section.right_margin = Inches(0.82)

    normal = doc.styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor(32, 43, 58)
    normal.paragraph_format.space_after = Pt(5.5)
    normal.paragraph_format.line_spacing = 1.1

    title = doc.styles["Title"]
    title.font.name = "Aptos Display"
    title.font.size = Pt(29)
    title.font.bold = True
    title.font.color.rgb = RGBColor(0, 0, 0)
    title.paragraph_format.space_after = Pt(12)

    for style_name, size, before, after in (("Heading 1", 19, 16, 7), ("Heading 2", 14, 12, 5), ("Heading 3", 11.5, 9, 4)):
        style = doc.styles[style_name]
        style.font.name = "Aptos Display"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    if "PIA Lead" not in [s.name for s in doc.styles]:
        lead = doc.styles.add_style("PIA Lead", WD_STYLE_TYPE.PARAGRAPH)
        lead.font.name = "Aptos"
        lead.font.size = Pt(12.5)
        lead.font.color.rgb = RGBColor(45, 57, 73)
        lead.paragraph_format.space_after = Pt(12)
        lead.paragraph_format.line_spacing = 1.18

    footer = section.footer.paragraphs[0]
    footer.style = doc.styles["Normal"]
    footer.runs.clear()
    add_page_field(footer)
    for run in footer.runs:
        run.font.size = Pt(8.5)
        run.font.color.rgb = RGBColor(92, 105, 124)
    return doc


def add_cover(doc):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(54)
    r = p.add_run("FORMACIÓN TECNOLÓGICA")
    r.bold = True
    r.font.size = Pt(10)
    r.font.color.rgb = RGBColor(22, 135, 120)

    title = doc.add_paragraph(style="Title")
    title.add_run("Manual de uso del mapa y calendario visual de la ruta curricular")

    subtitle = doc.add_paragraph(style="PIA Lead")
    subtitle.add_run("Guía para docentes nuevos y con experiencia en PIA 1.9.2")

    doc.add_paragraph("III Ciclo · Construcción de una sola ruta de mediación curricular y Proyecto")
    doc.add_paragraph("Versión del manual 1.0 · Setiembre de 2026")

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(34)
    r = p.add_run("Alcance")
    r.bold = True
    r.font.size = Pt(12)
    p = doc.add_paragraph()
    p.add_run("Este manual explica una herramienta de apoyo. PIA organiza y visualiza decisiones declaradas, pero no sustituye el criterio profesional, los documentos oficiales, el diagnóstico del grupo ni las decisiones de las instancias competentes.")

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(20)
    r = p.add_run("Dos formas de utilizarlo")
    r.bold = True
    r.font.size = Pt(12)
    for label, desc in (
        ("Necesito una guía paso a paso", "Recorrido completo para comprender el mapa, ubicar semanas y revisar alertas."),
        ("Quiero auditar mi ruta", "Recorrido breve para revisar coherencia curricular, pedagógica y temporal."),
    ):
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(label + ": ").bold = True
        p.add_run(desc)
    doc.add_page_break()


def add_orientation_page(doc):
    doc.add_heading("Cómo utilizar este manual", level=1)
    p = doc.add_paragraph(style="PIA Lead")
    p.add_run("Lea primero Propósito, Dónde se encuentra y Cómo leer el calendario. Después siga el recorrido que corresponda a su experiencia.")
    table = doc.add_table(rows=1, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    widths = [Inches(1.65), Inches(2.25), Inches(2.7)]
    headers = ["Perfil", "Secciones prioritarias", "Resultado esperado"]
    for i, text in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.width = widths[i]
        set_cell_shading(cell, NAVY)
        cell.text = text
    data = [
        ("Docente nuevo", "Propósito · lectura del mapa · recorrido paso a paso · preguntas de apoyo", "Comprender la lógica de la ruta antes de generar el prompt semestral"),
        ("Docente con experiencia", "Recorrido de auditoría · estados y alertas · lista de comprobación", "Detectar vacíos, relaciones forzadas, discontinuidad o decisiones pendientes"),
        ("Persona asesora", "Qué información utiliza · Proyecto y APD · límites de PIA", "Acompañar sin convertir la visualización en aprobación o certificación"),
    ]
    for row_data in data:
        row = table.add_row()
        for i, text in enumerate(row_data):
            row.cells[i].width = widths[i]
            row.cells[i].text = text
    format_table(table)
    doc.add_heading("Idea central", level=2)
    p = doc.add_paragraph()
    p.add_run("Mapa = dónde se ubican y cómo se articulan los saberes. ").bold = True
    p.add_run("Calendario = cuándo se prevé desarrollar y qué permanece pendiente. Ambos representan una sola ruta y ninguno escribe automáticamente las semanas del planeamiento.")
    doc.add_page_break()


def format_table(table):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    repeat_table_header(table.rows[0])
    for r_index, row in enumerate(table.rows):
        for cell in row.cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            set_cell_border(cell)
            if r_index == 0:
                set_cell_shading(cell, NAVY)
                for paragraph in cell.paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for run in paragraph.runs:
                        run.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
                        run.font.size = Pt(9.2)
            elif r_index % 2 == 0:
                set_cell_shading(cell, PALE)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(2)
                paragraph.paragraph_format.line_spacing = 1.05
                for run in paragraph.runs:
                    run.font.size = Pt(9.0)


def parse_table(lines, index, doc):
    rows = []
    while index < len(lines) and lines[index].strip().startswith("|"):
        values = [cell.strip() for cell in lines[index].strip().strip("|").split("|")]
        if not all(re.fullmatch(r"[-: ]+", value or "-") for value in values):
            rows.append(values)
        index += 1
    if not rows:
        return index
    cols = max(len(row) for row in rows)
    table = doc.add_table(rows=1, cols=cols)
    for col, text in enumerate(rows[0]):
        add_inline(table.rows[0].cells[col].paragraphs[0], text)
    for row_values in rows[1:]:
        row = table.add_row()
        for col in range(cols):
            add_inline(row.cells[col].paragraphs[0], row_values[col] if col < len(row_values) else "")
    format_table(table)
    doc.add_paragraph()
    return index


def add_markdown_body(doc):
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    index = 1
    paragraph_buffer = []

    def flush():
        nonlocal paragraph_buffer
        if paragraph_buffer:
            p = doc.add_paragraph()
            add_inline(p, " ".join(part.strip() for part in paragraph_buffer))
            paragraph_buffer = []

    while index < len(lines):
        line = lines[index].rstrip()
        stripped = line.strip()
        if not stripped:
            flush()
            index += 1
            continue
        if stripped.startswith("|") and index + 1 < len(lines) and lines[index + 1].strip().startswith("|"):
            flush()
            index = parse_table(lines, index, doc)
            continue
        heading = re.match(r"^(#{2,3})\s+(.*)$", stripped)
        if heading:
            flush()
            level = len(heading.group(1)) - 1
            doc.add_heading(heading.group(2), level=level)
            index += 1
            continue
        numbered = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if numbered:
            flush()
            p = doc.add_paragraph(style="List Number")
            add_inline(p, numbered.group(2))
            index += 1
            continue
        bullet = re.match(r"^-\s+(.*)$", stripped)
        if bullet:
            flush()
            content = bullet.group(1)
            if content.startswith("[ ]"):
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Inches(0.2)
                p.paragraph_format.first_line_indent = Inches(-0.2)
                p.add_run("☐ ")
                add_inline(p, content[3:].strip())
            else:
                p = doc.add_paragraph(style="List Bullet")
                add_inline(p, content)
            index += 1
            continue
        paragraph_buffer.append(stripped)
        index += 1
    flush()


def finalize(doc):
    for paragraph in doc.paragraphs:
        if paragraph.style.name.startswith("Heading"):
            paragraph.paragraph_format.keep_with_next = True
        paragraph.paragraph_format.widow_control = True
    props = doc.core_properties
    props.title = "Manual de uso del mapa y calendario visual de la ruta curricular"
    props.subject = "PIA 1.9.2 para III Ciclo"
    props.author = "PIA PNFT"
    props.keywords = "PIA, PNFT, mapa curricular, calendario visual, Proyecto, Pensamiento de Diseño"
    doc.save(OUTPUT)


def main():
    doc = setup_document()
    add_cover(doc)
    add_orientation_page(doc)
    add_markdown_body(doc)
    finalize(doc)
    print(OUTPUT)


if __name__ == "__main__":
    main()
