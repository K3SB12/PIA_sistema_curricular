# Publicar la revisión correcta de PIA 1.14.4

Esta entrega se reconoce por el texto visible **PIA 1.14.4 · Revisión 2026-09-27** y por la huella SHA-256 `405b32be33b778ea2b55f0be57d16160a28cb18a013e90cbaf9df28de8258736`.

1. Descargue y extraiga el ZIP de esta entrega.
2. Localice el archivo `index.html` situado en la raíz de la carpeta extraída.
3. En GitHub, confirme en **Settings → Pages** cuál carpeta publica el sitio: raíz `/` o `/docs`.
4. Sustituya el `index.html` de esa ubicación por el archivo recién extraído. No suba un `index.html` conservado en otra carpeta.
5. Confirme el cambio y espere la actualización de GitHub Pages.
6. Abra el sitio con una recarga completa. Debe verse **PIA 1.14.4 · Revisión 2026-09-27** en la portada y el encabezado.

El ZIP no debe utilizarse como página web. Es un paquete de respaldo que contiene código fuente, pruebas, documentación y tres copias idénticas del HTML ensamblado. Para GitHub Pages basta con publicar el `index.html` extraído en la carpeta configurada.

## Cambios distintivos de esta revisión

- Reflexión docente independiente en cada semana y exportación dentro de esa semana.
- Reflexión general del período identificada como opcional.
- Mejor contraste del tema oscuro en contenido pedagógico y controles.
- Circuito de propuestas IA/JSON, mapa, calendario y exportación selectiva de semanas conservados.
- **237 pruebas aprobadas y 0 fallos**.
