import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = path => readFile(join(root, path), 'utf8');

test('cada semana ofrece cuatro campos de reflexión docente persistentes', async () => {
  const [view, operations, initialization] = await Promise.all([
    read('src/ui/week-view.js'),
    read('src/domain/planning/week-operations.js'),
    read('src/application/initialization.js'),
  ]);
  for (const field of ['queFunciono', 'queNoFunciono', 'queMejorar', 'observaciones']) {
    assert.match(view, new RegExp(`data-pia-week-reflection-field="${field}"`));
    assert.match(operations, new RegExp(field));
    assert.match(initialization, new RegExp(field));
  }
  assert.match(view, /actualizarReflexionSemana/);
  assert.match(operations, /PIAEnhancements\.markDirty/);
});

test('Word y PDF ubican la reflexión dentro de cada semana seleccionada', async () => {
  const exporter = await read('src/infrastructure/export/pdf-exporter.js');
  assert.match(exporter, /function reflexionSemanaWord\(semana\)/);
  assert.match(exporter, /function reflexionSemanaPDF\(semana\)/);
  assert.match(exporter, /REFLEXIÓN DOCENTE DE ESTA SEMANA/);
  assert.match(exporter, /Reflexión general del período \(opcional\)/);
  assert.match(exporter, /REFLEXIÓN GENERAL DEL PERÍODO \(OPCIONAL\)/);
});

test('el prompt semanal usa la reflexión real y prohíbe inventar resultados', async () => {
  const prompt = await read('src/prompts/weekly-prompt.js');
  assert.match(prompt, /REFLEXIÓN DOCENTE YA REGISTRADA/);
  assert.match(prompt, /no invente resultados de aplicación/i);
  assert.match(prompt, /promptConReflexion/);
});

test('la revisión publicable es visible y el tema oscuro cubre contenido pedagógico', async () => {
  const [header, welcome, theme] = await Promise.all([
    read('src/templates/header.html'),
    read('src/templates/body-open.html'),
    read('src/styles/08-enhancements.css'),
  ]);
  assert.match(header, /PIA 1\.14\.4/);
  assert.match(header, /Revisión 2026-09-27/);
  assert.match(welcome, /archivo para publicación/);
  for (const selector of ['.semana-item', '.saber-contenido', '.pia-week-reflection', '.indicador-logro', ':focus-visible']) {
    assert.ok(theme.includes(selector), `Falta cobertura oscura para ${selector}`);
  }
  assert.match(theme, /#c4d0e2/);
});
