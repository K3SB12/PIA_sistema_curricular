# Informe de validación — PIA 1.14.4

## Alcance

Esta entrega cierra los ajustes del constructor **Ruta curricular del semestre** de III Ciclo y su continuidad hacia el planeamiento. Se verifican el intercambio estructurado con IA externa, persistencia del estado, controles curriculares y temporales, accesibilidad del modal, selección inicial de nivel y tema claro/oscuro.

## Cambios verificados

- Cada propuesta incluye una vista conceptual preliminar por nodos y fases APD antes de aplicar la ruta completa.
- Las métricas distinguen Solo lecciones, Solo Proyecto y Lecciones + Proyecto; se calcula además presencia total en cada momento para evitar interpretar 0 % Solo Proyecto como ausencia del Proyecto.
- La respuesta validada puede descargarse localmente como `.md` y el bloque técnico validado como `.json`.
- El primer clic conserva el nodo del DOM; el doble clic navega a la fila editable sin perder el evento.
- Los bloques del grafo pueden reposicionarse de forma efímera y esas coordenadas no se persisten.
- El prompt comparativo puede señalar oportunidades orientadoras de Trabajo cotidiano/Tarea y reserva la recomendación de instrumentos para la mediación semanal.
- El contrato prohíbe estirar `weekStart/weekEnd` para esconder momentos discontinuos.
- I Ciclo inicia en 1.º, II Ciclo en 4.º y III Ciclo en 7.º.
- Tema claro/oscuro persistente mediante `localStorage`.
- Paso 3 denominado **Propuesta de la IA**.
- Entrada equivalente por Markdown o archivo `.json` local.
- Contrato `pia-route-options-v3`, huella de selección, validación de identificadores, semanas y cobertura de saberes.
- Protección de Empatizar, Definir, Idear, Prototipar y Probar/Evaluar cuando el Proyecto está activado.
- Una propuesta inválida no reemplaza la ruta vigente; aplicar una propuesta requiere acción explícita.
- Exportación de `Consulta-para-IA.md`, `Ruta-curricular.json` y mapa PNG.
- Persistencia de respuesta, propuesta validada, opción seleccionada, distribución de fases y prompt de estrategias.
- Panel **Continuar con el planeamiento** con proyección semestral y estrategias semana a semana.
- Prompt semanal con Inicio, Desarrollo, Cierre, evidencia, DUA/accesibilidad, diagnóstico declarado, Trabajo cotidiano/tarea, instrumento y ajuste/alerta.
- Doble clic en un saber del mapa para ir a su fila editable y acción **Volver al mapa**.
- El constructor no se cierra al pulsar accidentalmente fuera del panel.
- Barra inferior sin margen negativo y sin superposición sobre la auditoría.

## Validación visual de la barra

Se ejecutó una prueba de geometría con los estilos reales del modal en 1440×900, 1024×768 y 390×844, simulando zoom de 100 %, 150 % y 200 %. En todos los casos la intersección entre el final de la auditoría y el inicio de la barra fue **0 px**. En 390 px las cuatro acciones se apilan en una columna. El popover contextual se oculta cuando el constructor está abierto.

## Validación automatizada

La batería completa contiene **230 pruebas**. La entrega debe considerarse cerrada únicamente con **230 aprobadas y 0 fallos** en `npm test`.

## Integridad de compilación

Las tres salidas generadas son byte a byte equivalentes:

- `index.html`
- `dist/web/index.html`
- `dist/portable/index.html`

SHA-256 común: `139a294bf7d56e4b720f291cdb68641785f92b4a9747d7a8e7afc0415670c281`

## Criterio de liberación

La versión 1.14.4 conserva el currículo protegido y el esquema de planeamiento existente. Las nuevas funciones organizan, validan, representan y persisten decisiones; no asignan logro al estudiantado, no fijan automáticamente momentos evaluativos y no reemplazan el criterio profesional docente.


## Corrección visual 1.14.4

- La barra de acciones del constructor conserva comportamiento visible en escritorio sin cubrir el contenido de la auditoría.
- En tableta y celular la barra vuelve al flujo normal del modal y organiza los botones en filas, evitando superposición.
- El botón global de ayuda permanece oculto mientras el constructor está abierto.
- Los controles mantienen margen de desplazamiento para navegación con teclado y zoom.


## Cierre de segunda iteración

Se añadieron seis regresiones específicas para: diferenciación estructural de propuestas, matriz completa de comparación, edición detallada por saber, separación táctil entre desplazamiento y movimiento de nodos, explicitación de producto/recursos/puentes/evidencias y contraste de tema oscuro.
