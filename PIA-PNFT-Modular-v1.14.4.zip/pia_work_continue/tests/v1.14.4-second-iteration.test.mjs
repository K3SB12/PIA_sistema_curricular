import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [runtime,template,styles,spec,agents]=await Promise.all([
  read('src/application/enhancements.js'),read('src/templates/enhancements.html'),read('src/styles/08-enhancements.css'),read('SPEC.md'),read('AGENTS.md')
]);

test('las propuestas comparadas deben diferenciarse estructuralmente y no inflar Proyecto',()=>{
  assert.match(runtime,/alternativas deben ser estructuralmente distintas/i);
  assert.match(runtime,/No aumente artificialmente la presencia del Proyecto/i);
  assert.match(runtime,/misma distribución de saberes, fases y semanas/i);
  assert.match(spec,/estructuralmente distintas/i);
});

test('cada propuesta expone una matriz completa antes de aplicarse',()=>{
  assert.match(runtime,/function routeProposalMatrixHtml/);
  assert.match(runtime,/Ver matriz completa de esta propuesta/);
  for(const label of ['Saber e indicador','Ubicación','Fase APD','Semana(s)','Agrupación','Evidencia','TC / tarea','Contexto o puente']) assert.match(runtime,new RegExp(label.replace(/[()]/g,'\\$&')));
});

test('la tabla editable conserva todos los campos de la propuesta seleccionada',()=>{
  for(const attr of ['data-pia-route-group','data-pia-route-evidence','data-pia-route-evaluation','data-pia-route-note']) assert.match(runtime,new RegExp(attr));
  assert.match(runtime,/Trabajo cotidiano/);
  assert.match(runtime,/Tarea/);
});

test('tableta y celular separan desplazar mapa de mover bloques',()=>{
  for(const id of ['piaRoutePanMode','piaRouteMoveMode','piaRouteInteractionStatus']) assert.match(template,new RegExp(`id="${id}"`));
  assert.match(runtime,/function setRouteInteractionMode/);
  assert.match(runtime,/pointer: coarse/);
  assert.match(runtime,/routeInteractionMode!=='move'/);
  assert.match(styles,/data-interaction-mode="pan"/);
  assert.match(styles,/data-interaction-mode="move"/);
  assert.match(agents,/modos separados/);
});

test('el prompt hace visibles producto, recursos, puentes y evidencias',()=>{
  for(const phrase of ['estrategia de producto/solución','recursos o restricciones relevantes','puentes pedagógicos','evidencias']) assert.match(runtime,new RegExp(phrase,'i'));
});

test('el tema oscuro cubre matriz, porcentajes y continuidad',()=>{
  assert.match(styles,/body\.pia-dark \.pia-route-proposal-matrix/);
  assert.match(styles,/body\.pia-dark \.pia-route-distribution span/);
  assert.match(styles,/body\.pia-dark \.pia-route-continue-grid article/);
});
