# Publicar PIA 1.15.0 sin confundir versiones

1. Verifique que el ZIP se llame `PIA-PNFT-Modular-v1.15.0.zip`.
2. Extraiga el ZIP en una carpeta nueva; no mezcle sus archivos con una versión anterior.
3. Para probar localmente, abra una terminal en la carpeta extraída y ejecute `python -m http.server 4173`.
4. Abra `http://localhost:4173/` y confirme que el recorrido muestre **PIA 1.15.0**.
5. En GitHub Pages cargue los archivos extraídos, incluido `index.html`; no intente cargar el ZIP como página.
6. Si reemplaza una publicación anterior, elimine o sustituya sus archivos mediante el flujo normal del repositorio y espere la finalización del despliegue.
7. Confirme la versión publicada en una ventana privada para evitar que la caché muestre un HTML anterior.

La huella SHA-256 del HTML certificado se encuentra en `CURRENT.sha256` y en el informe de validación de esta versión.
