import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = path => readFile(join(root, path), 'utf8');

test('la portada incorpora la identidad oficial y el conjunto PNFT sin textos duplicados', async () => {
  const [template, build] = await Promise.all([
    read('src/templates/body-open.html'),
    read('scripts/build.mjs'),
  ]);
  for (const token of ['__PIA_MEP_OFFICIAL_LOGO__', '__PIA_OFFICIAL_LOGO__', '__PIA_PNFT_ICON_CLUSTER__']) {
    assert.ok(template.includes(token), `Falta el recurso ${token} en la portada`);
    assert.ok(build.includes(token), `Falta ensamblar ${token}`);
  }
  assert.match(template, /alt="Ministerio de Educación Pública, Gobierno de Costa Rica"/);
  assert.match(template, /alt="PIA, Planificación Integral y Ágil"/);
  assert.match(template, /alt="Iconos de las áreas de conocimiento del Programa Nacional de Formación Tecnológica"/);
  assert.doesNotMatch(template, /src="__PIA_PNFT_OFFICIAL_LOGO__"/);
});

test('las tres decisiones de entrada son botones completos, independientes y sin secuencia artificial', async () => {
  const template = await read('src/templates/body-open.html');
  const actions = [
    ['piaOpenMethodologyGame', 'Explorar un ejemplo de planeamiento'],
    ['piaStartPlanning', 'Comenzar mi planeamiento'],
    ['piaWelcomeLoad', 'Continuar un planeamiento'],
  ];
  for (const [id, label] of actions) {
    assert.match(template, new RegExp(`<button[^>]+id="${id}"[\\s\\S]*?<strong>${label}</strong>[\\s\\S]*?</button>`));
  }
  assert.doesNotMatch(template, />\s*Elegir\s*</i);
  assert.doesNotMatch(template, /pia-welcome-action[^>]*>[\s\S]*?[→➜➝]/);
});

test('el tema usa variables semánticas, conserva logotipos y refuerza mapa y foco', async () => {
  const css = await read('src/styles/08-enhancements.css');
  for (const token of ['--pia-page-bg', '--pia-surface', '--pia-text', '--pia-text-muted', '--pia-border', '--pia-focus']) {
    assert.ok(css.includes(token), `Falta la variable semántica ${token}`);
  }
  assert.match(css, /body\.pia-dark\{[\s\S]*?color-scheme:dark/);
  assert.match(css, /\.pia-welcome-program h2\{[\s\S]*?border-bottom:4px solid/);
  assert.match(css, /\.pia-welcome-action:focus-visible/);
  assert.match(css, /body\.pia-dark \.pia-route-graph-node\{[\s\S]*?box-shadow/);
  assert.match(css, /pia-welcome-mep-logo[\s\S]*?filter:none!important/);
  assert.doesNotMatch(css, /filter\s*:\s*invert\s*\(/i);
});

test('el ensamblado sustituye los recursos oficiales y mantiene los controles funcionales', async () => {
  const html = await read('index.html');
  assert.doesNotMatch(html, /__PIA_(?:MEP|PNFT)?_?OFFICIAL_LOGO__/);
  assert.match(html, /class="pia-welcome-mep-logo" src="data:image\/jpeg;base64,/);
  assert.match(html, /class="pia-welcome-pia-logo" src="data:image\/jpeg;base64,/);
  assert.match(html, /class="pia-welcome-pnft-logo" src="data:image\/png;base64,/);
  for (const id of ['piaOpenMethodologyGame', 'piaStartPlanning', 'piaWelcomeLoad', 'piaThemeToggleWelcome']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
});

test('el tema oscuro cubre las superficies residuales reportadas por docentes', async () => {
  const css = await read('src/styles/08-enhancements.css');
  for (const selector of [
    '.pia-logo-box', '#asignatura[readonly]', '.pia-planning-context,.pia-curricular-reference',
    '.pia-curricular-framework,.pia-resource-inventory', '.pia-framework-source,.pia-framework-card',
    '.pia-diagnosis-entry,.pia-project-card', '.pia-switch', '.pia-evaluation-summary,.pia-evaluation-guidance',
    '.pia-route-explanation', '.pia-route-steps button', '.pia-route-input-audit-grid article',
    '.pia-route-layers', '.semanas-controls',
    '.pia-planning-context,.pia-curricular-reference', '.pia-reference-body',
    '.pia-reference-card,.pia-reference-column,.pia-reference-week-item', '.pia-context-enable',
  ]) assert.ok(css.includes(selector), `Falta cobertura oscura para ${selector}`);
  assert.match(css, /Verificación visual 2026-09-29/);
});

test('la paleta oscura esencial alcanza contraste WCAG AA para texto normal', () => {
  const luminance = hex => {
    const rgb = hex.match(/[a-f\d]{2}/gi).map(value => parseInt(value, 16) / 255)
      .map(value => value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4);
    return .2126 * rgb[0] + .7152 * rgb[1] + .0722 * rgb[2];
  };
  const ratio = (foreground, background) => {
    const values = [luminance(foreground), luminance(background)].sort((a, b) => b - a);
    return (values[0] + .05) / (values[1] + .05);
  };
  const pairs = [
    ['edf3fc', '141d2d'], ['c4d0e2', '141d2d'], ['e4d8fb', '1a263a'],
    ['d7fff8', '153b3a'], ['e7f2ff', '192b46'], ['71e4ad', '141d2d'],
    ['dce6f5', '29364c'], ['ffe5a1', '342b16'],
  ];
  for (const [foreground, background] of pairs) {
    assert.ok(ratio(foreground, background) >= 4.5, `${foreground} sobre ${background} no alcanza 4.5:1`);
  }
});
