import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [coreSource,runtime,dialogs,enhancementsTemplate,exporter,spec]=await Promise.all([
  read('src/domain/projection/projection-core.js'),
  read('src/application/enhancements.js'),
  read('src/templates/dialogs.html'),
  read('src/templates/enhancements.html'),
  read('src/infrastructure/export/pdf-exporter.js'),
  read('SPEC.md'),
]);

test('la migración conserva posiciones visuales acotadas y la propuesta elegida',()=>{
  const context={};vm.createContext(context);vm.runInContext(`${coreSource};this.PIAProjectionCoreResult=PIAProjectionCore;`,context);
  const migrated=context.PIAProjectionCoreResult.migrate({pia:{methodology:{routeAssignments:{s1:{role:'pedagogical'}}},routeMap:{positions:{'concept-s1':{x:120,y:-45},extreme:{x:99999,y:-99999}},aiExchange:{selectedOptionId:'opcion-a',selectedOptionSnapshot:{id:'opcion-a'},revisionHistory:[{optionId:'opcion-a',title:'A',option:{id:'opcion-a'}}]}}}});
  assert.deepEqual({...migrated.routeMap.positions['concept-s1']},{x:120,y:-45});
  assert.deepEqual({...migrated.routeMap.positions.extreme},{x:5000,y:-5000});
  assert.equal(migrated.routeMap.aiExchange.selectedOptionSnapshot.id,'opcion-a');
  assert.equal(migrated.routeMap.aiExchange.revisionHistory.length,1);
});

test('el contrato de IA admite archivo o pegado y revisiones trazables',()=>{
  assert.match(runtime,/pia-route-options-v4/);
  assert.match(runtime,/selectedOptionSnapshot/);
  assert.match(runtime,/parentOptionId/);
  assert.match(runtime,/revisionOf/);
  assert.match(runtime,/Descargar propuesta elegida|downloadSelectedRouteProposal/);
  assert.match(enhancementsTemplate,/accept="application\/json,text\/plain,text\/markdown,\.json,\.md,\.txt"/);
});

test('Word y PDF permiten todo, rango o semanas específicas sin renumerarlas',()=>{
  for(const id of ['exportarAlcanceTodas','exportarAlcanceRango','exportarAlcancePersonalizado','exportarSemanaDesde','exportarSemanaHasta','exportarSemanasPersonalizadas'])assert.match(dialogs,new RegExp(`id="${id}"`));
  assert.match(exporter,/function obtenerSemanasSeleccionadasParaExportar/);
  assert.match(exporter,/semanasSeleccionadas\.forEach\(\(\{semana,index\}/);
  assert.match(exporter,/Semana \$\{index \+ 1\}/);
  assert.match(exporter,/Saberes conceptuales \(saber\)/);
  assert.match(exporter,/Saberes procedimentales \(saber hacer\)/);
  assert.match(exporter,/Saberes actitudinales \(saber ser\)/);
  assert.match(spec,/rango continuo o semanas específicas/i);
});
