import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [runtime,semester,weekly,general,coreSource,agents,spec]=await Promise.all([
  read('src/application/enhancements.js'),
  read('src/prompts/semester-projection-prompt.js'),
  read('src/prompts/weekly-prompt.js'),
  read('src/prompts/general-prompt.js'),
  read('src/domain/projection/projection-core.js'),
  read('AGENTS.md'),
  read('SPEC.md')
]);

test('los cuatro prompts respetan el orden pedagógico acordado',()=>{
  const combined=[runtime,semester,weekly,general].join('\n');
  for(const expected of [
    'currículo oficial → análisis del verbo',
    'mediación → evidencia',
    'dos indicadores de evaluación alternativos',
    'decisión docente',
    'comprobación retrospectiva del alineamiento',
    'instrumento'
  ])assert.match(combined,new RegExp(expected,'i'));
  assert.match(runtime,/Indicador sugerido A[\s\S]*Indicador sugerido B[\s\S]*Decisión docente[\s\S]*Alineamiento \/ ajuste/);
  assert.match(semester,/sugerencia A de indicador de evaluación[\s\S]*sugerencia B[\s\S]*decisión docente/i);
});

test('las dos propuestas son alternativas editables y no obligaciones simultáneas',()=>{
  for(const source of [runtime,semester,weekly,general]){
    assert.match(source,/alternativ/i);
    assert.match(source,/dos obligaciones simultáneas/i);
    assert.match(source,/selecciona?r? una|seleccionar una/i);
    assert.match(source,/ajust/i);
    assert.match(source,/descart/i);
  }
});

test('una diferencia de alineamiento exige revisión docente sin reescritura silenciosa',()=>{
  for(const source of [runtime,semester,weekly,general]){
    assert.match(source,/Requiere revisión docente/);
    assert.match(source,/(?:no (?:cambie|modifique)|sin modificar) silenciosamente/i);
  }
});

test('los prompts dependientes de la ruta registran y comparan una huella semántica',()=>{
  for(const expected of ['routeSemanticFingerprint','routePromptSourceFingerprint','routePromptSyncStatus','associatePromptWithCurrentRoute','alignment-v1'])assert.match(runtime,new RegExp(expected));
  assert.match(runtime,/Prompt sincronizado con la ruta actual/);
  assert.match(runtime,/La ruta curricular o sus datos de contexto cambiaron/);
  assert.match(runtime,/no contiene una huella que permita comprobar/);
  assert.match(runtime,/Actualizar con la ruta actual/);
  assert.match(runtime,/Ver o conservar prompt anterior/);
  assert.match(runtime,/if\(updated\)associatePromptWithCurrentRoute\('routeStrategies'\)/);
  assert.match(runtime,/if\(updated&&\$\('ciclo'\)\?\.value==='III Ciclo'\)associatePromptWithCurrentRoute\('semester'\)/);
});

test('cancelar una actualización conserva el texto docente',()=>{
  assert.match(runtime,/Puede cancelar para conservarlo/);
  assert.match(runtime,/editor\.value = previous; setPromptValue\(state\.aiPrompts, descriptor, previous\)[\s\S]*return false/);
  assert.match(runtime,/updated=applyGeneratedUpdate/);
});

test('la huella semántica excluye presentación visual y conserva decisiones pedagógicas',()=>{
  const semantic=runtime.slice(runtime.indexOf('function routeSemanticFingerprint'),runtime.indexOf('function routePromptSourceFingerprint'));
  for(const expected of ['assignments','groups','connections','phaseSchedule','weekStart','weekEnd','evidence'])assert.match(semantic,new RegExp(expected));
  for(const excluded of ['positions','zoom','view','theme'])assert.doesNotMatch(semantic,new RegExp(excluded));
});

test('la migración v6 conserva huellas nuevas y abre archivos históricos',()=>{
  const context=vm.createContext({result:null,encodeURIComponent});
  vm.runInContext(`${coreSource}\nresult=PIAProjectionCore;`,context);
  const core=context.result;
  const historical=core.migrate({pia:{aiPrompts:{semester:'Edición docente anterior'}}});
  assert.equal(historical.aiPrompts.semester,'Edición docente anterior');
  assert.equal(historical.aiPromptMeta.sourceRouteFingerprint.semester,'');
  assert.equal(historical.routeMap.semanticFingerprint,'');
  const current=core.migrate({pia:{routeMap:{semanticFingerprint:'pia-route-abc'},aiPromptMeta:{sourceRouteFingerprint:{semester:'pia-source-uno',routeStrategies:'pia-source-dos'}}}});
  assert.equal(current.routeMap.semanticFingerprint,'pia-route-abc');
  assert.deepEqual(structuredClone(current.aiPromptMeta.sourceRouteFingerprint),{semester:'pia-source-uno',routeStrategies:'pia-source-dos'});
});

test('los contratos documentan la corrección sin cambiar el organizador comparativo',()=>{
  assert.match(agents,/Los dos indicadores de evaluación son alternativas para comparar/);
  assert.match(agents,/Posiciones de nodos, zoom, vista y tema son metadatos visuales/);
  assert.match(spec,/Solicitar propuestas para organizar el módulo[\s\S]*no se convierte en un generador detallado/i);
  assert.match(spec,/schemaVersion: 6/);
});
